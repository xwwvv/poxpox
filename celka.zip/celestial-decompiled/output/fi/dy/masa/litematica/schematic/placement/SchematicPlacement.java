/*
 * Decompiled with CFR 0.152.
 */
package fi.dy.masa.litematica.schematic.placement;

import fi.dy.masa.litematica.schematic.placement.SchematicPlacementUnloaded;
import protected.rpa;
import protected.rqd_0;

public class SchematicPlacement
extends SchematicPlacementUnloaded {
    private rqd_0 rotation;
    private rpa mirror;

    public rpa getMirror() {
        return this.mirror;
    }

    public rqd_0 getRotation() {
        return this.rotation;
    }
}

