/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
package fi.dy.masa.litematica.schematic.placement;

import java.io.File;
import javax.annotation.Nullable;
import protected.rfH;

public class SchematicPlacementUnloaded {
    protected String name = "?";
    @Nullable
    protected File schematicFile;
    protected rfH origin = rfH.protected;

    public String getName() {
        return this.name;
    }

    @Nullable
    public File getSchematicFile() {
        return this.schematicFile;
    }

    public rfH getOrigin() {
        return this.origin;
    }
}

