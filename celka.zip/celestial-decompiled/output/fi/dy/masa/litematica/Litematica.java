/*
 * Decompiled with CFR 0.152.
 */
package fi.dy.masa.litematica;

public class Litematica {
}

