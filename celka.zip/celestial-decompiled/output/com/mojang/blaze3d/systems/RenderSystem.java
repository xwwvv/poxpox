/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Queues
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 *  org.lwjgl.glfw.GLFW
 *  org.lwjgl.glfw.GLFWErrorCallbackI
 */
package com.mojang.blaze3d.systems;

import com.google.common.collect.Queues;
import com.mojang.blaze3d.platform.GLX;
import java.nio.ByteBuffer;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.function.Consumer;
import java.util.function.IntSupplier;
import java.util.function.LongSupplier;
import java.util.function.Supplier;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.glfw.GLFWErrorCallbackI;
import protected.ma_1;
import protected.md_1;
import protected.mk_1;
import protected.mt_1;
import protected.oj_2;
import protected.op_2;
import protected.qw_1;
import protected.qy_1;
import protected.rjV;
import protected.rje;
import protected.vw_0;
import protected.yb_1;

public class RenderSystem {
    private static final Logger LOGGER = LogManager.getLogger();
    private static final ConcurrentLinkedQueue<oj_2> recordingQueue = Queues.newConcurrentLinkedQueue();
    private static final yb_1 RENDER_THREAD_TESSELATOR = new yb_1();
    public static final float DEFAULTALPHACUTOFF = 0.1f;
    private static final int MINIMUM_ATLAS_TEXTURE_SIZE = 1024;
    private static boolean isReplayingQueue;
    private static Thread gameThread;
    private static Thread renderThread;
    private static int MAX_SUPPORTED_TEXTURE_SIZE;
    private static boolean isInInit;
    private static double lastDrawTime;

    static {
        MAX_SUPPORTED_TEXTURE_SIZE = -1;
        lastDrawTime = Double.MIN_VALUE;
    }

    public static void clear(int n2, boolean bl2) {
        RenderSystem.assertThread(RenderSystem::isOnGameThreadOrInit);
        mt_1.class(n2, bl2);
    }

    public static void getString(int n2, Consumer<String> consumer) {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        consumer.accept(mt_1.instanceof(n2));
    }

    public static void initRenderThread() {
        if (renderThread != null || gameThread == Thread.currentThread()) {
            throw new IllegalStateException("Could not initialize render thread");
        }
        renderThread = Thread.currentThread();
    }

    public static void initGameThread(boolean bl2) {
        boolean bl3;
        boolean bl4 = bl3 = renderThread == Thread.currentThread();
        if (gameThread != null || renderThread == null || bl3 == bl2) {
            throw new IllegalStateException("Could not initialize tick thread");
        }
        gameThread = Thread.currentThread();
    }

    public static void beginInitialization() {
        isInInit = true;
    }

    public static void finishInitialization() {
        isInInit = false;
        if (!recordingQueue.isEmpty()) {
            RenderSystem.replayQueue();
        }
        if (!recordingQueue.isEmpty()) {
            throw new IllegalStateException("Recorded to render queue during initialization");
        }
    }

    @Deprecated
    public static void disableRescaleNormal() {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.strictfp();
    }

    @Deprecated
    public static void enableRescaleNormal() {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.const();
    }

    public static String getBackendDescription() {
        RenderSystem.assertThread(RenderSystem::isInInitPhase);
        return String.format("LWJGL version %s", GLX._getLWJGLVersion());
    }

    @Deprecated
    public static void fogMode(md_1 md_12) {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.package(md_12.param);
    }

    @Deprecated
    public static void fogMode(int n2) {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.package(n2);
    }

    @Deprecated
    public static void ortho(double d, double d2, double d3, double d4, double d5, double d6) {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.class(d, d2, d3, d4, d5, d6);
    }

    @Deprecated
    public static void fogDensity(float f2) {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.class(f2);
    }

    @Deprecated
    public static void runAsFancy(Runnable runnable) {
        boolean bl2 = qy_1.d();
        if (!bl2) {
            runnable.run();
        } else {
            qw_1 qw_12 = (qw_1)qy_1.instanceof().class[20];
            vw_0 vw_02 = qw_12.case;
            qw_12.case = vw_0.FANCY;
            runnable.run();
            qw_12.case = vw_02;
        }
    }

    public static void flipFrame(long l2) {
        GLFW.glfwPollEvents();
        RenderSystem.replayQueue();
        yb_1.class().byte().native();
        GLFW.glfwSwapBuffers((long)l2);
        GLFW.glfwPollEvents();
    }

    @Deprecated
    public static void fogEnd(float f2) {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.byte(f2);
    }

    public static void blendColor(float f2, float f3, float f4, float f5) {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.class(f2, f3, f4, f5);
    }

    @Deprecated
    public static void fogStart(float f2) {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.break(f2);
    }

    @Deprecated
    public static void fogi(int n2, int n3) {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.native(n2, n3);
    }

    public static void logicOp(ma_1 ma_12) {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.int(ma_12.opcode);
    }

    public static void stencilOp(int n2, int n3, int n4) {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.throws(n2, n3, n4);
    }

    @Deprecated
    public static void alphaFunc(int n2, float f2) {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.class(n2, f2);
    }

    public static void clearDepth(double d) {
        RenderSystem.assertThread(RenderSystem::isOnGameThreadOrInit);
        mt_1.class(d);
    }

    public static void depthFunc(int n2) {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.break(n2);
    }

    public static void clearColor(float f2, float f3, float f4, float f5) {
        RenderSystem.assertThread(RenderSystem::isOnGameThreadOrInit);
        mt_1.break(f2, f3, f4, f5);
    }

    @Deprecated
    public static void scaled(double d, double d2, double d3) {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.class(d, d2, d3);
    }

    public static void drawArrays(int n2, int n3, int n4) {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.case(n2, n3, n4);
    }

    public static void pixelStore(int n2, int n3) {
        RenderSystem.assertThread(RenderSystem::isOnGameThreadOrInit);
        mt_1.final(n2, n3);
    }

    public static void readPixels(int n2, int n3, int n4, int n5, int n6, int n7, ByteBuffer byteBuffer) {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.class(n2, n3, n4, n5, n6, n7, byteBuffer);
    }

    public static void glUniform1(int n2, FloatBuffer floatBuffer) {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.break(n2, floatBuffer);
    }

    public static void glUniform1(int n2, IntBuffer intBuffer) {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.class(n2, intBuffer);
    }

    public static void glUniform2(int n2, FloatBuffer floatBuffer) {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.byte(n2, floatBuffer);
    }

    public static void glUniform2(int n2, IntBuffer intBuffer) {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.break(n2, intBuffer);
    }

    public static void glUniform3(int n2, IntBuffer intBuffer) {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.byte(n2, intBuffer);
    }

    public static void glUniform3(int n2, FloatBuffer floatBuffer) {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.protected(n2, floatBuffer);
    }

    public static void glUniform4(int n2, FloatBuffer floatBuffer) {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.throws(n2, floatBuffer);
    }

    public static void glUniform4(int n2, IntBuffer intBuffer) {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.protected(n2, intBuffer);
    }

    @Deprecated
    public static void color4f(float f2, float f3, float f4, float f5) {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.protected(f2, f3, f4, f5);
    }

    @Deprecated
    public static void shadeModel(int n2) {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.this(n2);
    }

    public static void blendFunc(int n2, int n3) {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.break(n2, n3);
    }

    public static void blendFunc(op_2 op_22, mk_1 mk_12) {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.break(op_22.param, mk_12.param);
    }

    public static void enableTexture() {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.import();
    }

    public static void disableTexture() {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.short();
    }

    public static void enableBlend() {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.package();
    }

    public static void defaultBlendFunc() {
        RenderSystem.blendFuncSeparate(op_2.SRC_ALPHA, mk_1.ONE_MINUS_SRC_ALPHA, op_2.ONE, mk_1.ZERO);
    }

    public static void disableBlend() {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.final();
    }

    public static void enableDepthTest() {
        RenderSystem.assertThread(RenderSystem::isOnGameThreadOrInit);
        mt_1.volatile();
    }

    public static void enableScissor(int n2, int n3, int n4, int n5) {
        RenderSystem.assertThread(RenderSystem::isOnGameThreadOrInit);
        mt_1.extends();
        mt_1.class(n2, n3, n4, n5);
    }

    @Deprecated
    public static void enableAlphaTest() {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.throws();
    }

    @Deprecated
    public static void disableAlphaTest() {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.protected();
    }

    public static void disableScissor() {
        RenderSystem.assertThread(RenderSystem::isOnGameThreadOrInit);
        mt_1.finally();
    }

    public static void blendFuncSeparate(int n2, int n3, int n4, int n5) {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.break(n2, n3, n4, n5);
    }

    public static void blendFuncSeparate(op_2 op_22, mk_1 mk_12, op_2 op_23, mk_1 mk_13) {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.break(op_22.param, mk_12.param, op_23.param, mk_13.param);
    }

    public static void enableCull() {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.throw();
    }

    @Deprecated
    public static void popMatrix() {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.for();
    }

    @Deprecated
    public static void color3f(float f2, float f3, float f4) {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.protected(f2, f3, f4, 1.0f);
    }

    @Deprecated
    public static void disableFog() {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.instanceof();
    }

    public static void depthMask(boolean bl2) {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.class(bl2);
    }

    public static void viewport(int n2, int n3, int n4, int n5) {
        RenderSystem.assertThread(RenderSystem::isOnGameThreadOrInit);
        mt_1.protected(n2, n3, n4, n5);
    }

    @Deprecated
    public static void pushMatrix() {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.transient();
    }

    public static void lineWidth(float f2) {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.protected(f2);
    }

    @Deprecated
    public static void translated(double d, double d2, double d3) {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.break(d, d2, d3);
    }

    @Deprecated
    public static void translatef(float f2, float f3, float f4) {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.byte(f2, f3, f4);
    }

    @Deprecated
    public static void normal3f(float f2, float f3, float f4) {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.class(f2, f3, f4);
    }

    @Deprecated
    public static void enableFog() {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.try();
    }

    @Deprecated
    public static void multMatrix(rjV rjV2) {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.class(rjV2);
    }

    @Deprecated
    public static void rotatef(float f2, float f3, float f4, float f5) {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.byte(f2, f3, f4, f5);
    }

    @Deprecated
    public static void scalef(float f2, float f3, float f4) {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.break(f2, f3, f4);
    }

    public static void colorMask(boolean bl2, boolean bl3, boolean bl4, boolean bl5) {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.class(bl2, bl3, bl4, bl5);
    }

    @Deprecated
    public static void fog(int n2, float f2, float f3, float f4, float f5) {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.class(n2, new float[]{f2, f3, f4, f5});
    }

    @Deprecated
    public static void matrixMode(int n2) {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.return(n2);
    }

    public static boolean isOnRenderThreadOrInit() {
        return isInInit || RenderSystem.isOnRenderThread();
    }

    @Deprecated
    public static void enableColorMaterial() {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.private();
    }

    @Deprecated
    public static void disableColorMaterial() {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.implements();
    }

    @Deprecated
    public static void pushLightingAttributes() {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.class();
    }

    public static boolean isOnGameThreadOrInit() {
        return isInInit || RenderSystem.isOnGameThread();
    }

    @Deprecated
    public static void pushTextureAttributes() {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.break();
    }

    public static void enableSmoothShadeModel() {
        RenderSystem.shadeModel(7425);
    }

    public static void setupGui3DDiffuseLighting(rje rje2, rje rje3) {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.break(rje2, rje3);
    }

    public static void setupEndPortalTexGen() {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.public();
    }

    public static yb_1 renderThreadTesselator() {
        RenderSystem.assertThread(RenderSystem::isOnRenderThread);
        return RENDER_THREAD_TESSELATOR;
    }

    public static void mulTextureByProjModelView() {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.while();
    }

    public static void teardownOverlayColor() {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.return();
    }

    public static int maxSupportedTextureSize() {
        RenderSystem.assertThread(RenderSystem::isInInitPhase);
        if (MAX_SUPPORTED_TEXTURE_SIZE == -1) {
            int n2 = mt_1.throw(3379);
            for (int k = Math.max(32768, n2); k >= 1024; k >>= 1) {
                mt_1.class(32868, 0, 6408, k, k, 0, 6408, 5121, null);
                int n3 = mt_1.byte(32868, 0, 4096);
                if (n3 == 0) continue;
                MAX_SUPPORTED_TEXTURE_SIZE = k;
                return k;
            }
            MAX_SUPPORTED_TEXTURE_SIZE = Math.max(n2, 1024);
            LOGGER.info("Failed to determine maximum texture size by probing, trying GL_MAX_TEXTURE_SIZE = {}", (Object)MAX_SUPPORTED_TEXTURE_SIZE);
        }
        return MAX_SUPPORTED_TEXTURE_SIZE;
    }

    public static void disableColorLogicOp() {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.static();
    }

    public static void disableSmoothShadeModel() {
        RenderSystem.shadeModel(7424);
    }

    public static void setupLevelDiffuseLighting(rje rje2, rje rje3, rjV rjV2) {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.class(rje2, rje3, rjV2);
    }

    public static void disablePolygonOffset() {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.abstract();
    }

    public static void enablePolygonOffset() {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.char();
    }

    public static void disableCull() {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.interface();
    }

    public static void texParameter(int n2, int n3, int n4) {
        mt_1.break(n2, n3, n4);
    }

    public static void bindTexture(int n2) {
        mt_1.super(n2);
    }

    public static void defaultAlphaFunc() {
        RenderSystem.alphaFunc(516, 0.1f);
    }

    @Deprecated
    public static void loadIdentity() {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.boolean();
    }

    @Deprecated
    public static void clearCurrentColor() {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.double();
    }

    public static void polygonOffset(float f2, float f3) {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.class(f2, f3);
    }

    public static void teardownOutline() {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.synchronized();
    }

    public static void setupOutline() {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.else();
    }

    @Deprecated
    public static void glMultiTexCoord2f(int n2, float f2, float f3) {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.class(n2, f2, f3);
    }

    public static void disableDepthTest() {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.native();
    }

    public static void initRenderer(int n2, boolean bl2) {
        RenderSystem.assertThread(RenderSystem::isInInitPhase);
        GLX._init(n2, bl2);
    }

    public static String getCapsString() {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        return GLX._getCapsString();
    }

    public static String getApiDescription() {
        RenderSystem.assertThread(RenderSystem::isInInitPhase);
        return GLX.getOpenGLVersionString();
    }

    public static LongSupplier initBackendSystem() {
        RenderSystem.assertThread(RenderSystem::isInInitPhase);
        return GLX._initGlfw();
    }

    public static void limitDisplayFPS(int n2) {
        double d = lastDrawTime + 1.0 / (double)n2;
        double d2 = GLFW.glfwGetTime();
        while (d2 < d) {
            GLFW.glfwWaitEventsTimeout((double)(d - d2));
            d2 = GLFW.glfwGetTime();
        }
        lastDrawTime = d2;
    }

    public static void setErrorCallback(GLFWErrorCallbackI gLFWErrorCallbackI) {
        RenderSystem.assertThread(RenderSystem::isInInitPhase);
        GLX._setGlfwErrorCallback(gLFWErrorCallbackI);
    }

    public static void setupDefaultState(int n2, int n3, int n4, int n5) {
        RenderSystem.assertThread(RenderSystem::isInInitPhase);
        mt_1.import();
        mt_1.this(7425);
        mt_1.class(1.0);
        mt_1.volatile();
        mt_1.break(515);
        mt_1.throws();
        mt_1.class(516, 0.1f);
        mt_1.return(5889);
        mt_1.boolean();
        mt_1.return(5888);
        mt_1.protected(n2, n3, n4, n5);
    }

    public static void setupGuiFlatDiffuseLighting(rje rje2, rje rje3) {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.class(rje2, rje3);
    }

    public static boolean isOnGameThread() {
        return true;
    }

    public static void assertThread(Supplier<Boolean> supplier) {
        if (!supplier.get().booleanValue()) {
            throw new IllegalStateException("Rendersystem called from wrong thread");
        }
    }

    @Deprecated
    public static void colorMaterial(int n2, int n3) {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.class(n2, n3);
    }

    public static void blendEquation(int n2) {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.byte(n2);
    }

    public static boolean isOnRenderThread() {
        return Thread.currentThread() == renderThread;
    }

    public static boolean isInInitPhase() {
        return true;
    }

    public static void recordRenderCall(oj_2 oj_22) {
        recordingQueue.add(oj_22);
    }

    public static void replayQueue() {
        isReplayingQueue = true;
        while (!recordingQueue.isEmpty()) {
            oj_2 oj_22 = recordingQueue.poll();
            oj_22.execute();
        }
        isReplayingQueue = false;
    }

    @Deprecated
    public static void popAttributes() {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.byte();
    }

    @Deprecated
    public static void enableLighting() {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.case();
    }

    @Deprecated
    public static void disableLighting() {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.catch();
    }

    public static void stencilFunc(int n2, int n3, int n4) {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.protected(n2, n3, n4);
    }

    public static void renderCrosshair(int n2) {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        GLX._renderCrosshair(n2, true, true, true);
    }

    public static void clearTexGen() {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.goto();
    }

    public static void enableLineOffset() {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.long();
    }

    public static void deleteTexture(int n2) {
        RenderSystem.assertThread(RenderSystem::isOnGameThreadOrInit);
        mt_1.continue(n2);
    }

    public static void clearStencil(int n2) {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.synchronized(n2);
    }

    public static void stencilMask(int n2) {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.else(n2);
    }

    public static void glUniformMatrix4(int n2, boolean bl2, FloatBuffer floatBuffer) {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.byte(n2, bl2, floatBuffer);
    }

    public static void glUniformMatrix2(int n2, boolean bl2, FloatBuffer floatBuffer) {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.class(n2, bl2, floatBuffer);
    }

    public static void disableLineOffset() {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.float();
    }

    public static void activeTexture(int n2) {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.new(n2);
    }

    public static void glUniformMatrix3(int n2, boolean bl2, FloatBuffer floatBuffer) {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.break(n2, bl2, floatBuffer);
    }

    public static void setupNvFogDistance() {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        GLX._setupNvFogDistance();
    }

    public static void glBindBuffer(int n2, Supplier<Integer> supplier) {
        mt_1.catch(n2, supplier.get());
    }

    public static void setupOverlayColor(IntSupplier intSupplier, int n2) {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.extends(intSupplier.getAsInt(), n2);
    }

    public static void enableColorLogicOp() {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.void();
    }

    public static void pixelTransfer(int n2, float f2) {
        mt_1.break(n2, f2);
    }

    public static void glDeleteBuffers(int n2) {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.finally(n2);
    }

    public static void glBufferData(int n2, ByteBuffer byteBuffer, int n3) {
        RenderSystem.assertThread(RenderSystem::isOnRenderThreadOrInit);
        mt_1.class(n2, byteBuffer, n3);
    }

    public static void glUniform1i(int n2, int n3) {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.case(n2, n3);
    }

    public static void glGenBuffers(Consumer<Integer> consumer) {
        if (!RenderSystem.isOnRenderThread()) {
            RenderSystem.recordRenderCall(() -> consumer.accept(mt_1.new()));
        } else {
            consumer.accept(mt_1.new());
        }
    }

    public static void polygonMode(int n2, int n3) {
        RenderSystem.assertThread(RenderSystem::isOnGameThread);
        mt_1.volatile(n2, n3);
    }
}

