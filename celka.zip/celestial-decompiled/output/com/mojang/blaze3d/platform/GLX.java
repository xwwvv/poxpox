/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.base.Joiner
 *  com.google.common.collect.Lists
 *  com.google.common.collect.Maps
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 *  org.lwjgl.Version
 *  org.lwjgl.glfw.GLFW
 *  org.lwjgl.glfw.GLFWErrorCallback
 *  org.lwjgl.glfw.GLFWErrorCallbackI
 *  org.lwjgl.glfw.GLFWVidMode
 *  org.lwjgl.opengl.GL
 *  org.lwjgl.opengl.GL11
 *  org.lwjgl.opengl.GLCapabilities
 *  oshi.SystemInfo
 *  oshi.hardware.Processor
 */
package com.mojang.blaze3d.platform;

import com.google.common.base.Joiner;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.mojang.blaze3d.systems.RenderSystem;
import java.util.ArrayList;
import java.util.Map;
import java.util.function.Consumer;
import java.util.function.LongSupplier;
import java.util.function.Supplier;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.lwjgl.Version;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.glfw.GLFWErrorCallback;
import org.lwjgl.glfw.GLFWErrorCallbackI;
import org.lwjgl.glfw.GLFWVidMode;
import org.lwjgl.opengl.GL;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GLCapabilities;
import oshi.SystemInfo;
import oshi.hardware.Processor;
import protected.hx_0;
import protected.ju_0;
import protected.lD;
import protected.mt_1;
import protected.qg_1;
import protected.rrbb;
import protected.yb_1;

public class GLX {
    private static final Logger LOGGER = LogManager.getLogger();
    private static String capsString = "";
    private static String cpuInfo;
    private static final Map<Integer, String> LOOKUP_MAP;

    static {
        LOOKUP_MAP = GLX.make(Maps.newHashMap(), hashMap -> {
            hashMap.put(0, "No error");
            hashMap.put(1280, "Enum parameter is invalid for this function");
            hashMap.put(1281, "Parameter is invalid for this function");
            hashMap.put(1282, "Current state is invalid for this function");
            hashMap.put(1283, "Stack overflow");
            hashMap.put(1284, "Stack underflow");
            hashMap.put(1285, "Out of memory");
            hashMap.put(1286, "Operation on incomplete framebuffer");
            hashMap.put(1286, "Operation on incomplete framebuffer");
        });
    }

    public static <T> T make(Supplier<T> supplier) {
        return supplier.get();
    }

    public static <T> T make(T t2, Consumer<T> consumer) {
        consumer.accept(t2);
        return t2;
    }

    public static void _init(int n2, boolean bl2) {
        RenderSystem.assertThread(RenderSystem::isInInitPhase);
        GLCapabilities gLCapabilities = GL.getCapabilities();
        capsString = "Using framebuffer using " + mt_1.class(gLCapabilities);
        try {
            Processor[] processorArray = new SystemInfo().getHardware().getProcessors();
            cpuInfo = String.format("%dx %s", processorArray.length, processorArray[0]).replaceAll("\\s+", " ");
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        hx_0.class(n2, bl2);
    }

    public static LongSupplier _initGlfw() {
        RenderSystem.assertThread(RenderSystem::isInInitPhase);
        qg_1.class((n2, string) -> {
            throw new IllegalStateException(String.format("GLFW error before init: [0x%X]%s", n2, string));
        });
        ArrayList arrayList = Lists.newArrayList();
        GLFWErrorCallback gLFWErrorCallback = GLFW.glfwSetErrorCallback((n2, l2) -> arrayList.add(String.format("GLFW error during init: [0x%X]%s", n2, l2)));
        if (!GLFW.glfwInit()) {
            throw new IllegalStateException("Failed to initialize GLFW, errors: " + Joiner.on((String)",").join((Iterable)arrayList));
        }
        LongSupplier longSupplier = () -> (long)(GLFW.glfwGetTime() * 1.0E9);
        for (String string2 : arrayList) {
            LOGGER.error("GLFW error collected during initialization: {}", (Object)string2);
        }
        RenderSystem.setErrorCallback((GLFWErrorCallbackI)gLFWErrorCallback);
        return longSupplier;
    }

    public static boolean useVbo() {
        return true;
    }

    public static void _setupNvFogDistance() {
        RenderSystem.assertThread(RenderSystem::isOnRenderThread);
        if (GL.getCapabilities().GL_NV_fog_distance) {
            if (rrbb.this()) {
                mt_1.native(34138, 34139);
            }
            if (rrbb.else()) {
                mt_1.native(34138, 34140);
            }
        }
    }

    public static void _setGlfwErrorCallback(GLFWErrorCallbackI gLFWErrorCallbackI) {
        RenderSystem.assertThread(RenderSystem::isInInitPhase);
        GLFWErrorCallback gLFWErrorCallback = GLFW.glfwSetErrorCallback((GLFWErrorCallbackI)gLFWErrorCallbackI);
        if (gLFWErrorCallback != null) {
            gLFWErrorCallback.free();
        }
    }

    public static String getOpenGLVersionString() {
        RenderSystem.assertThread(RenderSystem::isOnRenderThread);
        return GLFW.glfwGetCurrentContext() == 0L ? "NO CONTEXT" : mt_1.instanceof(7937) + " GL version " + mt_1.instanceof(7938) + ", " + mt_1.instanceof(7936);
    }

    public static boolean isUsingFBOs() {
        return !rrbb.T();
    }

    public static boolean _shouldClose(qg_1 qg_12) {
        return GLFW.glfwWindowShouldClose((long)qg_12.implements());
    }

    public static int _getRefreshRate(qg_1 qg_12) {
        RenderSystem.assertThread(RenderSystem::isOnRenderThread);
        long l2 = GLFW.glfwGetWindowMonitor((long)qg_12.implements());
        if (l2 == 0L) {
            l2 = GLFW.glfwGetPrimaryMonitor();
        }
        GLFWVidMode gLFWVidMode = l2 == 0L ? null : GLFW.glfwGetVideoMode((long)l2);
        return gLFWVidMode == null ? 0 : gLFWVidMode.refreshRate();
    }

    public static String _getCpuInfo() {
        return cpuInfo == null ? "<unknown>" : cpuInfo;
    }

    public static String getErrorString(int n2) {
        return LOOKUP_MAP.get(n2);
    }

    public static String _getLWJGLVersion() {
        RenderSystem.assertThread(RenderSystem::isInInitPhase);
        return Version.getVersion();
    }

    public static void _renderCrosshair(int n2, boolean bl2, boolean bl3, boolean bl4) {
        RenderSystem.assertThread(RenderSystem::isOnRenderThread);
        mt_1.short();
        mt_1.class(false);
        yb_1 yb_12 = RenderSystem.renderThreadTesselator();
        lD lD2 = yb_12.byte();
        GL11.glLineWidth((float)4.0f);
        lD2.class(1, ju_0.this);
        if (bl2) {
            lD2.class(0.0, 0.0, 0.0).break(0, 0, 0, 255).class();
            lD2.class((double)n2, 0.0, 0.0).break(0, 0, 0, 255).class();
        }
        if (bl3) {
            lD2.class(0.0, 0.0, 0.0).break(0, 0, 0, 255).class();
            lD2.class(0.0, (double)n2, 0.0).break(0, 0, 0, 255).class();
        }
        if (bl4) {
            lD2.class(0.0, 0.0, 0.0).break(0, 0, 0, 255).class();
            lD2.class(0.0, 0.0, (double)n2).break(0, 0, 0, 255).class();
        }
        yb_12.break();
        GL11.glLineWidth((float)2.0f);
        lD2.class(1, ju_0.this);
        if (bl2) {
            lD2.class(0.0, 0.0, 0.0).break(255, 0, 0, 255).class();
            lD2.class((double)n2, 0.0, 0.0).break(255, 0, 0, 255).class();
        }
        if (bl3) {
            lD2.class(0.0, 0.0, 0.0).break(0, 255, 0, 255).class();
            lD2.class(0.0, (double)n2, 0.0).break(0, 255, 0, 255).class();
        }
        if (bl4) {
            lD2.class(0.0, 0.0, 0.0).break(127, 127, 255, 255).class();
            lD2.class(0.0, 0.0, (double)n2).break(127, 127, 255, 255).class();
        }
        yb_12.break();
        GL11.glLineWidth((float)1.0f);
        mt_1.class(true);
        mt_1.import();
    }

    public static String _getCapsString() {
        return capsString;
    }
}

