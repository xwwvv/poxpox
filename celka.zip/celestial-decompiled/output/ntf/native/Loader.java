/*
 * Decompiled with CFR 0.152.
 */
package ntf.native;

import java.lang.invoke.MethodHandle;

public final class Loader {
    public static /* bridge */ /* synthetic */ Object invoke(MethodHandle methodHandle) {
        return methodHandle.invoke();
    }

    public static /* bridge */ /* synthetic */ Object invoke(MethodHandle methodHandle, Object object) {
        return methodHandle.invoke(object);
    }
}

