/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.Gson
 *  com.google.gson.GsonBuilder
 *  com.mojang.authlib.properties.PropertyMap
 *  com.mojang.authlib.properties.PropertyMap$Serializer
 *  joptsimple.ArgumentAcceptingOptionSpec
 *  joptsimple.NonOptionArgumentSpec
 *  joptsimple.OptionParser
 *  joptsimple.OptionSet
 *  joptsimple.OptionSpec
 *  org.apache.commons.lang3.RandomStringUtils
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 *  ru.ntfhack.UserInfo
 */
package net.minecraft.client.main;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.mojang.authlib.properties.PropertyMap;
import com.mojang.blaze3d.systems.RenderSystem;
import java.io.File;
import java.net.Authenticator;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.util.List;
import java.util.OptionalInt;
import joptsimple.ArgumentAcceptingOptionSpec;
import joptsimple.NonOptionArgumentSpec;
import joptsimple.OptionParser;
import joptsimple.OptionSet;
import joptsimple.OptionSpec;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import protected.KY;
import protected.ae_2;
import protected.as_1;
import protected.as_2;
import protected.gn_0;
import protected.jV;
import protected.mc_1;
import protected.qp_1;
import protected.qq_1;
import protected.qt_1;
import protected.qt_2;
import protected.qw_1;
import protected.qy_1;
import protected.qy_2;
import protected.rhd_2;
import protected.rpY;
import protected.rqR;
import protected.rqn_0;
import protected.rrqj_1;
import protected.rrzr_1;
import protected.rvn_0;
import protected.rya_1;
import protected.ys_1;
import ru.ntfhack.StringChecker;
import ru.ntfhack.UserInfo;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class Main {
    public static final Logger class = LogManager.getLogger();

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public static void main(String[] stringArray) {
        ae_2 ae_22;
        qy_1 qy_12;
        rrzr_1 rrzr_12;
        try {
            rrzr_1 rrzr_13 = rrzr_12 = new rrzr_1(UserInfo.getUsername(), String.valueOf(UserInfo.getUID()));
            rrqj_1.class[5] = rrzr_13;
            StringChecker.init("Celestial", (String)rrqj_1.class[1], "1.1", "1.16.5", "25/05/2026", rrzr_12.break(), rrzr_12.protected());
        }
        catch (Error | Exception throwable) {
            throwable.printStackTrace();
            rrzr_1 rrzr_14 = new rrzr_1("mogg", "1337");
            rrqj_1.class[5] = rrzr_14;
        }
        rrzr_12 = new OptionParser();
        rrzr_12.allowsUnrecognizedOptions();
        rrzr_12.accepts("demo");
        rrzr_12.accepts("disableMultiplayer");
        rrzr_12.accepts("disableChat");
        rrzr_12.accepts("fullscreen");
        rrzr_12.accepts("checkGlErrors");
        ArgumentAcceptingOptionSpec argumentAcceptingOptionSpec = rrzr_12.accepts("server").withRequiredArg();
        ArgumentAcceptingOptionSpec argumentAcceptingOptionSpec2 = rrzr_12.accepts("port").withRequiredArg().ofType(Integer.class).defaultsTo((Object)25565, (Object[])new Integer[0]);
        ArgumentAcceptingOptionSpec argumentAcceptingOptionSpec3 = rrzr_12.accepts("gameDir").withRequiredArg().ofType(File.class).defaultsTo((Object)new File("."), (Object[])new File[0]);
        ArgumentAcceptingOptionSpec argumentAcceptingOptionSpec4 = rrzr_12.accepts("assetsDir").withRequiredArg().ofType(File.class);
        ArgumentAcceptingOptionSpec argumentAcceptingOptionSpec5 = rrzr_12.accepts("resourcePackDir").withRequiredArg().ofType(File.class);
        ArgumentAcceptingOptionSpec argumentAcceptingOptionSpec6 = rrzr_12.accepts("dataPackDir").withRequiredArg().ofType(File.class);
        ArgumentAcceptingOptionSpec argumentAcceptingOptionSpec7 = rrzr_12.accepts("proxyHost").withRequiredArg();
        ArgumentAcceptingOptionSpec argumentAcceptingOptionSpec8 = rrzr_12.accepts("proxyPort").withRequiredArg().defaultsTo((Object)"8080", (Object[])new String[0]).ofType(Integer.class);
        ArgumentAcceptingOptionSpec argumentAcceptingOptionSpec9 = rrzr_12.accepts("proxyUser").withRequiredArg();
        ArgumentAcceptingOptionSpec argumentAcceptingOptionSpec10 = rrzr_12.accepts("proxyPass").withRequiredArg();
        ArgumentAcceptingOptionSpec argumentAcceptingOptionSpec11 = rrzr_12.accepts("username").withRequiredArg().defaultsTo((Object)("CelUser" + RandomStringUtils.randomNumeric((int)5)), (Object[])new String[0]);
        ArgumentAcceptingOptionSpec argumentAcceptingOptionSpec12 = rrzr_12.accepts("uuid").withRequiredArg();
        ArgumentAcceptingOptionSpec argumentAcceptingOptionSpec13 = rrzr_12.accepts("accessToken").withRequiredArg().required();
        ArgumentAcceptingOptionSpec argumentAcceptingOptionSpec14 = rrzr_12.accepts("version").withRequiredArg().required();
        ArgumentAcceptingOptionSpec argumentAcceptingOptionSpec15 = rrzr_12.accepts("width").withRequiredArg().ofType(Integer.class).defaultsTo((Object)854, (Object[])new Integer[0]);
        ArgumentAcceptingOptionSpec argumentAcceptingOptionSpec16 = rrzr_12.accepts("height").withRequiredArg().ofType(Integer.class).defaultsTo((Object)480, (Object[])new Integer[0]);
        ArgumentAcceptingOptionSpec argumentAcceptingOptionSpec17 = rrzr_12.accepts("fullscreenWidth").withRequiredArg().ofType(Integer.class);
        ArgumentAcceptingOptionSpec argumentAcceptingOptionSpec18 = rrzr_12.accepts("fullscreenHeight").withRequiredArg().ofType(Integer.class);
        ArgumentAcceptingOptionSpec argumentAcceptingOptionSpec19 = rrzr_12.accepts("userProperties").withRequiredArg().defaultsTo((Object)"{}", (Object[])new String[0]);
        ArgumentAcceptingOptionSpec argumentAcceptingOptionSpec20 = rrzr_12.accepts("profileProperties").withRequiredArg().defaultsTo((Object)"{}", (Object[])new String[0]);
        ArgumentAcceptingOptionSpec argumentAcceptingOptionSpec21 = rrzr_12.accepts("assetIndex").withRequiredArg();
        ArgumentAcceptingOptionSpec argumentAcceptingOptionSpec22 = rrzr_12.accepts("userType").withRequiredArg().defaultsTo((Object)"legacy", (Object[])new String[0]);
        ArgumentAcceptingOptionSpec argumentAcceptingOptionSpec23 = rrzr_12.accepts("versionType").withRequiredArg().defaultsTo((Object)"release", (Object[])new String[0]);
        NonOptionArgumentSpec nonOptionArgumentSpec = rrzr_12.nonOptions();
        OptionSet optionSet = rrzr_12.parse(stringArray);
        List list = optionSet.valuesOf((OptionSpec)nonOptionArgumentSpec);
        if (!list.isEmpty()) {
            System.out.println("Completely ignored arguments: " + list);
        }
        String string = (String)Main.class(optionSet, argumentAcceptingOptionSpec7);
        Proxy proxy = Proxy.NO_PROXY;
        if (string != null) {
            try {
                proxy = new Proxy(Proxy.Type.SOCKS, new InetSocketAddress(string, (int)((Integer)Main.class(optionSet, argumentAcceptingOptionSpec8))));
            }
            catch (Exception exception) {
                // empty catch block
            }
        }
        String string2 = (String)Main.class(optionSet, argumentAcceptingOptionSpec9);
        String string3 = (String)Main.class(optionSet, argumentAcceptingOptionSpec10);
        if (!proxy.equals(Proxy.NO_PROXY) && Main.class(string2) && Main.class(string3)) {
            Authenticator.setDefault(new as_2(string2, string3));
        }
        int n2 = (Integer)Main.class(optionSet, argumentAcceptingOptionSpec15);
        int n3 = (Integer)Main.class(optionSet, argumentAcceptingOptionSpec16);
        OptionalInt optionalInt = Main.class((Integer)Main.class(optionSet, argumentAcceptingOptionSpec17));
        OptionalInt optionalInt2 = Main.class((Integer)Main.class(optionSet, argumentAcceptingOptionSpec18));
        boolean bl2 = optionSet.has("fullscreen");
        boolean bl3 = optionSet.has("demo");
        boolean bl4 = optionSet.has("disableMultiplayer");
        boolean bl5 = optionSet.has("disableChat");
        String string4 = (String)Main.class(optionSet, argumentAcceptingOptionSpec14);
        Gson gson = new GsonBuilder().registerTypeAdapter(PropertyMap.class, (Object)new PropertyMap.Serializer()).create();
        PropertyMap propertyMap = rpY.class(gson, (String)Main.class(optionSet, argumentAcceptingOptionSpec19), PropertyMap.class);
        PropertyMap propertyMap2 = rpY.class(gson, (String)Main.class(optionSet, argumentAcceptingOptionSpec20), PropertyMap.class);
        String string5 = (String)Main.class(optionSet, argumentAcceptingOptionSpec23);
        File file = (File)Main.class(optionSet, argumentAcceptingOptionSpec3);
        File file2 = optionSet.has((OptionSpec)argumentAcceptingOptionSpec4) ? (File)Main.class(optionSet, argumentAcceptingOptionSpec4) : new File(file, "assets/");
        File file3 = optionSet.has((OptionSpec)argumentAcceptingOptionSpec5) ? (File)Main.class(optionSet, argumentAcceptingOptionSpec5) : new File(file, "resourcepacks/");
        String string6 = optionSet.has((OptionSpec)argumentAcceptingOptionSpec12) ? (String)argumentAcceptingOptionSpec12.value(optionSet) : rhd_2.extends((String)argumentAcceptingOptionSpec11.value(optionSet)).toString();
        String string7 = optionSet.has((OptionSpec)argumentAcceptingOptionSpec21) ? (String)argumentAcceptingOptionSpec21.value(optionSet) : null;
        String string8 = (String)Main.class(optionSet, argumentAcceptingOptionSpec);
        Integer n4 = (Integer)Main.class(optionSet, argumentAcceptingOptionSpec2);
        KY.catch();
        rvn_0.class();
        rvn_0.byte();
        rqR.final();
        rqn_0 rqn_02 = new rqn_0((String)argumentAcceptingOptionSpec11.value(optionSet), string6, (String)argumentAcceptingOptionSpec13.value(optionSet), (String)argumentAcceptingOptionSpec22.value(optionSet));
        qy_2 qy_22 = new qy_2(new qt_1(rqn_02, propertyMap, propertyMap2, proxy), new ys_1(n2, n3, optionalInt, optionalInt2, bl2), new qp_1(file, file3, file2, string7), new qq_1(bl3, string4, string5, bl4, bl5), new qt_2(string8, n4));
        as_1 as_12 = new as_1("Client Shutdown Thread");
        as_12.setUncaughtExceptionHandler(new rya_1(Main.class));
        Runtime.getRuntime().addShutdownHook(as_12);
        new mc_1();
        try {
            Thread.currentThread().setName("Render thread");
            RenderSystem.initRenderThread();
            RenderSystem.beginInitialization();
            qy_12 = new qy_1(qy_22);
            RenderSystem.finishInitialization();
        }
        catch (gn_0 gn_02) {
            Main.class.warn("Failed to create window: ", (Throwable)gn_02);
            return;
        }
        catch (Throwable throwable) {
            KY kY = KY.class(throwable, "Initializing game");
            kY.class("Initialization");
            qy_1.class((jV)null, qy_22.protected.break, (qw_1)null, kY);
            qy_1.byte(kY);
            return;
        }
        if (qy_12.O()) {
            ae_22 = new ae_2("Game thread", qy_12);
            ae_22.start();
            while (qy_12.goto()) {
            }
        } else {
            ae_22 = null;
            try {
                RenderSystem.initGameThread(false);
                qy_12.double();
            }
            catch (Throwable throwable) {
                Main.class.error("Unhandled game exception", throwable);
            }
        }
        try {
            qy_12.G();
            if (ae_22 != null) {
                ae_22.join();
            }
        }
        catch (InterruptedException interruptedException) {
            Main.class.error("Exception during client thread shutdown", (Throwable)interruptedException);
        }
        finally {
            qy_12.m();
        }
    }

    private static <T> T class(OptionSet optionSet, OptionSpec<T> optionSpec) {
        try {
            return (T)optionSet.valueOf(optionSpec);
        }
        catch (Throwable throwable) {
            ArgumentAcceptingOptionSpec argumentAcceptingOptionSpec;
            List list;
            if (optionSpec instanceof ArgumentAcceptingOptionSpec && !(list = (argumentAcceptingOptionSpec = (ArgumentAcceptingOptionSpec)optionSpec).defaultValues()).isEmpty()) {
                return (T)list.get(0);
            }
            throw throwable;
        }
    }

    private static boolean class(String string) {
        return string != null && !string.isEmpty();
    }

    private static OptionalInt class(Integer n2) {
        return n2 != null ? OptionalInt.of(n2) : OptionalInt.empty();
    }
}

