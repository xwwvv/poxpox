/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.hn_0;
import protected.qa_1;
import protected.qg_1;
import protected.qy_1;
import protected.ys_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.yh
 */
public final class yh_1
implements AutoCloseable {
    private final qy_1 class;
    private final hn_0 break;

    public yh_1(qy_1 qy_12) {
        this.class = qy_12;
        this.break = new hn_0(qa_1::new);
    }

    public qg_1 class(ys_1 ys_12, String string, String string2) {
        return new qg_1(this.class, this.break, ys_12, string, string2);
    }

    @Override
    public void close() {
        this.break.class();
    }
}

