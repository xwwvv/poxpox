/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.cache.CacheLoader
 */
package protected;

import com.google.common.cache.CacheLoader;
import protected.rjC;
import protected.rjn_0;
import protected.rjw;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.xk
 */
class xk_0
extends CacheLoader<rjC, Boolean> {
    xk_0() {
    }

    public /* synthetic */ Object load(Object object) throws Exception {
        return this.class((rjC)object);
    }

    public Boolean class(rjC rjC2) {
        return !rjw.byte(rjw.break(), rjC2, rjn_0.catch);
    }
}

