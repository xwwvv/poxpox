/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.brigadier.ImmutableStringReader
 *  com.mojang.brigadier.StringReader
 *  com.mojang.brigadier.arguments.ArgumentType
 *  com.mojang.brigadier.context.CommandContext
 *  com.mojang.brigadier.exceptions.CommandSyntaxException
 *  com.mojang.brigadier.exceptions.DynamicCommandExceptionType
 *  com.mojang.brigadier.suggestion.Suggestions
 *  com.mojang.brigadier.suggestion.SuggestionsBuilder
 */
package protected;

import com.mojang.brigadier.ImmutableStringReader;
import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.DynamicCommandExceptionType;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import java.util.Arrays;
import java.util.Collection;
import java.util.concurrent.CompletableFuture;
import protected.Rm;
import protected.gR;
import protected.gy_0;
import protected.rgn;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.Ru
 */
public class ru_0
implements ArgumentType<Rm> {
    private static final Collection<String> class = Arrays.asList("eyes", "feet");
    private static final DynamicCommandExceptionType break = new DynamicCommandExceptionType(object -> new rgn("argument.anchor.invalid", object));

    public static Rm class(CommandContext<gy_0> commandContext, String string) {
        return (Rm)((Object)commandContext.getArgument(string, Rm.class));
    }

    public Rm class(StringReader stringReader) throws CommandSyntaxException {
        int n2 = stringReader.getCursor();
        String string = stringReader.readUnquotedString();
        Rm rm = Rm.class(string);
        if (rm == null) {
            stringReader.setCursor(n2);
            throw break.createWithContext((ImmutableStringReader)stringReader, (Object)string);
        }
        return rm;
    }

    public static ru_0 class() {
        return new ru_0();
    }

    public /* synthetic */ Object parse(StringReader stringReader) throws CommandSyntaxException {
        return this.class(stringReader);
    }

    public Collection<String> getExamples() {
        return ru_0.class;
    }

    public <S> CompletableFuture<Suggestions> listSuggestions(CommandContext<S> commandContext, SuggestionsBuilder suggestionsBuilder) {
        return gR.break(Rm.BY_NAME.keySet(), suggestionsBuilder);
    }
}

