/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonObject
 */
package protected;

import com.google.gson.JsonObject;
import protected.hg_2;
import protected.ho_1;
import protected.hz_1;
import protected.rdn_1;
import protected.rhn_2;
import protected.rqo_0;
import protected.rwl_1;
import protected.xf_2;
import protected.xh_2;
import protected.xo_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.XM
 */
public class xm_2
extends hg_2<xo_2> {
    static final rqo_0 class = new rqo_0("item_durability_changed");

    public void class(rhn_2 rhn_22, rdn_1 rdn_12, int n2) {
        this.class(rhn_22, (T xo_22) -> xo_22.class(rdn_12, n2));
    }

    @Override
    public rqo_0 class() {
        return xm_2.class;
    }

    @Override
    public /* synthetic */ hz_1 class(JsonObject jsonObject, ho_1 ho_12, rwl_1 rwl_12) {
        return this.break(jsonObject, ho_12, rwl_12);
    }

    public xo_2 break(JsonObject jsonObject, ho_1 ho_12, rwl_1 rwl_12) {
        xh_2 xh_22 = xh_2.class(jsonObject.get("item"));
        xf_2 xf_22 = xf_2.class(jsonObject.get("durability"));
        xf_2 xf_23 = xf_2.class(jsonObject.get("delta"));
        return new xo_2(ho_12, xh_22, xf_22, xf_23);
    }
}

