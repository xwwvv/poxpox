/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.util.Arrays;
import java.util.Comparator;
import protected.rfU;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.VX
 */
public final class vx_0
extends Enum<vx_0> {
    public static final /* enum */ vx_0 OFF = new vx_0(0, "options.off");
    public static final /* enum */ vx_0 CROSSHAIR = new vx_0(1, "options.attack.crosshair");
    public static final /* enum */ vx_0 HOTBAR = new vx_0(2, "options.attack.hotbar");
    private static final vx_0[] BY_ID;
    private final int id;
    private final String resourceKey;
    private static final /* synthetic */ vx_0[] $VALUES;

    private static /* synthetic */ vx_0[] byte() {
        return new vx_0[]{OFF, CROSSHAIR, HOTBAR};
    }

    private vx_0(int n3, String string2) {
        this.id = n3;
        this.resourceKey = string2;
    }

    static {
        $VALUES = vx_0.byte();
        BY_ID = (vx_0[])Arrays.stream(vx_0.values()).sorted(Comparator.comparingInt(vx_0::class)).toArray(vx_0[]::new);
    }

    public static vx_0[] values() {
        return (vx_0[])$VALUES.clone();
    }

    public static vx_0 valueOf(String string) {
        return Enum.valueOf(vx_0.class, string);
    }

    public int class() {
        return this.id;
    }

    public static vx_0 class(int n2) {
        return BY_ID[rfU.break(n2, BY_ID.length)];
    }

    public String break() {
        return this.resourceKey;
    }
}

