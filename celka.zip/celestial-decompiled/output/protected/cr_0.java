/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.CK;
import protected.ch_0;
import protected.cy_0;
import protected.gm;
import protected.ly_0;
import protected.ok_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.Cr
 */
class cr_0
extends CK {
    private boolean break;
    private boolean interface;
    private final cy_0 char;
    private float abstract;
    private float long;
    private float float;
    private boolean void;

    cr_0(gm gm2, double d, double d2, double d3, double d4, double d5, double d6, cy_0 cy_02, ch_0 ch_02) {
        super(gm2, d, d2, d3, ch_02, -0.004f);
        this.finally = d4;
        this.extends = d5;
        this.native = d6;
        this.char = cy_02;
        this.throw *= 0.75f;
        this.this = 48 + this.continue.nextInt(12);
        this.break(ch_02);
    }

    public void class(boolean bl2) {
        this.break = bl2;
    }

    @Override
    public void class(ok_2 ok_22, ly_0 ly_02, float f2) {
        if (!this.interface || this.super < this.this / 3 || (this.super + this.this) / 3 % 2 == 0) {
            super.class(ok_22, ly_02, f2);
        }
    }

    public void break(boolean bl2) {
        this.interface = bl2;
    }

    @Override
    public void case() {
        super.case();
        if (this.break && this.super < this.this / 2 && (this.super + this.this) % 2 == 0) {
            cr_0 cr_02 = new cr_0(this.byte, this.catch, this.private, this.implements, 0.0, 0.0, 0.0, this.char, this.class);
            cr_02.throws(0.99f);
            cr_02.class(this.synchronized, this.return, this.public);
            cr_02.super = cr_02.this / 2;
            if (this.void) {
                cr_02.void = true;
                cr_02.abstract = this.abstract;
                cr_02.long = this.long;
                cr_02.float = this.float;
            }
            cr_02.interface = this.interface;
            this.char.class(cr_02);
        }
    }
}

