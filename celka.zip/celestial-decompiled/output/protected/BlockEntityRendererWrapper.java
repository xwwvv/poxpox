/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableMap
 *  com.google.common.collect.Maps
 *  com.google.common.collect.Sets
 */
package protected;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import java.util.HashSet;
import java.util.Map;
import java.util.Random;
import protected.jc_1;
import protected.jq_1;
import protected.kr_1;
import protected.rCL;
import protected.rCY;
import protected.rCm;
import protected.rRR;
import protected.rRg;
import protected.rRq;
import protected.rYB;
import protected.rct_0;
import protected.rcu_0;
import protected.rfH;
import protected.rfU;
import protected.rff;
import protected.rfw;
import protected.rhd_2;
import protected.rhx_1;
import protected.rjC;
import protected.rja;
import protected.rje;
import protected.rjm;
import protected.rjw;
import protected.rlc_2;
import protected.rpa;
import protected.rpb;
import protected.rpm;
import protected.rpr_0;
import protected.rqd_0;
import protected.rxx;
import protected.ryz_1;
import protected.wz_1;
import protected.xc_0;
import protected.xd_0;
import protected.xu_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.Wu
 */
public class wu_2
extends xd_0 {
    public static final rcu_0<rCY> volatile = rct_0.S;
    public static final rcu_0<rCY> final = rct_0.B;
    public static final rcu_0<rCY> package = rct_0.s;
    public static final rcu_0<rCY> int = rct_0.E;
    public static final rCm new = rct_0.H;
    public static final Map<rpr_0, rcu_0<rCY>> continue = Maps.newEnumMap((Map)ImmutableMap.of((Object)rpr_0.NORTH, volatile, (Object)rpr_0.EAST, final, (Object)rpr_0.SOUTH, package, (Object)rpr_0.WEST, int));
    private static final rjC super = xd_0.class(3.0, 0.0, 3.0, 13.0, 1.0, 13.0);
    private static final Map<rpr_0, rjC> this = Maps.newEnumMap((Map)ImmutableMap.of((Object)rpr_0.NORTH, (Object)xd_0.class(3.0, 0.0, 0.0, 13.0, 1.0, 13.0), (Object)rpr_0.SOUTH, (Object)xd_0.class(3.0, 0.0, 3.0, 13.0, 1.0, 16.0), (Object)rpr_0.EAST, (Object)xd_0.class(3.0, 0.0, 3.0, 16.0, 1.0, 13.0), (Object)rpr_0.WEST, (Object)xd_0.class(0.0, 0.0, 3.0, 13.0, 1.0, 13.0)));
    private static final Map<rpr_0, rjC> else = Maps.newEnumMap((Map)ImmutableMap.of((Object)rpr_0.NORTH, (Object)rjw.class(this.get(rpr_0.NORTH), xd_0.class(3.0, 0.0, 0.0, 13.0, 16.0, 1.0)), (Object)rpr_0.SOUTH, (Object)rjw.class(this.get(rpr_0.SOUTH), xd_0.class(3.0, 0.0, 15.0, 13.0, 16.0, 16.0)), (Object)rpr_0.EAST, (Object)rjw.class(this.get(rpr_0.EAST), xd_0.class(15.0, 0.0, 3.0, 16.0, 16.0, 13.0)), (Object)rpr_0.WEST, (Object)rjw.class(this.get(rpr_0.WEST), xd_0.class(0.0, 0.0, 3.0, 1.0, 16.0, 13.0))));
    private final Map<xc_0, rjC> synchronized = Maps.newHashMap();
    private static final rje[] return = new rje[16];
    private final xc_0 public;
    private boolean goto = true;

    @Override
    public boolean byte(xc_0 xc_02) {
        return this.goto;
    }

    public static int byte(int n2) {
        rje rje2 = return[n2];
        return rfU.throws(rje2.class(), rje2.break(), rje2.byte());
    }

    public wu_2(jq_1 jq_12) {
        super(jq_12);
        this.extends((xc_0)((xc_0)((xc_0)((xc_0)((xc_0)((xc_0)this.abstract.break()).class(volatile, rCY.NONE)).class(final, rCY.NONE)).class(package, rCY.NONE)).class(int, rCY.NONE)).class(new, 0));
        this.public = (xc_0)((xc_0)((xc_0)((xc_0)this.continue().class(volatile, rCY.SIDE)).class(final, rCY.SIDE)).class(package, rCY.SIDE)).class(int, rCY.SIDE);
        for (xc_0 xc_02 : this.new().class()) {
            if (xc_02.byte(new) != 0) continue;
            this.synchronized.put(xc_02, this.implements(xc_02));
        }
    }

    static {
        for (int k = 0; k <= 15; ++k) {
            float f2;
            float f3 = f2 * 0.6f + ((f2 = (float)k / 15.0f) > 0.0f ? 0.4f : 0.3f);
            float f4 = rfU.class(f2 * f2 * 0.7f - 0.5f, 0.0f, 1.0f);
            float f5 = rfU.class(f2 * f2 * 0.6f - 0.7f, 0.0f, 1.0f);
            wu_2.return[k] = new rje(f3, f4, f5);
        }
    }

    @Override
    public int class(xc_0 xc_02, rRq rRq2, rfH rfH2, rpr_0 rpr_02) {
        if (this.goto && rpr_02 != rpr_0.DOWN) {
            int n2 = xc_02.byte(new);
            if (n2 == 0) {
                return 0;
            }
            return rpr_02 != rpr_0.UP && !((rCY)this.class(rRq2, xc_02, rfH2).byte(continue.get(rpr_02.case()))).break() ? 0 : n2;
        }
        return 0;
    }

    protected static boolean class(xc_0 xc_02, rpr_0 rpr_02) {
        if (xc_02.class(xu_0.ra)) {
            return true;
        }
        if (xc_02.class(xu_0.BS)) {
            rpr_0 rpr_03 = xc_02.byte(wz_1.p);
            return rpr_03 == rpr_02 || rpr_03.case() == rpr_02;
        }
        if (xc_02.class(xu_0.bK)) {
            return rpr_02 == xc_02.byte(kr_1.volatile);
        }
        return xc_02.implements() && rpr_02 != null;
    }

    @Override
    public rjC class(xc_0 xc_02, rRq rRq2, rfH rfH2, rjm rjm2) {
        return this.synchronized.get(xc_02.class(new, 0));
    }

    private void class(rYB rYB2, Random random, rfH rfH2, rje rje2, rpr_0 rpr_02, rpr_0 rpr_03, float f2, float f3) {
        float f4 = f3 - f2;
        if (!(random.nextFloat() >= 0.2f * f4)) {
            float f5 = 0.4375f;
            float f6 = f2 + f4 * random.nextFloat();
            double d = 0.5 + (double)(0.4375f * (float)rpr_02.implements()) + (double)(f6 * (float)rpr_03.implements());
            double d2 = 0.5 + (double)(0.4375f * (float)rpr_02.finally()) + (double)(f6 * (float)rpr_03.finally());
            double d3 = 0.5 + (double)(0.4375f * (float)rpr_02.extends()) + (double)(f6 * (float)rpr_03.extends());
            rYB2.class(new rlc_2(rje2.class(), rje2.break(), rje2.byte(), 1.0f), (double)rfH2.b_() + d, (double)rfH2.c_() + d2, (double)rfH2.d_() + d3, 0.0, 0.0, 0.0);
        }
    }

    @Override
    public void class(xc_0 xc_02, rYB rYB2, rfH rfH2, xd_0 xd_02, rfH rfH3, boolean bl2) {
        if (!rYB2.continue) {
            if (xc_02.class((rRR)rYB2, rfH2)) {
                this.class(rYB2, rfH2, xc_02);
            } else {
                wu_2.protected(xc_02, rYB2, rfH2);
                rYB2.class(rfH2, false);
            }
        }
    }

    @Override
    public void class(xc_0 xc_02, rYB rYB2, rfH rfH2, xc_0 xc_03, boolean bl2) {
        if (!xc_03.class(xc_02.break()) && !rYB2.continue) {
            this.class(rYB2, rfH2, xc_02);
            for (rpr_0 rpr_02 : rpb.VERTICAL) {
                rYB2.break(rfH2.break(rpr_02), this);
            }
            this.protected(rYB2, rfH2);
        }
    }

    @Override
    public xc_0 class(rxx rxx2) {
        return this.class((rRq)rxx2.int(), this.public, rxx2.class());
    }

    private void class(rYB rYB2, rfH rfH2, xc_0 xc_02, xc_0 xc_03) {
        for (rpr_0 rpr_02 : rpb.HORIZONTAL) {
            rfH rfH3 = rfH2.break(rpr_02);
            if (((rCY)xc_02.byte(continue.get(rpr_02))).break() == ((rCY)xc_03.byte(continue.get(rpr_02))).break() || !rYB2.byte(rfH3).catch(rYB2, rfH3)) continue;
            rYB2.class(rfH3, xc_03.break(), rpr_02.case());
        }
    }

    @Override
    public ryz_1 class(xc_0 xc_02, rYB rYB2, rfH rfH2, rhd_2 rhd_22, rpm rpm2, rff rff2) {
        if (!((rhx_1)rhd_22.implements[18]).throws) {
            return ryz_1.PASS;
        }
        if (wu_2.volatile(xc_02) || wu_2.final(xc_02)) {
            xc_0 xc_03 = wu_2.volatile(xc_02) ? this.continue() : this.public;
            xc_03 = (xc_0)xc_03.class(new, xc_02.byte(new));
            if ((xc_03 = this.class((rRq)rYB2, xc_03, rfH2)) != xc_02) {
                rYB2.class(rfH2, xc_03, 3);
                this.class(rYB2, rfH2, xc_02, xc_03);
                return ryz_1.SUCCESS;
            }
        }
        return ryz_1.PASS;
    }

    @Override
    protected void class(rCL<xd_0, xc_0> rCL2) {
        rCL2.class(volatile, final, package, int, new);
    }

    @Override
    public xc_0 class(xc_0 xc_02, rpa rpa2) {
        switch (rpa2) {
            case LEFT_RIGHT: {
                return (xc_0)((xc_0)xc_02.class(volatile, xc_02.byte(package))).class(package, xc_02.byte(volatile));
            }
            case FRONT_BACK: {
                return (xc_0)((xc_0)xc_02.class(final, xc_02.byte(int))).class(int, xc_02.byte(final));
            }
        }
        return super.class(xc_02, rpa2);
    }

    @Override
    public xc_0 class(xc_0 xc_02, rqd_0 rqd_02) {
        switch (rqd_02) {
            case CLOCKWISE_180: {
                return (xc_0)((xc_0)((xc_0)((xc_0)xc_02.class(volatile, xc_02.byte(package))).class(final, xc_02.byte(int))).class(package, xc_02.byte(volatile))).class(int, xc_02.byte(final));
            }
            case COUNTERCLOCKWISE_90: {
                return (xc_0)((xc_0)((xc_0)((xc_0)xc_02.class(volatile, xc_02.byte(final))).class(final, xc_02.byte(package))).class(package, xc_02.byte(int))).class(int, xc_02.byte(volatile));
            }
            case CLOCKWISE_90: {
                return (xc_0)((xc_0)((xc_0)((xc_0)xc_02.class(volatile, xc_02.byte(int))).class(final, xc_02.byte(volatile))).class(package, xc_02.byte(final))).class(int, xc_02.byte(package));
            }
        }
        return xc_02;
    }

    @Override
    public void class(xc_0 xc_02, rYB rYB2, rfH rfH2, Random random) {
        int n2 = xc_02.byte(new);
        if (n2 != 0) {
            block4: for (rpr_0 rpr_02 : rpb.HORIZONTAL) {
                rCY rCY2 = (rCY)xc_02.byte(continue.get(rpr_02));
                switch (rCY2) {
                    case UP: {
                        this.class(rYB2, random, rfH2, return[n2], rpr_02, rpr_0.UP, -0.5f, 0.5f);
                    }
                    case SIDE: {
                        this.class(rYB2, random, rfH2, return[n2], rpr_0.DOWN, rpr_02, 0.0f, 0.5f);
                        continue block4;
                    }
                }
                this.class(rYB2, random, rfH2, return[n2], rpr_0.DOWN, rpr_02, 0.0f, 0.3f);
            }
        }
    }

    private void class(rYB rYB2, rfH rfH2, xc_0 xc_02) {
        int n2 = this.class(rYB2, rfH2);
        if (xc_02.byte(new) != n2) {
            if (rYB2.byte(rfH2) == xc_02) {
                rYB2.class(rfH2, (xc_0)xc_02.class(new, n2), 2);
            }
            HashSet hashSet = Sets.newHashSet();
            hashSet.add(rfH2);
            for (rpr_0 rpr_02 : rpr_0.values()) {
                hashSet.add(rfH2.break(rpr_02));
            }
            for (rfH rfH3 : hashSet) {
                rYB2.break(rfH3, this);
            }
        }
    }

    @Override
    public xc_0 class(xc_0 xc_02, rpr_0 rpr_02, xc_0 xc_03, rRg rRg2, rfH rfH2, rfH rfH3) {
        if (rpr_02 == rpr_0.DOWN) {
            return xc_02;
        }
        if (rpr_02 == rpr_0.UP) {
            return this.class((rRq)rRg2, xc_02, rfH2);
        }
        rCY rCY2 = this.class((rRq)rRg2, rfH2, rpr_02);
        return rCY2.break() == ((rCY)xc_02.byte(continue.get(rpr_02))).break() && !wu_2.volatile(xc_02) ? (xc_0)xc_02.class(continue.get(rpr_02), rCY2) : this.class((rRq)rRg2, (xc_0)((xc_0)this.public.class(new, xc_02.byte(new))).class(continue.get(rpr_02), rCY2), rfH2);
    }

    @Override
    public void class(xc_0 xc_02, rRg rRg2, rfH rfH2, int n2, int n3) {
        rfw rfw2 = new rfw();
        for (rpr_0 rpr_02 : rpb.HORIZONTAL) {
            Object object;
            Object object2;
            rCY rCY2 = (rCY)xc_02.byte(continue.get(rpr_02));
            if (rCY2 == rCY.NONE || rRg2.byte(rfw2.class((rja)rfH2, rpr_02)).class(this)) continue;
            rfw2.class(rpr_0.DOWN);
            xc_0 xc_03 = rRg2.byte(rfw2);
            if (!xc_03.class(xu_0.bK)) {
                object2 = rfw2.break(rpr_02.case());
                object = xc_03.class(rpr_02.case(), rRg2.byte((rfH)object2), rRg2, (rfH)rfw2, (rfH)object2);
                wu_2.class(xc_03, (xc_0)object, rRg2, rfw2, n2, n3);
            }
            rfw2.class((rja)rfH2, rpr_02).class(rpr_0.UP);
            object2 = rRg2.byte(rfw2);
            if (((jc_1)object2).class(xu_0.bK)) continue;
            object = rfw2.break(rpr_02.case());
            xc_0 xc_04 = ((jc_1)object2).class(rpr_02.case(), rRg2.byte((rfH)object), rRg2, (rfH)rfw2, (rfH)object);
            wu_2.class((xc_0)object2, xc_04, rRg2, rfw2, n2, n3);
        }
    }

    private rCY class(rRq rRq2, rfH rfH2, rpr_0 rpr_02) {
        return this.class(rRq2, rfH2, rpr_02, !rRq2.byte(rfH2.final()).catch(rRq2, rfH2));
    }

    @Override
    public boolean class(xc_0 xc_02, rRR rRR2, rfH rfH2) {
        rfH rfH3 = rfH2.break();
        xc_0 xc_03 = rRR2.byte(rfH3);
        return this.break((rRq)rRR2, rfH3, xc_03);
    }

    private rCY class(rRq rRq2, rfH rfH2, rpr_0 rpr_02, boolean bl2) {
        boolean bl3;
        rfH rfH3 = rfH2.break(rpr_02);
        xc_0 xc_02 = rRq2.byte(rfH3);
        if (bl2 && (bl3 = this.break(rRq2, rfH3, xc_02)) && wu_2.private(rRq2.byte(rfH3.final()))) {
            if (xc_02.protected(rRq2, rfH3, rpr_02.case())) {
                return rCY.UP;
            }
            return rCY.SIDE;
        }
        return !wu_2.class(xc_02, rpr_02) && (xc_02.catch(rRq2, rfH3) || !wu_2.private(rRq2.byte(rfH3.break()))) ? rCY.NONE : rCY.SIDE;
    }

    private xc_0 class(rRq rRq2, xc_0 xc_02, rfH rfH2) {
        boolean bl2;
        boolean bl3 = wu_2.final(xc_02);
        xc_02 = this.break(rRq2, (xc_0)this.continue().class(new, xc_02.byte(new)), rfH2);
        if (bl3 && wu_2.final(xc_02)) {
            return xc_02;
        }
        boolean bl4 = xc_02.byte(volatile).break();
        boolean bl5 = xc_02.byte(package).break();
        boolean bl6 = xc_02.byte(final).break();
        boolean bl7 = xc_02.byte(int).break();
        boolean bl8 = !bl4 && !bl5;
        boolean bl9 = bl2 = !bl6 && !bl7;
        if (!bl7 && bl8) {
            xc_02 = (xc_0)xc_02.class(int, rCY.SIDE);
        }
        if (!bl6 && bl8) {
            xc_02 = (xc_0)xc_02.class(final, rCY.SIDE);
        }
        if (!bl4 && bl2) {
            xc_02 = (xc_0)xc_02.class(volatile, rCY.SIDE);
        }
        if (!bl5 && bl2) {
            xc_02 = (xc_0)xc_02.class(package, rCY.SIDE);
        }
        return xc_02;
    }

    private int class(rYB rYB2, rfH rfH2) {
        this.goto = false;
        int n2 = rYB2.goto(rfH2);
        this.goto = true;
        int n3 = 0;
        if (n2 < 15) {
            for (rpr_0 rpr_02 : rpb.HORIZONTAL) {
                rfH rfH3 = rfH2.break(rpr_02);
                xc_0 xc_02 = rYB2.byte(rfH3);
                n3 = Math.max(n3, this.package(xc_02));
                rfH rfH4 = rfH2.final();
                if (xc_02.catch(rYB2, rfH3) && !rYB2.byte(rfH4).catch(rYB2, rfH4)) {
                    n3 = Math.max(n3, this.package(rYB2.byte(rfH3.final())));
                    continue;
                }
                if (xc_02.catch(rYB2, rfH3)) continue;
                n3 = Math.max(n3, this.package(rYB2.byte(rfH3.break())));
            }
        }
        return Math.max(n2, n3 - 1);
    }

    private xc_0 break(rRq rRq2, xc_0 xc_02, rfH rfH2) {
        boolean bl2 = !rRq2.byte(rfH2.final()).catch(rRq2, rfH2);
        for (rpr_0 rpr_02 : rpb.HORIZONTAL) {
            if (((rCY)xc_02.byte(continue.get(rpr_02))).break()) continue;
            rCY rCY2 = this.class(rRq2, rfH2, rpr_02, bl2);
            xc_02 = (xc_0)xc_02.class(continue.get(rpr_02), rCY2);
        }
        return xc_02;
    }

    private void break(rYB rYB2, rfH rfH2) {
        if (rYB2.byte(rfH2).class(this)) {
            rYB2.break(rfH2, this);
            for (rpr_0 rpr_02 : rpr_0.values()) {
                rYB2.break(rfH2.break(rpr_02), this);
            }
        }
    }

    @Override
    public void break(xc_0 xc_02, rYB rYB2, rfH rfH2, xc_0 xc_03, boolean bl2) {
        if (!bl2 && !xc_02.class(xc_03.break())) {
            super.break(xc_02, rYB2, rfH2, xc_03, bl2);
            if (!rYB2.continue) {
                for (rpr_0 rpr_02 : rpr_0.values()) {
                    rYB2.break(rfH2.break(rpr_02), this);
                }
                this.class(rYB2, rfH2, xc_02);
                this.protected(rYB2, rfH2);
            }
        }
    }

    @Override
    public int break(xc_0 xc_02, rRq rRq2, rfH rfH2, rpr_0 rpr_02) {
        return !this.goto ? 0 : xc_02.break(rRq2, rfH2, rpr_02);
    }

    private boolean break(rRq rRq2, rfH rfH2, xc_0 xc_02) {
        return xc_02.protected(rRq2, rfH2, rpr_0.UP) || xc_02.class(xu_0.sl);
    }

    private rjC implements(xc_0 xc_02) {
        rjC rjC2 = super;
        for (rpr_0 rpr_02 : rpb.HORIZONTAL) {
            rCY rCY2 = (rCY)xc_02.byte(continue.get(rpr_02));
            if (rCY2 == rCY.SIDE) {
                rjC2 = rjw.class(rjC2, this.get(rpr_02));
                continue;
            }
            if (rCY2 != rCY.UP) continue;
            rjC2 = rjw.class(rjC2, else.get(rpr_02));
        }
        return rjC2;
    }

    private int package(xc_0 xc_02) {
        return xc_02.class(this) ? xc_02.byte(new) : 0;
    }

    private void protected(rYB rYB2, rfH rfH2) {
        for (rpr_0 rpr_02 : rpb.HORIZONTAL) {
            this.break(rYB2, rfH2.break(rpr_02));
        }
        for (rpr_0 rpr_02 : rpb.HORIZONTAL) {
            rfH rfH3 = rfH2.break(rpr_02);
            if (rYB2.byte(rfH3).catch(rYB2, rfH3)) {
                this.break(rYB2, rfH3.final());
                continue;
            }
            this.break(rYB2, rfH3.break());
        }
    }

    protected static boolean private(xc_0 xc_02) {
        return wu_2.class(xc_02, (rpr_0)null);
    }

    private static boolean final(xc_0 xc_02) {
        return !xc_02.byte(volatile).break() && !xc_02.byte(package).break() && !xc_02.byte(final).break() && !xc_02.byte(int).break();
    }

    private static boolean volatile(xc_0 xc_02) {
        return xc_02.byte(volatile).break() && xc_02.byte(package).break() && xc_02.byte(final).break() && xc_02.byte(int).break();
    }
}

