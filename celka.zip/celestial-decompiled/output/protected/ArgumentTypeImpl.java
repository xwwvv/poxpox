/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.brigadier.arguments.ArgumentType
 */
package protected;

import com.mojang.brigadier.arguments.ArgumentType;
import protected.ri_0;
import protected.rqo_0;

/*
 * Renamed from protected.Rb
 * Illegal identifiers - consider using --renameillegalidents true
 */
class rb_0<T extends ArgumentType<?>> {
    public final Class<T> class;
    public final ri_0<T> break;
    public final rqo_0 byte;

    rb_0(Class<T> clazz, ri_0<T> ri_02, rqo_0 rqo_02) {
        this.class = clazz;
        this.break = ri_02;
        this.byte = rqo_02;
    }
}

