/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.datafixers.DSL
 *  com.mojang.datafixers.DSL$TypeReference
 *  com.mojang.datafixers.DataFix
 *  com.mojang.datafixers.OpticFinder
 *  com.mojang.datafixers.TypeRewriteRule
 *  com.mojang.datafixers.Typed
 *  com.mojang.datafixers.schemas.Schema
 *  com.mojang.datafixers.types.Type
 */
package protected;

import com.mojang.datafixers.DSL;
import com.mojang.datafixers.DataFix;
import com.mojang.datafixers.OpticFinder;
import com.mojang.datafixers.TypeRewriteRule;
import com.mojang.datafixers.Typed;
import com.mojang.datafixers.schemas.Schema;
import com.mojang.datafixers.types.Type;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.rwW
 */
public abstract class rww_0
extends DataFix {
    private final String class;
    private final String break;
    private final DSL.TypeReference byte;

    public rww_0(Schema schema, boolean bl2, String string, DSL.TypeReference typeReference, String string2) {
        super(schema, bl2);
        this.class = string;
        this.byte = typeReference;
        this.break = string2;
    }

    protected abstract Typed<?> class(Typed<?> var1);

    public TypeRewriteRule makeRule() {
        OpticFinder opticFinder = DSL.namedChoice((String)this.break, (Type)this.getInputSchema().getChoiceType(this.byte, this.break));
        return this.fixTypeEverywhereTyped(this.class, this.getInputSchema().getType(this.byte), this.getOutputSchema().getType(this.byte), typed -> typed.updateTyped(opticFinder, this.getOutputSchema().getChoiceType(this.byte, this.break), this::class));
    }
}

