/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.bt_1;
import protected.rja;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.Bn
 */
public class bn_2
extends bt_1 {
    private static byte[] byte;
    private static short[] protected;
    public Object[] class;
    private static boolean[] throws;

    public bn_2(String string, Pattern[] patternArray) {
        super(string);
        Pattern[] patternArray2;
        this.private();
        this.class[bn_2.protected[0]] = patternArray2 = patternArray;
    }

    static {
        bn_2.ntfClinit();
    }

    public void class(rja rja2) {
        this.private();
        rja rja3 = rja2;
        this.class[bn_2.protected[5]] = rja3;
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0xFB6054D49BCC4FAAL;
    }

    public static String class(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{69, -115, -28, -108, 35, -62, 118, -26}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0xA82ECE1A;
    }

    public rja break(String string) throws NullPointerException {
        this.private();
        if (((Pattern[])this.class[protected[1]]).length == 0) {
            throw new NullPointerException("\u041d\u0435 \u0443\u043a\u0430\u0437\u0430\u043d\u044b \u043f\u0430\u0442\u0442\u0435\u0440\u043d\u044b \u0434\u043b\u044f " + this.getClass().getSimpleName());
        }
        Pattern[] patternArray = (Pattern[])this.class[protected[2]];
        int n2 = patternArray.length;
        for (int k = throws[0]; k < n2; ++k) {
            Pattern pattern = patternArray[k];
            Matcher matcher = pattern.matcher(string);
            if (!matcher.find()) continue;
            try {
                int n3;
                int n4 = Integer.parseInt(matcher.group(throws[1]));
                int n5 = byte[0];
                int n6 = matcher.groupCount();
                String string2 = matcher.group(byte[1]);
                if (n6 == byte[2]) {
                    n3 = Integer.parseInt(string2);
                } else {
                    if (string2 != null) {
                        n5 = Integer.parseInt(string2);
                    }
                    n3 = Integer.parseInt(matcher.group(byte[3]));
                }
                return new rja(n4, n5, n3);
            }
            catch (Exception exception) {
                exception.printStackTrace();
                return null;
            }
        }
        return null;
    }

    public Pattern[] break() {
        this.private();
        return (Pattern[])this.class[protected[3]];
    }

    private static /* synthetic */ void ntfClinit() {
        bn_2.implements();
        bn_2.catch();
        bn_2.finally();
    }

    private static void finally() {
        byte = new byte[]{75, 2, 2, 3, 2};
    }

    private static void catch() {
        short[] sArray = new short[6];
        sArray[4] = 1;
        sArray[5] = 1;
        protected = sArray;
    }

    private static void implements() {
        boolean[] blArray = new boolean[2];
        blArray[1] = true;
        throws = blArray;
    }

    private void private() {
        if (this.class == null) {
            Object[] objectArray = this.class = new Object[byte[4]];
        }
    }

    public rja e_() {
        this.private();
        return (rja)this.class[protected[4]];
    }
}

