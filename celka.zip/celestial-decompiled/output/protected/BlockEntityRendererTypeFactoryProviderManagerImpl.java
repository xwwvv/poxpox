/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.rRp;
import protected.rYB;
import protected.rfH;
import protected.roj_0;
import protected.rox;
import protected.rpr_0;
import protected.rrsC;
import protected.rrse;
import protected.rxe_2;
import protected.ryg_0;
import protected.ryo_2;
import protected.xc_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.yW
 */
public class yw_2
implements rRp {
    protected final int class;
    protected final int break;
    protected final rfH byte;
    protected final int protected;
    protected final int throws;
    protected final int case;
    protected final roj_0[][] catch;
    protected final xc_0[] private;
    protected final rxe_2[] implements;
    protected final rYB finally;

    @Override
    public xc_0 byte(rfH rfH2) {
        int n2 = (rfH2.b_() >> 4) - this.class;
        int n3 = (rfH2.d_() >> 4) - this.break;
        return this.catch[n2][n3].byte(rfH2);
    }

    public yw_2(rYB rYB2, int n2, int n3, roj_0[][] roj_0Array, rfH rfH2, rfH rfH3) {
        this.finally = rYB2;
        this.class = n2;
        this.break = n3;
        this.catch = roj_0Array;
        this.byte = rfH2;
        this.protected = rfH3.b_() - rfH2.b_() + 1;
        this.throws = rfH3.c_() - rfH2.c_() + 1;
        this.case = rfH3.d_() - rfH2.d_() + 1;
        this.private = null;
        this.implements = null;
    }

    @Override
    public rrse class() {
        return this.finally.class();
    }

    @Override
    public float class(rpr_0 rpr_02, boolean bl2) {
        return this.finally.class(rpr_02, bl2);
    }

    public roj_0 class(int n2, int n3) {
        return this.catch[n2][n3];
    }

    @Override
    public ryo_2 class(rfH rfH2) {
        return this.class(rfH2, rox.IMMEDIATE);
    }

    public ryo_2 class(rfH rfH2, rox rox2) {
        int n2 = (rfH2.b_() >> 4) - this.class;
        int n3 = (rfH2.d_() >> 4) - this.break;
        return this.catch[n2][n3].class(rfH2, rox2);
    }

    @Override
    public int class(rfH rfH2, rrsC rrsC2) {
        return this.finally.class(rfH2, rrsC2);
    }

    public static yw_2 class(rYB rYB2, rfH rfH2, rfH rfH3, int n2) {
        return yw_2.class(rYB2, rfH2, rfH3, n2, true);
    }

    public static yw_2 class(rYB rYB2, rfH rfH2, rfH rfH3, int n2, boolean bl2) {
        int n3;
        int n4 = rfH2.b_() - n2 >> 4;
        int n5 = rfH2.d_() - n2 >> 4;
        int n6 = rfH3.b_() + n2 >> 4;
        int n7 = rfH3.d_() + n2 >> 4;
        roj_0[][] roj_0Array = new roj_0[n6 - n4 + 1][n7 - n5 + 1];
        for (n3 = n4; n3 <= n6; ++n3) {
            for (int k = n5; k <= n7; ++k) {
                roj_0Array[n3 - n4][k - n5] = rYB2.throws(n3, k);
            }
        }
        if (bl2 && yw_2.class(rfH2, rfH3, n4, n5, roj_0Array)) {
            return null;
        }
        n3 = 1;
        rfH rfH4 = rfH2.break(-1, -1, -1);
        rfH rfH5 = rfH3.break(1, 1, 1);
        return new yw_2(rYB2, n4, n5, roj_0Array, rfH4, rfH5);
    }

    public static boolean class(rfH rfH2, rfH rfH3, int n2, int n3, roj_0[][] roj_0Array) {
        for (int k = rfH2.b_() >> 4; k <= rfH3.b_() >> 4; ++k) {
            for (int i2 = rfH2.d_() >> 4; i2 <= rfH3.d_() >> 4; ++i2) {
                roj_0 roj_02 = roj_0Array[k - n2][i2 - n3];
                if (roj_02.class(rfH2.c_(), rfH3.c_())) continue;
                return false;
            }
        }
        return true;
    }

    protected int class(int n2, int n3, int n4) {
        int n5 = n2 - this.byte.b_();
        int n6 = n3 - this.byte.c_();
        int n7 = n4 - this.byte.d_();
        return n7 * this.protected * this.throws + n6 * this.protected + n5;
    }

    @Override
    public rxe_2 break(rfH rfH2) {
        int n2 = (rfH2.b_() >> 4) - this.class;
        int n3 = (rfH2.d_() >> 4) - this.break;
        return this.catch[n2][n3].break(rfH2);
    }

    public ryg_0 throws(rfH rfH2) {
        return this.finally.implements(rfH2);
    }

    protected final int protected(rfH rfH2) {
        return this.class(rfH2.b_(), rfH2.c_(), rfH2.d_());
    }
}

