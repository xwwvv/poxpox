/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.rYB;
import protected.rab_2;
import protected.rdb_1;
import protected.rdn_1;
import protected.rdy_2;
import protected.rkf_1;
import protected.rqo_0;
import protected.rwn_2;
import protected.rxk_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.rWZ
 */
public class rwz_1
extends rwn_2 {
    public rwz_1(rqo_0 rqo_02) {
        super(rqo_02);
    }

    @Override
    public boolean class(int n2, int n3) {
        return n2 >= 2 && n3 >= 2;
    }

    @Override
    public rdn_1 class(rxk_1 rxk_12) {
        rdn_1 rdn_12 = rxk_12.extends(1 + rxk_12.protected());
        if (rdn_12.break() != rdy_2.kQ) {
            return rdn_1.break;
        }
        rdn_1 rdn_13 = new rdn_1(rdy_2.kz, 8);
        rab_2.class(rdn_13, rab_2.protected(rdn_12));
        rab_2.class(rdn_13, rab_2.break(rdn_12));
        return rdn_13;
    }

    @Override
    public boolean class(rxk_1 rxk_12, rYB rYB2) {
        if (rxk_12.protected() == 3 && rxk_12.byte() == 3) {
            for (int k = 0; k < rxk_12.protected(); ++k) {
                for (int i2 = 0; i2 < rxk_12.byte(); ++i2) {
                    rdn_1 rdn_12 = rxk_12.extends(k + i2 * rxk_12.protected());
                    if (rdn_12.class()) {
                        return false;
                    }
                    rdb_1 rdb_12 = rdn_12.break();
                    if (!(k == 1 && i2 == 1 ? rdb_12 != rdy_2.kQ : rdb_12 != rdy_2.OO)) continue;
                    return false;
                }
            }
            return true;
        }
        return false;
    }

    @Override
    public rkf_1<?> W_() {
        return rkf_1.finally;
    }
}

