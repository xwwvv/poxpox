/*
 * Decompiled with CFR 0.152.
 */
package protected;

import com.mojang.blaze3d.systems.RenderSystem;
import protected.cj_0;
import protected.fY;
import protected.fj_0;
import protected.ju_0;
import protected.lD;
import protected.yb_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.Cd
 */
class cd_0
implements cj_0 {
    cd_0() {
    }

    public String toString() {
        return "PARTICLE_SHEET_OPAQUE";
    }

    @Override
    public void class(lD lD2, fY fY2) {
        RenderSystem.disableBlend();
        RenderSystem.depthMask(true);
        fY2.class(fj_0.break);
        lD2.class(7, ju_0.continue);
    }

    @Override
    public void class(yb_1 yb_12) {
        yb_12.break();
    }
}

