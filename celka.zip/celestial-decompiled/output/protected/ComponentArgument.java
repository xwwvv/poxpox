/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonParseException
 *  com.mojang.brigadier.ImmutableStringReader
 *  com.mojang.brigadier.StringReader
 *  com.mojang.brigadier.arguments.ArgumentType
 *  com.mojang.brigadier.context.CommandContext
 *  com.mojang.brigadier.exceptions.CommandSyntaxException
 *  com.mojang.brigadier.exceptions.DynamicCommandExceptionType
 */
package protected;

import com.google.gson.JsonParseException;
import com.mojang.brigadier.ImmutableStringReader;
import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.DynamicCommandExceptionType;
import java.util.Arrays;
import java.util.Collection;
import protected.gy_0;
import protected.rVi;
import protected.rgP;
import protected.rgb_0;
import protected.rgn;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.RQ
 */
public class rq_0
implements ArgumentType<rgP> {
    private static final Collection<String> break = Arrays.asList("\"hello world\"", "\"\"", "\"{\"text\":\"hello world\"}", "[\"\"]");
    public static final DynamicCommandExceptionType class = new DynamicCommandExceptionType(object -> new rgn("argument.component.invalid", object));

    private rq_0() {
    }

    public static rgP class(CommandContext<gy_0> commandContext, String string) {
        return (rgP)commandContext.getArgument(string, rgP.class);
    }

    public rgP class(StringReader stringReader) throws CommandSyntaxException {
        try {
            rVi rVi2 = rgb_0.class(stringReader);
            if (rVi2 == null) {
                throw rq_0.class.createWithContext((ImmutableStringReader)stringReader, (Object)"empty");
            }
            return rVi2;
        }
        catch (JsonParseException jsonParseException) {
            String string = jsonParseException.getCause() != null ? jsonParseException.getCause().getMessage() : jsonParseException.getMessage();
            throw rq_0.class.createWithContext((ImmutableStringReader)stringReader, (Object)string);
        }
    }

    public static rq_0 class() {
        return new rq_0();
    }

    public /* synthetic */ Object parse(StringReader stringReader) throws CommandSyntaxException {
        return this.class(stringReader);
    }

    public Collection<String> getExamples() {
        return break;
    }
}

