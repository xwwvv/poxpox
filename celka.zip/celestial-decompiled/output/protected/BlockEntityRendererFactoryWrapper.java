/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonObject
 */
package protected;

import com.google.gson.JsonObject;
import protected.hr_1;
import protected.rqo_0;
import protected.rwh_1;
import protected.xs_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.XE
 */
public class xe_2
implements hr_1 {
    @Override
    public rqo_0 class() {
        return xs_1.class;
    }

    @Override
    public JsonObject class(rwh_1 rwh_12) {
        return new JsonObject();
    }
}

