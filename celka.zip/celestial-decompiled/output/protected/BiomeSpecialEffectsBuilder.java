/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.util.Optional;
import java.util.OptionalInt;
import protected.ns_2;
import protected.rYV;
import protected.rYg;
import protected.rYj;
import protected.rqa_0;
import protected.ryq_0;
import protected.ryw_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.rYz
 */
public class ryz_0 {
    private OptionalInt class = OptionalInt.empty();
    private OptionalInt break = OptionalInt.empty();
    private OptionalInt byte = OptionalInt.empty();
    private OptionalInt protected = OptionalInt.empty();
    private Optional<Integer> throws = Optional.empty();
    private Optional<Integer> case = Optional.empty();
    private ryq_0 catch = ryq_0.NONE;
    private Optional<rYV> private = Optional.empty();
    private Optional<rqa_0> implements = Optional.empty();
    private Optional<rYj> finally = Optional.empty();
    private Optional<rYg> extends = Optional.empty();
    private Optional<ns_2> native = Optional.empty();

    public ryz_0 byte(int n2) {
        this.byte = OptionalInt.of(n2);
        return this;
    }

    public ryz_0 class(rYV rYV2) {
        this.private = Optional.of(rYV2);
        return this;
    }

    public ryz_0 class(rqa_0 rqa_02) {
        this.implements = Optional.of(rqa_02);
        return this;
    }

    public ryz_0 class(rYj rYj2) {
        this.finally = Optional.of(rYj2);
        return this;
    }

    public ryz_0 class(rYg rYg2) {
        this.extends = Optional.of(rYg2);
        return this;
    }

    public ryz_0 class(ns_2 ns_22) {
        this.native = Optional.of(ns_22);
        return this;
    }

    public ryw_0 class() {
        return new ryw_0(this.class.orElseThrow(() -> new IllegalStateException("Missing 'fog' color.")), this.break.orElseThrow(() -> new IllegalStateException("Missing 'water' color.")), this.byte.orElseThrow(() -> new IllegalStateException("Missing 'water fog' color.")), this.protected.orElseThrow(() -> new IllegalStateException("Missing 'sky' color.")), this.throws, this.case, this.catch, this.private, this.implements, this.finally, this.extends, this.native);
    }

    public ryz_0 class(ryq_0 ryq_02) {
        this.catch = ryq_02;
        return this;
    }

    public ryz_0 class(int n2) {
        this.class = OptionalInt.of(n2);
        return this;
    }

    public ryz_0 break(int n2) {
        this.break = OptionalInt.of(n2);
        return this;
    }

    public ryz_0 throws(int n2) {
        this.throws = Optional.of(n2);
        return this;
    }

    public ryz_0 case(int n2) {
        this.case = Optional.of(n2);
        return this;
    }

    public ryz_0 protected(int n2) {
        this.protected = OptionalInt.of(n2);
        return this;
    }
}

