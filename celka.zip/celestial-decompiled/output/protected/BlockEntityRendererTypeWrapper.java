/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonObject
 */
package protected;

import com.google.gson.JsonObject;
import protected.an;
import protected.hg_2;
import protected.hl_2;
import protected.ho_1;
import protected.hy_1;
import protected.hz_1;
import protected.rhn_2;
import protected.rqo_0;
import protected.rwl_1;
import protected.rye_1;
import protected.rzr_2;
import protected.xf_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.XI
 */
public class xi_2
extends hg_2<xf_1> {
    static final rqo_0 class = new rqo_0("player_hurt_entity");

    public void class(rhn_2 rhn_22, an an2, rye_1 rye_12, float f2, float f3, boolean bl2) {
        rzr_2 rzr_22 = hy_1.break(rhn_22, an2);
        this.class(rhn_22, (T xf_12) -> xf_12.class(rhn_22, rzr_22, rye_12, f2, f3, bl2));
    }

    @Override
    public rqo_0 class() {
        return xi_2.class;
    }

    @Override
    public /* synthetic */ hz_1 class(JsonObject jsonObject, ho_1 ho_12, rwl_1 rwl_12) {
        return this.break(jsonObject, ho_12, rwl_12);
    }

    public xf_1 break(JsonObject jsonObject, ho_1 ho_12, rwl_1 rwl_12) {
        hl_2 hl_22 = hl_2.class(jsonObject.get("damage"));
        ho_1 ho_13 = ho_1.class(jsonObject, "entity", rwl_12);
        return new xf_1(ho_12, hl_22, ho_13);
    }
}

