/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.ai_0;
import protected.an;
import protected.iq_1;
import protected.is;
import protected.iy_2;
import protected.rbj_0;
import protected.rbk_0;
import protected.rbm_0;
import protected.rfU;
import protected.wh_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.wO
 */
public class wo_0<T extends is>
extends wh_0<T> {
    public final iq_1 native;
    public final iq_1 volatile;
    private final iq_1 goto;
    private final iq_1 while;
    private final iq_1 try;
    private final iq_1 instanceof;

    public wo_0(float f2, int n2, int n3) {
        super(f2, false);
        this.return = n2;
        this.public = n3;
        this.byte = new iq_1(this, 16, 16);
        this.byte.class(-4.0f, 0.0f, -2.0f, 8.0f, 12.0f, 4.0f, f2);
        this.class = new iq_1(this);
        this.class.class(0, 0).class(-5.0f, -8.0f, -4.0f, 10.0f, 8.0f, 8.0f, f2);
        this.class.class(31, 1).class(-2.0f, -4.0f, -5.0f, 4.0f, 4.0f, 1.0f, f2);
        this.class.class(2, 4).class(2.0f, -2.0f, -5.0f, 1.0f, 2.0f, 1.0f, f2);
        this.class.class(2, 0).class(-3.0f, -2.0f, -5.0f, 1.0f, 2.0f, 1.0f, f2);
        this.native = new iq_1(this);
        this.native.class(4.5f, -6.0f, 0.0f);
        this.native.class(51, 6).class(0.0f, 0.0f, -2.0f, 1.0f, 5.0f, 4.0f, f2);
        this.class.break(this.native);
        this.volatile = new iq_1(this);
        this.volatile.class(-4.5f, -6.0f, 0.0f);
        this.volatile.class(39, 6).class(-1.0f, 0.0f, -2.0f, 1.0f, 5.0f, 4.0f, f2);
        this.class.break(this.volatile);
        this.break = new iq_1(this);
        this.goto = this.byte.class();
        this.while = this.class.class();
        this.try = this.throws.class();
        this.instanceof = this.throws.class();
    }

    private void class(T t2) {
        if (((is)t2).Z()) {
            this.throws.case = -1.8f;
        } else {
            this.protected.case = -1.8f;
        }
    }

    @Override
    protected void class(T t2, float f2) {
        if (this.final > 0.0f && t2 instanceof rbk_0 && ((rbk_0)t2).sd() == rbj_0.ATTACKING_WITH_MELEE_WEAPON) {
            iy_2.class(this.protected, this.throws, t2, this.final, f2);
        } else {
            super.class(t2, f2);
        }
    }

    @Override
    public void class(T t2, float f2, float f3, float f4, float f5, float f6) {
        this.byte.class(this.goto);
        this.class.class(this.while);
        this.throws.class(this.try);
        this.protected.class(this.instanceof);
        super.class(t2, f2, f3, f4, f5, f6);
        float f7 = 0.5235988f;
        float f8 = f4 * 0.1f + f2 * 0.5f;
        float f9 = 0.08f + f3 * 0.4f;
        this.native.private = -0.5235988f - rfU.break(f8 * 1.2f) * f9;
        this.volatile.private = 0.5235988f + rfU.break(f8) * f9;
        if (t2 instanceof rbm_0) {
            rbm_0 rbm_02 = (rbm_0)t2;
            rbj_0 rbj_02 = rbm_02.sd();
            if (rbj_02 == rbj_0.DANCING) {
                float f10 = f4 / 60.0f;
                this.volatile.private = 0.5235988f + (float)Math.PI / 180 * rfU.class(f10 * 30.0f) * 10.0f;
                this.native.private = -0.5235988f - (float)Math.PI / 180 * rfU.break(f10 * 30.0f) * 10.0f;
                this.class.byte = rfU.class(f10 * 10.0f);
                this.class.protected = rfU.class(f10 * 40.0f) + 0.4f;
                this.protected.private = (float)Math.PI / 180 * (70.0f + rfU.break(f10 * 40.0f) * 10.0f);
                this.throws.private = this.protected.private * -1.0f;
                this.protected.protected = rfU.class(f10 * 40.0f) * 0.5f + 1.5f;
                this.throws.protected = rfU.class(f10 * 40.0f) * 0.5f + 1.5f;
                this.byte.protected = rfU.class(f10 * 40.0f) * 0.35f;
            } else if (rbj_02 == rbj_0.ATTACKING_WITH_MELEE_WEAPON && this.final == 0.0f) {
                this.class(t2);
            } else if (rbj_02 == rbj_0.CROSSBOW_HOLD) {
                iy_2.class(this.protected, this.throws, this.class, !((is)t2).Z());
            } else if (rbj_02 == rbj_0.CROSSBOW_CHARGE) {
                iy_2.class(this.protected, this.throws, t2, !((is)t2).Z());
            } else if (rbj_02 == rbj_0.ADMIRING_ITEM) {
                this.class.case = 0.5f;
                this.class.catch = 0.0f;
                if (((is)t2).Z()) {
                    this.protected.catch = -0.5f;
                    this.protected.case = -0.9f;
                } else {
                    this.throws.catch = 0.5f;
                    this.throws.case = -0.9f;
                }
            }
        } else if (((an)t2).BC() == ai_0.rb) {
            iy_2.class(this.throws, this.protected, ((is)t2).v(), this.final, f4);
        }
        this.super.class(this.catch);
        this.this.class(this.case);
        this.new.class(this.throws);
        this.continue.class(this.protected);
        this.else.class(this.byte);
        this.break.class(this.class);
    }
}

