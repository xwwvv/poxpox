/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.stream.Stream;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.for;
import protected.rfU;
import protected.rs_2;
import protected.ru_1;
import protected.s;
import protected.static;
import protected.switch;
import protected.x;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class b
extends Enum<b>
implements switch<rs_2, ru_1> {
    private static short[] shortsdf0e2a18debd3d38bfaf4a483a1d8c36;
    private static boolean[] booleansdf0e2a18debd3d38bfaf4a483a1d8c36;
    private static String[] stringsdf0e2a18debd3d38bfaf4a483a1d8c36;
    private static byte[] bytesdf0e2a18debd3d38bfaf4a483a1d8c36;
    public static Object[] staticFieldsdf0e2a18debd3d38bfaf4a483a1d8c36;

    private static void byte() {
        stringsdf0e2a18debd3d38bfaf4a483a1d8c36 = new String[]{new String("INSTANCE")};
    }

    static {
        b.ntfClinit();
    }

    public static b[] values() {
        return (b[])((b[])staticFieldsdf0e2a18debd3d38bfaf4a483a1d8c36[shortsdf0e2a18debd3d38bfaf4a483a1d8c36[0]]).clone();
    }

    public static b valueOf(String string) {
        return Enum.valueOf(b.class, string);
    }

    @Override
    public Stream<String> class(for for_) {
        static static_ = for_.class();
        if (static_.catch(bytesdf0e2a18debd3d38bfaf4a483a1d8c36[0])) {
            return static_.class((s)s.staticFields2f6c75eddeaf3dec901642e9ef998dc8[shortsdf0e2a18debd3d38bfaf4a483a1d8c36[8]]);
        }
        return Stream.empty();
    }

    private static /* synthetic */ b[] class() {
        b[] bArray = new b[booleansdf0e2a18debd3d38bfaf4a483a1d8c36[0]];
        bArray[b.booleansdf0e2a18debd3d38bfaf4a483a1d8c36[1]] = (b)staticFieldsdf0e2a18debd3d38bfaf4a483a1d8c36[shortsdf0e2a18debd3d38bfaf4a483a1d8c36[9]];
        return bArray;
    }

    public static String class(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{48, -100, 29, -15, 105, -123, 76, 57}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    @Override
    public rs_2 class(for for_, ru_1 ru_12) throws x {
        if (ru_12 == null) {
            ru_12 = (ru_1)ru_1.class[shortsdf0e2a18debd3d38bfaf4a483a1d8c36[1]];
        }
        static static_ = for_.class();
        return new rs_2(rfU.byte((Double)static_.break((s)s.staticFields2f6c75eddeaf3dec901642e9ef998dc8[shortsdf0e2a18debd3d38bfaf4a483a1d8c36[2]], Double.valueOf(((Integer)ru_12.break[shortsdf0e2a18debd3d38bfaf4a483a1d8c36[3]]).intValue()))), rfU.byte((Double)static_.break((s)s.staticFields2f6c75eddeaf3dec901642e9ef998dc8[shortsdf0e2a18debd3d38bfaf4a483a1d8c36[4]], Double.valueOf(((Integer)ru_12.break[shortsdf0e2a18debd3d38bfaf4a483a1d8c36[5]]).intValue()))), rfU.byte((Double)static_.break((s)s.staticFields2f6c75eddeaf3dec901642e9ef998dc8[shortsdf0e2a18debd3d38bfaf4a483a1d8c36[6]], Double.valueOf(((Integer)ru_12.break[shortsdf0e2a18debd3d38bfaf4a483a1d8c36[7]]).intValue()))));
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0x11E02825;
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0x592103D9B677995AL;
    }

    private static void break() {
        bytesdf0e2a18debd3d38bfaf4a483a1d8c36 = new byte[]{3, 2};
    }

    private static void throws() {
        boolean[] blArray = new boolean[5];
        blArray[0] = true;
        blArray[4] = true;
        booleansdf0e2a18debd3d38bfaf4a483a1d8c36 = blArray;
    }

    private static /* synthetic */ void ntfClinit() {
        b.throws();
        b.byte();
        b.protected();
        b.break();
        b.case();
    }

    private static void case() {
        Object[] objectArray;
        objectArray = new Object[]{new b(), new b[]{(b)objectArray[0]}};
        staticFieldsdf0e2a18debd3d38bfaf4a483a1d8c36 = objectArray;
    }

    private static void protected() {
        short[] sArray = new short[10];
        sArray[0] = 1;
        sArray[5] = 1;
        sArray[7] = 2;
        shortsdf0e2a18debd3d38bfaf4a483a1d8c36 = sArray;
    }
}

