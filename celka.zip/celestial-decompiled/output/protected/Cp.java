/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableList
 */
package protected;

import com.google.common.collect.ImmutableList;
import java.util.List;
import java.util.Random;
import protected.ch_0;
import protected.cy_0;
import protected.fj;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
class Cp
implements ch_0 {
    private List<fj> class;

    Cp(cy_0 cy_02) {
    }

    public void class(List<fj> list) {
        this.class = ImmutableList.copyOf(list);
    }

    @Override
    public fj class(Random random) {
        return this.class.get(random.nextInt(this.class.size()));
    }

    @Override
    public fj class(int n2, int n3) {
        return this.class.get(n2 * (this.class.size() - 1) / n3);
    }
}

