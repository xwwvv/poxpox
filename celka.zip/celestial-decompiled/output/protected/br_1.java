/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Optional;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.V;
import protected.bb_2;
import protected.bp_1;
import protected.bs_1;
import protected.bs_2;
import protected.class;
import protected.g;
import protected.j;
import protected.package;
import protected.pj_2;
import protected.ps_1;
import protected.pv_2;
import protected.px_2;
import protected.q;
import protected.rrax_0;
import protected.rraz_0;
import protected.rrtj_1;
import protected.rrtq_1;
import protected.rrtt_1;
import protected.rus_2;
import protected.rz_2;
import protected.rzj_0;
import protected.rzo_0;
import protected.rzx_0;
import protected.t;
import protected.throws;
import protected.volatile;
import protected.y_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.Br
 */
public class br_1
extends pv_2
implements volatile {
    private static float[] byte;
    private static short[] protected;
    private static boolean[] throws;
    public Object[] break;
    private static byte[] case;

    @Override
    public px_2 byte() {
        rrtj_1 rrtj_12 = this.break();
        if (rrtj_12 == null) {
            return null;
        }
        return (px_2)((bs_1)rrtj_12).class[protected[4]];
    }

    public br_1(class clazz) {
        super(clazz);
        this.case();
        bb_2 bb_22 = new bb_2(clazz.throw());
        this.break[br_1.protected[0]] = bb_22;
    }

    static {
        br_1.ntfClinit();
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0xAF00441A;
    }

    @Override
    public void class(j j2) {
        this.case();
        if (j2.class() == (V)((Object)V.staticFields30e1cd8580ce39faa61be3646b7cc079[protected[5]])) {
            ((bb_2)this.break[protected[6]]).break();
            Object var6_2 = null;
            this.break[br_1.protected[7]] = var6_2;
        }
    }

    @Override
    public void class(t t2) {
        this.case();
        if ((bs_1)this.break[protected[44]] != null) {
            px_2 px_22 = ((bb_2)this.break[protected[45]]).class((px_2)((bs_1)this.break[br_1.protected[46]]).class[protected[47]]);
            t2.class(px_22);
        }
    }

    @Override
    public void class(rraz_0 rraz_02) {
        this.case();
        if ((bs_1)this.break[protected[37]] != null) {
            rrtq_1 rrtq_12;
            rz_2 rz_22 = protected.throws.byte().void().throws();
            if (rz_22 != null && (rrtq_12 = rz_22.throws()) != null) {
                rraz_02.class(rrtq_12.break());
                rraz_02.class(rrtq_12.class());
                return;
            }
            rraz_02.class(((ps_1)this.class[protected[38]]).catch().goto());
            rraz_02.class(pj_2.class(((ps_1)this.class[protected[39]]).catch().goto(), rraz_02.protected(), throws[0]));
        }
    }

    @Override
    public void class(g g2) {
        this.finally();
    }

    @Override
    public void class(q q2) {
        this.case();
        if ((bs_1)this.break[protected[8]] == null) {
            return;
        }
        switch (((int[])bp_1.class[protected[9]])[q2.class().ordinal()]) {
            case 1: {
                if ((bs_2)((Object)((bs_1)this.break[br_1.protected[10]]).class[protected[11]]) == (bs_2)((Object)bs_2.staticFieldsab676614e82b32e79a1e1e0ca1d59f08[protected[12]])) {
                    return;
                }
                br_1 br_12 = this;
                rrtt_1.break[br_1.protected[13]] = br_12;
                if ((bs_2)((Object)((bs_1)this.break[br_1.protected[14]]).class[protected[15]]) == (bs_2)((Object)bs_2.staticFieldsab676614e82b32e79a1e1e0ca1d59f08[protected[16]])) {
                    px_2 px_22 = new px_2(((Float)((ps_1)this.class[br_1.protected[17]]).catch().throws[protected[18]]).floatValue(), ((Float)((ps_1)this.class[br_1.protected[19]]).catch().throws[protected[20]]).floatValue());
                    this.break[br_1.protected[21]] = px_22;
                }
                px_2 px_23 = ((bb_2)this.break[protected[22]]).class((px_2)((bs_1)this.break[br_1.protected[23]]).class[protected[24]]);
                Float f2 = Float.valueOf(px_23.throws());
                ((ps_1)this.class[br_1.protected[25]]).catch().throws[br_1.protected[26]] = f2;
                Float f3 = Float.valueOf(px_23.protected());
                ((ps_1)this.class[br_1.protected[27]]).catch().throws[br_1.protected[28]] = f3;
                break;
            }
            case 2: {
                if ((px_2)this.break[protected[29]] == null) break;
                Float f4 = Float.valueOf(((px_2)this.break[protected[31]]).throws());
                ((ps_1)this.class[br_1.protected[30]]).catch().throws[br_1.protected[32]] = f4;
                Float f5 = Float.valueOf(((px_2)this.break[protected[34]]).protected());
                ((ps_1)this.class[br_1.protected[33]]).catch().throws[br_1.protected[35]] = f5;
                Object var13_9 = null;
                this.break[br_1.protected[36]] = var13_9;
            }
        }
    }

    public void class(px_2 px_22, boolean bl2) {
        this.case();
        bs_1 bs_12 = new bs_1(px_22, bl2);
        this.break[br_1.protected[1]] = bs_12;
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0x465FB2275E1D5E25L;
    }

    @Override
    public package class() {
        this.case();
        return (bb_2)this.break[protected[2]];
    }

    @Override
    public void class(rrax_0 rrax_02) {
        this.case();
        if ((bs_1)this.break[protected[40]] != null) {
            px_2 px_22 = ((bb_2)this.break[protected[41]]).class((px_2)((bs_1)this.break[br_1.protected[42]]).class[protected[43]]);
            rrax_02.class(px_22);
        }
    }

    @Override
    public rrtj_1 break() {
        this.case();
        return (bs_1)this.break[protected[3]];
    }

    public static String break(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{-30, -116, -70, -25, 122, -106, -99, -92}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    @Override
    public void break(y_0 y_02) {
        rzo_0 rzo_02;
        this.case();
        rus_2<?> rus_22 = y_02.protected();
        if (rus_22 instanceof rzo_0 && ((rzo_02 = (rzo_0)rus_22) instanceof rzj_0 || rzo_02 instanceof rzx_0)) {
            px_2 px_22 = new px_2(rzo_02.class(byte[0]), rzo_02.break(byte[1]));
            this.break[br_1.protected[48]] = px_22;
        }
    }

    public void throws() {
        this.case();
        if ((bs_1)this.break[protected[51]] != null) {
            px_2 px_22 = ((bb_2)this.break[protected[52]]).class((px_2)((bs_1)this.break[br_1.protected[53]]).class[protected[54]]);
            Float f2 = Float.valueOf(px_22.throws());
            ((ps_1)this.class[br_1.protected[55]]).catch().throws[br_1.protected[56]] = f2;
        }
    }

    private static /* synthetic */ void ntfClinit() {
        br_1.private();
        br_1.catch();
        br_1.implements();
        br_1.extends();
    }

    private void finally() {
        this.case();
        Object var5_1 = null;
        this.break[br_1.protected[49]] = var5_1;
        Object var6_2 = null;
        this.break[br_1.protected[50]] = var6_2;
    }

    private static void catch() {
        short[] sArray = new short[59];
        sArray[0] = 3;
        sArray[2] = 3;
        sArray[6] = 3;
        sArray[11] = 1;
        sArray[12] = 2;
        sArray[13] = 3;
        sArray[15] = 1;
        sArray[16] = 1;
        sArray[17] = 1;
        sArray[18] = 15;
        sArray[19] = 1;
        sArray[20] = 16;
        sArray[21] = 2;
        sArray[22] = 3;
        sArray[25] = 1;
        sArray[26] = 15;
        sArray[27] = 1;
        sArray[28] = 16;
        sArray[29] = 2;
        sArray[30] = 1;
        sArray[31] = 2;
        sArray[32] = 15;
        sArray[33] = 1;
        sArray[34] = 2;
        sArray[35] = 16;
        sArray[36] = 2;
        sArray[38] = 1;
        sArray[39] = 1;
        sArray[41] = 3;
        sArray[45] = 3;
        sArray[48] = 1;
        sArray[49] = 1;
        sArray[52] = 3;
        sArray[55] = 1;
        sArray[56] = 15;
        sArray[58] = 1;
        protected = sArray;
    }

    private static void extends() {
        case = new byte[]{4};
    }

    private void case() {
        if (this.break == null) {
            Object[] objectArray = this.break = new Object[case[0]];
        }
    }

    private static void implements() {
        byte = new float[2];
    }

    public Optional<px_2> protected() {
        this.case();
        if (((Boolean)protected.class.instanceof().n.class[protected[57]]).booleanValue()) {
            return Optional.ofNullable((px_2)this.break[protected[58]]);
        }
        return Optional.empty();
    }

    private static void private() {
        throws = new boolean[1];
    }

    @Override
    public void native() {
        super.native();
        this.finally();
    }
}

