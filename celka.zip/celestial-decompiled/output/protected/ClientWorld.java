/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 *  com.google.common.collect.Maps
 *  it.unimi.dsi.fastutil.ints.Int2ObjectMap
 *  it.unimi.dsi.fastutil.ints.Int2ObjectMap$Entry
 *  it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap
 *  it.unimi.dsi.fastutil.objects.Object2ObjectArrayMap
 *  it.unimi.dsi.fastutil.objects.ObjectIterator
 */
package protected;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import it.unimi.dsi.fastutil.ints.Int2ObjectMap;
import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.objects.Object2ObjectArrayMap;
import it.unimi.dsi.fastutil.objects.ObjectIterator;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.function.BooleanSupplier;
import protected.KU;
import protected.KY;
import protected.Ko;
import protected.an;
import protected.ao_2;
import protected.aq_1;
import protected.ax_1;
import protected.cb_0;
import protected.cb_1;
import protected.cg_2;
import protected.cy_0;
import protected.gf_0;
import protected.gv_0;
import protected.hh_0;
import protected.nd_2;
import protected.np_1;
import protected.nq_2;
import protected.qw_1;
import protected.qy_1;
import protected.rKv;
import protected.rRV;
import protected.rRl;
import protected.rVm;
import protected.rYB;
import protected.rYl;
import protected.rYm;
import protected.rcd_2;
import protected.rdn_1;
import protected.rfH;
import protected.rfR;
import protected.rfU;
import protected.rfw;
import protected.rgP;
import protected.rgn;
import protected.rhd_2;
import protected.rjC;
import protected.rjU;
import protected.rlq_0;
import protected.rlq_2;
import protected.rls;
import protected.rlx_1;
import protected.rnW;
import protected.rns_0;
import protected.roj_0;
import protected.ron_0;
import protected.rox_0;
import protected.rpb_0;
import protected.rpr_0;
import protected.rqR;
import protected.rqa_0;
import protected.rql_0;
import protected.rqm_0;
import protected.rrGb;
import protected.rrGs;
import protected.rraq_0;
import protected.rrbb;
import protected.rrbg;
import protected.rrbl;
import protected.rrdZ;
import protected.rrd_0;
import protected.rrfd_1;
import protected.rrfk_1;
import protected.rrj_0;
import protected.rrjf_1;
import protected.rrme_1;
import protected.rrnb;
import protected.rrnc_0;
import protected.rrnm_0;
import protected.rrqx_1;
import protected.rrsC;
import protected.rru_0;
import protected.rrxr_0;
import protected.rud_1;
import protected.rus_2;
import protected.rvl_0;
import protected.rwb_2;
import protected.rxe_2;
import protected.rxs_1;
import protected.ryg_0;
import protected.xc_0;
import protected.xd_0;
import protected.xu_0;
import protected.yl_1;
import protected.yx_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class gm
extends rYB {
    private final Int2ObjectMap<an> this = new Int2ObjectOpenHashMap();
    private final aq_1 else;
    private final yx_1 synchronized;
    private final gv_0 return;
    private final gf_0 public;
    private final qy_1 goto = qy_1.instanceof();
    private final List<cg_2> while = Lists.newArrayList();
    private rns_0 try = new rns_0();
    private final Map<String, rrGb> instanceof = Maps.newHashMap();
    private int throw;
    private final Object2ObjectArrayMap<rrsC, yl_1> interface = rqR.class(new Object2ObjectArrayMap(3), (T object2ObjectArrayMap) -> {
        object2ObjectArrayMap.put((Object)rYm.class, (Object)new yl_1());
        object2ObjectArrayMap.put((Object)rYm.break, (Object)new yl_1());
        object2ObjectArrayMap.put((Object)rYm.byte, (Object)new yl_1());
    });
    private final ao_2 char;
    private boolean abstract = false;

    @Override
    public ryg_0 byte(int n2, int n3, int n4) {
        return this.new().break(rvl_0.n).byte(rYl.break);
    }

    public float byte(float f2) {
        float f3 = this.protected(f2);
        float f4 = 1.0f - (rfU.break(f3 * ((float)Math.PI * 2)) * 2.0f + 0.25f);
        f4 = rfU.class(f4, 0.0f, 1.0f);
        return f4 * f4 * 0.5f;
    }

    public Iterable<an> byte() {
        return this.this.values();
    }

    @Override
    public void byte(int n2) {
        this.throw = n2;
    }

    public void byte(an an2) {
        rrme_1.break(an2, this);
        if (rrbb.rL()) {
            rrbg.break(an2, rrbb.z());
        }
    }

    @Override
    public rlq_0 int() {
        return this.else.extends();
    }

    public gm(aq_1 aq_12, gv_0 gv_02, rqm_0<rYB> rqm_02, rrj_0 rrj_02, int n2, yx_1 yx_12, boolean bl2, long l2) {
        super(gv_02, rqm_02, rrj_02, true, bl2, l2);
        this.else = aq_12;
        this.char = new ao_2(this, n2);
        this.return = gv_02;
        this.synchronized = yx_12;
        this.public = gf_0.class(rrj_02);
        this.break(new rfH(8, 64, 8), 0.0f);
        this.double();
        this.switch();
        if ((ax_1)this.goto.class[55] != null && ((ax_1)this.goto.class[55]).getClass() == ax_1.class) {
            rrjf_1 rrjf_12 = new rrjf_1(this.goto, this.else);
            this.goto.class[55] = rrjf_12;
            rrbl.class((rrjf_1)((ax_1)this.goto.class[55]));
        }
    }

    public String toString() {
        return "ClientLevel";
    }

    public rfH this() {
        rfH rfH2 = new rfH(this.new.class(), this.new.break(), this.new.byte());
        if (!this.instanceof().class(rfH2)) {
            rfH2 = this.class(rKv.MOTION_BLOCKING, new rfH(this.instanceof().class(), 0.0, this.instanceof().break()));
        }
        return rfH2;
    }

    public void class(rfH rfH2, rqa_0 rqa_02, rql_0 rql_02, float f2, float f3, boolean bl2) {
        this.class((double)rfH2.b_() + 0.5, (double)rfH2.c_() + 0.5, (double)rfH2.d_() + 0.5, rqa_02, rql_02, f2, f3, bl2);
    }

    @Override
    public rrGb class(String string) {
        return this.instanceof.get(string);
    }

    @Override
    public void class(rrGb rrGb2) {
        this.instanceof.put(rrGb2.throws(), rrGb2);
    }

    @Override
    public void class(rfH rfH2, xc_0 xc_02, xc_0 xc_03, int n2) {
        this.synchronized.class(this, rfH2, xc_02, xc_03, n2);
    }

    @Override
    public void class(rhd_2 rhd_22, an an2, rqa_0 rqa_02, rql_0 rql_02, float f2, float f3) {
        if (rhd_22 == (cb_1)this.goto.class[57]) {
            this.goto.c().class((nq_2)new nd_2(rqa_02, rql_02, an2));
        }
    }

    @Override
    public void class(double d, double d2, double d3, double d4, double d5, double d6, rcd_2 rcd_22) {
        ((cy_0)this.goto.class[12]).class(new cb_0(this, d, d2, d3, d4, d5, d6, (cy_0)this.goto.class[12], rcd_22));
    }

    @Override
    public void class(rus_2<?> rus_22) {
        this.else.class(rus_22);
    }

    public void class(rns_0 rns_02) {
        this.try = rns_02;
    }

    @Override
    public boolean class(rfH rfH2, xc_0 xc_02, int n2) {
        this.abstract = this.O();
        boolean bl2 = super.class(rfH2, xc_02, n2);
        rrnc_0.break(rfH2, xc_02, bl2);
        this.abstract = false;
        return bl2;
    }

    @Override
    public void class(double d, double d2, double d3, rqa_0 rqa_02, rql_0 rql_02, float f2, float f3, boolean bl2) {
        double d4 = ((hh_0)this.goto.class[16]).finally().break().protected(d, d2, d3);
        np_1 np_12 = new np_1(rqa_02, rql_02, f2, f3, d, d2, d3);
        if (bl2 && d4 > 100.0) {
            double d5 = Math.sqrt(d4) / 40.0;
            this.goto.c().class(np_12, (int)(d5 * 20.0));
        } else {
            this.goto.c().class(np_12);
        }
    }

    public rjU class(rfH rfH2, float f2) {
        float f3;
        float f4;
        float f5 = this.protected(f2);
        float f6 = rfU.break(f5 * ((float)Math.PI * 2)) * 2.0f + 0.5f;
        f6 = rfU.class(f6, 0.0f, 1.0f);
        ryg_0 ryg_02 = this.implements(rfH2);
        int n2 = ryg_02.class();
        float f7 = (float)(n2 >> 16 & 0xFF) / 255.0f;
        float f8 = (float)(n2 >> 8 & 0xFF) / 255.0f;
        float f9 = (float)(n2 & 0xFF) / 255.0f;
        f7 *= f6;
        f8 *= f6;
        f9 *= f6;
        float f10 = this.private(f2);
        if (f10 > 0.0f) {
            f4 = (f7 * 0.3f + f8 * 0.59f + f9 * 0.11f) * 0.6f;
            f3 = 1.0f - f10 * 0.75f;
            f7 = f7 * f3 + f4 * (1.0f - f3);
            f8 = f8 * f3 + f4 * (1.0f - f3);
            f9 = f9 * f3 + f4 * (1.0f - f3);
        }
        if ((f4 = this.case(f2)) > 0.0f) {
            f3 = (f7 * 0.3f + f8 * 0.59f + f9 * 0.11f) * 0.2f;
            float f11 = 1.0f - f4 * 0.75f;
            f7 = f7 * f11 + f3 * (1.0f - f11);
            f8 = f8 * f11 + f3 * (1.0f - f11);
            f9 = f9 * f11 + f3 * (1.0f - f11);
        }
        if (this.throw > 0) {
            f3 = (float)this.throw - f2;
            if (f3 > 1.0f) {
                f3 = 1.0f;
            }
            f7 = f7 * (1.0f - (f3 *= 0.45f)) + 0.8f * f3;
            f8 = f8 * (1.0f - f3) + 0.8f * f3;
            f9 = f9 * (1.0f - f3) + 1.0f * f3;
        }
        return new rjU(f7, f8, f9);
    }

    @Override
    public float class(rpr_0 rpr_02, boolean bl2) {
        boolean bl3 = this.break().throws();
        boolean bl4 = rrbb.rs();
        if (!bl2) {
            return bl3 ? 0.9f : 1.0f;
        }
        switch (rpr_02) {
            case DOWN: {
                return bl3 ? 0.9f : (bl4 ? rrdZ.sp : 0.5f);
            }
            case UP: {
                return bl3 ? 0.9f : 1.0f;
            }
            case NORTH: 
            case SOUTH: {
                if (rrbb.rs()) {
                    return rrdZ.sT;
                }
                return 0.8f;
            }
            case WEST: 
            case EAST: {
                if (rrbb.rs()) {
                    return rrdZ.sq;
                }
                return 0.6f;
            }
        }
        return 1.0f;
    }

    @Override
    public int class(rfH rfH2, rrsC rrsC2) {
        yl_1 yl_12 = (yl_1)this.interface.get((Object)rrsC2);
        return yl_12.class(rfH2, () -> this.break(rfH2, rrsC2));
    }

    @Override
    public void class(rfH rfH2, xc_0 xc_02, xc_0 xc_03) {
        this.synchronized.class(rfH2, xc_02, xc_03);
    }

    @Override
    public void class(int n2, rfH rfH2, int n3) {
        this.synchronized.break(n2, rfH2, n3);
    }

    @Override
    public void class(rhd_2 rhd_22, int n2, rfH rfH2, int n3) {
        try {
            this.synchronized.class(rhd_22, n2, rfH2, n3);
        }
        catch (Throwable throwable) {
            KY kY = KY.class(throwable, "Playing level event");
            Ko ko = kY.class("Level event being played");
            ko.class("Block coordinates", Ko.class(rfH2));
            ko.class("Event source", rhd_22);
            ko.class("Event type", n2);
            ko.class("Event data", n3);
            throw new KU(kY);
        }
    }

    @Override
    public void class(rlx_1 rlx_12, double d, double d2, double d3, double d4, double d5, double d6) {
        this.synchronized.class(rlx_12, rlx_12.protected().throws(), d, d2, d3, d4, d5, d6);
    }

    @Override
    public void class(rlx_1 rlx_12, boolean bl2, double d, double d2, double d3, double d4, double d5, double d6) {
        this.synchronized.class(rlx_12, rlx_12.protected().throws() || bl2, d, d2, d3, d4, d5, d6);
    }

    public float class(float f2) {
        float f3 = this.protected(f2);
        float f4 = 1.0f - (rfU.break(f3 * ((float)Math.PI * 2)) * 2.0f + 0.2f);
        f4 = rfU.class(f4, 0.0f, 1.0f);
        f4 = 1.0f - f4;
        f4 = (float)((double)f4 * (1.0 - (double)(this.private(f2) * 5.0f) / 16.0));
        f4 = (float)((double)f4 * (1.0 - (double)(this.case(f2) * 5.0f) / 16.0));
        return f4 * 0.8f + 0.2f;
    }

    public void class(rfH rfH2, xc_0 xc_02) {
        this.class(rfH2, xc_02, 19);
    }

    public void class(an an2, an an3) {
        if (!((Boolean)an3.throws[27]).booleanValue() && an3.ra() == an2) {
            if (an3 instanceof rhd_2 || this.native().class(an3)) {
                an3.native(an3.rx(), an3.re(), an3.BO());
                Float f2 = Float.valueOf(((Float)an3.throws[15]).floatValue());
                an3.throws[17] = f2;
                Float f3 = Float.valueOf(((Float)an3.throws[16]).floatValue());
                an3.throws[18] = f3;
                if (((Boolean)an3.throws[50]).booleanValue()) {
                    an an4 = an3;
                    Integer n2 = (Integer)an4.throws[41] + 1;
                    an4.throws[41] = n2;
                    an3.A();
                }
                this.case(an3);
                if (((Boolean)an3.throws[50]).booleanValue()) {
                    for (an an5 : an3.Bh()) {
                        this.class(an3, an5);
                    }
                }
            }
        } else {
            an3.BH();
        }
    }

    public void class(int n2, int n3, int n4) {
        Random random = new Random();
        boolean bl2 = false;
        if (((ax_1)this.goto.class[55]).native() == rRl.CREATIVE) {
            for (rdn_1 rdn_12 : ((cb_1)this.goto.class[57]).rs()) {
                if (rdn_12.break() != xu_0.Ec.case()) continue;
                bl2 = true;
                break;
            }
        }
        rfw rfw2 = new rfw();
        for (int k = 0; k < 667; ++k) {
            this.class(n2, n3, n4, 16, random, bl2, rfw2);
            this.class(n2, n3, n4, 32, random, bl2, rfw2);
        }
    }

    public void class(int n2, int n3, int n4, int n5, Random random, boolean bl2, rfw rfw2) {
        int n6 = n2 + this.int.nextInt(n5) - this.int.nextInt(n5);
        int n7 = n3 + this.int.nextInt(n5) - this.int.nextInt(n5);
        int n8 = n4 + this.int.nextInt(n5) - this.int.nextInt(n5);
        rfw2.class(n6, n7, n8);
        xc_0 xc_02 = this.byte(rfw2);
        xc_02.break().class(xc_02, (rYB)this, (rfH)rfw2, random);
        rxe_2 rxe_22 = this.break(rfw2);
        if (!rxe_22.byte()) {
            rxe_22.class(this, rfw2, random);
            rlx_1 rlx_12 = rxe_22.private();
            if (rlx_12 != null && this.int.nextInt(10) == 0) {
                boolean bl3 = xc_02.protected(this, rfw2, rpr_0.DOWN);
                rfH rfH2 = rfw2.break();
                this.class(rfH2, this.byte(rfH2), rlx_12, bl3);
            }
        }
        if (bl2 && xc_02.class(xu_0.Ec)) {
            this.class(rlq_2.byte, (double)n6 + 0.5, (double)n7 + 0.5, (double)n8 + 0.5, 0.0, 0.0, 0.0);
        }
        if (!xc_02.new(this, rfw2)) {
            this.implements(rfw2).package().ifPresent(rYV2 -> {
                if (rYV2.class(this.int)) {
                    this.class(rYV2.class(), (double)rfw2.b_() + this.int.nextDouble(), (double)rfw2.c_() + this.int.nextDouble(), (double)rfw2.d_() + this.int.nextDouble(), 0.0, 0.0, 0.0);
                }
            });
        }
    }

    public void class(an an2) {
        if (!(an2 instanceof rhd_2) && !this.native().class(an2)) {
            this.case(an2);
        } else {
            an2.native(an2.rx(), an2.re(), an2.BO());
            Float f2 = Float.valueOf(((Float)an2.throws[15]).floatValue());
            an2.throws[17] = f2;
            Float f3 = Float.valueOf(((Float)an2.throws[16]).floatValue());
            an2.throws[18] = f3;
            if (((Boolean)an2.throws[50]).booleanValue() || an2.native()) {
                an an3 = an2;
                Integer n2 = (Integer)an3.throws[41] + 1;
                an3.throws[41] = n2;
                an2.this();
            }
            this.case(an2);
            if (((Boolean)an2.throws[50]).booleanValue()) {
                for (an an4 : an2.Bh()) {
                    this.class(an2, an4);
                }
            }
        }
    }

    public void class(int n2, an an2) {
        if (((rrqx_1)rrqx_1.staticFields09f1f28026cd378cb9df490a64ac8f2a[0]).finally().class(rrnb.class(an2)).byte()) {
            return;
        }
        this.break(n2, an2);
    }

    public void class(int n2) {
        an an2 = (an)this.this.remove(n2);
        if (an2 != null) {
            an2.PD();
            this.catch(an2);
            rraq_0.class(an2);
        }
    }

    public void class(int n2, cg_2 cg_22) {
        this.break(n2, cg_22);
        this.while.add(cg_22);
        rrnm_0.break(cg_22);
    }

    public void class(int n2, int n3) {
        this.interface.forEach((rrsC2, yl_12) -> yl_12.class(n2, n3));
    }

    public void class(roj_0 roj_02) {
        Collection collection = rrxr_0.PR.protected() ? (Collection)rrxr_0.class(this, rrxr_0.PR) : this.implements;
        collection.addAll(roj_02.volatile().values());
        this.char.class().class(roj_02.private(), false);
    }

    public void class(long l2) {
        this.return.class(l2);
    }

    private void class(rfH rfH2, rlx_1 rlx_12, rjC rjC2, double d) {
        this.class((double)rfH2.b_() + rjC2.break(rpb_0.X), (double)rfH2.b_() + rjC2.byte(rpb_0.X), (double)rfH2.d_() + rjC2.break(rpb_0.Z), (double)rfH2.d_() + rjC2.byte(rpb_0.Z), d, rlx_12);
    }

    public void class(BooleanSupplier booleanSupplier) {
        this.instanceof().super();
        this.M();
        this.char.class(booleanSupplier);
    }

    private void class(double d, double d2, double d3, double d4, double d5, rlx_1 rlx_12) {
        this.class(rlx_12, rfU.protected(this.int.nextDouble(), d, d2), d5, rfU.protected(this.int.nextDouble(), d3, d4), 0.0, 0.0, 0.0);
    }

    private void class(rfH rfH2, xc_0 xc_02, rlx_1 rlx_12, boolean bl2) {
        if (xc_02.volatile().byte()) {
            rjC rjC2 = xc_02.extends(this, rfH2);
            double d = rjC2.byte(rpb_0.Y);
            if (d < 1.0) {
                if (bl2) {
                    this.class((double)rfH2.b_(), (double)(rfH2.b_() + 1), (double)rfH2.d_(), (double)(rfH2.d_() + 1), (double)(rfH2.c_() + 1) - 0.05, rlx_12);
                }
            } else if (!xc_02.class(rls.B)) {
                double d2 = rjC2.break(rpb_0.Y);
                if (d2 > 0.0) {
                    this.class(rfH2, rlx_12, rjC2, (double)rfH2.c_() + d2 - 0.05);
                } else {
                    rfH rfH3 = rfH2.break();
                    xc_0 xc_03 = this.byte(rfH3);
                    rjC rjC3 = xc_03.extends(this, rfH3);
                    double d3 = rjC3.byte(rpb_0.Y);
                    if (d3 < 1.0 && xc_03.volatile().byte()) {
                        this.class(rfH2, rlx_12, rjC2, (double)rfH2.c_() - 0.05);
                    }
                }
            }
        }
    }

    @Override
    public void class(rhd_2 rhd_22, double d, double d2, double d3, rqa_0 rqa_02, rql_0 rql_02, float f2, float f3) {
        if (rhd_22 == (cb_1)this.goto.class[57]) {
            this.class(d, d2, d3, rqa_02, rql_02, f2, f3, false);
        }
    }

    @Override
    public Ko class(KY kY) {
        Ko ko = super.class(kY);
        ko.class("Server brand", () -> ((cb_1)this.goto.class[57]).short());
        ko.class("Server type", () -> this.goto.this() == null ? "Non-integrated multiplayer server" : "Integrated singleplayer server");
        return ko;
    }

    @Override
    public void break(rlx_1 rlx_12, boolean bl2, double d, double d2, double d3, double d4, double d5, double d6) {
        this.synchronized.class(rlx_12, rlx_12.protected().throws() || bl2, true, d, d2, d3, d4, d5, d6);
    }

    @Override
    public void break(rlx_1 rlx_12, double d, double d2, double d3, double d4, double d5, double d6) {
        this.synchronized.class(rlx_12, false, true, d, d2, d3, d4, d5, d6);
    }

    public gf_0 break() {
        return this.public;
    }

    private void break(int n2, an an2) {
        this.class(n2);
        this.this.put(n2, (Object)an2);
        this.native().class(rfU.byte(an2.rx() / 16.0), rfU.byte(an2.BO() / 16.0), ron_0.volatile, true).class(an2);
        this.break(an2);
    }

    public void break(rfH rfH2, float f2) {
        this.new.class(rfH2, f2);
    }

    public int break(rfH rfH2, rrsC rrsC2) {
        int n2 = ((qw_1)qy_1.instanceof().class[20]).abstract;
        if (n2 == 0) {
            return rrsC2.getColor(this.implements(rfH2), rfH2.b_(), rfH2.d_());
        }
        int n3 = (n2 * 2 + 1) * (n2 * 2 + 1);
        int n4 = 0;
        int n5 = 0;
        int n6 = 0;
        rfR rfR2 = new rfR(rfH2.b_() - n2, rfH2.c_(), rfH2.d_() - n2, rfH2.b_() + n2, rfH2.c_(), rfH2.d_() + n2);
        rfw rfw2 = new rfw();
        while (rfR2.class()) {
            rfw2.class(rfR2.break(), rfR2.byte(), rfR2.protected());
            int n7 = rrsC2.getColor(this.implements(rfw2), rfw2.b_(), rfw2.d_());
            n4 += (n7 & 0xFF0000) >> 16;
            n5 += (n7 & 0xFF00) >> 8;
            n6 += n7 & 0xFF;
        }
        return (n4 / n3 & 0xFF) << 16 | (n5 / n3 & 0xFF) << 8 | n6 / n3 & 0xFF;
    }

    public void break(long l2) {
        if (l2 < 0L) {
            l2 = -l2;
            this.B().class(rru_0.finally).class(false, (rnW)null);
        } else {
            this.B().class(rru_0.finally).class(true, (rnW)null);
        }
        this.return.break(l2);
    }

    public rjU break(float f2) {
        float f3;
        float f4;
        float f5 = this.protected(f2);
        float f6 = rfU.break(f5 * ((float)Math.PI * 2)) * 2.0f + 0.5f;
        f6 = rfU.class(f6, 0.0f, 1.0f);
        float f7 = 1.0f;
        float f8 = 1.0f;
        float f9 = 1.0f;
        float f10 = this.private(f2);
        if (f10 > 0.0f) {
            f4 = (f7 * 0.3f + f8 * 0.59f + f9 * 0.11f) * 0.6f;
            f3 = 1.0f - f10 * 0.95f;
            f7 = f7 * f3 + f4 * (1.0f - f3);
            f8 = f8 * f3 + f4 * (1.0f - f3);
            f9 = f9 * f3 + f4 * (1.0f - f3);
        }
        f7 *= f6 * 0.9f + 0.1f;
        f8 *= f6 * 0.9f + 0.1f;
        f9 *= f6 * 0.85f + 0.15f;
        f4 = this.case(f2);
        if (f4 > 0.0f) {
            f3 = (f7 * 0.3f + f8 * 0.59f + f9 * 0.11f) * 0.2f;
            float f11 = 1.0f - f4 * 0.95f;
            f7 = f7 * f11 + f3 * (1.0f - f11);
            f8 = f8 * f11 + f3 * (1.0f - f11);
            f9 = f9 * f11 + f3 * (1.0f - f11);
        }
        return new rjU(f7, f8, f9);
    }

    @Override
    public boolean break(int n2, int n3) {
        return true;
    }

    @Override
    public an break(int n2) {
        return (an)this.this.get(n2);
    }

    public void break(roj_0 roj_02) {
        for (Int2ObjectMap.Entry entry : this.this.int2ObjectEntrySet()) {
            an an2 = (an)entry.getValue();
            int n2 = rfU.byte(an2.rx() / 16.0);
            int n3 = rfU.byte(an2.BO() / 16.0);
            if (n2 != roj_02.private().break || n3 != roj_02.private().byte) continue;
            roj_02.class(an2);
        }
    }

    public void break(an an2) {
        rrme_1.class(an2, (rYB)this);
        if (rrbb.rL()) {
            rrbg.class(an2, rrbb.z());
        }
    }

    @Override
    public void break(int n2, rfH rfH2, int n3) {
        this.synchronized.class(n2, rfH2, n3);
    }

    public void break(int n2, int n3, int n4) {
        this.synchronized.class(n2, n3, n4);
    }

    public void throws() {
        this.interface.forEach((rrsC2, yl_12) -> yl_12.class());
    }

    private void M() {
        this.class(this.new.throws() + 1L);
        if (this.new.finally().break(rru_0.finally)) {
            this.break(this.new.case() + 1L);
        }
    }

    @Override
    public rRV<xd_0> finally() {
        return rrd_0.class();
    }

    @Override
    public void catch() {
        rud_1 rud_12 = this.else.class();
        rud_12.class(new rgn("multiplayer.status.quitting"));
        rrfk_1.class((rrfd_1)((Object)rrfd_1.staticFields1658baa549203f63991cdcef51acf497[1]), rgP.byte(""), rud_12);
    }

    private void catch(an an2) {
        an2.K();
        if (((Boolean)an2.throws[50]).booleanValue()) {
            this.throws((Integer)an2.throws[51], (Integer)an2.throws[53]).break(an2);
        }
        this.while.remove(an2);
        this.byte(an2);
    }

    private boolean O() {
        if ((ax_1)this.goto.class[55] instanceof rrjf_1) {
            rrjf_1 rrjf_12 = (rrjf_1)((ax_1)this.goto.class[55]);
            return rrjf_12.new();
        }
        return false;
    }

    @Override
    public rRV<rxs_1> extends() {
        return rrd_0.class();
    }

    @Override
    public /* synthetic */ rox_0 goto() {
        return this.native();
    }

    private void case(an an2) {
        if (an2.BE()) {
            int n2 = rfU.byte(an2.rx() / 16.0);
            int n3 = rfU.byte(an2.re() / 16.0);
            int n4 = rfU.byte(an2.BO() / 16.0);
            if (!((Boolean)an2.throws[50]).booleanValue() || (Integer)an2.throws[51] != n2 || (Integer)an2.throws[52] != n3 || (Integer)an2.throws[53] != n4) {
                if (((Boolean)an2.throws[50]).booleanValue() && this.break((int)((Integer)an2.throws[51]), (int)((Integer)an2.throws[53]))) {
                    this.throws((Integer)an2.throws[51], (Integer)an2.throws[53]).class(an2, (int)((Integer)an2.throws[52]));
                }
                if (!an2.rn() && !this.break(n2, n4)) {
                    if (((Boolean)an2.throws[50]).booleanValue()) {
                        gm.class.warn("Entity {} left loaded chunk area", (Object)an2);
                    }
                    Boolean bl2 = false;
                    an2.throws[50] = bl2;
                } else {
                    this.throws(n2, n4).class(an2);
                }
            }
        }
    }

    public int case() {
        return this.this.size();
    }

    public List<cg_2> continue() {
        return this.while;
    }

    public float else() {
        return this.new.protected();
    }

    @Override
    public rwb_2 implements() {
        return this.else.protected();
    }

    @Override
    public rVm new() {
        return this.else.package();
    }

    @Override
    public rns_0 package() {
        return this.try;
    }

    public Int2ObjectMap<an> return() {
        return this.this;
    }

    public int super() {
        return this.throw;
    }

    @Override
    public /* synthetic */ rrGs public() {
        return this.synchronized();
    }

    public void protected() {
        ObjectIterator objectIterator = this.this.int2ObjectEntrySet().iterator();
        cb_1 cb_12 = (cb_1)this.goto.class[57];
        while (objectIterator.hasNext()) {
            Int2ObjectMap.Entry entry = (Int2ObjectMap.Entry)objectIterator.next();
            an an2 = (an)entry.getValue();
            if (an2 == cb_12 || an2.Pm()) continue;
            if (!((Boolean)an2.throws[27]).booleanValue()) {
                this.class(this::class, an2);
            }
            if (!((Boolean)an2.throws[27]).booleanValue()) continue;
            objectIterator.remove();
            this.catch(an2);
        }
        if (cb_12 != null && !cb_12.Pm()) {
            if (!((Boolean)cb_12.throws[27]).booleanValue()) {
                this.class(this::class, (an)cb_12);
            }
            if (((Boolean)cb_12.throws[27]).booleanValue()) {
                this.this.remove(cb_12.V());
                this.catch(cb_12);
            }
        }
        this.transient();
    }

    public void private() {
        ObjectIterator objectIterator = this.this.int2ObjectEntrySet().iterator();
        while (objectIterator.hasNext()) {
            Int2ObjectMap.Entry entry = (Int2ObjectMap.Entry)objectIterator.next();
            an an2 = (an)entry.getValue();
            if (!((Boolean)an2.throws[27]).booleanValue()) continue;
            objectIterator.remove();
            this.catch(an2);
        }
    }

    @Override
    public int final() {
        return 0;
    }

    public boolean volatile() {
        return this.abstract;
    }

    public gv_0 synchronized() {
        return this.return;
    }

    public ao_2 native() {
        return this.char;
    }
}

