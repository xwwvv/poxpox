/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.List;
import java.util.Locale;
import java.util.stream.Stream;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.case;
import protected.class;
import protected.interface;
import protected.ps_1;
import protected.rVe;
import protected.rVi;
import protected.rgF;
import protected.rgh_0;
import protected.rgl_0;
import protected.rgn_0;
import protected.rgp_0;
import protected.rgv;
import protected.rgy_0;
import protected.x;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public abstract class try
implements interface {
    private static boolean[] break;
    private static short[] throws;
    private static byte[] case;
    private static String[] catch;
    public Object[] class;

    @Override
    public x byte() {
        return null;
    }

    public try(case case_, String ... stringArray) {
        List<String> list;
        this.native();
        this.class[try.throws[0]] = list = Stream.of(stringArray).map(string -> string.toLowerCase(Locale.US)).toList();
        case case_2 = case_;
        this.class[try.throws[1]] = case_2;
        ps_1 ps_12 = case_.throw();
        this.class[try.throws[2]] = ps_12;
    }

    static {
        try.ntfClinit();
    }

    public static String class(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{67, -56, -68, 69, -16, 46, -88, 16}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0xBB4515F4;
    }

    @Override
    public rVi class() {
        rVi rVi2 = new rVe(catch[0]).class(new rgn_0("'" + this.break().get(break[0]) + "'").break(rgF.RED));
        rVe rVe2 = new rVe(this.implements() + "\n\n" + String.join((CharSequence)catch[1], this.catch()));
        rVi2.class(rVi2.class().class(rgF.GRAY));
        rVe2.class(rVe2.class().class(rgF.GRAY));
        return rgv.class(rVi2, new rgy_0(rgp_0.class, rVe2), new rgl_0(rgh_0.SUGGEST_COMMAND, (String)protected.class.instanceof().protected.class[throws[3]] + this.break().get(break[1]) + " "));
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0x7BBA5160A6D81245L;
    }

    @Override
    public List<String> break() {
        return (List)this.class[throws[4]];
    }

    private static void throws() {
        break = new boolean[2];
    }

    private static /* synthetic */ void ntfClinit() {
        try.throws();
        try.finally();
        try.protected();
        try.extends();
    }

    private static void finally() {
        catch = new String[]{new String("\u041d\u0430\u0432\u0435\u0434\u0438\u0442\u0435 \u043c\u044b\u0448\u044c, \u0447\u0442\u043e\u0431\u044b \u0443\u0432\u0438\u0434\u0435\u0442\u044c \u043f\u043e\u0434\u0440\u043e\u0431\u043d\u043e\u0435 \u043e\u043f\u0438\u0441\u0430\u043d\u0438\u0435 \u043a\u043e\u043c\u0430\u043d\u0434\u044b "), new String("\n")};
    }

    private static void extends() {
        case = new byte[]{3};
    }

    private static void protected() {
        short[] sArray = new short[5];
        sArray[0] = 2;
        sArray[2] = 1;
        sArray[4] = 2;
        throws = sArray;
    }

    private void native() {
        if (this.class == null) {
            Object[] objectArray = this.class = new Object[case[0]];
        }
    }
}

