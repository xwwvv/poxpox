/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
package protected;

import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.function.BooleanSupplier;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import protected.ah_2;
import protected.an;
import protected.gm;
import protected.qy_1;
import protected.rRo;
import protected.rRq;
import protected.rYB;
import protected.rYZ;
import protected.rcd_2;
import protected.rfH;
import protected.rfU;
import protected.rfj;
import protected.rjh_0;
import protected.roC;
import protected.roj_0;
import protected.ron;
import protected.ron_0;
import protected.roq_0;
import protected.rox_0;
import protected.rrbb_0;
import protected.rrbs_0;
import protected.rrse;
import protected.ruu_1;
import protected.yx_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.AO
 */
public class ao_2
extends rox_0 {
    private static final Logger class = LogManager.getLogger();
    private final roj_0 break;
    private final rrse byte;
    private volatile ah_2 protected;
    final gm throws;

    @Override
    public String byte() {
        return "Client Chunk Cache: " + this.protected.break.length() + ", " + this.protected();
    }

    @Override
    public boolean byte(int n2, int n3) {
        return this.case(n2 >> 4, n3 >> 4);
    }

    public ao_2(gm gm2, int n2) {
        this.throws = gm2;
        this.break = new ron((rYB)gm2, new rfj(0, 0));
        this.byte = new rrse(this, true, gm2.default().break());
        this.protected = new ah_2(this, ao_2.break(n2));
    }

    @Override
    public boolean class(rfH rfH2) {
        return this.case(rfH2.b_() >> 4, rfH2.d_() >> 4);
    }

    @Override
    public void class(rRo rRo2, rjh_0 rjh_02) {
        ((yx_1)qy_1.instanceof().class[8]).break(rjh_02.break(), rjh_02.byte(), rjh_02.protected());
    }

    public void class(int n2, int n3) {
        int n4;
        roj_0 roj_02;
        if (this.protected.break(n2, n3) && ao_2.class(roj_02 = this.protected.class(n4 = this.protected.class(n2, n3)), n2, n3)) {
            roj_02.class(false);
            this.protected.class(n4, roj_02, null);
        }
    }

    private static boolean class(roj_0 roj_02, int n2, int n3) {
        if (roj_02 == null) {
            return false;
        }
        rfj rfj2 = roj_02.private();
        return rfj2.break == n2 && rfj2.byte == n3;
    }

    @Override
    public boolean class(rfj rfj2) {
        return this.case(rfj2.break, rfj2.byte);
    }

    @Override
    public rrse class() {
        return this.byte;
    }

    @Override
    public boolean class(an an2) {
        return this.case(rfU.byte(an2.rx()) >> 4, rfU.byte(an2.BO()) >> 4);
    }

    public roj_0 class(int n2, int n3, rYZ rYZ2, ruu_1 ruu_12, rcd_2 rcd_22, int n4, boolean bl2) {
        Object object;
        Object object2;
        if (!this.protected.break(n2, n3)) {
            ao_2.class.warn("Ignoring chunk since it's not in the view range: {}, {}", (Object)n2, (Object)n3);
            return null;
        }
        int n5 = this.protected.class(n2, n3);
        roj_0 roj_02 = this.protected.break.get(n5);
        if (!bl2 && ao_2.class(roj_02, n2, n3)) {
            boolean bl3 = false;
            if (roj_02 instanceof rrbs_0) {
                object2 = (rrbs_0)roj_02;
                Object object3 = ruu_12.break("ChunkDataOF");
                if (object3 instanceof rrbb_0) {
                    object = (rrbb_0)object3;
                    ((rrbs_0)object2).class((rrbb_0)object);
                    roq_0.class.set((rrbb_0)object);
                    bl3 = true;
                }
            }
            roj_02.class(rYZ2, ruu_12, rcd_22, n4);
            if (bl3) {
                roq_0.class.set(null);
            }
        } else {
            if (rYZ2 == null) {
                ao_2.class.warn("Ignoring chunk since we don't have complete data: {}, {}", (Object)n2, (Object)n3);
                return null;
            }
            if (roj_02 != null) {
                roj_02.class(false);
            }
            roj_02 = new rrbs_0(this.throws, new rfj(n2, n3), rYZ2);
            roj_02.class(rYZ2, ruu_12, rcd_22, n4);
            this.protected.class(n5, roj_02);
        }
        roq_0[] roq_0Array = roj_02.byte();
        object2 = this.class();
        ((rrse)object2).class(new rfj(n2, n3), true);
        for (int k = 0; k < roq_0Array.length; ++k) {
            object = roq_0Array[k];
            ((rrse)object2).class(rjh_0.class(n2, k, n3), roq_0.class((roq_0)object));
        }
        this.throws.class(n2, n3);
        roj_02.class(true);
        return roj_02;
    }

    public roj_0 class(int n2, int n3, ron_0 ron_02, boolean bl2) {
        roj_0 roj_02;
        if (this.protected.break(n2, n3) && ao_2.class(roj_02 = this.protected.class(this.protected.class(n2, n3)), n2, n3)) {
            return roj_02;
        }
        return bl2 ? this.break : null;
    }

    public void class(int n2) {
        int n3 = this.protected.byte;
        int n4 = ao_2.break(n2);
        if (n3 != n4) {
            ah_2 ah_22 = new ah_2(this, n4);
            ah_22.throws = this.protected.throws;
            ah_22.case = this.protected.case;
            for (int k = 0; k < this.protected.break.length(); ++k) {
                roj_0 roj_02 = this.protected.break.get(k);
                if (roj_02 == null) continue;
                rfj rfj2 = roj_02.private();
                if (!ah_22.break(rfj2.break, rfj2.byte)) continue;
                ah_22.class(ah_22.class(rfj2.break, rfj2.byte), roj_02);
            }
            this.protected = ah_22;
        }
    }

    public void class(BooleanSupplier booleanSupplier) {
    }

    @Override
    public rRq break() {
        return this.throws;
    }

    @Override
    public /* synthetic */ roC break(int n2, int n3, ron_0 ron_02, boolean bl2) {
        return this.class(n2, n3, ron_02, bl2);
    }

    public void break(int n2, int n3) {
        this.protected.throws = n2;
        this.protected.case = n3;
    }

    private static int break(int n2) {
        return Math.max(2, n2) + 3;
    }

    public ao_2 throws() {
        ah_2 ah_22 = this.case();
        ao_2 ao_22 = new ao_2(this.throws, ah_22.byte() - 3);
        ah_2 ah_23 = ao_22.case();
        ah_23.class(ah_22);
        if (ah_23.byte() != ah_22.byte()) {
            throw new IllegalStateException(ah_23.byte() + " " + ah_22.byte());
        }
        return ao_22;
    }

    public ah_2 case() {
        for (Field field : ao_2.class.getDeclaredFields()) {
            if (!ah_2.class.isAssignableFrom(field.getType())) continue;
            try {
                return (ah_2)field.get(this);
            }
            catch (IllegalAccessException illegalAccessException) {
                throw new RuntimeException(illegalAccessException);
            }
        }
        throw new RuntimeException(Arrays.toString(ao_2.class.getDeclaredFields()));
    }

    public int protected() {
        return this.protected.catch;
    }
}

