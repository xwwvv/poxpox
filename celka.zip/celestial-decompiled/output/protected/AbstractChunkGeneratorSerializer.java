/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.datafixers.util.Pair
 */
package protected;

import com.mojang.datafixers.util.Pair;
import java.util.function.Function;
import protected.rvl_0;
import protected.rzh_1;
import protected.rzp_1;
import protected.rzt_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.rzq
 */
public class rzq_1<E, T extends rzh_1<E>> {
    private final rvl_0<T> class;
    private final String break;
    private final String byte;
    private final Function<E, T> protected;
    private Pair<T, rzp_1<? extends E>> throws;

    rzq_1(rvl_0<T> rvl_02, String string, String string2, Function<E, T> function) {
        this.class = rvl_02;
        this.break = string;
        this.byte = string2;
        this.protected = function;
    }

    public Object class() {
        return new rzt_2<E, T>(this.class, this.break, this.byte, this.protected, this.throws);
    }
}

