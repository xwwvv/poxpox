/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.util.function.Predicate;
import protected.ai_0;
import protected.eU;
import protected.jq_1;
import protected.ke_2;
import protected.oo_1;
import protected.qd_2;
import protected.qh_2;
import protected.qj_2;
import protected.qm_2;
import protected.qp_2;
import protected.qx_1;
import protected.rCL;
import protected.rCZ;
import protected.rRR;
import protected.rYB;
import protected.rcc_0;
import protected.rfH;
import protected.rhn_2;
import protected.rja;
import protected.rmz_1;
import protected.rox_2;
import protected.rpr_0;
import protected.rxx;
import protected.ryw_1;
import protected.xc_0;
import protected.xd_0;
import protected.xu_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.xy
 */
public class xy_0
extends ke_2
implements eU {
    public static final rcc_0 volatile = ke_2.p;
    private qh_2 final;
    private qh_2 package;
    private qh_2 int;
    private qh_2 new;
    private static final Predicate<xc_0> continue = xc_02 -> xc_02 != null && (xc_02.class(xu_0.Br) || xc_02.class(xu_0.BP));

    protected xy_0(jq_1 jq_12) {
        super(jq_12);
        this.extends((xc_0)((xc_0)this.abstract.break()).class(volatile, rpr_0.NORTH));
    }

    private qh_2 this() {
        if (this.new == null) {
            this.new = qx_1.class().class("~^~", "###", "~#~").class('^', ryw_1.class(continue)).class('#', ryw_1.class(qd_2.class(xu_0.rw))).class('~', ryw_1.class(qm_2.class(qp_2.class))).break();
        }
        return this.new;
    }

    @Override
    protected void class(rCL<xd_0, xc_0> rCL2) {
        rCL2.class(new rCZ[]{volatile});
    }

    @Override
    public void class(xc_0 xc_02, rYB rYB2, rfH rfH2, xc_0 xc_03, boolean bl2) {
        if (!xc_03.class(xc_02.break())) {
            this.class(rYB2, rfH2);
        }
    }

    public boolean class(rRR rRR2, rfH rfH2) {
        return this.break().class(rRR2, rfH2) != null || this.finally().class(rRR2, rfH2) != null;
    }

    @Override
    public xc_0 class(rxx rxx2) {
        return (xc_0)this.continue().class(volatile, rxx2.case().case());
    }

    /*
     * WARNING - void declaration
     */
    private void class(rYB rYB2, rfH rfH2) {
        block9: {
            qj_2 qj_22;
            block8: {
                Object object;
                qj_22 = this.implements().class(rYB2, rfH2);
                if (qj_22 == null) break block8;
                for (int k = 0; k < this.implements().break(); ++k) {
                    object = qj_22.class(0, k, 0);
                    rYB2.class(((ryw_1)object).protected(), xu_0.class.continue(), 2);
                    rYB2.byte(2001, ((ryw_1)object).protected(), xd_0.finally(((ryw_1)object).class()));
                }
                rox_2 rox_22 = ai_0.H.class(rYB2);
                object = qj_22.class(0, 2, 0).protected();
                rox_22.class((double)((rja)object).b_() + 0.5, (double)((rja)object).c_() + 0.05, (double)((rja)object).d_() + 0.5, 0.0f, 0.0f);
                rYB2.a_(rox_22);
                for (rhn_2 object2 : rYB2.class(rhn_2.class, rox_22.rN().class(5.0))) {
                    oo_1.final.class(object2, rox_22);
                }
                for (int k = 0; k < this.implements().break(); ++k) {
                    ryw_1 i3 = qj_22.class(0, k, 0);
                    rYB2.class(i3.protected(), xu_0.class);
                }
                break block9;
            }
            qj_22 = this.this().class(rYB2, rfH2);
            if (qj_22 == null) break block9;
            for (int k = 0; k < this.this().byte(); ++k) {
                for (int i2 = 0; i2 < this.this().break(); ++i2) {
                    ryw_1 ryw_12 = qj_22.class(k, i2, 0);
                    rYB2.class(ryw_12.protected(), xu_0.class.continue(), 2);
                    rYB2.byte(2001, ryw_12.protected(), xd_0.finally(ryw_12.class()));
                }
            }
            rfH rfH3 = qj_22.class(1, 2, 0).protected();
            rmz_1 rmz_12 = ai_0.import.class(rYB2);
            rmz_12.else(true);
            rmz_12.class((double)rfH3.b_() + 0.5, (double)rfH3.c_() + 0.05, (double)rfH3.d_() + 0.5, 0.0f, 0.0f);
            rYB2.a_(rmz_12);
            for (rhn_2 rhn_22 : rYB2.class(rhn_2.class, rmz_12.rN().class(5.0))) {
                oo_1.final.class(rhn_22, rmz_12);
            }
            for (int k = 0; k < this.this().byte(); ++k) {
                void var7_20;
                boolean bl2 = false;
                while (var7_20 < this.this().break()) {
                    ryw_1 ryw_12 = qj_22.class(k, (int)var7_20, 0);
                    rYB2.class(ryw_12.protected(), xu_0.class);
                    ++var7_20;
                }
            }
        }
    }

    private qh_2 break() {
        if (this.final == null) {
            this.final = qx_1.class().class(" ", "#", "#").class('#', ryw_1.class(qd_2.class(xu_0.Pt))).break();
        }
        return this.final;
    }

    private qh_2 finally() {
        if (this.int == null) {
            this.int = qx_1.class().class("~ ~", "###", "~#~").class('#', ryw_1.class(qd_2.class(xu_0.rw))).class('~', ryw_1.class(qm_2.class(qp_2.class))).break();
        }
        return this.int;
    }

    private qh_2 implements() {
        if (this.package == null) {
            this.package = qx_1.class().class("^", "#", "#").class('^', ryw_1.class(continue)).class('#', ryw_1.class(qd_2.class(xu_0.Pt))).break();
        }
        return this.package;
    }
}

