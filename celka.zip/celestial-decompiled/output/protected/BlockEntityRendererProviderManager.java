/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonObject
 */
package protected;

import com.google.gson.JsonObject;
import java.util.Collection;
import protected.hg_2;
import protected.ho_1;
import protected.hy_1;
import protected.hz_1;
import protected.rdn_1;
import protected.rhn_2;
import protected.rhp_1;
import protected.rqo_0;
import protected.rwl_1;
import protected.rzr_2;
import protected.xb_2;
import protected.xh_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.XP
 */
public class xp_2
extends hg_2<xb_2> {
    static final rqo_0 class = new rqo_0("fishing_rod_hooked");

    public void class(rhn_2 rhn_22, rdn_1 rdn_12, rhp_1 rhp_12, Collection<rdn_1> collection) {
        rzr_2 rzr_22 = hy_1.break(rhn_22, rhp_12.catch() != null ? rhp_12.catch() : rhp_12);
        this.class(rhn_22, (T xb_22) -> xb_22.class(rdn_12, rzr_22, collection));
    }

    @Override
    public rqo_0 class() {
        return xp_2.class;
    }

    @Override
    public /* synthetic */ hz_1 class(JsonObject jsonObject, ho_1 ho_12, rwl_1 rwl_12) {
        return this.break(jsonObject, ho_12, rwl_12);
    }

    public xb_2 break(JsonObject jsonObject, ho_1 ho_12, rwl_1 rwl_12) {
        xh_2 xh_22 = xh_2.class(jsonObject.get("rod"));
        ho_1 ho_13 = ho_1.class(jsonObject, "entity", rwl_12);
        xh_2 xh_23 = xh_2.class(jsonObject.get("item"));
        return new xb_2(ho_12, xh_22, ho_13, xh_23);
    }
}

