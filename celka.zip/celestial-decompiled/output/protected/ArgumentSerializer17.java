/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  it.unimi.dsi.fastutil.longs.LongSet
 *  org.apache.commons.lang3.ArrayUtils
 */
package protected;

import it.unimi.dsi.fastutil.longs.LongSet;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import org.apache.commons.lang3.ArrayUtils;
import protected.rVi;
import protected.rck_1;
import protected.rct_1;
import protected.rct_2;
import protected.rcv_2;
import protected.rcx_1;
import protected.rcz_1;
import protected.rgP;
import protected.rgn_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.rcq
 */
public class rcq_1
extends rcx_1<rct_1> {
    public static final rcv_2<rcq_1> class = new rct_2();
    private long[] break;

    @Override
    public /* synthetic */ void byte(int n2, rcz_1 rcz_12) {
        this.break(n2, (rct_1)rcz_12);
    }

    @Override
    public /* synthetic */ rcz_1 byte(int n2) {
        return this.break(n2);
    }

    @Override
    public /* synthetic */ rcz_1 byte() {
        return this.protected();
    }

    public rcq_1(long[] lArray) {
        this.break = lArray;
    }

    public rcq_1(List<Long> list) {
        this(rcq_1.class(list));
    }

    public rcq_1(LongSet longSet) {
        this.break = longSet.toLongArray();
    }

    @Override
    public /* synthetic */ Object remove(int n2) {
        return this.break(n2);
    }

    @Override
    public int size() {
        return this.break.length;
    }

    @Override
    public /* synthetic */ Object get(int n2) {
        return this.class(n2);
    }

    @Override
    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        return object instanceof rcq_1 && Arrays.equals(this.break, ((rcq_1)object).break);
    }

    @Override
    public String toString() {
        StringBuilder stringBuilder = new StringBuilder("[L;");
        for (int k = 0; k < this.break.length; ++k) {
            if (k != 0) {
                stringBuilder.append(',');
            }
            stringBuilder.append(this.break[k]).append('L');
        }
        return stringBuilder.append(']').toString();
    }

    @Override
    public int hashCode() {
        return Arrays.hashCode(this.break);
    }

    @Override
    public void clear() {
        this.break = new long[0];
    }

    @Override
    public /* synthetic */ void add(int n2, Object object) {
        this.break(n2, (rct_1)object);
    }

    @Override
    public byte class() {
        return 12;
    }

    public rct_1 class(int n2, rct_1 rct_12) {
        long l2 = this.break[n2];
        this.break[n2] = rct_12.throws();
        return rct_1.class(l2);
    }

    @Override
    public void class(DataOutput dataOutput) throws IOException {
        dataOutput.writeInt(this.break.length);
        for (long l2 : this.break) {
            dataOutput.writeLong(l2);
        }
    }

    private static long[] class(List<Long> list) {
        long[] lArray = new long[list.size()];
        for (int k = 0; k < list.size(); ++k) {
            Long l2 = list.get(k);
            lArray[k] = l2 == null ? 0L : l2;
        }
        return lArray;
    }

    @Override
    public boolean class(int n2, rcz_1 rcz_12) {
        if (rcz_12 instanceof rck_1) {
            this.break[n2] = ((rck_1)rcz_12).throws();
            return true;
        }
        return false;
    }

    @Override
    public rgP class(String string, int n2) {
        rVi rVi2 = new rgn_0("L").class(catch);
        rVi rVi3 = new rgn_0("[").class(rVi2).break(";");
        for (int k = 0; k < this.break.length; ++k) {
            rVi rVi4 = new rgn_0(String.valueOf(this.break[k])).class(case);
            rVi3.break(" ").class(rVi4).class(rVi2);
            if (k == this.break.length - 1) continue;
            rVi3.break(",");
        }
        rVi3.break("]");
        return rVi3;
    }

    public rct_1 class(int n2) {
        return rct_1.class(this.break[n2]);
    }

    @Override
    public /* synthetic */ Object set(int n2, Object object) {
        return this.class(n2, (rct_1)object);
    }

    public rct_1 break(int n2) {
        long l2 = this.break[n2];
        this.break = ArrayUtils.remove((long[])this.break, (int)n2);
        return rct_1.class(l2);
    }

    @Override
    public boolean break(int n2, rcz_1 rcz_12) {
        if (rcz_12 instanceof rck_1) {
            this.break = ArrayUtils.add((long[])this.break, (int)n2, (long)((rck_1)rcz_12).throws());
            return true;
        }
        return false;
    }

    public void break(int n2, rct_1 rct_12) {
        this.break = ArrayUtils.add((long[])this.break, (int)n2, (long)rct_12.throws());
    }

    public rcv_2<rcq_1> break() {
        return rcq_1.class;
    }

    @Override
    public byte throws() {
        return 4;
    }

    public long[] case() {
        return this.break;
    }

    public rcq_1 protected() {
        long[] lArray = new long[this.break.length];
        System.arraycopy(this.break, 0, lArray, 0, this.break.length);
        return new rcq_1(lArray);
    }

    @Override
    public /* synthetic */ rcz_1 protected(int n2, rcz_1 rcz_12) {
        return this.class(n2, (rct_1)rcz_12);
    }
}

