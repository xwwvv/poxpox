/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.brigadier.Message
 *  com.mojang.brigadier.suggestion.Suggestion
 */
package protected;

import com.mojang.brigadier.Message;
import com.mojang.brigadier.suggestion.Suggestion;
import java.util.List;
import protected.HZ;
import protected.ch_2;
import protected.cw_2;
import protected.jI;
import protected.ml_1;
import protected.qi_1;
import protected.rfU;
import protected.rgv;
import protected.rjK;
import protected.vm_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.cQ
 */
public class cq_2 {
    private final HZ break;
    private final String byte;
    private final List<Suggestion> protected;
    private int throws;
    private int case;
    private rjK catch = rjK.class;
    private boolean private;
    private int implements;
    final /* synthetic */ cw_2 class;

    String byte() {
        this.implements = this.case;
        Suggestion suggestion = this.protected.get(this.case);
        Message message = suggestion.getTooltip();
        return message != null ? jI.class("narration.suggestion.tooltip", this.case + 1, this.protected.size(), suggestion.getText(), message.getString()) : jI.class("narration.suggestion", this.case + 1, this.protected.size(), suggestion.getText());
    }

    /*
     * Ignored method signature, as it can't be verified against descriptor
     */
    cq_2(cw_2 cw_22, int n2, int n3, int n4, List list, boolean bl2) {
        this.class = cw_22;
        int n5 = n2 - 1;
        int n6 = cw_22.volatile ? n3 - 3 - Math.min(list.size(), cw_22.native) * 12 : n3;
        this.break = new HZ(n5, n6, n4 + 1, Math.min(list.size(), cw_22.native) * 12);
        this.byte = cw_22.catch.private();
        this.implements = bl2 ? -1 : 0;
        this.protected = list;
        this.break(0);
    }

    public void class(int n2) {
        this.break(this.case + n2);
        int n3 = this.throws;
        int n4 = this.throws + this.class.native - 1;
        if (this.case < n3) {
            this.throws = rfU.class(this.case, 0, Math.max(this.protected.size() - this.class.native, 0));
        } else if (this.case > n4) {
            this.throws = rfU.class(this.case + this.class.extends - this.class.native, 0, Math.max(this.protected.size() - this.class.native, 0));
        }
    }

    public void class() {
        Suggestion suggestion = this.protected.get(this.case);
        this.class.synchronized = true;
        this.class.catch.class(suggestion.apply(this.byte));
        int n2 = suggestion.getRange().getStart() + suggestion.getText().length();
        this.class.catch.private(n2);
        this.class.catch.native(n2);
        this.break(this.case);
        this.class.synchronized = false;
        this.private = true;
    }

    public void class(ml_1 ml_12, int n2, int n3) {
        Message message;
        int n4;
        boolean bl2;
        int n5 = Math.min(this.protected.size(), this.class.native);
        int n6 = -5592406;
        boolean bl3 = this.throws > 0;
        boolean bl4 = this.protected.size() > this.throws + n5;
        boolean bl5 = bl3 || bl4;
        boolean bl6 = bl2 = this.catch.byte != (float)n2 || this.catch.protected != (float)n3;
        if (bl2) {
            this.catch = new rjK(n2, n3);
        }
        if (bl5) {
            ch_2.class(ml_12, this.break.class(), this.break.break() - 1, this.break.class() + this.break.byte(), this.break.break(), this.class.final);
            ch_2.class(ml_12, this.break.class(), this.break.break() + this.break.protected(), this.break.class() + this.break.byte(), this.break.break() + this.break.protected() + 1, this.class.final);
            if (bl3) {
                for (n4 = 0; n4 < this.break.byte(); ++n4) {
                    if (n4 % 2 != 0) continue;
                    ch_2.class(ml_12, this.break.class() + n4, this.break.break() - 1, this.break.class() + n4 + 1, this.break.break(), -1);
                }
            }
            if (bl4) {
                for (n4 = 0; n4 < this.break.byte(); ++n4) {
                    if (n4 % 2 != 0) continue;
                    ch_2.class(ml_12, this.break.class() + n4, this.break.break() + this.break.protected(), this.break.class() + n4 + 1, this.break.break() + this.break.protected() + 1, -1);
                }
            }
        }
        n4 = 0;
        for (int k = 0; k < n5; ++k) {
            Suggestion suggestion = this.protected.get(k + this.throws);
            ch_2.class(ml_12, this.break.class(), this.break.break() + 12 * k, this.break.class() + this.break.byte(), this.break.break() + 12 * k + 12, this.class.final);
            if (n2 > this.break.class() && n2 < this.break.class() + this.break.byte() && n3 > this.break.break() + 12 * k && n3 < this.break.break() + 12 * k + 12) {
                if (bl2) {
                    this.break(k + this.throws);
                }
                n4 = 1;
            }
            this.class.private.class(ml_12, suggestion.getText(), (float)(this.break.class() + 1), (float)(this.break.break() + 2 + 12 * k), k + this.throws == this.case ? -256 : -5592406);
        }
        if (n4 != 0 && (message = this.protected.get(this.case).getTooltip()) != null) {
            this.class.case.class(ml_12, rgv.class(message), n2, n3);
        }
    }

    public boolean class(double d) {
        int n2;
        int n3 = (int)(((qi_1)this.class.throws.class[22]).byte() * (double)this.class.throws.else().super() / (double)this.class.throws.else().new());
        if (this.break.class(n3, n2 = (int)(((qi_1)this.class.throws.class[22]).protected() * (double)this.class.throws.else().this() / (double)this.class.throws.else().continue()))) {
            this.throws = rfU.class((int)((double)this.throws - d), 0, Math.max(this.protected.size() - this.class.native, 0));
            return true;
        }
        return false;
    }

    public boolean class(int n2, int n3, int n4) {
        if (!this.break.class(n2, n3)) {
            return false;
        }
        int n5 = (n3 - this.break.break()) / 12 + this.throws;
        if (n5 >= 0 && n5 < this.protected.size()) {
            this.break(n5);
            this.class();
        }
        return true;
    }

    public void break() {
        this.class.this = null;
    }

    public boolean break(int n2, int n3, int n4) {
        if (n2 == 265) {
            this.class(-1);
            this.private = false;
            return true;
        }
        if (n2 == 264) {
            this.class(1);
            this.private = false;
            return true;
        }
        if (n2 == 258) {
            if (this.private) {
                this.class(vm_1.synchronized() ? -1 : 1);
            }
            this.class();
            return true;
        }
        if (n2 == 256) {
            this.break();
            return true;
        }
        return false;
    }

    public void break(int n2) {
        this.case = n2;
        if (this.case < 0) {
            this.case += this.protected.size();
        }
        if (this.case >= this.protected.size()) {
            this.case -= this.protected.size();
        }
        Suggestion suggestion = this.protected.get(this.case);
        this.class.catch.byte(cw_2.class(this.class.catch.private(), suggestion.apply(this.byte)));
    }
}

