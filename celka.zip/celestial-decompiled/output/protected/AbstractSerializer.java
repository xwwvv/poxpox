/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.BiMap
 *  com.google.common.collect.HashBiMap
 *  com.google.common.collect.ImmutableList
 *  com.google.common.collect.ImmutableMap
 *  com.google.common.collect.Maps
 *  com.mojang.serialization.Codec
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
package protected;

import com.google.common.collect.BiMap;
import com.google.common.collect.HashBiMap;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Maps;
import com.mojang.serialization.Codec;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import protected.rKd;
import protected.rKm;
import protected.rRR;
import protected.rUV;
import protected.rUo;
import protected.rUt;
import protected.rVm;
import protected.rYY;
import protected.rYf;
import protected.raK;
import protected.raZ;
import protected.rab_0;
import protected.rae;
import protected.raf_0;
import protected.rai_0;
import protected.ran;
import protected.raq;
import protected.rcd_2;
import protected.rcy_2;
import protected.reP;
import protected.reV;
import protected.reY;
import protected.rey_0;
import protected.rfH;
import protected.rfi;
import protected.rfj;
import protected.riH;
import protected.riU;
import protected.rij;
import protected.ril_0;
import protected.rin;
import protected.rio;
import protected.rit_0;
import protected.rjh_0;
import protected.roC;
import protected.ron_0;
import protected.rqm;
import protected.rqo_0;
import protected.rrpt_1;
import protected.rrrH;
import protected.rrra_0;
import protected.rrrf;
import protected.rrri;
import protected.rrri_0;
import protected.rrrn;
import protected.rrrq;
import protected.rrru_0;
import protected.rrrv_0;
import protected.rrsi_2;
import protected.ruv_0;
import protected.rvl_0;
import protected.ryg_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public abstract class rrrZ<C extends ruv_0> {
    public static final BiMap<String, rrrZ<?>> class = HashBiMap.create();
    private static final Map<rrrZ<?>, rKm> else = Maps.newHashMap();
    private static final Logger synchronized = LogManager.getLogger();
    public static final rrrZ<rrri_0> break = rrrZ.class("Pillager_Outpost", new rit_0(rrri_0.class), rKm.SURFACE_STRUCTURES);
    public static final rrrZ<rai_0> byte = rrrZ.class("Mineshaft", new raK(rai_0.class), rKm.UNDERGROUND_STRUCTURES);
    public static final rrrZ<rUt> protected = rrrZ.class("Mansion", new rrri(rUt.class), rKm.SURFACE_STRUCTURES);
    public static final rrrZ<rUt> throws = rrrZ.class("Jungle_Pyramid", new raq(rUt.class), rKm.SURFACE_STRUCTURES);
    public static final rrrZ<rUt> case = rrrZ.class("Desert_Pyramid", new reY(rUt.class), rKm.SURFACE_STRUCTURES);
    public static final rrrZ<rUt> catch = rrrZ.class("Igloo", new ran(rUt.class), rKm.SURFACE_STRUCTURES);
    public static final rrrZ<rUo> private = rrrZ.class("Ruined_Portal", new rij(rUo.class), rKm.SURFACE_STRUCTURES);
    public static final rrrZ<rio> implements = rrrZ.class("Shipwreck", new riU(rio.class), rKm.SURFACE_STRUCTURES);
    public static final rrrq finally = rrrZ.class("Swamp_Hut", new rrrq(rUt.class), rKm.SURFACE_STRUCTURES);
    public static final rrrZ<rUt> extends = rrrZ.class("Stronghold", new rrru_0(rUt.class), rKm.STRONGHOLDS);
    public static final rrrZ<rUt> native = rrrZ.class("Monument", new ril_0(rUt.class), rKm.SURFACE_STRUCTURES);
    public static final rrrZ<rin> volatile = rrrZ.class("Ocean_Ruin", new riH(rin.class), rKm.SURFACE_STRUCTURES);
    public static final rrrZ<rUt> final = rrrZ.class("Fortress", new raZ(rUt.class), rKm.UNDERGROUND_DECORATION);
    public static final rrrZ<rUt> package = rrrZ.class("EndCity", new rab_0(rUt.class), rKm.SURFACE_STRUCTURES);
    public static final rrrZ<rUV> int = rrrZ.class("Buried_Treasure", new reV(rUV.class), rKm.UNDERGROUND_STRUCTURES);
    public static final rrrZ<rrri_0> new = rrrZ.class("Village", new rrrf(rrri_0.class), rKm.SURFACE_STRUCTURES);
    public static final rrrZ<rUt> continue = rrrZ.class("Nether_Fossil", new rae(rUt.class), rKm.UNDERGROUND_DECORATION);
    public static final rrrZ<rrri_0> super = rrrZ.class("Bastion_Remnant", new rey_0(rrri_0.class), rKm.SURFACE_STRUCTURES);
    public static final List<rrrZ<?>> this = ImmutableList.of(break, new, continue);
    private static final rqo_0 return = new rqo_0("jigsaw");
    private static final Map<rqo_0, rqo_0> public = ImmutableMap.builder().put((Object)new rqo_0("nvi"), (Object)return).put((Object)new rqo_0("pcp"), (Object)return).put((Object)new rqo_0("bastionremnant"), (Object)return).put((Object)new rqo_0("runtime"), (Object)return).build();
    private final Codec<reP<C, rrrZ<C>>> goto;

    public List<rYf> byte() {
        return ImmutableList.of();
    }

    public rrrZ(Codec<C> codec) {
        this.goto = codec.fieldOf("config").xmap(ruv_02 -> new reP<ruv_0, rrrZ>(this, (ruv_0)ruv_02), reP2 -> reP2.throws).codec();
    }

    private rrrH<C> class(int n2, int n3, rfi rfi2, int n4, long l2) {
        return this.class().create(this, n2, n3, rfi2, n4, l2);
    }

    public rrrH<?> class(rVm rVm2, rKd rKd2, rYY rYY2, rrpt_1 rrpt_12, long l2, rfj rfj2, ryg_0 ryg_02, int n2, rqm rqm2, rrsi_2 rrsi_22, C c) {
        rfj rfj3 = this.class(rrsi_22, l2, rqm2, rfj2.break, rfj2.byte);
        if (rfj2.break == rfj3.break && rfj2.byte == rfj3.byte && this.class(rKd2, rYY2, l2, rqm2, rfj2.break, rfj2.byte, ryg_02, rfj3, c)) {
            rrrH<C> rrrH2 = this.class(rfj2.break, rfj2.byte, rfi.class(), n2, l2);
            rrrH2.class(rVm2, rKd2, rrpt_12, rfj2.break, rfj2.byte, ryg_02, c);
            if (rrrH2.throws()) {
                return rrrH2;
            }
        }
        return rrrH.class;
    }

    protected boolean class(rKd rKd2, rYY rYY2, long l2, rqm rqm2, int n2, int n3, ryg_0 ryg_02, rfj rfj2, C c) {
        return true;
    }

    public final rfj class(rrsi_2 rrsi_22, long l2, rqm rqm2, int n2, int n3) {
        int n4;
        int n5;
        int n6 = rrsi_22.class();
        int n7 = rrsi_22.break();
        int n8 = Math.floorDiv(n2, n6);
        int n9 = Math.floorDiv(n3, n6);
        rqm2.class(l2, n8, n9, rrsi_22.byte());
        if (this.break()) {
            n5 = rqm2.nextInt(n6 - n7);
            n4 = rqm2.nextInt(n6 - n7);
        } else {
            n5 = (rqm2.nextInt(n6 - n7) + rqm2.nextInt(n6 - n7)) / 2;
            n4 = (rqm2.nextInt(n6 - n7) + rqm2.nextInt(n6 - n7)) / 2;
        }
        return new rfj(n8 * n6 + n5, n9 * n6 + n4);
    }

    public abstract rrrv_0<C> class();

    private static <F extends rrrZ<?>> F class(String string, F f2, rKm rKm2) {
        rrrZ.class.put((Object)string.toLowerCase(Locale.ROOT), f2);
        else.put(f2, rKm2);
        return (F)rvl_0.class(rvl_0.t, string.toLowerCase(Locale.ROOT), f2);
    }

    public reP<C, ? extends rrrZ<C>> class(C c) {
        return new reP<C, rrrZ>(this, c);
    }

    public rfH class(rRR rRR2, rrra_0 rrra_02, rfH rfH2, int n2, boolean bl2, long l2, rrsi_2 rrsi_22) {
        int n3 = rrsi_22.class();
        int n4 = rfH2.b_() >> 4;
        int n5 = rfH2.d_() >> 4;
        rqm rqm2 = new rqm();
        block0: for (int k = 0; k <= n2; ++k) {
            for (int i2 = -k; i2 <= k; ++i2) {
                boolean bl3 = i2 == -k || i2 == k;
                for (int i3 = -k; i3 <= k; ++i3) {
                    boolean bl4;
                    boolean bl5 = bl4 = i3 == -k || i3 == k;
                    if (!bl3 && !bl4) continue;
                    int n6 = n4 + n3 * i2;
                    int n7 = n5 + n3 * i3;
                    rfj rfj2 = this.class(rrsi_22, l2, rqm2, n6, n7);
                    roC roC2 = rRR2.class(rfj2.break, rfj2.byte, ron_0.break);
                    rrrH<?> rrrH2 = rrra_02.class(rjh_0.class(roC2.private(), 0), this, roC2);
                    if (rrrH2 != null && rrrH2.throws()) {
                        if (bl2 && rrrH2.private()) {
                            rrrH2.implements();
                            return rrrH2.class();
                        }
                        if (!bl2) {
                            return rrrH2.class();
                        }
                    }
                    if (k == 0) break;
                }
                if (k == 0) continue block0;
            }
        }
        return null;
    }

    public static rrrH<?> class(rrpt_1 rrpt_12, rcd_2 rcd_22, long l2) {
        String string = rcd_22.native("id");
        if ("INVALID".equals(string)) {
            return rrrH.class;
        }
        rrrZ<?> rrrZ2 = rvl_0.t.class(new rqo_0(string.toLowerCase(Locale.ROOT)));
        if (rrrZ2 == null) {
            synchronized.error("Unknown feature id: {}", (Object)string);
            return null;
        }
        int n2 = rcd_22.private("ChunkX");
        int n3 = rcd_22.private("ChunkZ");
        int n4 = rcd_22.private("references");
        rfi rfi2 = rcd_22.throws("BB") ? new rfi(rcd_22.final("BB")) : rfi.class();
        rcy_2 rcy_22 = rcd_22.protected("Children", 10);
        try {
            rrrH<?> rrrH2 = rrrZ2.class(n2, n3, rfi2, n4, l2);
            for (int k = 0; k < rcy_22.size(); ++k) {
                rcd_2 rcd_23 = rcy_22.class(k);
                String string2 = rcd_23.native("id").toLowerCase(Locale.ROOT);
                rqo_0 rqo_02 = new rqo_0(string2);
                rqo_0 rqo_03 = public.getOrDefault(rqo_02, rqo_02);
                raf_0 raf_02 = rvl_0.I.class(rqo_03);
                if (raf_02 == null) {
                    synchronized.error("Unknown structure piece id: {}", (Object)rqo_03);
                    continue;
                }
                try {
                    rrrn rrrn2 = raf_02.load(rrpt_12, rcd_23);
                    rrrH2.protected().add(rrrn2);
                    continue;
                }
                catch (Exception exception) {
                    synchronized.error("Exception loading structure piece with id {}", (Object)rqo_03, (Object)exception);
                }
            }
            return rrrH2;
        }
        catch (Exception exception) {
            synchronized.error("Failed Start with id {}", (Object)string, (Object)exception);
            return null;
        }
    }

    protected boolean break() {
        return true;
    }

    public static void throws() {
    }

    public String catch() {
        return (String)rrrZ.class.inverse().get((Object)this);
    }

    public Codec<reP<C, rrrZ<C>>> case() {
        return this.goto;
    }

    public rKm protected() {
        return else.get(this);
    }

    public List<rYf> private() {
        return ImmutableList.of();
    }
}

