/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.serialization.Codec
 */
package protected;

import com.mojang.serialization.Codec;
import java.util.Random;
import protected.jc_1;
import protected.rDC;
import protected.rDD;
import protected.rDH;
import protected.rDK;
import protected.rDU;
import protected.rDV;
import protected.rDY;
import protected.rDZ;
import protected.rDa;
import protected.rDe;
import protected.rDf;
import protected.rDg;
import protected.rDi;
import protected.rDj;
import protected.rDl;
import protected.rDm;
import protected.rDn;
import protected.rDp;
import protected.rDq;
import protected.rDt;
import protected.rDw;
import protected.rKd;
import protected.rKl;
import protected.rRY;
import protected.rUC;
import protected.rUD;
import protected.rUH;
import protected.rUK;
import protected.rUR;
import protected.rUU;
import protected.rUV;
import protected.rUY;
import protected.rUZ;
import protected.rUa;
import protected.rUe;
import protected.rUf;
import protected.rUg;
import protected.rUi;
import protected.rUl;
import protected.rUm;
import protected.rUn;
import protected.rUp;
import protected.rUq;
import protected.rUt;
import protected.rUw;
import protected.rda_0;
import protected.rdc_0;
import protected.rdi_0;
import protected.rdl_0;
import protected.rdt_0;
import protected.rdu_0;
import protected.rdv_0;
import protected.reE;
import protected.reG;
import protected.reM;
import protected.reO;
import protected.reh;
import protected.reh_0;
import protected.rer_0;
import protected.res;
import protected.res_0;
import protected.rfH;
import protected.rip_0;
import protected.rri_0;
import protected.rua_0;
import protected.rub_0;
import protected.ruc_0;
import protected.rue_0;
import protected.ruf_0;
import protected.rui_0;
import protected.ruj_0;
import protected.rul_0;
import protected.rum_0;
import protected.run_0;
import protected.rup_0;
import protected.ruq_0;
import protected.rur_0;
import protected.rus_0;
import protected.rut_0;
import protected.ruu_0;
import protected.ruv_0;
import protected.ruy_0;
import protected.ruz_0;
import protected.rvl_0;
import protected.xc_0;
import protected.xd_0;
import protected.xu_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.rUO
 */
public abstract class ruo_0<FC extends ruv_0> {
    public static final ruo_0<rUt> break = ruo_0.class("no_op", new rUw(rUt.class));
    public static final ruo_0<rdv_0> byte = ruo_0.class("tree", new res_0(rdv_0.class));
    public static final run_0<rDH> protected = ruo_0.class("flower", new rDa(rDH.class));
    public static final run_0<rDH> throws = ruo_0.class("no_bonemeal_flower", new rDa(rDH.class));
    public static final ruo_0<rDH> case = ruo_0.class("random_patch", new rUg(rDH.class));
    public static final ruo_0<rdt_0> catch = ruo_0.class("block_pile", new rDp(rdt_0.class));
    public static final ruo_0<rUH> private = ruo_0.class("spring_feature", new rer_0(rUH.class));
    public static final ruo_0<rUt> implements = ruo_0.class("chorus_plant", new rDj(rUt.class));
    public static final ruo_0<rUR> finally = ruo_0.class("emerald_ore", new rUY(rUR.class));
    public static final ruo_0<rUt> extends = ruo_0.class("void_start_platform", new reO(rUt.class));
    public static final ruo_0<rUt> native = ruo_0.class("desert_well", new rDi(rUt.class));
    public static final ruo_0<rUt> volatile = ruo_0.class("fossil", new ruc_0(rUt.class));
    public static final ruo_0<rda_0> final = ruo_0.class("huge_red_mushroom", new rDn(rda_0.class));
    public static final ruo_0<rda_0> package = ruo_0.class("huge_brown_mushroom", new rdl_0(rda_0.class));
    public static final ruo_0<rUt> int = ruo_0.class("ice_spike", new rua_0(rUt.class));
    public static final ruo_0<rUt> new = ruo_0.class("glowstone_blob", new ruu_0(rUt.class));
    public static final ruo_0<rUt> continue = ruo_0.class("freeze_top_layer", new ruf_0(rUt.class));
    public static final ruo_0<rUt> super = ruo_0.class("vines", new reM(rUt.class));
    public static final ruo_0<rUt> this = ruo_0.class("monster_room", new rur_0(rUt.class));
    public static final ruo_0<rUt> else = ruo_0.class("blue_ice", new rdi_0(rUt.class));
    public static final ruo_0<rDq> synchronized = ruo_0.class("iceberg", new rUn(rDq.class));
    public static final ruo_0<rDq> return = ruo_0.class("forest_rock", new rDl(rDq.class));
    public static final ruo_0<rUa> public = ruo_0.class("disk", new rUi(rUa.class));
    public static final ruo_0<rUa> goto = ruo_0.class("ice_patch", new rul_0(rUa.class));
    public static final ruo_0<rDq> while = ruo_0.class("lake", new rUl(rDq.class));
    public static final ruo_0<rUf> try = ruo_0.class("ore", new rui_0(rUf.class));
    public static final ruo_0<rum_0> instanceof = ruo_0.class("end_spike", new rue_0(rum_0.class));
    public static final ruo_0<rUt> throw = ruo_0.class("end_island", new rus_0(rUt.class));
    public static final ruo_0<rup_0> interface = ruo_0.class("end_gateway", new rub_0(rup_0.class));
    public static final rUK char = ruo_0.class("seagrass", new rUK(rUV.class));
    public static final ruo_0<rUt> abstract = ruo_0.class("kelp", new rUC(rUt.class));
    public static final ruo_0<rUt> long = ruo_0.class("coral_tree", new rDD(rUt.class));
    public static final ruo_0<rUt> float = ruo_0.class("coral_mushroom", new rDK(rUt.class));
    public static final ruo_0<rUt> void = ruo_0.class("coral_claw", new rDY(rUt.class));
    public static final ruo_0<ruj_0> static = ruo_0.class("sea_pickle", new rUD(ruj_0.class));
    public static final ruo_0<rDt> import = ruo_0.class("simple_block", new rDw(rDt.class));
    public static final ruo_0<rUV> short = ruo_0.class("bamboo", new rdc_0(rUV.class));
    public static final ruo_0<rUm> default = ruo_0.class("huge_fungus", new rUZ(rUm.class));
    public static final ruo_0<rdt_0> const = ruo_0.class("nether_forest_vegetation", new rUq(rdt_0.class));
    public static final ruo_0<rUt> strictfp = ruo_0.class("weeping_vines", new reh(rUt.class));
    public static final ruo_0<rUt> boolean = ruo_0.class("twisting_vines", new res(rUt.class));
    public static final ruo_0<rDV> transient = ruo_0.class("basalt_columns", new rdu_0(rDV.class));
    public static final ruo_0<rDm> for = ruo_0.class("delta_feature", new reh_0(rDm.class));
    public static final ruo_0<rDC> double = ruo_0.class("netherrack_replace_blobs", new rip_0(rDC.class));
    public static final ruo_0<ruz_0> switch = ruo_0.class("fill_layer", new ruq_0(ruz_0.class));
    public static final rDf r = ruo_0.class("bonus_chest", new rDf(rUt.class));
    public static final ruo_0<rUt> P = ruo_0.class("basalt_pillar", new rDZ(rUt.class));
    public static final ruo_0<rUf> B = ruo_0.class("no_surface_ore", new rut_0(rUf.class));
    public static final ruo_0<ruy_0> S = ruo_0.class("random_selector", new rUp(ruy_0.class));
    public static final ruo_0<rUU> s = ruo_0.class("simple_random_selector", new rUe(rUU.class));
    public static final ruo_0<reE> E = ruo_0.class("random_boolean_selector", new reG(reE.class));
    public static final ruo_0<rDe> G = ruo_0.class("decorated", new rDU(rDe.class));
    private final Codec<rDg<FC, ruo_0<FC>>> class;

    public ruo_0(Codec<FC> codec) {
        this.class = codec.fieldOf("config").xmap(ruv_02 -> new rDg<ruv_0, ruo_0>(this, (ruv_0)ruv_02), rDg2 -> rDg2.case).codec();
    }

    public static boolean class(rKl rKl2, rfH rfH2) {
        return rKl2.class(rfH2, xc_02 -> ruo_0.break(xc_02.break()));
    }

    private static <C extends ruv_0, F extends ruo_0<C>> F class(String string, F f2) {
        return (F)rvl_0.class(rvl_0.q, string, f2);
    }

    public Codec<rDg<FC, ruo_0<FC>>> class() {
        return this.class;
    }

    protected void class(rRY rRY2, rfH rfH2, xc_0 xc_02) {
        rRY2.class(rfH2, xc_02, 3);
    }

    public abstract boolean class(rri_0 var1, rKd var2, Random var3, rfH var4, FC var5);

    protected static boolean class(xd_0 xd_02) {
        return xd_02 == xu_0.break || xd_02 == xu_0.byte || xd_02 == xu_0.throws || xd_02 == xu_0.catch;
    }

    public static boolean break(xd_0 xd_02) {
        return xd_02 == xu_0.finally || xd_02 == xu_0.implements || xd_02 == xu_0.native || xd_02 == xu_0.extends || xd_02 == xu_0.Bi;
    }

    public rDg<FC, ?> break(FC FC) {
        return new rDg<FC, ruo_0>(this, FC);
    }

    public static boolean break(rKl rKl2, rfH rfH2) {
        return rKl2.class(rfH2, jc_1::catch);
    }
}

