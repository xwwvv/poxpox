/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.class;
import protected.ps_1;
import protected.pv_2;
import protected.rdn_1;
import protected.rdy_2;
import protected.rhd_2;
import protected.rrAp;
import protected.rrfH;
import protected.rrlu_2;
import protected.rvq_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.Bv
 */
public class bv_1
extends pv_2 {
    private static boolean[] break;
    private static short[] byte;
    private static byte[] protected;

    private static void byte() {
        byte = new short[]{1};
    }

    public bv_1(class clazz) {
        super(clazz);
    }

    static {
        bv_1.ntfClinit();
    }

    @Override
    public void class(rrlu_2 rrlu_22) {
        rvq_2 rvq_22;
        super.class(rrlu_22);
        Object object = rrlu_22.class();
        if (object instanceof rvq_2 && (rvq_22 = (rvq_2)object).break() == protected[0] && (object = rvq_22.class(((ps_1)this.class[byte[0]]).case())) instanceof rhd_2) {
            rdn_1[] rdn_1Array;
            rhd_2 rhd_22 = (rhd_2)object;
            rdn_1[] rdn_1Array2 = rdn_1Array = rrfH.class(rhd_22);
            int n2 = rdn_1Array2.length;
            for (int k = break[0]; k < n2; ++k) {
                rdn_1 rdn_12 = rdn_1Array2[k];
                if (rdn_12.break() != rdy_2.kL) continue;
                rrAp.class(rhd_22, rdn_12);
                break;
            }
        }
    }

    private static void class() {
        protected = new byte[]{35};
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0x156D5362;
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0x3426F73F20D66D08L;
    }

    public static String break(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{23, -8, -79, 90, -100, 64, 94, 84}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    private static void break() {
        break = new boolean[1];
    }

    private static /* synthetic */ void ntfClinit() {
        bv_1.break();
        bv_1.byte();
        bv_1.class();
    }
}

