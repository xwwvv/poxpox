/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.char;
import protected.su_1;
import protected.void;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.SK
 */
public class sk_1
extends Enum<sk_1>
implements char {
    private static String[] strings84fbf20de4d13027acc13a6866788039;
    private static short[] shorts84fbf20de4d13027acc13a6866788039;
    private static byte[] bytes84fbf20de4d13027acc13a6866788039;
    private static boolean[] booleans84fbf20de4d13027acc13a6866788039;
    public static Object[] staticFields84fbf20de4d13027acc13a6866788039;

    private static void byte() {
        Object[] objectArray;
        objectArray = new Object[]{new sk_1(), new sk_1[]{(sk_1)objectArray[0]}};
        staticFields84fbf20de4d13027acc13a6866788039 = objectArray;
    }

    static {
        sk_1.ntfClinit();
    }

    public static sk_1[] values() {
        return (sk_1[])((sk_1[])staticFields84fbf20de4d13027acc13a6866788039[shorts84fbf20de4d13027acc13a6866788039[0]]).clone();
    }

    public static sk_1 valueOf(String string) {
        return Enum.valueOf(sk_1.class, string);
    }

    public static String class(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{44, -29, -63, 18, -54, -8, -4, 25}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    @Override
    public void class() {
        return (su_1)su_1.staticFields60242b15623d3e12b4eaac026de79971[shorts84fbf20de4d13027acc13a6866788039[1]];
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0xFDF5F6359274F9BEL;
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0xC59EB060;
    }

    private static void break() {
        bytes84fbf20de4d13027acc13a6866788039 = new byte[]{2};
    }

    private static void throws() {
        boolean[] blArray = new boolean[5];
        blArray[0] = true;
        blArray[4] = true;
        booleans84fbf20de4d13027acc13a6866788039 = blArray;
    }

    private static /* synthetic */ void ntfClinit() {
        sk_1.throws();
        sk_1.protected();
        sk_1.case();
        sk_1.break();
        sk_1.byte();
    }

    private static /* synthetic */ sk_1[] catch() {
        sk_1[] sk_1Array = new sk_1[booleans84fbf20de4d13027acc13a6866788039[0]];
        sk_1Array[sk_1.booleans84fbf20de4d13027acc13a6866788039[1]] = (sk_1)staticFields84fbf20de4d13027acc13a6866788039[shorts84fbf20de4d13027acc13a6866788039[2]];
        return sk_1Array;
    }

    private static void case() {
        short[] sArray = new short[3];
        sArray[0] = 1;
        shorts84fbf20de4d13027acc13a6866788039 = sArray;
    }

    private static void protected() {
        strings84fbf20de4d13027acc13a6866788039 = new String[]{new String("INSTANCE")};
    }
}

