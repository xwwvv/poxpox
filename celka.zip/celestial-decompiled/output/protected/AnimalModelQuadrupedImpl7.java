/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableList
 */
package protected;

import com.google.common.collect.ImmutableList;
import protected.an;
import protected.iq_1;
import protected.rfU;
import protected.rsy_0;
import protected.tY;
import protected.to_0;
import protected.wn_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.wI
 */
public class wi_0<T extends an>
extends wn_0<T>
implements tY,
to_0 {
    protected iq_1 class;
    protected iq_1 break;
    protected final iq_1 byte;
    protected final iq_1 protected;
    protected final iq_1 throws;
    protected final iq_1 case;
    protected final iq_1 catch;
    protected final iq_1 private;
    protected final iq_1 implements;

    @Override
    public iq_1 byte() {
        return this.class;
    }

    public wi_0(float f2) {
        this(f2, 64, 64);
    }

    public wi_0(float f2, int n2, int n3) {
        float f3 = 0.5f;
        this.class = new iq_1(this).break(n2, n3);
        this.class.class(0.0f, 0.0f, 0.0f);
        this.class.class(0, 0).class(-4.0f, -10.0f, -4.0f, 8.0f, 10.0f, 8.0f, f2);
        this.break = new iq_1(this).break(n2, n3);
        this.break.class(0.0f, 0.0f, 0.0f);
        this.break.class(32, 0).class(-4.0f, -10.0f, -4.0f, 8.0f, 10.0f, 8.0f, f2 + 0.5f);
        this.class.break(this.break);
        this.byte = new iq_1(this).break(n2, n3);
        this.byte.class(0.0f, 0.0f, 0.0f);
        this.byte.class(30, 47).class(-8.0f, -8.0f, -6.0f, 16.0f, 16.0f, 1.0f, f2);
        this.byte.case = -1.5707964f;
        this.break.break(this.byte);
        this.implements = new iq_1(this).break(n2, n3);
        this.implements.class(0.0f, -2.0f, 0.0f);
        this.implements.class(24, 0).class(-1.0f, -1.0f, -6.0f, 2.0f, 4.0f, 2.0f, f2);
        this.class.break(this.implements);
        this.protected = new iq_1(this).break(n2, n3);
        this.protected.class(0.0f, 0.0f, 0.0f);
        this.protected.class(16, 20).class(-4.0f, 0.0f, -3.0f, 8.0f, 12.0f, 6.0f, f2);
        this.throws = new iq_1(this).break(n2, n3);
        this.throws.class(0.0f, 0.0f, 0.0f);
        this.throws.class(0, 38).class(-4.0f, 0.0f, -3.0f, 8.0f, 18.0f, 6.0f, f2 + 0.5f);
        this.protected.break(this.throws);
        this.case = new iq_1(this).break(n2, n3);
        this.case.class(0.0f, 2.0f, 0.0f);
        this.case.class(44, 22).class(-8.0f, -2.0f, -2.0f, 4.0f, 8.0f, 4.0f, f2);
        this.case.class(44, 22).class(4.0f, -2.0f, -2.0f, 4.0f, 8.0f, 4.0f, f2, true);
        this.case.class(40, 38).class(-4.0f, 2.0f, -2.0f, 8.0f, 4.0f, 4.0f, f2);
        this.catch = new iq_1(this, 0, 22).break(n2, n3);
        this.catch.class(-2.0f, 12.0f, 0.0f);
        this.catch.class(-2.0f, 0.0f, -2.0f, 4.0f, 12.0f, 4.0f, f2);
        this.private = new iq_1(this, 0, 22).break(n2, n3);
        this.private.implements = true;
        this.private.class(2.0f, 12.0f, 0.0f);
        this.private.class(-2.0f, 0.0f, -2.0f, 4.0f, 12.0f, 4.0f, f2);
    }

    @Override
    public void class(boolean bl2) {
        this.class.finally = bl2;
        this.break.finally = bl2;
        this.byte.finally = bl2;
    }

    @Override
    public void class(T t2, float f2, float f3, float f4, float f5, float f6) {
        boolean bl2 = false;
        if (t2 instanceof rsy_0) {
            bl2 = ((rsy_0)t2).L() > 0;
        }
        this.class.catch = f5 * ((float)Math.PI / 180);
        this.class.case = f6 * ((float)Math.PI / 180);
        if (bl2) {
            this.class.private = 0.3f * rfU.class(0.45f * f4);
            this.class.case = 0.4f;
        } else {
            this.class.private = 0.0f;
        }
        this.case.protected = 3.0f;
        this.case.throws = -1.0f;
        this.case.case = -0.75f;
        this.catch.case = rfU.break(f2 * 0.6662f) * 1.4f * f3 * 0.5f;
        this.private.case = rfU.break(f2 * 0.6662f + (float)Math.PI) * 1.4f * f3 * 0.5f;
        this.catch.catch = 0.0f;
        this.private.catch = 0.0f;
    }

    @Override
    public Iterable<iq_1> class() {
        return ImmutableList.of((Object)this.class, (Object)this.protected, (Object)this.catch, (Object)this.private, (Object)this.case);
    }
}

