/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonObject
 *  com.google.gson.JsonSyntaxException
 */
package protected;

import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import protected.hg_2;
import protected.ho_1;
import protected.hz_1;
import protected.js_1;
import protected.rdn_1;
import protected.rfH;
import protected.rhn_2;
import protected.rpY;
import protected.rqo_0;
import protected.rvl_0;
import protected.rwl_1;
import protected.xc_0;
import protected.xd_0;
import protected.xh_2;
import protected.xn_2;
import protected.xp_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.Xy
 */
public class xy_2
extends hg_2<xp_1> {
    static final rqo_0 class = new rqo_0("placed_block");

    @Override
    public rqo_0 class() {
        return xy_2.class;
    }

    @Override
    public /* synthetic */ hz_1 class(JsonObject jsonObject, ho_1 ho_12, rwl_1 rwl_12) {
        return this.break(jsonObject, ho_12, rwl_12);
    }

    private static xd_0 class(JsonObject jsonObject) {
        if (jsonObject.has("block")) {
            rqo_0 rqo_02 = new rqo_0(rpY.case(jsonObject, "block"));
            return rvl_0.strictfp.break(rqo_02).orElseThrow(() -> new JsonSyntaxException("Unknown block type '" + rqo_02 + "'"));
        }
        return null;
    }

    public void class(rhn_2 rhn_22, rfH rfH2, rdn_1 rdn_12) {
        xc_0 xc_02 = rhn_22.continue().byte(rfH2);
        this.class(rhn_22, (T xp_12) -> xp_12.class(xc_02, rfH2, rhn_22.continue(), rdn_12));
    }

    public xp_1 break(JsonObject jsonObject, ho_1 ho_12, rwl_1 rwl_12) {
        xd_0 xd_02 = xy_2.class(jsonObject);
        js_1 js_12 = js_1.class(jsonObject.get("state"));
        if (xd_02 != null) {
            js_12.class(xd_02.new(), (String string) -> {
                throw new JsonSyntaxException("Block " + xd_02 + " has no property " + string + ":");
            });
        }
        xn_2 xn_22 = xn_2.class(jsonObject.get("location"));
        xh_2 xh_22 = xh_2.class(jsonObject.get("item"));
        return new xp_1(ho_12, xd_02, js_12, xn_22, xh_22);
    }
}

