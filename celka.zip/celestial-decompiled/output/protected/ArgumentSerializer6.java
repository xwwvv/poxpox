/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.rpH;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.rCy
 */
public final class rcy_0
extends Enum<rcy_0>
implements rpH {
    public static final /* enum */ rcy_0 NONE = new rcy_0("none");
    public static final /* enum */ rcy_0 SMALL = new rcy_0("small");
    public static final /* enum */ rcy_0 LARGE = new rcy_0("large");
    private final String name;
    private static final /* synthetic */ rcy_0[] $VALUES;

    private rcy_0(String string2) {
        this.name = string2;
    }

    static {
        $VALUES = rcy_0.break();
    }

    public String toString() {
        return this.name;
    }

    public static rcy_0[] values() {
        return (rcy_0[])$VALUES.clone();
    }

    public static rcy_0 valueOf(String string) {
        return Enum.valueOf(rcy_0.class, string);
    }

    @Override
    public String class() {
        return this.name;
    }

    private static /* synthetic */ rcy_0[] break() {
        return new rcy_0[]{NONE, SMALL, LARGE};
    }
}

