/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.regex.Pattern;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.bl_2;
import protected.bn_2;
import protected.bu_2;
import protected.by_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.BD
 */
public class bd_2
extends bn_2
implements by_1 {
    private static short[] protected;
    private static boolean[] throws;
    public Object[] byte;
    private static String[] case;

    public bd_2() {
        super(case[0], (Pattern[])bl_2.class[protected[0]]);
        this.private();
    }

    static {
        bd_2.ntfClinit();
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0xC3F9353FC606495FL;
    }

    @Override
    public String class() {
        this.private();
        if ((bu_2)((Object)this.byte[protected[4]]) == null) {
            return null;
        }
        return ((bu_2)((Object)this.byte[protected[5]])).class();
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0x714DA9B6;
    }

    @Override
    public void throws(String string) {
        this.private();
        super.throws(string);
        bu_2 bu_22 = bu_2.class(string);
        this.byte[bd_2.protected[1]] = bu_22;
        if ((bu_2)((Object)this.byte[protected[2]]) != null) {
            this.protected(((bu_2)((Object)this.byte[protected[3]])).class() + " " + this.throws().toLowerCase());
        }
    }

    private static /* synthetic */ void ntfClinit() {
        bd_2.finally();
        bd_2.implements();
        bd_2.catch();
    }

    private static void finally() {
        throws = new boolean[]{true};
    }

    private static void catch() {
        short[] sArray = new short[6];
        sArray[0] = 23;
        protected = sArray;
    }

    public static String catch(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{-107, -82, 77, 43, 5, -80, -107, -38}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    private static void implements() {
        case = new String[]{new String("\u0413\u0435\u0439\u0437\u0435\u0440")};
    }

    private void private() {
        if (this.byte == null) {
            Object[] objectArray = this.byte = new Object[throws[0]];
        }
    }
}

