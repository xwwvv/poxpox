/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap
 */
package protected;

import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import protected.roH;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public abstract class rrsj<M extends rrsj<M>> {
    private final long[] break = new long[2];
    private final roH[] byte = new roH[2];
    private boolean protected;
    protected final Long2ObjectOpenHashMap<roH> class;

    public roH byte(long l2) {
        roH roH2;
        if (this.protected) {
            for (int k = 0; k < 2; ++k) {
                if (l2 != this.break[k]) continue;
                return this.byte[k];
            }
        }
        if ((roH2 = (roH)this.class.get(l2)) == null) {
            return null;
        }
        if (this.protected) {
            for (int k = 1; k > 0; --k) {
                this.break[k] = this.break[k - 1];
                this.byte[k] = this.byte[k - 1];
            }
            this.break[0] = l2;
            this.byte[0] = roH2;
        }
        return roH2;
    }

    public void byte() {
        for (int k = 0; k < 2; ++k) {
            this.break[k] = Long.MAX_VALUE;
            this.byte[k] = null;
        }
    }

    protected rrsj(Long2ObjectOpenHashMap<roH> long2ObjectOpenHashMap) {
        this.class = long2ObjectOpenHashMap;
        this.byte();
        this.protected = true;
    }

    public void class(long l2, roH roH2) {
        this.class.put(l2, (Object)roH2);
    }

    public void class(long l2) {
        this.class.put(l2, (Object)((roH)this.class.get(l2)).break());
        this.byte();
    }

    public boolean break(long l2) {
        return this.class.containsKey(l2);
    }

    public abstract M break();

    public roH protected(long l2) {
        return (roH)this.class.remove(l2);
    }

    public void protected() {
        this.protected = false;
    }
}

