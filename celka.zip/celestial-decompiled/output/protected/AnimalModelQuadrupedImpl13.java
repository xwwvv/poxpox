/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableList
 */
package protected;

import com.google.common.collect.ImmutableList;
import protected.an;
import protected.iq_1;
import protected.rfU;
import protected.to_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class wq<T extends an>
extends to_1<T> {
    private final iq_1 class;
    private final iq_1 break;
    private final iq_1 byte;
    private final iq_1 protected;
    private final iq_1 throws;

    public wq(float f2) {
        this.return = 32;
        this.public = 32;
        int n2 = 22;
        this.class = new iq_1(this, 0, 0);
        this.class.class(-1.0f, -1.5f, -3.0f, 2.0f, 3.0f, 6.0f, f2);
        this.class.class(0.0f, 22.0f, 0.0f);
        this.break = new iq_1(this, 22, -6);
        this.break.class(0.0f, -1.5f, 0.0f, 0.0f, 3.0f, 6.0f, f2);
        this.break.class(0.0f, 22.0f, 3.0f);
        this.byte = new iq_1(this, 2, 16);
        this.byte.class(-2.0f, -1.0f, 0.0f, 2.0f, 2.0f, 0.0f, f2);
        this.byte.class(-1.0f, 22.5f, 0.0f);
        this.byte.catch = 0.7853982f;
        this.protected = new iq_1(this, 2, 12);
        this.protected.class(0.0f, -1.0f, 0.0f, 2.0f, 2.0f, 0.0f, f2);
        this.protected.class(1.0f, 22.5f, 0.0f);
        this.protected.catch = -0.7853982f;
        this.throws = new iq_1(this, 10, -5);
        this.throws.class(0.0f, -3.0f, 0.0f, 0.0f, 3.0f, 6.0f, f2);
        this.throws.class(0.0f, 20.5f, -3.0f);
    }

    @Override
    public Iterable<iq_1> class() {
        return ImmutableList.of((Object)this.class, (Object)this.break, (Object)this.byte, (Object)this.protected, (Object)this.throws);
    }

    @Override
    public void class(T t2, float f2, float f3, float f4, float f5, float f6) {
        float f7 = 1.0f;
        if (!((an)t2).rT()) {
            f7 = 1.5f;
        }
        this.break.catch = -f7 * 0.45f * rfU.class(0.6f * f4);
    }
}

