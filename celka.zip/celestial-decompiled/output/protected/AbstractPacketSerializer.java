/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.rhz_2;
import protected.rja_1;
import protected.rjb_2;
import protected.rjd_1;
import protected.rje_2;
import protected.rjf_1;
import protected.rjj_2;
import protected.rjk_1;
import protected.rjl_1;
import protected.rjo_1;
import protected.rjo_2;
import protected.rjp_1;
import protected.rjr_2;
import protected.rjs_1;
import protected.rjv_1;
import protected.rjv_2;
import protected.rjz_2;
import protected.rvl_0;
import protected.rxe_1;
import protected.rxf_2;
import protected.rxi_2;
import protected.rxr_1;
import protected.rxt_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.rJP
 */
public class rjp_2<T extends rjr_2> {
    public static final rjp_2<rxe_1> class = rjp_2.class("generic_9x1", rxe_1::class);
    public static final rjp_2<rxe_1> break = rjp_2.class("generic_9x2", rxe_1::break);
    public static final rjp_2<rxe_1> byte = rjp_2.class("generic_9x3", rxe_1::byte);
    public static final rjp_2<rxe_1> protected = rjp_2.class("generic_9x4", rxe_1::protected);
    public static final rjp_2<rxe_1> throws = rjp_2.class("generic_9x5", rxe_1::throws);
    public static final rjp_2<rxe_1> case = rjp_2.class("generic_9x6", rxe_1::case);
    public static final rjp_2<rjs_1> catch = rjp_2.class("generic_3x3", rjs_1::new);
    public static final rjp_2<rjf_1> private = rjp_2.class("anvil", rjf_1::new);
    public static final rjp_2<rxt_1> implements = rjp_2.class("beacon", rxt_1::new);
    public static final rjp_2<rxi_2> finally = rjp_2.class("blast_furnace", rxi_2::new);
    public static final rjp_2<rxf_2> extends = rjp_2.class("brewing_stand", rxf_2::new);
    public static final rjp_2<rja_1> native = rjp_2.class("crafting", rja_1::new);
    public static final rjp_2<rje_2> volatile = rjp_2.class("enchantment", rje_2::new);
    public static final rjp_2<rjo_2> final = rjp_2.class("furnace", rjo_2::new);
    public static final rjp_2<rjj_2> package = rjp_2.class("grindstone", rjj_2::new);
    public static final rjp_2<rjz_2> int = rjp_2.class("hopper", rjz_2::new);
    public static final rjp_2<rjv_2> new = rjp_2.class("lectern", (n2, rhz_22) -> new rjv_2(n2));
    public static final rjp_2<rjl_1> continue = rjp_2.class("loom", rjl_1::new);
    public static final rjp_2<rjp_1> super = rjp_2.class("merchant", rjp_1::new);
    public static final rjp_2<rjv_1> this = rjp_2.class("shulker_box", rjv_1::new);
    public static final rjp_2<rjo_1> else = rjp_2.class("smithing", rjo_1::new);
    public static final rjp_2<rjk_1> synchronized = rjp_2.class("smoker", rjk_1::new);
    public static final rjp_2<rxr_1> return = rjp_2.class("cartography_table", rxr_1::new);
    public static final rjp_2<rjd_1> public = rjp_2.class("stonecutter", rjd_1::new);
    private final rjb_2<T> goto;

    private rjp_2(rjb_2<T> rjb_22) {
        this.goto = rjb_22;
    }

    private static <T extends rjr_2> rjp_2<T> class(String string, rjb_2<T> rjb_22) {
        return rvl_0.class(rvl_0.G, string, new rjp_2<T>(rjb_22));
    }

    public T class(int n2, rhz_2 rhz_22) {
        return this.goto.create(n2, rhz_22);
    }
}

