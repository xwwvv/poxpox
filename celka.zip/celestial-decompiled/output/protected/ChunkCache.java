/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  it.unimi.dsi.fastutil.longs.Long2ObjectMap
 *  it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap
 */
package protected;

import it.unimi.dsi.fastutil.longs.Long2ObjectMap;
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.attribute.FileAttribute;
import java.security.Key;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingQueue;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.case;
import protected.class;
import protected.continue;
import protected.pp_2;
import protected.rYB;
import protected.return;
import protected.rfH;
import protected.roj_0;
import protected.rqm_0;
import protected.sf_1;
import protected.st_1;
import protected.super;
import protected.sw_1;
import protected.throws;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.SI
 */
public class si_2
implements pp_2,
super {
    private static short[] throws;
    private static long[] case;
    public static Object[] class;
    private static int[] catch;
    private static double[] private;
    private static byte[] implements;
    private static boolean[] finally;
    public Object[] break;

    public boolean byte(int n2, int n3) {
        return this.throws(n2 >> implements[2], n3 >> implements[3]) != null ? finally[3] : finally[4];
    }

    private void byte() {
        if (this.break == null) {
            Object[] objectArray = this.break = new Object[implements[17]];
        }
    }

    public si_2(Path path, rqm_0<rYB> rqm_02) {
        rqm_0<rYB> rqm_03;
        ConcurrentHashMap concurrentHashMap;
        LinkedBlockingQueue linkedBlockingQueue;
        this.byte();
        Long2ObjectOpenHashMap long2ObjectOpenHashMap = new Long2ObjectOpenHashMap();
        this.break[si_2.throws[0]] = long2ObjectOpenHashMap;
        this.break[si_2.throws[1]] = linkedBlockingQueue = new LinkedBlockingQueue();
        this.break[si_2.throws[2]] = concurrentHashMap = new ConcurrentHashMap();
        if (!Files.exists(path, new LinkOption[finally[0]])) {
            try {
                Files.createDirectories(path, new FileAttribute[finally[1]]);
            }
            catch (IOException iOException) {
                // empty catch block
            }
        }
        String string = path.toString();
        this.break[si_2.throws[3]] = string;
        this.break[si_2.throws[4]] = rqm_03 = rqm_02;
        protected.class.interface().execute(new sf_1(this));
        protected.class.interface().execute(() -> {
            try {
                Thread.sleep(case[5]);
                while (true) {
                    this.class();
                    Thread.sleep(case[6]);
                }
            }
            catch (InterruptedException interruptedException) {
                interruptedException.printStackTrace();
                return;
            }
        });
    }

    static {
        si_2.ntfClinit();
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0xA8E3BAC7;
    }

    @Override
    public void class() {
        if (!((Boolean)protected.class.instanceof().throw.class[throws[13]]).booleanValue()) {
            this.catch().forEach(sw_12 -> {
                if (sw_12 != null) {
                    sw_12.byte();
                }
            });
            this.finally();
            return;
        }
        this.catch().parallelStream().forEach(sw_12 -> {
            if (sw_12 != null) {
                sw_12.byte((String)this.break[throws[29]]);
            }
        });
        this.finally();
    }

    void class(st_1 st_12) {
        sw_1 sw_12 = this.case((Integer)st_12.break[throws[9]] >> implements[6], (Integer)st_12.break[throws[10]] >> implements[7]);
        sw_12.class((Integer)st_12.break[throws[11]] & implements[8], (Integer)st_12.break[throws[12]] & implements[9], st_12);
    }

    public static String class(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{-80, 35, -77, -106, 114, 41, 61, -45}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    @Override
    public /* synthetic */ continue class(int n2, int n3) {
        return this.throws(n2, n3);
    }

    @Override
    public void class(roj_0 roj_02) {
        if (((Map)this.break[throws[5]]).put(roj_02.private(), roj_02) == null) {
            ((LinkedBlockingQueue)this.break[throws[6]]).add(roj_02.private());
        }
    }

    @Override
    public ArrayList<rfH> class(String string, int n2, int n3, int n4, int n5) {
        ArrayList<rfH> arrayList = new ArrayList<rfH>();
        int n6 = n3 >> implements[4];
        int n7 = n4 >> implements[5];
        for (int k = finally[5]; k <= n5; ++k) {
            for (int i2 = -k; i2 <= k; ++i2) {
                for (int i3 = -k; i3 <= k; ++i3) {
                    int n8;
                    int n9;
                    sw_1 sw_12;
                    int n10 = i2 * i2 + i3 * i3;
                    if (n10 != k || (sw_12 = this.case(n9 = i2 + n6, n8 = i3 + n7)) == null) continue;
                    arrayList.addAll(sw_12.protected(string));
                }
            }
            if (arrayList.size() < n2) continue;
            return arrayList;
        }
        return arrayList;
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0x9E53AB88C9216AF4L;
    }

    @Override
    public boolean break(int n2, int n3) {
        sw_1 sw_12 = this.throws(n2 >> implements[0], n3 >> implements[1]);
        if (sw_12 == null) {
            return finally[2];
        }
        return sw_12.class(n2 & throws[7], n3 & throws[8]);
    }

    @Override
    public void break() {
        long l2 = System.nanoTime() / case[0];
        this.catch().forEach(sw_12 -> {
            if (sw_12 != null) {
                sw_12.class((String)this.break[throws[28]]);
            }
        });
        long l3 = System.nanoTime() / case[1];
        System.out.println("World load took " + (l3 - l2) + "ms");
    }

    private static void throws() {
        catch = new int[]{58594, -58594, 58594, -58594, 58594};
    }

    public synchronized sw_1 throws(int n2, int n3) {
        return (sw_1)((Long2ObjectMap)this.break[throws[24]]).get(this.private(n2, n3));
    }

    private static /* synthetic */ void ntfClinit() {
        si_2.case();
        si_2.volatile();
        si_2.final();
        si_2.extends();
        si_2.protected();
        si_2.throws();
        si_2.implements();
    }

    private synchronized void finally() {
        if (!((Boolean)protected.class.instanceof().throws.class[throws[14]]).booleanValue()) {
            return;
        }
        rfH rfH2 = this.native();
        for (sw_1 sw_12 : this.catch()) {
            int n2;
            int n3;
            double d;
            if (sw_12 == null || !((d = Math.sqrt((n3 = (sw_12.break() << implements[10]) + throws[15] - rfH2.b_()) * n3 + (n2 = (sw_12.class() << implements[11]) + throws[16] - rfH2.d_()) * n2)) > private[0])) continue;
            if (!((Boolean)protected.class.instanceof().A.class[throws[17]]).booleanValue()) {
                this.byte("Deleting cached region " + sw_12.break() + "," + sw_12.class() + " from ram");
            }
            ((Long2ObjectMap)this.break[throws[18]]).remove(this.private(sw_12.break(), sw_12.class()));
        }
    }

    private boolean catch(int n2, int n3) {
        return n2 <= catch[0] && n2 >= catch[1] && n3 <= catch[2] && n3 >= catch[3] ? finally[10] : finally[11];
    }

    private synchronized List<sw_1> catch() {
        return new ArrayList<sw_1>((Collection<sw_1>)((Long2ObjectMap)this.break[throws[23]]).values());
    }

    private static void extends() {
        private = new double[]{1024.0};
    }

    private static void case() {
        boolean[] blArray = new boolean[14];
        blArray[3] = true;
        blArray[10] = true;
        blArray[12] = true;
        finally = blArray;
    }

    private synchronized sw_1 case(int n2, int n3) {
        return (sw_1)((Long2ObjectMap)this.break[throws[25]]).computeIfAbsent(this.private(n2, n3), l2 -> {
            sw_1 sw_12 = new sw_1(n2, n3, (rqm_0)this.break[throws[26]]);
            sw_12.class((String)this.break[throws[27]]);
            return sw_12;
        });
    }

    private static void implements() {
        Object[] objectArray = new Object[]{58594};
        si_2.class = objectArray;
    }

    public void protected(int n2, int n3) {
        this.case(n2, n3);
    }

    private static void protected() {
        implements = new byte[]{9, 9, 9, 9, 9, 9, 5, 5, 31, 31, 9, 9, 4, 8, 4, 8, 32, 5};
    }

    private long private(int n2, int n3) {
        if (!this.catch(n2, n3)) {
            return case[2];
        }
        return (long)n2 & case[3] | ((long)n3 & case[4]) << implements[16];
    }

    private static void final() {
        short[] sArray = new short[30];
        sArray[1] = 2;
        sArray[2] = 3;
        sArray[3] = 1;
        sArray[4] = 4;
        sArray[5] = 3;
        sArray[6] = 2;
        sArray[7] = 511;
        sArray[8] = 511;
        sArray[10] = 1;
        sArray[12] = 1;
        sArray[15] = 256;
        sArray[16] = 256;
        sArray[19] = 7;
        sArray[20] = 7;
        sArray[22] = 1;
        sArray[26] = 4;
        sArray[27] = 1;
        sArray[28] = 1;
        sArray[29] = 1;
        throws = sArray;
    }

    private static void volatile() {
        long[] lArray = new long[7];
        lArray[0] = 1000000L;
        lArray[1] = 1000000L;
        lArray[3] = 0xFFFFFFFFL;
        lArray[4] = 0xFFFFFFFFL;
        lArray[5] = 30000L;
        lArray[6] = 600000L;
        case = lArray;
    }

    private rfH native() {
        for (case object : protected.throws.class().case()) {
            return return_ = object.implements().class();
            if (return_ == null || return_.break() != this || object.throw().catch() == null) continue;
            return object.throw().volatile();
        }
        Object object = null;
        for (sw_1 sw_12 : this.catch()) {
            st_1 st_12;
            if (sw_12 == null || (st_12 = sw_12.protected()) == null || object != null && (Long)((st_1)object).break[throws[19]] >= (Long)st_12.break[throws[20]]) continue;
            object = st_12;
        }
        if (object == null) {
            return new rfH(finally[6], finally[7], finally[8]);
        }
        return new rfH(((Integer)((st_1)object).break[throws[21]] << implements[12]) + implements[13], finally[9], ((Integer)((st_1)object).break[throws[22]] << implements[14]) + implements[15]);
    }
}

