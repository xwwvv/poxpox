/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.util.function.Consumer;
import protected.ai_0;
import protected.hk_1;
import protected.hl_1;
import protected.hw_1;
import protected.hw_2;
import protected.jo_2;
import protected.oe_1;
import protected.or_1;
import protected.ot_1;
import protected.ot_2;
import protected.rYB;
import protected.rdy_2;
import protected.rgP;
import protected.rgn;
import protected.rqo_0;
import protected.rrrZ;
import protected.xb_1;
import protected.xk_1;
import protected.xk_2;
import protected.xm_1;
import protected.xn_2;
import protected.xu_0;
import protected.xz_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.UN
 */
public class un_0
implements Consumer<Consumer<ot_1>> {
    public void class(Consumer<ot_1> consumer) {
        ot_1 ot_12 = ot_2.class().class(xu_0.Sh, (rgP)new rgn("advancements.end.root.title"), (rgP)new rgn("advancements.end.root.description"), new rqo_0("textures/gui/advancements/backgrounds/end.png"), oe_1.TASK, false, false, false).class("entered_end", hw_2.class(rYB.throws)).class(consumer, "end/root");
        ot_1 ot_13 = ot_2.class().class(ot_12).class(xu_0.sQ, (rgP)new rgn("advancements.end.kill_dragon.title"), (rgP)new rgn("advancements.end.kill_dragon.description"), (rqo_0)null, oe_1.TASK, true, true, false).class("killed_dragon", xk_2.class(hk_1.class().class(ai_0.this))).class(consumer, "end/kill_dragon");
        ot_1 ot_14 = ot_2.class().class(ot_13).class(rdy_2.Jm, (rgP)new rgn("advancements.end.enter_end_gateway.title"), (rgP)new rgn("advancements.end.enter_end_gateway.description"), (rqo_0)null, oe_1.TASK, true, true, false).class("entered_end_gateway", hw_1.class(xu_0.bw)).class(consumer, "end/enter_end_gateway");
        ot_2.class().class(ot_13).class(rdy_2.kM, (rgP)new rgn("advancements.end.respawn_dragon.title"), (rgP)new rgn("advancements.end.respawn_dragon.description"), (rqo_0)null, oe_1.GOAL, true, true, false).class("summoned_dragon", jo_2.class(hk_1.class().class(ai_0.this))).class(consumer, "end/respawn_dragon");
        ot_1 ot_15 = ot_2.class().class(ot_14).class(xu_0.bH, (rgP)new rgn("advancements.end.find_end_city.title"), (rgP)new rgn("advancements.end.find_end_city.description"), (rqo_0)null, oe_1.TASK, true, true, false).class("in_city", xk_1.class(xn_2.class(rrrZ.package))).class(consumer, "end/find_end_city");
        ot_2.class().class(ot_13).class(rdy_2.kd, (rgP)new rgn("advancements.end.dragon_breath.title"), (rgP)new rgn("advancements.end.dragon_breath.description"), (rqo_0)null, oe_1.GOAL, true, true, false).class("dragon_breath", xb_1.class(rdy_2.kd)).class(consumer, "end/dragon_breath");
        ot_2.class().class(ot_15).class(rdy_2.kA, (rgP)new rgn("advancements.end.levitate.title"), (rgP)new rgn("advancements.end.levitate.description"), (rqo_0)null, oe_1.CHALLENGE, true, true, false).class(or_1.class(50)).class("levitated", xz_2.class(hl_1.break(xm_1.class(50.0f)))).class(consumer, "end/levitate");
        ot_2.class().class(ot_15).class(rdy_2.kc, (rgP)new rgn("advancements.end.elytra.title"), (rgP)new rgn("advancements.end.elytra.description"), (rqo_0)null, oe_1.GOAL, true, true, false).class("elytra", xb_1.class(rdy_2.kc)).class(consumer, "end/elytra");
        ot_2.class().class(ot_13).class(xu_0.SX, (rgP)new rgn("advancements.end.dragon_egg.title"), (rgP)new rgn("advancements.end.dragon_egg.description"), (rqo_0)null, oe_1.GOAL, true, true, false).class("dragon_egg", xb_1.class(xu_0.SX)).class(consumer, "end/dragon_egg");
    }

    @Override
    public /* synthetic */ void accept(Object object) {
        this.class((Consumer)object);
    }
}

