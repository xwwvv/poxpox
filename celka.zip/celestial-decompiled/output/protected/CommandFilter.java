/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.regex.Pattern;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.C;
import protected.class;
import protected.pv_2;
import protected.rrfZ;
import protected.rrfv_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.BM
 */
public class bm_2
extends pv_2 {
    private static short[] byte;
    private static String[] protected;
    public static Object[] break;
    private static byte[] throws;
    private static boolean[] case;

    private static void byte() {
        short[] sArray = new short[2];
        sArray[1] = 1;
        byte = sArray;
    }

    public bm_2(class clazz) {
        super(clazz);
    }

    static {
        bm_2.ntfClinit();
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0xC0FEC579;
    }

    @Override
    public void class(C c) {
        super.class(c);
        boolean bl2 = rrfZ.byte();
        if (!bl2) {
            return;
        }
        String string = c.class().toLowerCase().trim();
        if ((((Pattern)break[byte[0]]).matcher(string).find() || ((Pattern)break[byte[1]]).matcher(string).find()) && rrfv_0.class(string, case[0])) {
            c.break();
        }
    }

    private static void class() {
        Object[] objectArray = new Object[]{Pattern.compile(protected[0], 0), Pattern.compile(protected[1])};
        break = objectArray;
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0xD3831135E37A50C2L;
    }

    public static String break(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{56, -83, -109, 79, 69, -109, -79, 76}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    private static void break() {
        throws = new byte[]{2};
    }

    private static void throws() {
        protected = new String[]{new String("^/(an|anarchy|grf|grief)(\\d+).*"), new String("^/(hub).*")};
    }

    private static /* synthetic */ void ntfClinit() {
        bm_2.protected();
        bm_2.throws();
        bm_2.byte();
        bm_2.break();
        bm_2.class();
    }

    private static void protected() {
        boolean[] blArray = new boolean[3];
        blArray[0] = true;
        blArray[2] = true;
        case = blArray;
    }
}

