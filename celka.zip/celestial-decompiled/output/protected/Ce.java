/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.ch_0;
import protected.cj_0;
import protected.gm;
import protected.nw_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class Ce
extends nw_0 {
    private final ch_0 class;

    Ce(gm gm2, double d, double d2, double d3, double d4, double d5, double d6, ch_0 ch_02) {
        super(gm2, d, d2, d3, d4, d5, d6);
        this.class = ch_02;
        this.protected(1.5f);
        this.break(ch_02);
    }

    @Override
    public cj_0 class() {
        return cj_0.byte;
    }

    @Override
    public void case() {
        super.case();
        if (!this.package) {
            this.break(this.class);
        }
    }
}

