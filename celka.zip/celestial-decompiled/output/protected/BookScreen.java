/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableList
 *  com.google.common.collect.ImmutableList$Builder
 */
package protected;

import com.google.common.collect.ImmutableList;
import com.mojang.blaze3d.systems.RenderSystem;
import java.util.Collections;
import java.util.List;
import protected.cm_1;
import protected.cn_2;
import protected.lf_2;
import protected.ln_2;
import protected.ml_1;
import protected.rcd_2;
import protected.rcy_2;
import protected.rfU;
import protected.rgP;
import protected.rgS;
import protected.rgc_0;
import protected.rgh_0;
import protected.rgl_0;
import protected.rgn;
import protected.rgn_0;
import protected.rpl;
import protected.rqo_0;
import protected.vm_1;
import protected.vn_2;
import protected.vq_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.vz
 */
public class vz_2
extends vm_1 {
    public static final vn_2 class = new vq_2();
    public static final rqo_0 throws = new rqo_0("textures/gui/book.png");
    private vn_2 case;
    private int catch;
    private List<rpl> private = Collections.emptyList();
    private int implements = -1;
    private rgP finally = rgn_0.byte;
    private ln_2 else;
    private ln_2 synchronized;
    private final boolean return;

    public boolean byte(int n2) {
        int n3 = rfU.class(n2, 0, this.case.class() - 1);
        if (n3 != this.catch) {
            this.catch = n3;
            this.interface();
            this.implements = -1;
            return true;
        }
        return false;
    }

    protected void int() {
        int n2 = (this.package - 192) / 2;
        int n3 = 2;
        this.else = this.class(new ln_2(n2 + 116, 159, true, lf_22 -> this.package(), this.return));
        this.synchronized = this.class(new ln_2(n2 + 43, 159, false, lf_22 -> this.final(), this.return));
        this.interface();
    }

    public vz_2(vn_2 vn_22) {
        this(vn_22, true);
    }

    public vz_2() {
        this(vz_2.class, false);
    }

    private vz_2(vn_2 vn_22, boolean bl2) {
        super(rgn_0.byte);
        this.case = vn_22;
        this.return = bl2;
    }

    private void interface() {
        this.else.new = this.catch < this.finally() - 1;
        this.synchronized.new = this.catch > 0;
    }

    @Override
    public void class(ml_1 ml_12, int n2, int n3, float f2) {
        this.class(ml_12);
        RenderSystem.color4f(1.0f, 1.0f, 1.0f, 1.0f);
        this.volatile.A().class(throws);
        int n4 = (this.package - 192) / 2;
        int n5 = 2;
        this.break(ml_12, n4, 2, 0, 0, 192, 192);
        if (this.implements != this.catch) {
            rgS rgS2 = this.case.break(this.catch);
            this.private = this.super.break(rgS2, 114);
            this.finally = new rgn("book.pageIndicator", this.catch + 1, Math.max(this.finally(), 1));
        }
        this.implements = this.catch;
        int n6 = this.super.class(this.finally);
        this.super.byte(ml_12, this.finally, n4 - n6 + 192 - 44, 18.0f, 0);
        int n7 = Math.min(14, this.private.size());
        for (int k = 0; k < n7; ++k) {
            rpl rpl2 = this.private.get(k);
            this.super.break(ml_12, rpl2, (float)(n4 + 36), (float)(32 + k * 9), 0);
        }
        rgc_0 rgc_02 = this.protected(n2, n3);
        if (rgc_02 != null) {
            this.class(ml_12, rgc_02, n2, n3);
        }
        super.class(ml_12, n2, n3, f2);
    }

    @Override
    public boolean class(int n2, int n3, int n4) {
        if (super.class(n2, n3, n4)) {
            return true;
        }
        switch (n2) {
            case 266: {
                this.synchronized.catch();
                return true;
            }
            case 267: {
                this.else.catch();
                return true;
            }
        }
        return false;
    }

    public static List<String> class(rcd_2 rcd_22) {
        rcy_2 rcy_22 = rcd_22.protected("pages", 8).protected();
        ImmutableList.Builder builder = ImmutableList.builder();
        for (int k = 0; k < rcy_22.size(); ++k) {
            builder.add((Object)rcy_22.implements(k));
        }
        return builder.build();
    }

    @Override
    public boolean class(rgc_0 rgc_02) {
        rgl_0 rgl_02 = rgc_02.private();
        if (rgl_02 == null) {
            return false;
        }
        if (rgl_02.class() == rgh_0.CHANGE_PAGE) {
            String string = rgl_02.break();
            try {
                int n2 = Integer.parseInt(string) - 1;
                return this.break(n2);
            }
            catch (Exception exception) {
                return false;
            }
        }
        boolean bl2 = super.class(rgc_02);
        if (bl2 && rgl_02.class() == rgh_0.RUN_COMMAND) {
            this.volatile.break((vm_1)null);
        }
        return bl2;
    }

    public void class(vn_2 vn_22) {
        this.case = vn_22;
        this.catch = rfU.class(this.catch, 0, vn_22.class());
        this.interface();
        this.implements = -1;
    }

    @Override
    public boolean break(double d, double d2, int n2) {
        rgc_0 rgc_02;
        if (n2 == 0 && (rgc_02 = this.protected(d, d2)) != null && this.class(rgc_02)) {
            return true;
        }
        return super.break(d, d2, n2);
    }

    protected boolean break(int n2) {
        return this.byte(n2);
    }

    private int finally() {
        return this.case.class();
    }

    protected void package() {
        if (this.catch < this.finally() - 1) {
            ++this.catch;
        }
        this.interface();
    }

    public rgc_0 protected(double d, double d2) {
        if (this.private.isEmpty()) {
            return null;
        }
        int n2 = rfU.byte(d - (double)((this.package - 192) / 2) - 36.0);
        int n3 = rfU.byte(d2 - 2.0 - 30.0);
        if (n2 >= 0 && n3 >= 0) {
            int n4 = Math.min(14, this.private.size());
            if (n2 <= 114 && n3 < 9 * n4 + n4) {
                int n5 = n3 / 9;
                if (n5 >= 0 && n5 < this.private.size()) {
                    rpl rpl2 = this.private.get(n5);
                    return ((cm_1)this.volatile.class[15]).break().class(rpl2, n2);
                }
                return null;
            }
            return null;
        }
        return null;
    }

    protected void final() {
        if (this.catch > 0) {
            --this.catch;
        }
        this.interface();
    }

    protected void native() {
        this.class(new lf_2(this.package / 2 - 100, 196, 200, 20, cn_2.byte, lf_22 -> this.volatile.break((vm_1)null)));
    }

    @Override
    protected void v_() {
        this.native();
        this.int();
    }
}

