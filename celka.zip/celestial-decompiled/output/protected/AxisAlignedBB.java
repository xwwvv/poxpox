/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.je_1;
import protected.jq_1;
import protected.jt_2;
import protected.rjC;
import protected.rpr_0;
import protected.xd_0;
import protected.xu_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.zy
 */
public class zy_2
extends jt_2 {
    public static final rjC int = xd_0.class(4.0, 0.0, 4.0, 12.0, 16.0, 12.0);

    public zy_2(jq_1 jq_12) {
        super(jq_12, rpr_0.UP, int, false);
    }

    @Override
    protected je_1 implements() {
        return (je_1)xu_0.XH;
    }
}

