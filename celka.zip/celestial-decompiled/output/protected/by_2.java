/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.bo_2;
import protected.bt_1;
import protected.by_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.BY
 */
public class by_2
extends bt_1
implements by_1 {
    private static String[] byte;
    public Object[] class;
    private static boolean[] protected;
    private static short[] throws;

    public by_2() {
        super(byte[0]);
        this.private();
    }

    static {
        by_2.ntfClinit();
    }

    @Override
    public String class() {
        this.private();
        if ((bo_2)((Object)this.class[throws[3]]) == null) {
            return null;
        }
        return ((bo_2)((Object)this.class[throws[4]])).class();
    }

    public static String class(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{-89, 54, 102, 85, 96, 55, 45, 38}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0xE5B4F7C8594D6840L;
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0x8EDBE485;
    }

    private static void break() {
        byte = new String[]{new String("\u0421\u0443\u043d\u0434\u0443\u043a \u0441\u043c\u0435\u0440\u0442\u0438")};
    }

    @Override
    public void throws(String string) {
        this.private();
        super.throws(string);
        bo_2 bo_22 = bo_2.class(string);
        this.class[by_2.throws[0]] = bo_22;
        if ((bo_2)((Object)this.class[throws[1]]) != null) {
            this.protected(((bo_2)((Object)this.class[throws[2]])).class() + " " + this.throws().toLowerCase());
        }
    }

    private static /* synthetic */ void ntfClinit() {
        by_2.implements();
        by_2.break();
        by_2.catch();
    }

    private static void catch() {
        throws = new short[5];
    }

    private static void implements() {
        protected = new boolean[]{true};
    }

    private void private() {
        if (this.class == null) {
            Object[] objectArray = this.class = new Object[protected[0]];
        }
    }
}

