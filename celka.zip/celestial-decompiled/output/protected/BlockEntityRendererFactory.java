/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.brigadier.context.CommandContext
 *  com.mojang.brigadier.exceptions.CommandSyntaxException
 *  com.mojang.brigadier.suggestion.SuggestionProvider
 *  com.mojang.brigadier.suggestion.Suggestions
 *  com.mojang.brigadier.suggestion.SuggestionsBuilder
 */
package protected;

import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import java.util.concurrent.CompletableFuture;
import protected.gR;
import protected.rqo_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class YH
implements SuggestionProvider<gR> {
    private final SuggestionProvider<gR> class;
    final rqo_0 break;

    public YH(rqo_0 rqo_02, SuggestionProvider<gR> suggestionProvider) {
        this.class = suggestionProvider;
        this.break = rqo_02;
    }

    public CompletableFuture<Suggestions> getSuggestions(CommandContext<gR> commandContext, SuggestionsBuilder suggestionsBuilder) throws CommandSyntaxException {
        return this.class.getSuggestions(commandContext, suggestionsBuilder);
    }
}

