/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableList
 */
package protected;

import com.google.common.collect.ImmutableList;
import protected.an;
import protected.iq_1;
import protected.rfU;
import protected.wn_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.wd
 */
public class wd_0<T extends an>
extends wn_0<T> {
    private final iq_1 class;
    private final iq_1 break;
    private final iq_1 byte;
    private final iq_1 protected;
    private final iq_1 throws;
    private final iq_1 case;

    public wd_0() {
        this.return = 32;
        this.public = 32;
        int n2 = 23;
        this.class = new iq_1(this, 0, 27);
        this.class.class(-1.5f, -2.0f, -1.5f, 3.0f, 2.0f, 3.0f);
        this.class.class(0.0f, 23.0f, 0.0f);
        this.break = new iq_1(this, 24, 6);
        this.break.class(-1.5f, 0.0f, -1.5f, 1.0f, 1.0f, 1.0f);
        this.break.class(0.0f, 20.0f, 0.0f);
        this.byte = new iq_1(this, 28, 6);
        this.byte.class(0.5f, 0.0f, -1.5f, 1.0f, 1.0f, 1.0f);
        this.byte.class(0.0f, 20.0f, 0.0f);
        this.case = new iq_1(this, -3, 0);
        this.case.class(-1.5f, 0.0f, 0.0f, 3.0f, 0.0f, 3.0f);
        this.case.class(0.0f, 22.0f, 1.5f);
        this.protected = new iq_1(this, 25, 0);
        this.protected.class(-1.0f, 0.0f, 0.0f, 1.0f, 0.0f, 2.0f);
        this.protected.class(-1.5f, 22.0f, -1.5f);
        this.throws = new iq_1(this, 25, 0);
        this.throws.class(0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 2.0f);
        this.throws.class(1.5f, 22.0f, -1.5f);
    }

    @Override
    public Iterable<iq_1> class() {
        return ImmutableList.of((Object)this.class, (Object)this.break, (Object)this.byte, (Object)this.case, (Object)this.protected, (Object)this.throws);
    }

    @Override
    public void class(T t2, float f2, float f3, float f4, float f5, float f6) {
        this.protected.private = -0.2f + 0.4f * rfU.class(f4 * 0.2f);
        this.throws.private = 0.2f - 0.4f * rfU.class(f4 * 0.2f);
    }
}

