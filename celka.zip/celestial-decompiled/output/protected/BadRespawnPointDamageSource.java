/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.ib_0;
import protected.rVi;
import protected.rgP;
import protected.rgh_0;
import protected.rgl_0;
import protected.rgn;
import protected.rgn_0;
import protected.rgp_0;
import protected.rgv;
import protected.rgy_0;
import protected.rye_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.ryC
 */
public class ryc_1
extends rye_1 {
    protected ryc_1() {
        super("badRespawnPoint");
        this.continue();
        this.throws();
    }

    @Override
    public rgP class(ib_0 ib_02) {
        rVi rVi2 = rgv.class(new rgn("death.attack.badRespawnPoint.link")).class(rgc_02 -> rgc_02.class(new rgl_0(rgh_0.OPEN_URL, "https://bugs.mojang.com/browse/MCPE-28723")).class(new rgy_0(rgp_0.class, new rgn_0("MCPE-28723"))));
        return new rgn("death.attack.badRespawnPoint.message", ib_02.L_(), rVi2);
    }
}

