/*
 * Decompiled with CFR 0.152.
 */
package protected;

/*
 * Renamed from protected.aL
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class al_0 {
    public static final al_0 class = new al_0();
    public static final al_0 break = new al_0();
    public static final al_0 byte = new al_0();
    public static final al_0 protected = new al_0();
    public static final al_0 throws = new al_0();
}

