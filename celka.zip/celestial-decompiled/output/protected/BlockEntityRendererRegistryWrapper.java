/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonArray
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonNull
 *  com.google.gson.JsonObject
 *  com.google.gson.JsonParseException
 *  com.google.gson.JsonSyntaxException
 */
package protected;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonSyntaxException;
import java.util.Map;
import protected.ea_0;
import protected.ev_0;
import protected.ht_2;
import protected.rab_2;
import protected.rdb_1;
import protected.rdn_1;
import protected.rlZ;
import protected.rlb;
import protected.rli_1;
import protected.rpY;
import protected.rqo_0;
import protected.rvl_0;
import protected.rxy_0;
import protected.xc_1;
import protected.xf_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.Xh
 */
public class xh_2 {
    public static final xh_2 class = new xh_2();
    private final rlb<rdb_1> break;
    private final rdb_1 byte;
    private final xf_2 protected;
    private final xf_2 throws;
    private final ht_2[] case;
    private final ht_2[] catch;
    private final rli_1 private;
    private final xc_1 implements;

    public xh_2() {
        this.break = null;
        this.byte = null;
        this.private = null;
        this.protected = xf_2.throws;
        this.throws = xf_2.throws;
        this.case = ht_2.break;
        this.catch = ht_2.break;
        this.implements = xc_1.class;
    }

    public xh_2(rlb<rdb_1> rlb2, rdb_1 rdb_12, xf_2 xf_22, xf_2 xf_23, ht_2[] ht_2Array, ht_2[] ht_2Array2, rli_1 rli_12, xc_1 xc_12) {
        this.break = rlb2;
        this.byte = rdb_12;
        this.protected = xf_22;
        this.throws = xf_23;
        this.case = ht_2Array;
        this.catch = ht_2Array2;
        this.private = rli_12;
        this.implements = xc_12;
    }

    public JsonElement class() {
        JsonArray jsonArray;
        if (this == xh_2.class) {
            return JsonNull.INSTANCE;
        }
        JsonObject jsonObject = new JsonObject();
        if (this.byte != null) {
            jsonObject.addProperty("item", rvl_0.for.break(this.byte).toString());
        }
        if (this.break != null) {
            jsonObject.addProperty("tag", rlZ.class().break().break(this.break).toString());
        }
        jsonObject.add("count", this.protected.protected());
        jsonObject.add("durability", this.throws.protected());
        jsonObject.add("nbt", this.implements.class());
        if (this.case.length > 0) {
            jsonArray = new JsonArray();
            for (ht_2 ht_22 : this.case) {
                jsonArray.add(ht_22.class());
            }
            jsonObject.add("enchantments", (JsonElement)jsonArray);
        }
        if (this.catch.length > 0) {
            jsonArray = new JsonArray();
            for (ht_2 ht_22 : this.catch) {
                jsonArray.add(ht_22.class());
            }
            jsonObject.add("stored_enchantments", (JsonElement)jsonArray);
        }
        if (this.private != null) {
            jsonObject.addProperty("potion", rvl_0.double.break(this.private).toString());
        }
        return jsonObject;
    }

    private static /* synthetic */ JsonSyntaxException class(rqo_0 rqo_02) {
        return new JsonSyntaxException("Unknown potion '" + rqo_02 + "'");
    }

    public static xh_2 class(JsonElement jsonElement) {
        if (jsonElement != null && !jsonElement.isJsonNull()) {
            ht_2[] ht_2Array;
            Object object;
            rlb<rdb_1> rlb2;
            JsonObject jsonObject = rpY.private(jsonElement, "item");
            xf_2 xf_22 = xf_2.class(jsonObject.get("count"));
            xf_2 xf_23 = xf_2.class(jsonObject.get("durability"));
            if (jsonObject.has("data")) {
                throw new JsonParseException("Disallowed data tag found");
            }
            xc_1 xc_12 = xc_1.class(jsonObject.get("nbt"));
            rdb_1 rdb_12 = null;
            if (jsonObject.has("item")) {
                rlb2 = new rqo_0(rpY.case(jsonObject, "item"));
                rdb_12 = rvl_0.for.break((rqo_0)((Object)rlb2)).orElseThrow(() -> xh_2.break((rqo_0)((Object)rlb2)));
            }
            rlb2 = null;
            if (jsonObject.has("tag")) {
                object = new rqo_0(rpY.case(jsonObject, "tag"));
                rlb2 = rlZ.class().break().class((rqo_0)object);
                if (rlb2 == null) {
                    throw new JsonSyntaxException("Unknown item tag '" + (rqo_0)object + "'");
                }
            }
            object = null;
            if (jsonObject.has("potion")) {
                ht_2Array = new rqo_0(rpY.case(jsonObject, "potion"));
                object = rvl_0.double.break((rqo_0)ht_2Array).orElseThrow(() -> xh_2.class((rqo_0)ht_2Array));
            }
            ht_2Array = ht_2.break(jsonObject.get("enchantments"));
            ht_2[] ht_2Array2 = ht_2.break(jsonObject.get("stored_enchantments"));
            return new xh_2(rlb2, rdb_12, xf_22, xf_23, ht_2Array, ht_2Array2, (rli_1)object, xc_12);
        }
        return xh_2.class;
    }

    public boolean class(rdn_1 rdn_12) {
        Map<ev_0, Integer> map;
        if (this == xh_2.class) {
            return true;
        }
        if (this.break != null && !this.break.class(rdn_12.break())) {
            return false;
        }
        if (this.byte != null && rdn_12.break() != this.byte) {
            return false;
        }
        if (!this.protected.byte(rdn_12.char())) {
            return false;
        }
        if (!this.throws.byte() && !rdn_12.throws()) {
            return false;
        }
        if (!this.throws.byte(rdn_12.private() - rdn_12.catch())) {
            return false;
        }
        if (!this.implements.class(rdn_12)) {
            return false;
        }
        if (this.case.length > 0) {
            map = ea_0.class(rdn_12.new());
            for (ht_2 ht_22 : this.case) {
                if (ht_22.class(map)) continue;
                return false;
            }
        }
        if (this.catch.length > 0) {
            map = ea_0.class(rxy_0.protected(rdn_12));
            for (ht_2 ht_22 : this.catch) {
                if (ht_22.class(map)) continue;
                return false;
            }
        }
        map = rab_2.protected(rdn_12);
        return this.private == null || this.private == map;
    }

    public static xh_2[] break(JsonElement jsonElement) {
        if (jsonElement != null && !jsonElement.isJsonNull()) {
            JsonArray jsonArray = rpY.implements(jsonElement, "items");
            xh_2[] xh_2Array = new xh_2[jsonArray.size()];
            for (int k = 0; k < xh_2Array.length; ++k) {
                xh_2Array[k] = xh_2.class(jsonArray.get(k));
            }
            return xh_2Array;
        }
        return new xh_2[0];
    }

    private static /* synthetic */ JsonSyntaxException break(rqo_0 rqo_02) {
        return new JsonSyntaxException("Unknown item id '" + rqo_02 + "'");
    }
}

