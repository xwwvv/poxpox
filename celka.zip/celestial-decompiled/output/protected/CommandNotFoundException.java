/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.import;
import protected.interface;
import protected.pp_2;
import protected.x;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.N
 */
public class n_0
extends x {
    public Object[] class;
    private static String[] break;
    private static short[] byte;
    private static boolean[] protected;

    private static void byte() {
        boolean[] blArray = new boolean[3];
        blArray[0] = true;
        blArray[2] = true;
        protected = blArray;
    }

    public n_0(String string) {
        Object[] objectArray = new Object[protected[0]];
        objectArray[n_0.protected[1]] = string;
        super(String.format(break[0], objectArray));
        this.protected();
        String string2 = string;
        this.class[n_0.byte[0]] = string2;
    }

    static {
        n_0.ntfClinit();
    }

    @Override
    public void class(interface interface_, List<import> list) {
        pp_2.a_.case(this.getMessage());
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0x4F58C46AA4BB04CL;
    }

    public static String class(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{0, -128, -86, -73, -100, 14, -97, 65}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    private static void class() {
        byte = new short[1];
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0x6F0693A9;
    }

    private static void break() {
        break = new String[]{new String("\u041a\u043e\u043c\u0430\u043d\u0434\u0430 \u043d\u0435 \u043d\u0430\u0439\u0434\u0435\u043d\u0430: %s")};
    }

    private static /* synthetic */ void ntfClinit() {
        n_0.byte();
        n_0.break();
        n_0.class();
    }

    private void protected() {
        if (this.class == null) {
            Object[] objectArray = this.class = new Object[protected[2]];
        }
    }
}

