/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.datafixers.kinds.App
 *  com.mojang.datafixers.kinds.Applicative
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.MapCodec
 *  com.mojang.serialization.codecs.RecordCodecBuilder
 */
package protected;

import com.mojang.datafixers.kinds.App;
import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import protected.rYx;
import protected.ryj_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.rYX
 */
class ryx_0 {
    public static final MapCodec<ryx_0> class = RecordCodecBuilder.mapCodec(instance -> instance.group((App)ryj_0.CODEC.fieldOf("precipitation").forGetter(ryx_02 -> ryx_02.break), (App)Codec.FLOAT.fieldOf("temperature").forGetter(ryx_02 -> Float.valueOf(ryx_02.byte)), (App)rYx.CODEC.optionalFieldOf("temperature_modifier", (Object)rYx.NONE).forGetter(ryx_02 -> ryx_02.protected), (App)Codec.FLOAT.fieldOf("downfall").forGetter(ryx_02 -> Float.valueOf(ryx_02.throws))).apply((Applicative)instance, ryx_0::new));
    final ryj_0 break;
    final float byte;
    final rYx protected;
    final float throws;

    ryx_0(ryj_0 ryj_02, float f2, rYx rYx2, float f3) {
        this.break = ryj_02;
        this.byte = f2;
        this.protected = rYx2;
        this.throws = f3;
    }
}

