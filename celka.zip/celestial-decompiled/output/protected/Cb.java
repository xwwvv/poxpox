/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.CH;
import protected.ce_0;
import protected.ch_0;
import protected.cx_0;
import protected.gm;
import protected.rlo_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class Cb
implements cx_0<rlo_2> {
    private final ch_0 class;

    public Cb(ch_0 ch_02) {
        this.class = ch_02;
    }

    @Override
    public CH class(rlo_2 rlo_22, gm gm2, double d, double d2, double d3, double d4, double d5, double d6) {
        ce_0 ce_02 = new ce_0(gm2, d, d2, d3);
        ce_02.class(this.class);
        return ce_02;
    }
}

