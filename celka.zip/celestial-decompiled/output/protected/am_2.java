/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.oi_2;
import protected.oj_1;
import protected.ot_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.AM
 */
public interface am_2
extends oi_2 {
    public void class(ot_1 var1, oj_1 var2);

    public void throws(ot_1 var1);
}

