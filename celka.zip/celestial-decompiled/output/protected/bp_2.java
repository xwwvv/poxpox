/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.bq_2;
import protected.bt_1;
import protected.bt_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.Bp
 */
public class bp_2 {
    private static boolean[] byte;
    private static byte[] protected;
    private static short[] throws;
    public static Object[] class;
    public Object[] break;

    public bq_2 byte() {
        return (bq_2)((Object)this.break[throws[7]]);
    }

    public bp_2() {
        this.private();
    }

    static {
        bp_2.ntfClinit();
    }

    public static String class(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{112, -82, 4, -113, -9, 44, 64, -105}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0xA2F1191;
    }

    public bt_2 class() {
        return (bt_2)((Object)this.break[throws[9]]);
    }

    public static bp_2 class(bq_2 bq_22, bt_1 bt_12, bt_2 bt_22) {
        bq_2 bq_23 = bq_22;
        ((bp_2)bp_2.class[bp_2.throws[0]]).break[bp_2.throws[1]] = bq_23;
        bt_1 bt_13 = bt_12;
        ((bp_2)bp_2.class[bp_2.throws[2]]).break[bp_2.throws[3]] = bt_13;
        bt_2 bt_23 = bt_22;
        ((bp_2)bp_2.class[bp_2.throws[4]]).break[bp_2.throws[5]] = bt_23;
        return (bp_2)bp_2.class[throws[6]];
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0xE57F60FE1612B014L;
    }

    public bt_1 break() {
        return (bt_1)this.break[throws[8]];
    }

    private static void throws() {
        protected = new byte[]{3};
    }

    private static /* synthetic */ void ntfClinit() {
        bp_2.case();
        bp_2.protected();
        bp_2.throws();
        bp_2.catch();
    }

    private static void catch() {
        Object[] objectArray = new Object[]{new bp_2()};
        bp_2.class = objectArray;
    }

    private static void case() {
        boolean[] blArray = new boolean[2];
        blArray[1] = true;
        byte = blArray;
    }

    private static void protected() {
        short[] sArray = new short[10];
        sArray[3] = 1;
        sArray[5] = 2;
        sArray[8] = 1;
        sArray[9] = 2;
        throws = sArray;
    }

    private void private() {
        if (this.break == null) {
            Object[] objectArray = this.break = new Object[protected[0]];
        }
    }
}

