/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.hash.Hashing
 *  com.mojang.authlib.GameProfile
 */
package protected;

import com.google.common.hash.Hashing;
import com.mojang.authlib.GameProfile;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.aw_1;
import protected.cb_1;
import protected.fY;
import protected.fd_0;
import protected.ff;
import protected.gm;
import protected.iq_0;
import protected.jH;
import protected.qw_1;
import protected.qy_1;
import protected.rRl;
import protected.rfU;
import protected.rhd_2;
import protected.rhx_1;
import protected.rql;
import protected.rqo_0;
import protected.rrbb;
import protected.rrce_1;
import protected.rruo_0;
import protected.rrzw_1;
import protected.rxq_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.cG
 */
public abstract class cg_2
extends rhd_2
implements rrce_1 {
    private static boolean[] break;
    private static double[] finally;
    private static short[] extends;
    private static String[] native;
    private static float[] volatile;
    private static byte[] final;
    public Object[] class;

    private static void boolean() {
        finally = new double[]{1.0, 2.0};
    }

    @Override
    public void byte() {
        if (this.catch()) {
            this.class(this);
        }
        super.byte();
    }

    public rqo_0 int() {
        this.long();
        return (rqo_0)this.class[extends[21]];
    }

    private void long() {
        if (this.class == null) {
            Object[] objectArray = this.class = new Object[final[0]];
            objectArray[cg_2.final[1]] = Float.valueOf(volatile[10]);
            objectArray[cg_2.final[2]] = Float.valueOf(volatile[11]);
            objectArray[cg_2.final[3]] = Float.valueOf(volatile[12]);
            objectArray[cg_2.final[4]] = break[19];
            objectArray[cg_2.final[5]] = Float.valueOf(volatile[13]);
            objectArray[cg_2.final[6]] = Float.valueOf(volatile[14]);
            objectArray[cg_2.final[7]] = Float.valueOf(volatile[15]);
        }
    }

    private static void float() {
        float[] fArray = new float[16];
        fArray[0] = 1.0f;
        fArray[1] = 1.1f;
        fArray[3] = 1.0f;
        fArray[4] = 20.0f;
        fArray[5] = 1.0f;
        fArray[6] = 1.0f;
        fArray[7] = 1.0f;
        fArray[8] = 0.15f;
        fArray[9] = 1.0f;
        volatile = fArray;
    }

    public cg_2(gm gm2, GameProfile gameProfile) {
        super(gm2, gm2.this(), gm2.else(), gameProfile);
        this.long();
        Object var7_3 = null;
        this.class[cg_2.extends[0]] = var7_3;
        Boolean bl2 = break[0];
        this.class[cg_2.extends[1]] = bl2;
        gm gm3 = gm2;
        this.class[cg_2.extends[2]] = gm3;
        String string = gameProfile.getName();
        this.class[cg_2.extends[3]] = string;
        if ((String)this.class[extends[4]] != null && !((String)this.class[extends[5]]).isEmpty()) {
            String string2 = rql.class((String)this.class[extends[6]]);
            this.class[cg_2.extends[7]] = string2;
        }
    }

    static {
        cg_2.ntfClinit();
    }

    public static fd_0 class(rqo_0 rqo_02, String string) {
        fY fY2 = qy_1.instanceof().A();
        ff ff2 = fY2.break(rqo_02);
        if (ff2 == null) {
            Object[] objectArray = new Object[break[11]];
            objectArray[cg_2.break[12]] = rql.class(string);
            ff2 = new fd_0(null, String.format(native[0], objectArray), jH.class(cg_2.extends(string)), break[13], null);
            fY2.class(rqo_02, ff2);
        }
        return (fd_0)ff2;
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0x116F96C7;
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0x70DC3F8E1B88E1CBL;
    }

    @Override
    public void class(rruo_0 rruo_02) {
        this.long();
        rruo_0 rruo_03 = rruo_02;
        this.class[cg_2.extends[29]] = rruo_03;
    }

    public static rqo_0 class(String string) {
        return new rqo_0("skins/" + Hashing.sha1().hashUnencodedChars((CharSequence)rql.class(string)));
    }

    public void class(boolean bl2) {
        this.long();
        Boolean bl3 = bl2;
        this.class[cg_2.extends[25]] = bl3;
    }

    public void class(rqo_0 rqo_02) {
        this.long();
        rqo_0 rqo_03 = rqo_02;
        this.class[cg_2.extends[22]] = rqo_03;
    }

    private static void short() {
        boolean[] blArray = new boolean[20];
        blArray[1] = true;
        blArray[3] = true;
        blArray[5] = true;
        blArray[7] = true;
        blArray[9] = true;
        blArray[11] = true;
        blArray[13] = true;
        blArray[16] = true;
        blArray[17] = true;
        break = blArray;
    }

    public String break() {
        aw_1 aw_12 = this.continue();
        return aw_12 == null ? jH.break(this.ro()) : aw_12.throws();
    }

    public static String break(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{85, -78, -125, 96, 13, 77, -76, -89}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    @Override
    public rruo_0 throws() {
        this.long();
        return (rruo_0)this.class[extends[28]];
    }

    private static /* synthetic */ void ntfClinit() {
        cg_2.short();
        cg_2.public();
        cg_2.else();
        cg_2.float();
        cg_2.boolean();
        cg_2.static();
    }

    public boolean finally() {
        aw_1 aw_12 = this.continue();
        return aw_12 != null && aw_12.protected() ? break[7] : break[8];
    }

    public boolean catch() {
        return this.case() == (rqo_0)rhd_2.protected[extends[27]] ? break[17] : break[18];
    }

    @Override
    public String extends() {
        this.long();
        return (String)this.class[extends[20]];
    }

    public rqo_0 case() {
        this.long();
        if (!rrbb.e()) {
            return null;
        }
        if (this == (cb_1)qy_1.instanceof().class[extends[11]] || ((rrzw_1)rrzw_1.staticFieldsf09fd5e6d24c37ccb4408917cb188133[extends[12]]).class(this)) {
            return (rqo_0)rhd_2.protected[extends[13]];
        }
        if ((rqo_0)this.class[extends[14]] != null) {
            return (rqo_0)this.class[extends[15]];
        }
        aw_1 aw_12 = this.continue();
        return aw_12 == null ? null : aw_12.catch();
    }

    public aw_1 continue() {
        this.long();
        if ((aw_1)this.class[extends[8]] == null) {
            aw_1 aw_12 = qy_1.instanceof().void().class(this.ro());
            this.class[cg_2.extends[9]] = aw_12;
        }
        return (aw_1)this.class[extends[10]];
    }

    private static void else() {
        short[] sArray = new short[30];
        sArray[0] = 6;
        sArray[1] = 7;
        sArray[2] = 5;
        sArray[3] = 8;
        sArray[4] = 8;
        sArray[5] = 8;
        sArray[6] = 8;
        sArray[7] = 8;
        sArray[8] = 1;
        sArray[9] = 1;
        sArray[10] = 1;
        sArray[11] = 57;
        sArray[13] = 8;
        sArray[14] = 6;
        sArray[15] = 6;
        sArray[16] = 18;
        sArray[17] = 18;
        sArray[18] = 18;
        sArray[19] = 20;
        sArray[20] = 8;
        sArray[21] = 6;
        sArray[22] = 6;
        sArray[23] = 6;
        sArray[24] = 7;
        sArray[25] = 7;
        sArray[26] = 7;
        sArray[27] = 8;
        extends = sArray;
    }

    @Override
    public boolean implements() {
        aw_1 aw_12 = qy_1.instanceof().void().class(this.sv().getId());
        return aw_12 != null && aw_12.break() == rRl.CREATIVE ? break[3] : break[4];
    }

    public float new() {
        float f2 = volatile[0];
        if (((rhx_1)this.implements[cg_2.extends[16]]).break) {
            f2 *= volatile[1];
        }
        f2 = (float)((double)f2 * ((this.class(iq_0.protected) / (double)((rhx_1)this.implements[extends[17]]).break() + finally[0]) / finally[1]));
        if (((rhx_1)this.implements[extends[18]]).break() == volatile[2] || Float.isNaN(f2) || Float.isInfinite(f2)) {
            f2 = volatile[3];
        }
        if (this.return() && this.sX().break() instanceof rxq_0) {
            int n2 = this.SU();
            float f3 = (float)n2 / volatile[4];
            f3 = f3 > volatile[5] ? volatile[6] : (f3 *= f3);
            f2 *= volatile[7] - f3 * volatile[8];
        }
        return rfU.catch(((qw_1)qy_1.instanceof().class[cg_2.extends[19]]).e, volatile[9], f2);
    }

    public boolean package() {
        this.long();
        rqo_0 rqo_02 = this.case();
        if (this.catch()) {
            return break[14];
        }
        if (rqo_02 == null) {
            return break[15];
        }
        return rqo_02 == (rqo_0)this.class[extends[23]] ? (Boolean)this.class[extends[24]] : break[16];
    }

    public boolean super() {
        return this.continue() != null ? break[5] : break[6];
    }

    private static void static() {
        final = new byte[]{14, 2, 3, 4, 7, 11, 12, 13};
    }

    private static void public() {
        native = new String[]{new String("http://skins.minecraft.net/MinecraftSkins/%s.png")};
    }

    public boolean protected() {
        return this.continue() != null ? break[9] : break[10];
    }

    public boolean private() {
        this.long();
        return (Boolean)this.class[extends[26]];
    }

    public rqo_0 final() {
        aw_1 aw_12 = this.continue();
        return aw_12 == null ? jH.class(this.ro()) : aw_12.case();
    }

    public rqo_0 volatile() {
        aw_1 aw_12 = this.continue();
        return aw_12 == null ? null : aw_12.private();
    }

    @Override
    public boolean native() {
        aw_1 aw_12 = qy_1.instanceof().void().class(this.sv().getId());
        return aw_12 != null && aw_12.break() == rRl.SPECTATOR ? break[1] : break[2];
    }
}

