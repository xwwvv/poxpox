/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.Y;
import protected.rud_1;
import protected.rus_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.y
 */
public class y_0 {
    private static byte[] break;
    private static short[] byte;
    public Object[] class;

    public Y byte() {
        return (Y)((Object)this.class[byte[4]]);
    }

    public y_0(rud_1 rud_12, Y y, rus_2<?> rus_22) {
        rus_2<?> rus_23;
        this.throws();
        rud_1 rud_13 = rud_12;
        this.class[y_0.byte[0]] = rud_13;
        Y y2 = y;
        this.class[y_0.byte[1]] = y2;
        this.class[y_0.byte[2]] = rus_23 = rus_22;
    }

    static {
        y_0.ntfClinit();
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0xBBF4451C;
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0xE287EE6F9F89EAB7L;
    }

    public static String class(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{-94, 6, 14, -15, -61, -68, -23, -75}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    public rud_1 class() {
        return (rud_1)((Object)this.class[byte[3]]);
    }

    public <T extends rus_2<?>> T break() {
        return (T)((rus_2)this.class[byte[6]]);
    }

    private void throws() {
        if (this.class == null) {
            Object[] objectArray = this.class = new Object[break[0]];
        }
    }

    private static /* synthetic */ void ntfClinit() {
        y_0.case();
        y_0.catch();
    }

    private static void catch() {
        break = new byte[]{3};
    }

    private static void case() {
        short[] sArray = new short[7];
        sArray[1] = 1;
        sArray[2] = 2;
        sArray[4] = 1;
        sArray[5] = 2;
        sArray[6] = 2;
        byte = sArray;
    }

    public rus_2<?> protected() {
        return (rus_2)this.class[byte[5]];
    }
}

