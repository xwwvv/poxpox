/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.rRp;
import protected.rfH;
import protected.xc_0;

/*
 * Renamed from protected.yy
 */
public interface yy_2 {
    public int getColor(xc_0 var1, rRp var2, rfH var3, int var4);
}

