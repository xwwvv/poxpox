/*
 * Decompiled with CFR 0.152.
 */
package protected;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.ym
 */
final class ym_2
extends Enum<ym_2> {
    public static final /* enum */ ym_2 SUCCESSFUL = new ym_2();
    public static final /* enum */ ym_2 CANCELLED = new ym_2();
    private static final /* synthetic */ ym_2[] $VALUES;

    static {
        $VALUES = ym_2.class();
    }

    public static ym_2[] values() {
        return (ym_2[])$VALUES.clone();
    }

    public static ym_2 valueOf(String string) {
        return Enum.valueOf(ym_2.class, string);
    }

    private static /* synthetic */ ym_2[] class() {
        return new ym_2[]{SUCCESSFUL, CANCELLED};
    }
}

