/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.serialization.DataResult
 *  com.mojang.serialization.Dynamic
 *  com.mojang.serialization.DynamicOps
 *  org.apache.logging.log4j.Logger
 */
package protected;

import com.mojang.serialization.DataResult;
import com.mojang.serialization.Dynamic;
import com.mojang.serialization.DynamicOps;
import java.util.Random;
import java.util.UUID;
import org.apache.logging.log4j.Logger;
import protected.aU;
import protected.ai_0;
import protected.an;
import protected.ea_0;
import protected.iO;
import protected.oo_1;
import protected.rRf;
import protected.rYB;
import protected.rbB;
import protected.rcd_2;
import protected.rcf_1;
import protected.rcz_1;
import protected.rdf_1;
import protected.rdn_1;
import protected.rdy_2;
import protected.rfw;
import protected.rha_1;
import protected.rhd_2;
import protected.rhi_1;
import protected.rhn_2;
import protected.rhx_1;
import protected.rld_1;
import protected.rly_1;
import protected.rme_0;
import protected.rpm;
import protected.rqa_0;
import protected.rqn;
import protected.rrEm;
import protected.rrh_0;
import protected.rsC;
import protected.rsp;
import protected.rsq;
import protected.rst_0;
import protected.rut_2;
import protected.ruw_2;
import protected.rvl_0;
import protected.rxq_1;
import protected.rye_1;
import protected.ryz_1;
import protected.xb;
import protected.xd_0;
import protected.xu_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.rbE
 */
public class rbe_0
extends rbB
implements rha_1 {
    private static final rut_2<Boolean> class = rme_0.class(rbe_0.class, ruw_2.implements);
    private static final rut_2<rsp> break = rme_0.class(rbe_0.class, ruw_2.new);
    private int protected;
    private UUID super;
    private rcz_1 this;
    private rcd_2 else;
    private int synchronized;

    private void byte(rrEm rrEm2) {
        rsq rsq2 = this.class(ai_0.D, false);
        Object object = rxq_1.values();
        int n2 = ((rxq_1[])object).length;
        for (int k = 0; k < n2; ++k) {
            rxq_1 rxq_12 = object[k];
            rdn_1 rdn_12 = this.class(rxq_12);
            if (rdn_12.class()) continue;
            if (ea_0.protected(rdn_12)) {
                rsq2.class(rxq_12.break() + 300, rdn_12);
                continue;
            }
            double d = this.throws(rxq_12);
            if (!(d > 1.0)) continue;
            this.a_(rdn_12);
        }
        rsq2.class(this.su());
        if (this.this != null) {
            rsq2.class(this.this);
        }
        if (this.else != null) {
            rsq2.break(new rdf_1(this.else));
        }
        rsq2.else(this.synchronized);
        rsq2.class(rrEm2, rrEm2.throws(rsq2.Bs()), iO.CONVERSION, (aU)null, (rcd_2)null);
        if (this.super != null && (object = rrEm2.class(this.super)) instanceof rhn_2) {
            oo_1.continue.class((rhn_2)object, this, rsq2);
            rrEm2.class(rsC.class, (an)object, rsq2);
        }
        rsq2.break(new rly_1(rld_1.implements, 200, 0));
        if (!this.BF()) {
            rrEm2.class((rhd_2)null, 1027, this.Bs(), 0);
        }
    }

    @Override
    public rqa_0 byte(rye_1 rye_12) {
        return rqn.zM;
    }

    public rbe_0(ai_0<? extends rbe_0> ai_02, rYB rYB2) {
        super((ai_0<? extends rbB>)ai_02, rYB2);
        this.class(this.su().class(rvl_0.J.class((Random)this.throws[40])));
    }

    @Override
    public void this() {
        if (!((rYB)this.throws[7]).continue && this.BM() && this.sZ()) {
            int n2 = this.sv();
            this.protected -= n2;
            if (this.protected <= 0) {
                this.byte((rrEm)((rYB)this.throws[7]));
            }
        }
        super.this();
    }

    public void class(int n2) {
        this.synchronized = n2;
    }

    @Override
    public void class(rcd_2 rcd_22) {
        super.class(rcd_22);
        rsp.class.encodeStart((DynamicOps)rcf_1.class, (Object)this.su()).resultOrPartial(arg_0 -> ((Logger)((Logger)case[0])).error(arg_0)).ifPresent(rcz_12 -> rcd_22.class("VillagerData", (rcz_1)rcz_12));
        if (this.else != null) {
            rcd_22.class("Offers", this.else);
        }
        if (this.this != null) {
            rcd_22.class("Gossips", this.this);
        }
        rcd_22.break("ConversionTime", this.sZ() ? this.protected : -1);
        if (this.super != null) {
            rcd_22.class("ConversionPlayer", this.super);
        }
        rcd_22.break("Xp", this.synchronized);
    }

    @Override
    public void class(byte by) {
        if (by == 16) {
            if (!this.BF()) {
                ((rYB)this.throws[7]).class(this.rx(), this.rH(), this.BO(), rqn.zG, this.Pr(), 1.0f + ((Random)this.throws[40]).nextFloat(), ((Random)this.throws[40]).nextFloat() * 0.7f + 0.3f, false);
            }
        } else {
            super.class(by);
        }
    }

    public void class(rcz_1 rcz_12) {
        this.this = rcz_12;
    }

    @Override
    public aU class(rRf rRf2, rrh_0 rrh_02, iO iO2, aU aU2, rcd_2 rcd_22) {
        this.class(this.su().class(rhi_1.class(rRf2.protected(this.Bs()))));
        return super.class(rRf2, rrh_02, iO2, aU2, rcd_22);
    }

    public void class(rsp rsp2) {
        rsp rsp3 = this.su();
        if (rsp3.break() != rsp2.break()) {
            this.else = null;
        }
        ((rme_0)this.throws[49]).break(break, rsp2);
    }

    private void class(UUID uUID, int n2) {
        this.super = uUID;
        this.protected = n2;
        this.BQ().break(rbe_0.class, true);
        this.protected(rld_1.continue);
        this.break(new rly_1(rld_1.throws, n2, Math.min(((rYB)this.throws[7]).abstract().class() - 1, 0)));
        ((rYB)this.throws[7]).class((an)this, (byte)16);
    }

    @Override
    protected boolean sd() {
        return false;
    }

    @Override
    public ryz_1 break(rhd_2 rhd_22, rpm rpm2) {
        rdn_1 rdn_12 = rhd_22.protected(rpm2);
        if (rdn_12.break() == rdy_2.hy) {
            if (this.break(rld_1.continue)) {
                if (!((rhx_1)rhd_22.implements[18]).protected) {
                    rdn_12.catch(1);
                }
                if (!((rYB)this.throws[7]).continue) {
                    this.class(rhd_22.ro(), ((Random)this.throws[40]).nextInt(2401) + 3600);
                }
                return ryz_1.SUCCESS;
            }
            return ryz_1.CONSUME;
        }
        return super.break(rhd_22, rpm2);
    }

    @Override
    public void break(rcd_2 rcd_22) {
        super.break(rcd_22);
        if (rcd_22.byte("VillagerData", 10)) {
            DataResult dataResult = rsp.class.parse(new Dynamic((DynamicOps)rcf_1.class, (Object)rcd_22.byte("VillagerData")));
            dataResult.resultOrPartial(arg_0 -> ((Logger)((Logger)case[0])).error(arg_0)).ifPresent(this::class);
        }
        if (rcd_22.byte("Offers", 10)) {
            this.else = rcd_22.int("Offers");
        }
        if (rcd_22.byte("Gossips", 10)) {
            this.this = rcd_22.protected("Gossips", 10);
        }
        if (rcd_22.byte("ConversionTime", 99) && rcd_22.private("ConversionTime") > -1) {
            this.class(rcd_22.break("ConversionPlayer") ? rcd_22.class("ConversionPlayer") : null, rcd_22.private("ConversionTime"));
        }
        if (rcd_22.byte("Xp", 3)) {
            this.synchronized = rcd_22.private("Xp");
        }
    }

    @Override
    protected rdn_1 sx() {
        return rdn_1.break;
    }

    private int sv() {
        int n2 = 1;
        if (((Random)this.throws[40]).nextFloat() < 0.01f) {
            int n3 = 0;
            rfw rfw2 = new rfw();
            for (int k = (int)this.rx() - 4; k < (int)this.rx() + 4 && n3 < 14; ++k) {
                for (int i2 = (int)this.re() - 4; i2 < (int)this.re() + 4 && n3 < 14; ++i2) {
                    for (int i3 = (int)this.BO() - 4; i3 < (int)this.BO() + 4 && n3 < 14; ++i3) {
                        xd_0 xd_02 = ((rYB)this.throws[7]).byte(rfw2.class(k, i2, i3)).break();
                        if (xd_02 != xu_0.Bf && !(xd_02 instanceof xb)) continue;
                        if (((Random)this.throws[40]).nextFloat() < 0.3f) {
                            ++n2;
                        }
                        ++n3;
                    }
                }
            }
        }
        return n2;
    }

    public void catch(rcd_2 rcd_22) {
        this.else = rcd_22;
    }

    @Override
    public rqa_0 static() {
        return rqn.zs;
    }

    @Override
    public boolean private(double d) {
        return !this.sZ() && this.synchronized == 0;
    }

    @Override
    public rqa_0 Bt() {
        return rqn.zb;
    }

    @Override
    public rqa_0 sJ() {
        return rqn.zO;
    }

    @Override
    protected float SN() {
        return this.n_() ? (((Random)this.throws[40]).nextFloat() - ((Random)this.throws[40]).nextFloat()) * 0.2f + 2.0f : (((Random)this.throws[40]).nextFloat() - ((Random)this.throws[40]).nextFloat()) * 0.2f + 1.0f;
    }

    @Override
    public rsp su() {
        return ((rme_0)this.throws[49]).class(break);
    }

    public boolean sZ() {
        return this.BQ().class(rbe_0.class);
    }

    @Override
    protected void m_() {
        super.m_();
        ((rme_0)this.throws[49]).class(rbe_0.class, false);
        ((rme_0)this.throws[49]).class(break, new rsp(rhi_1.byte, rst_0.class, 1));
    }
}

