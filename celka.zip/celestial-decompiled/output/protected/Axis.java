/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.serialization.Codec
 */
package protected;

import com.mojang.serialization.Codec;
import java.util.Arrays;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import protected.rpH;
import protected.rpb;
import protected.rpe_0;
import protected.rpr_0;
import protected.rps;
import protected.rps_0;
import protected.rqR;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.rpB
 */
public abstract sealed class rpb_0
extends Enum<rpb_0>
implements Predicate<rpr_0>,
rpH
permits rps_0, rps, rpe_0 {
    public static final /* enum */ rpb_0 X = new rps_0("x");
    public static final /* enum */ rpb_0 Y = new rps("y");
    public static final /* enum */ rpb_0 Z = new rpe_0("z");
    private static final rpb_0[] VALUES;
    public static final Codec<rpb_0> CODEC;
    private static final Map<String, rpb_0> NAME_LOOKUP;
    private final String name;
    private static final /* synthetic */ rpb_0[] $VALUES;

    public boolean byte() {
        return this == Y;
    }

    rpb_0(String string2) {
        this.name = string2;
    }

    static {
        $VALUES = rpb_0.case();
        VALUES = rpb_0.values();
        CODEC = rpH.class(rpb_0::values, rpb_0::class);
        NAME_LOOKUP = Arrays.stream(VALUES).collect(Collectors.toMap(rpb_0::break, rpb_02 -> rpb_02));
    }

    public String toString() {
        return this.name;
    }

    public static rpb_0[] values() {
        return (rpb_0[])$VALUES.clone();
    }

    @Override
    public /* synthetic */ boolean test(Object object) {
        return this.class((rpr_0)object);
    }

    public static rpb_0 valueOf(String string) {
        return Enum.valueOf(rpb_0.class, string);
    }

    public abstract int class(int var1, int var2, int var3);

    public boolean class(rpr_0 rpr_02) {
        return rpr_02 != null && rpr_02.final() == this;
    }

    public abstract double class(double var1, double var3, double var5);

    @Override
    public String class() {
        return this.name;
    }

    public static rpb_0 class(Random random) {
        return rqR.class(VALUES, random);
    }

    public static rpb_0 class(String string) {
        return NAME_LOOKUP.get(string.toLowerCase(Locale.ROOT));
    }

    public String break() {
        return this.name;
    }

    public rpb throws() {
        switch (this) {
            case X: 
            case Z: {
                return rpb.HORIZONTAL;
            }
            case Y: {
                return rpb.VERTICAL;
            }
        }
        throw new Error("Someone's been tampering with the universe!");
    }

    private static /* synthetic */ rpb_0[] case() {
        return new rpb_0[]{X, Y, Z};
    }

    public boolean protected() {
        return this == X || this == Z;
    }
}

