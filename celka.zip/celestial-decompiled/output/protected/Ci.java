/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.util.Random;
import protected.ch_0;
import protected.cj_0;
import protected.gm;
import protected.lo_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class Ci
extends lo_0 {
    private static final Random class = new Random();
    private final ch_0 break;

    Ci(gm gm2, double d, double d2, double d3, double d4, double d5, double d6, ch_0 ch_02) {
        super(gm2, d, d2, d3, 0.5 - Ci.class.nextDouble(), d5, 0.5 - Ci.class.nextDouble());
        this.break = ch_02;
        this.extends *= (double)0.2f;
        if (d4 == 0.0 && d6 == 0.0) {
            this.finally *= (double)0.1f;
            this.native *= (double)0.1f;
        }
        this.throw *= 0.75f;
        this.this = (int)(8.0 / (Math.random() * 0.8 + 0.2));
        this.final = false;
        this.break(ch_02);
    }

    @Override
    public cj_0 class() {
        return cj_0.byte;
    }

    @Override
    public void case() {
        this.protected = this.catch;
        this.throws = this.private;
        this.case = this.implements;
        if (this.super++ >= this.this) {
            this.finally();
        } else {
            this.break(this.break);
            this.extends += 0.004;
            this.class(this.finally, this.extends, this.native);
            if (this.private == this.throws) {
                this.finally *= 1.1;
                this.native *= 1.1;
            }
            this.finally *= (double)0.96f;
            this.extends *= (double)0.96f;
            this.native *= (double)0.96f;
            if (this.volatile) {
                this.finally *= (double)0.7f;
                this.native *= (double)0.7f;
            }
        }
    }
}

