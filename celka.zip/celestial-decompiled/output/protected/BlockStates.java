/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableList
 *  com.mojang.datafixers.DSL
 *  com.mojang.datafixers.DataFixUtils
 *  com.mojang.datafixers.OpticFinder
 *  com.mojang.datafixers.Typed
 *  com.mojang.datafixers.schemas.Schema
 *  com.mojang.datafixers.types.Type
 *  com.mojang.datafixers.util.Pair
 *  com.mojang.serialization.Dynamic
 */
package protected;

import com.google.common.collect.ImmutableList;
import com.mojang.datafixers.DSL;
import com.mojang.datafixers.DataFixUtils;
import com.mojang.datafixers.OpticFinder;
import com.mojang.datafixers.Typed;
import com.mojang.datafixers.schemas.Schema;
import com.mojang.datafixers.types.Type;
import com.mojang.datafixers.util.Pair;
import com.mojang.serialization.Dynamic;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;
import protected.rTC;
import protected.rwb;
import protected.ryv_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.rwO
 */
public abstract class rwo_0 {
    private final Type<Pair<String, Dynamic<?>>> throws = DSL.named((String)rTC.volatile.typeName(), (Type)DSL.remainderType());
    protected final OpticFinder<List<Pair<String, Dynamic<?>>>> class = DSL.fieldFinder((String)"Palette", (Type)DSL.list(this.throws));
    protected final List break;
    protected final int byte;
    protected ryv_2 protected;

    int byte() {
        return this.byte;
    }

    public int byte(int n2) {
        return this.protected.class(n2);
    }

    public rwo_0(Typed<?> typed, Schema schema) {
        if (!Objects.equals(schema.getType(rTC.volatile), this.throws)) {
            throw new IllegalStateException("Block state type is not what was expected.");
        }
        Optional optional = typed.getOptional(this.class);
        this.break = optional.map(list -> list.stream().map(Pair::getSecond).collect(Collectors.toList())).orElse((List)ImmutableList.of());
        Dynamic dynamic = (Dynamic)typed.get(DSL.remainderFinder());
        this.byte = dynamic.get("Y").asInt(0);
        this.class(dynamic);
    }

    protected abstract boolean class();

    protected void class(Dynamic<?> dynamic) {
        if (this.class()) {
            this.protected = null;
        } else {
            long[] lArray = dynamic.get("BlockStates").asLongStream().toArray();
            int n2 = Math.max(4, DataFixUtils.ceillog2((int)this.break.size()));
            this.protected = new ryv_2(n2, 4096, lArray);
        }
    }

    public Typed<?> class(Typed<?> typed) {
        return this.break() ? typed : typed.update(DSL.remainderFinder(), dynamic -> dynamic.set("BlockStates", dynamic.createLongList(Arrays.stream(this.protected.class())))).set(this.class, this.break.stream().map(object -> Pair.of((Object)rTC.volatile.typeName(), (Object)object)).collect(Collectors.toList()));
    }

    protected int class(String string, boolean bl2, int n2) {
        return rwb.break.get((Object)string) << 5 | (bl2 ? 16 : 0) | n2;
    }

    public boolean break() {
        return this.protected == null;
    }
}

