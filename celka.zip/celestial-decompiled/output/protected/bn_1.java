/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.ib_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.BN
 */
public class bn_1 {
    private static short[] break;
    private static double[] byte;
    public Object[] class;
    private static byte[] protected;
    private static boolean[] throws;

    private static void byte() {
        byte = new double[1];
    }

    public bn_1(ib_0 ib_02, double d) {
        this.protected();
        ib_0 ib_03 = ib_02;
        this.class[bn_1.break[2]] = ib_03;
        Double d2 = d;
        this.class[bn_1.break[3]] = d2;
    }

    static {
        bn_1.ntfClinit();
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0x1A019BA6;
    }

    public ib_0 class() {
        return (ib_0)this.class[break[0]];
    }

    public static String class(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{12, 23, -93, -128, 109, -6, -3, 48}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0xD32D3D3D813B51D2L;
    }

    public double break() {
        return (Double)this.class[break[1]];
    }

    private static void throws() {
        protected = new byte[]{2};
    }

    private static /* synthetic */ void ntfClinit() {
        bn_1.catch();
        bn_1.case();
        bn_1.byte();
        bn_1.throws();
    }

    private static void catch() {
        throws = new boolean[]{true};
    }

    private static void case() {
        short[] sArray = new short[4];
        sArray[1] = 1;
        sArray[3] = 1;
        break = sArray;
    }

    private void protected() {
        if (this.class == null) {
            Object[] objectArray = this.class = new Object[protected[0]];
            objectArray[bn_1.throws[0]] = byte[0];
        }
    }
}

