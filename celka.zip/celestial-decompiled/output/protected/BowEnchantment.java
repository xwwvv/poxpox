/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.eC;
import protected.ef_0;
import protected.ev_0;
import protected.rxq_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.ah
 */
public class ah_0
extends ev_0 {
    public ah_0(ef_0 ef_02, rxq_1 ... rxq_1Array) {
        super(ef_02, eC.BOW, rxq_1Array);
    }

    @Override
    public int class() {
        return 2;
    }

    @Override
    public int class(int n2) {
        return 12 + (n2 - 1) * 20;
    }

    @Override
    public int break(int n2) {
        return this.class(n2) + 25;
    }
}

