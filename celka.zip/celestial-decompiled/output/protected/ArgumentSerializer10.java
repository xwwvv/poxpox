/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.io.DataInput;
import java.io.IOException;
import protected.rca_1;
import protected.rcg_1;
import protected.rcv_2;
import protected.rcz_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.rci
 */
class rci_1
implements rcv_2<rca_1> {
    @Override
    public boolean byte() {
        return true;
    }

    rci_1() {
    }

    public rca_1 class(DataInput dataInput, int n2, rcg_1 rcg_12) throws IOException {
        rcg_12.class(288L);
        String string = dataInput.readUTF();
        rcg_12.class(16 * string.length());
        return rca_1.class(string);
    }

    @Override
    public String class() {
        return "STRING";
    }

    @Override
    public /* synthetic */ rcz_1 break(DataInput dataInput, int n2, rcg_1 rcg_12) throws IOException {
        return this.class(dataInput, n2, rcg_12);
    }

    @Override
    public String break() {
        return "TAG_String";
    }
}

