/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import protected.HU;
import protected.Hx;
import protected.an;
import protected.hh_0;
import protected.ml_1;
import protected.ok_2;
import protected.qy_1;
import protected.rYB;
import protected.rjC;
import protected.rqR;
import protected.yd_2;
import protected.yx_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.yo
 */
public class yo_2
implements yd_2 {
    private final qy_1 class;
    private double break = Double.MIN_VALUE;
    private List<rjC> byte = Collections.emptyList();

    public yo_2(qy_1 qy_12) {
        this.class = qy_12;
    }

    @Override
    public void class(ml_1 ml_12, Hx hx, double d, double d2, double d3) {
        Object object;
        double d4 = rqR.byte();
        if (d4 - this.break > 1.0E8) {
            this.break = d4;
            object = ((hh_0)this.class.class[16]).finally().catch();
            this.byte = ((rYB)((an)object).throws[7]).byte((an)object, ((an)object).rN().class(6.0), an2 -> true).collect(Collectors.toList());
        }
        object = hx.getBuffer(HU.return());
        for (rjC rjC2 : this.byte) {
            yx_1.class(ml_12, (ok_2)object, rjC2, -d, -d2, -d3, 1.0f, 1.0f, 1.0f, 1.0f);
        }
    }
}

