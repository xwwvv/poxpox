/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.cn_2;
import protected.lf_2;
import protected.ll_2;
import protected.rVi;
import protected.rgP;
import protected.rgn;
import protected.vk_1;

/*
 * Renamed from protected.vD
 * Illegal identifiers - consider using --renameillegalidents true
 */
class vd_1
extends lf_2 {
    final /* synthetic */ vk_1 class;

    vd_1(vk_1 vk_12, int n2, int n3, int n4, int n5, rgP rgP2, ll_2 ll_22) {
        this.class = vk_12;
        super(n2, n3, n4, n5, rgP2, ll_22);
    }

    @Override
    protected rVi A_() {
        return super.A_().break(". ").class(new rgn("selectWorld.mapFeatures.info"));
    }

    @Override
    public rgP C_() {
        return cn_2.class(super.C_(), this.class.package.break());
    }
}

