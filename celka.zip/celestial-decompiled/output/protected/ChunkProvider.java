/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.new;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public interface continue
extends new {
    public int class();

    public boolean class(int var1, int var2);

    public int break();
}

