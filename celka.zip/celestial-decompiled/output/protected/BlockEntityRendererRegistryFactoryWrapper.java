/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  it.unimi.dsi.fastutil.objects.Object2ObjectLinkedOpenHashMap
 */
package protected;

import it.unimi.dsi.fastutil.objects.Object2ObjectLinkedOpenHashMap;
import java.util.SortedMap;
import protected.HU;
import protected.Hx;
import protected.hc_0;
import protected.hd_0;
import protected.hv_0;
import protected.ic_1;
import protected.lD;
import protected.lp;
import protected.rqR;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.yB
 */
public class yb_2 {
    private final hv_0 class = new hv_0();
    private final SortedMap<HU, lD> break = (SortedMap)rqR.class(new Object2ObjectLinkedOpenHashMap(), (T object2ObjectLinkedOpenHashMap) -> {
        object2ObjectLinkedOpenHashMap.put((Object)lp.catch(), (Object)this.class.class(HU.case()));
        object2ObjectLinkedOpenHashMap.put((Object)lp.private(), (Object)this.class.class(HU.private()));
        object2ObjectLinkedOpenHashMap.put((Object)lp.class(), (Object)this.class.class(HU.catch()));
        object2ObjectLinkedOpenHashMap.put((Object)lp.finally(), (Object)this.class.class(HU.implements()));
        yb_2.class((Object2ObjectLinkedOpenHashMap<HU, lD>)object2ObjectLinkedOpenHashMap, lp.break());
        yb_2.class((Object2ObjectLinkedOpenHashMap<HU, lD>)object2ObjectLinkedOpenHashMap, lp.byte());
        yb_2.class((Object2ObjectLinkedOpenHashMap<HU, lD>)object2ObjectLinkedOpenHashMap, lp.protected());
        yb_2.class((Object2ObjectLinkedOpenHashMap<HU, lD>)object2ObjectLinkedOpenHashMap, lp.throws());
        yb_2.class((Object2ObjectLinkedOpenHashMap<HU, lD>)object2ObjectLinkedOpenHashMap, lp.case());
        yb_2.class((Object2ObjectLinkedOpenHashMap<HU, lD>)object2ObjectLinkedOpenHashMap, HU.extends());
        yb_2.class((Object2ObjectLinkedOpenHashMap<HU, lD>)object2ObjectLinkedOpenHashMap, HU.final());
        yb_2.class((Object2ObjectLinkedOpenHashMap<HU, lD>)object2ObjectLinkedOpenHashMap, HU.package());
        yb_2.class((Object2ObjectLinkedOpenHashMap<HU, lD>)object2ObjectLinkedOpenHashMap, HU.new());
        yb_2.class((Object2ObjectLinkedOpenHashMap<HU, lD>)object2ObjectLinkedOpenHashMap, HU.continue());
        yb_2.class((Object2ObjectLinkedOpenHashMap<HU, lD>)object2ObjectLinkedOpenHashMap, HU.int());
        yb_2.class((Object2ObjectLinkedOpenHashMap<HU, lD>)object2ObjectLinkedOpenHashMap, HU.super());
        yb_2.class((Object2ObjectLinkedOpenHashMap<HU, lD>)object2ObjectLinkedOpenHashMap, HU.this());
        yb_2.class((Object2ObjectLinkedOpenHashMap<HU, lD>)object2ObjectLinkedOpenHashMap, HU.volatile());
        ic_1.extends.forEach(hU -> yb_2.class((Object2ObjectLinkedOpenHashMap<HU, lD>)object2ObjectLinkedOpenHashMap, hU));
    });
    private final hd_0 byte = Hx.class(this.break, new lD(256));
    private final hd_0 protected = Hx.class(new lD(256));
    private final hc_0 throws = new hc_0(this.byte);

    public hd_0 byte() {
        return this.protected;
    }

    private static void class(Object2ObjectLinkedOpenHashMap<HU, lD> object2ObjectLinkedOpenHashMap, HU hU) {
        object2ObjectLinkedOpenHashMap.put((Object)hU, (Object)new lD(hU.goto()));
    }

    public hv_0 class() {
        return this.class;
    }

    public hd_0 break() {
        return this.byte;
    }

    public hc_0 protected() {
        return this.throws;
    }
}

