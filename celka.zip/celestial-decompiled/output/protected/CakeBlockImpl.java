/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.jq_1;
import protected.rCL;
import protected.rCZ;
import protected.rCm;
import protected.rRR;
import protected.rRg;
import protected.rRq;
import protected.rYB;
import protected.rct_0;
import protected.rdn_1;
import protected.rfH;
import protected.rff;
import protected.rhd_2;
import protected.rjC;
import protected.rjm;
import protected.rlb_0;
import protected.rlt_2;
import protected.rpm;
import protected.rpr_0;
import protected.ryz_1;
import protected.xc_0;
import protected.xd_0;
import protected.xu_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.xA
 */
public class xa_0
extends xd_0 {
    public static final rCm volatile = rct_0.z;
    protected static final rjC[] final = new rjC[]{xd_0.class(1.0, 0.0, 1.0, 15.0, 8.0, 15.0), xd_0.class(3.0, 0.0, 1.0, 15.0, 8.0, 15.0), xd_0.class(5.0, 0.0, 1.0, 15.0, 8.0, 15.0), xd_0.class(7.0, 0.0, 1.0, 15.0, 8.0, 15.0), xd_0.class(9.0, 0.0, 1.0, 15.0, 8.0, 15.0), xd_0.class(11.0, 0.0, 1.0, 15.0, 8.0, 15.0), xd_0.class(13.0, 0.0, 1.0, 15.0, 8.0, 15.0)};

    protected xa_0(jq_1 jq_12) {
        super(jq_12);
        this.extends((xc_0)((xc_0)this.abstract.break()).class(volatile, 0));
    }

    @Override
    public rjC class(xc_0 xc_02, rRq rRq2, rfH rfH2, rjm rjm2) {
        return final[xc_02.byte(volatile)];
    }

    @Override
    protected void class(rCL<xd_0, xc_0> rCL2) {
        rCL2.class(new rCZ[]{volatile});
    }

    @Override
    public boolean class(xc_0 xc_02, rRq rRq2, rfH rfH2, rlt_2 rlt_22) {
        return false;
    }

    @Override
    public boolean class(xc_0 xc_02, rRR rRR2, rfH rfH2) {
        return rRR2.byte(rfH2.break()).byte().break();
    }

    private ryz_1 class(rRg rRg2, rfH rfH2, xc_0 xc_02, rhd_2 rhd_22) {
        if (!rhd_22.else(false)) {
            return ryz_1.PASS;
        }
        rhd_22.break(rlb_0.switch);
        rhd_22.sk().class(2, 0.1f);
        int n2 = xc_02.byte(volatile);
        if (n2 < 6) {
            rRg2.class(rfH2, (xc_0)xc_02.class(volatile, n2 + 1), 3);
        } else {
            rRg2.class(rfH2, false);
        }
        return ryz_1.SUCCESS;
    }

    @Override
    public ryz_1 class(xc_0 xc_02, rYB rYB2, rfH rfH2, rhd_2 rhd_22, rpm rpm2, rff rff2) {
        if (rYB2.continue) {
            rdn_1 rdn_12 = rhd_22.protected(rpm2);
            if (this.class((rRg)rYB2, rfH2, xc_02, rhd_22).class()) {
                return ryz_1.SUCCESS;
            }
            if (rdn_12.class()) {
                return ryz_1.CONSUME;
            }
        }
        return this.class((rRg)rYB2, rfH2, xc_02, rhd_22);
    }

    @Override
    public xc_0 class(xc_0 xc_02, rpr_0 rpr_02, xc_0 xc_03, rRg rRg2, rfH rfH2, rfH rfH3) {
        return rpr_02 == rpr_0.DOWN && !xc_02.class(rRg2, rfH2) ? xu_0.class.continue() : super.class(xc_02, rpr_02, xc_03, rRg2, rfH2, rfH3);
    }

    @Override
    public int break(xc_0 xc_02, rYB rYB2, rfH rfH2) {
        return (7 - xc_02.byte(volatile)) * 2;
    }

    @Override
    public boolean case(xc_0 xc_02) {
        return true;
    }
}

