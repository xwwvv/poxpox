/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableList
 *  com.mojang.serialization.Dynamic
 */
package protected;

import com.google.common.collect.ImmutableList;
import com.mojang.serialization.Dynamic;
import protected.aU;
import protected.ai_0;
import protected.iO;
import protected.iZ;
import protected.ib_0;
import protected.if_0;
import protected.il;
import protected.iq_0;
import protected.iz_0;
import protected.rRf;
import protected.rYB;
import protected.rbj_0;
import protected.rbm_0;
import protected.rbx;
import protected.rcd_2;
import protected.rdn_1;
import protected.rdy_2;
import protected.rei_1;
import protected.rfH;
import protected.rqa_0;
import protected.rqn;
import protected.rrEm;
import protected.rrh_0;
import protected.rrp_2;
import protected.rrr_2;
import protected.rxq_1;
import protected.rye_1;
import protected.xc_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.rbd
 */
public class rbd_0
extends rbm_0 {
    protected static final ImmutableList<rrp_2<? extends rrr_2<? super rbd_0>>> protected = ImmutableList.of(rrp_2.byte, rrp_2.protected, rrp_2.break, rrp_2.case, rrp_2.native);
    protected static final ImmutableList<il<?>> super = ImmutableList.of(il.final, il.synchronized, il.catch, il.private, il.extends, il.native, il.s, il.S, il.public, il.goto, il.volatile, il.interface, (Object[])new il[]{il.package, il.int, il.new, il.this, il.short, il.import, il.break});

    @Override
    protected rqa_0 byte(rye_1 rye_12) {
        return rqn.hX;
    }

    @Override
    protected void double() {
        this.SF().class((rrEm)((rYB)this.throws[7]), this);
        rbx.break(this);
        rbx.byte(this);
        super.double();
    }

    public rbd_0(ai_0<? extends rbd_0> ai_02, rYB rYB2) {
        super((ai_0<? extends rbm_0>)ai_02, rYB2);
        this.finally = 20;
    }

    @Override
    protected void class(rrh_0 rrh_02) {
        this.class(rxq_1.MAINHAND, new rdn_1(rdy_2.Ol));
    }

    @Override
    public aU class(rRf rRf2, rrh_0 rrh_02, iO iO2, aU aU2, rcd_2 rcd_22) {
        rbx.class(this);
        this.class(rrh_02);
        return super.class(rRf2, rrh_02, iO2, aU2, rcd_22);
    }

    @Override
    protected iZ<?> class(Dynamic<?> dynamic) {
        return rbx.class(this, this.SV().class(dynamic));
    }

    @Override
    public rbj_0 sd() {
        return this.v() && this.sk() ? rbj_0.ATTACKING_WITH_MELEE_WEAPON : rbj_0.DEFAULT;
    }

    @Override
    protected void break(rfH rfH2, xc_0 xc_02) {
        this.class(rqn.hJ, 0.15f, 1.0f);
    }

    @Override
    public boolean break(rye_1 rye_12, float f2) {
        boolean bl2 = super.break(rye_12, f2);
        if (((rYB)this.throws[7]).continue) {
            return false;
        }
        if (bl2 && rye_12.extends() instanceof ib_0) {
            rbx.class(this, (ib_0)rye_12.extends());
        }
        return bl2;
    }

    @Override
    public boolean throws() {
        return false;
    }

    @Override
    public boolean implements(rdn_1 rdn_12) {
        return rdn_12.break() == rdy_2.Ol ? super.implements(rdn_12) : false;
    }

    @Override
    protected rqa_0 static() {
        return rqn.hM;
    }

    public static iz_0 sz() {
        return rei_1.sm().class(iq_0.class, 50.0).class(iq_0.protected, 0.35f).class(iq_0.case, 7.0);
    }

    @Override
    protected rqa_0 Bt() {
        return rqn.hh;
    }

    public iZ<rbd_0> SF() {
        return super.SF();
    }

    @Override
    protected void sW() {
        this.class(rqn.hx, 1.0f, this.SN());
    }

    protected if_0<rbd_0> SV() {
        return iZ.class(super, protected);
    }

    protected void sQ() {
        this.class(rqn.hO, 1.0f, this.SN());
    }
}

