/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 *  com.google.common.collect.Sets
 *  com.google.gson.JsonObject
 */
package protected;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import protected.an;
import protected.hg_2;
import protected.ho_1;
import protected.hy_1;
import protected.hz_1;
import protected.rhn_2;
import protected.rqo_0;
import protected.rwl_1;
import protected.xf_2;
import protected.xx_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.XJ
 */
public class xj_2
extends hg_2<xx_1> {
    static final rqo_0 class = new rqo_0("killed_by_crossbow");

    @Override
    public void class(rhn_2 rhn_22, Collection<an> collection) {
        ArrayList arrayList = Lists.newArrayList();
        HashSet hashSet = Sets.newHashSet();
        for (an an2 : collection) {
            hashSet.add(an2.BC());
            arrayList.add(hy_1.break(rhn_22, an2));
        }
        this.class(rhn_22, (T xx_12) -> xx_12.class(arrayList, hashSet.size()));
    }

    @Override
    public rqo_0 class() {
        return xj_2.class;
    }

    @Override
    public /* synthetic */ hz_1 class(JsonObject jsonObject, ho_1 ho_12, rwl_1 rwl_12) {
        return this.break(jsonObject, ho_12, rwl_12);
    }

    public xx_1 break(JsonObject jsonObject, ho_1 ho_12, rwl_1 rwl_12) {
        ho_1[] ho_1Array = ho_1.break(jsonObject, "victims", rwl_12);
        xf_2 xf_22 = xf_2.class(jsonObject.get("unique_entity_types"));
        return new xx_1(ho_12, ho_1Array, xf_22);
    }
}

