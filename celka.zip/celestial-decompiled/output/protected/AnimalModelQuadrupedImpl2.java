/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.iq_1;
import protected.rob_1;
import protected.wk_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.wc
 */
public class wc_0<T extends rob_1>
extends wk_0<T> {
    private float catch;

    public wc_0() {
        super(12, 0.0f, false, 8.0f, 4.0f, 2.0f, 2.0f, 24);
        this.class = new iq_1(this, 0, 0);
        this.class.class(-3.0f, -4.0f, -6.0f, 6.0f, 6.0f, 8.0f, 0.0f);
        this.class.class(0.0f, 6.0f, -8.0f);
        this.break = new iq_1(this, 28, 8);
        this.break.class(-4.0f, -10.0f, -7.0f, 8.0f, 16.0f, 6.0f, 0.0f);
        this.break.class(0.0f, 5.0f, 2.0f);
    }

    @Override
    public void class(T t2, float f2, float f3, float f4, float f5, float f6) {
        super.class(t2, f2, f3, f4, f5, f6);
        this.class.case = this.catch;
    }

    @Override
    public void class(T t2, float f2, float f3, float f4) {
        super.class(t2, f2, f3, f4);
        this.class.protected = 6.0f + ((rob_1)t2).throw(f4) * 9.0f;
        this.catch = ((rob_1)t2).interface(f4);
    }
}

