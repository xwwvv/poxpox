/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.util.Objects;
import protected.cl_0;
import protected.gm;
import protected.rlq_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.CM
 */
public class cm_0
extends cl_0 {
    private int class;
    private final int break;

    cm_0(gm gm2, double d, double d2, double d3) {
        super(gm2, d, d2, d3, 0.0, 0.0, 0.0);
        this.break = 8;
    }

    @Override
    public void case() {
        for (int k = 0; k < 6; ++k) {
            double d = this.catch + (this.continue.nextDouble() - this.continue.nextDouble()) * 4.0;
            double d2 = this.private + (this.continue.nextDouble() - this.continue.nextDouble()) * 4.0;
            double d3 = this.implements + (this.continue.nextDouble() - this.continue.nextDouble()) * 4.0;
            float f2 = this.class;
            Objects.requireNonNull(this);
            this.byte.class(rlq_2.return, d, d2, d3, (double)(f2 / 8.0f), 0.0, 0.0);
        }
        ++this.class;
        Objects.requireNonNull(this);
        if (this.class == 8) {
            this.finally();
        }
    }
}

