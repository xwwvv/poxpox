/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.rpr_0;
import protected.yq_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.yx
 */
public class yx_2 {
    public final yq_2 class;
    rpr_0 break;
    int byte;
    int protected;

    public yx_2(yq_2 yq_22, rpr_0 rpr_02, int n2) {
        this.class = yq_22;
        this.break = rpr_02;
        this.byte = n2;
    }

    void class(rpr_0 rpr_02, int n2, int n3) {
        this.break = rpr_02;
        this.byte = n2;
        this.protected = n3;
    }

    public boolean class(rpr_0 rpr_02) {
        return (this.byte & 1 << rpr_02.ordinal()) > 0;
    }

    public void class(byte by, rpr_0 rpr_02) {
        this.byte = this.byte | by | 1 << this.break.ordinal();
    }
}

