/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableList
 */
package protected;

import com.google.common.collect.ImmutableList;
import protected.an;
import protected.iq_1;
import protected.rfU;
import protected.wn_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.wQ
 */
public class wq_0<T extends an>
extends wn_0<T> {
    private final iq_1 class;
    private final iq_1 break;
    private final iq_1 byte;
    private final iq_1 protected;
    private final iq_1 throws;

    public wq_0() {
        this.return = 32;
        this.public = 32;
        int n2 = 20;
        this.class = new iq_1(this, 0, 0);
        this.class.class(-1.5f, -2.5f, 0.0f, 3.0f, 5.0f, 8.0f);
        this.class.class(0.0f, 20.0f, 0.0f);
        this.break = new iq_1(this, 0, 13);
        this.break.class(-1.5f, -2.5f, 0.0f, 3.0f, 5.0f, 8.0f);
        this.break.class(0.0f, 20.0f, 8.0f);
        this.byte = new iq_1(this, 22, 0);
        this.byte.class(-1.0f, -2.0f, -3.0f, 2.0f, 4.0f, 3.0f);
        this.byte.class(0.0f, 20.0f, 0.0f);
        iq_1 iq_12 = new iq_1(this, 20, 10);
        iq_12.class(0.0f, -2.5f, 0.0f, 0.0f, 5.0f, 6.0f);
        iq_12.class(0.0f, 0.0f, 8.0f);
        this.break.break(iq_12);
        iq_1 iq_13 = new iq_1(this, 2, 1);
        iq_13.class(0.0f, 0.0f, 0.0f, 0.0f, 2.0f, 3.0f);
        iq_13.class(0.0f, -4.5f, 5.0f);
        this.class.break(iq_13);
        iq_1 iq_14 = new iq_1(this, 0, 2);
        iq_14.class(0.0f, 0.0f, 0.0f, 0.0f, 2.0f, 4.0f);
        iq_14.class(0.0f, -4.5f, -1.0f);
        this.break.break(iq_14);
        this.protected = new iq_1(this, -4, 0);
        this.protected.class(-2.0f, 0.0f, 0.0f, 2.0f, 0.0f, 2.0f);
        this.protected.class(-1.5f, 21.5f, 0.0f);
        this.protected.private = -0.7853982f;
        this.throws = new iq_1(this, 0, 0);
        this.throws.class(0.0f, 0.0f, 0.0f, 2.0f, 0.0f, 2.0f);
        this.throws.class(1.5f, 21.5f, 0.0f);
        this.throws.private = 0.7853982f;
    }

    @Override
    public Iterable<iq_1> class() {
        return ImmutableList.of((Object)this.class, (Object)this.break, (Object)this.byte, (Object)this.protected, (Object)this.throws);
    }

    @Override
    public void class(T t2, float f2, float f3, float f4, float f5, float f6) {
        float f7 = 1.0f;
        float f8 = 1.0f;
        if (!((an)t2).rT()) {
            f7 = 1.3f;
            f8 = 1.7f;
        }
        this.break.catch = -f7 * 0.25f * rfU.class(f8 * 0.6f * f4);
    }
}

