/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 */
package protected;

import com.google.common.collect.Lists;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import protected.rKd;
import protected.rVm;
import protected.rcd_2;
import protected.rcy_2;
import protected.rfH;
import protected.rfi;
import protected.rfj;
import protected.rja;
import protected.rqm;
import protected.rri_0;
import protected.rrpt_1;
import protected.rrrZ;
import protected.rrra_0;
import protected.rrrn;
import protected.rrry_0;
import protected.ruv_0;
import protected.rvl_0;
import protected.ryg_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public abstract class rrrH<C extends ruv_0> {
    public static final rrrH<?> class = new rrry_0((rrrZ)rrrZ.byte, 0, 0, rfi.class(), 0, 0L);
    private final rrrZ<C> throws;
    protected final List<rrrn> break = Lists.newArrayList();
    protected rfi byte;
    private final int case;
    private final int catch;
    private int private;
    protected final rqm protected;

    public rfi byte() {
        return this.byte;
    }

    public rrrH(rrrZ<C> rrrZ2, int n2, int n3, rfi rfi2, int n4, long l2) {
        this.throws = rrrZ2;
        this.case = n2;
        this.catch = n3;
        this.private = n4;
        this.protected = new rqm();
        this.protected.byte(l2, n2, n3);
        this.byte = rfi2;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public rcd_2 class(int n2, int n3) {
        rcd_2 rcd_22 = new rcd_2();
        if (this.throws()) {
            rcd_22.class("id", rvl_0.t.break(this.native()).toString());
            rcd_22.break("ChunkX", n2);
            rcd_22.break("ChunkZ", n3);
            rcd_22.break("references", this.private);
            rcd_22.class("BB", this.byte.private());
            rcy_2 rcy_22 = new rcy_2();
            List<rrrn> list = this.break;
            synchronized (list) {
                for (rrrn rrrn2 : this.break) {
                    rcy_22.add(rrrn2.case());
                }
            }
            rcd_22.class("Children", rcy_22);
            return rcd_22;
        }
        rcd_22.class("id", "INVALID");
        return rcd_22;
    }

    public rfH class() {
        return new rfH(this.case << 4, 0, this.catch << 4);
    }

    protected void class(Random random, int n2, int n3) {
        int n4 = n3 - n2 + 1 - this.byte.throws();
        int n5 = n4 > 1 ? n2 + random.nextInt(n4) : n2;
        int n6 = n5 - this.byte.break;
        this.byte.class(0, n6, 0);
        for (rrrn rrrn2 : this.break) {
            rrrn2.class(0, n6, 0);
        }
    }

    public abstract void class(rVm var1, rKd var2, rrpt_1 var3, int var4, int var5, ryg_0 var6, C var7);

    protected void class(int n2, Random random, int n3) {
        int n4 = n2 - n3;
        int n5 = this.byte.throws() + 1;
        if (n5 < n4) {
            n5 += random.nextInt(n4 - n5);
        }
        int n6 = n5 - this.byte.throws;
        this.byte.class(0, n6, 0);
        for (rrrn rrrn2 : this.break) {
            rrrn2.class(0, n6, 0);
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public void class(rri_0 rri_02, rrra_0 rrra_02, rKd rKd2, Random random, rfi rfi2, rfj rfj2) {
        List<rrrn> list = this.break;
        synchronized (list) {
            if (!this.break.isEmpty()) {
                rfi rfi3 = this.break.get((int)0).final;
                rja rja2 = rfi3.catch();
                rfH rfH2 = new rfH(rja2.b_(), rfi3.break, rja2.d_());
                Iterator<rrrn> iterator = this.break.iterator();
                while (iterator.hasNext()) {
                    rrrn rrrn2 = iterator.next();
                    if (!rrrn2.catch().class(rfi2) || rrrn2.class(rri_02, rrra_02, rKd2, random, rfi2, rfj2, rfH2)) continue;
                    iterator.remove();
                }
                this.break();
            }
        }
    }

    protected void break() {
        this.byte = rfi.class();
        for (rrrn rrrn2 : this.break) {
            this.byte.break(rrrn2.catch());
        }
    }

    public boolean throws() {
        return !this.break.isEmpty();
    }

    public int finally() {
        return this.private;
    }

    public int catch() {
        return this.catch;
    }

    protected int extends() {
        return 1;
    }

    public int case() {
        return this.case;
    }

    public void implements() {
        ++this.private;
    }

    public List<rrrn> protected() {
        return this.break;
    }

    public boolean private() {
        return this.private < this.extends();
    }

    public rrrZ<?> native() {
        return this.throws;
    }
}

