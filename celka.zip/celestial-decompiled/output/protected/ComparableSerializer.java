/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.base.MoreObjects
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.DataResult
 */
package protected;

import com.google.common.base.MoreObjects;
import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import java.util.Collection;
import java.util.Optional;
import java.util.stream.Stream;
import protected.rCn;
import protected.rCv;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public abstract class rCZ<T extends Comparable<T>> {
    private final Class<T> class;
    private final String break;
    private Integer byte;
    private final Codec<T> protected = Codec.STRING.comapFlatMap(string -> this.break((String)string).map(DataResult::success).orElseGet(() -> DataResult.error((String)("Unable to read property: " + this + " with value: " + string))), this::class);
    private final Codec<rCv<T>> throws = this.protected.xmap(this::break, rCv::break);

    public Stream<rCv<T>> byte() {
        return this.class().stream().map(this::break);
    }

    protected rCZ(String string2, Class<T> clazz) {
        this.class = clazz;
        this.break = string2;
    }

    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof rCZ)) {
            return false;
        }
        rCZ rCZ2 = (rCZ)object;
        return this.class.equals(rCZ2.class) && this.break.equals(rCZ2.break);
    }

    public String toString() {
        return MoreObjects.toStringHelper((Object)this).add("name", (Object)this.break).add("clazz", this.class).add("values", this.class()).toString();
    }

    public final int hashCode() {
        if (this.byte == null) {
            this.byte = this.break();
        }
        return this.byte;
    }

    public abstract String class(T var1);

    public rCv<T> class(rCn<?, ?> rCn2) {
        return new rCv(this, rCn2.byte(this));
    }

    public abstract Collection<T> class();

    public abstract Optional<T> break(String var1);

    public int break() {
        return 31 * this.class.hashCode() + this.break.hashCode();
    }

    public rCv<T> break(T t2) {
        return new rCv<T>(this, t2);
    }

    public String throws() {
        return this.break;
    }

    public Class<T> case() {
        return this.class;
    }

    public Codec<rCv<T>> protected() {
        return this.throws;
    }
}

