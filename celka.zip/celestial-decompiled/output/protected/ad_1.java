/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.CH;
import protected.ak_1;
import protected.cx_0;
import protected.gm;
import protected.rlk_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.AD
 */
public class ad_1
implements cx_0<rlk_2> {
    @Override
    public CH class(rlk_2 rlk_22, gm gm2, double d, double d2, double d3, double d4, double d5, double d6) {
        return new ak_1(gm2, d, d2, d3, d4, d5, d6, rlk_22.class());
    }
}

