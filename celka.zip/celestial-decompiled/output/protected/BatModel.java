/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableList
 */
package protected;

import com.google.common.collect.ImmutableList;
import protected.iq_1;
import protected.rbv_0;
import protected.rfU;
import protected.wn_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.td
 */
public class td_1
extends wn_0<rbv_0> {
    private final iq_1 class;
    private final iq_1 break;
    private final iq_1 byte;
    private final iq_1 protected;
    private final iq_1 throws;
    private final iq_1 case;

    public td_1() {
        this.return = 64;
        this.public = 64;
        this.class = new iq_1(this, 0, 0);
        this.class.class(-3.0f, -3.0f, -3.0f, 6.0f, 6.0f, 6.0f);
        iq_1 iq_12 = new iq_1(this, 24, 0);
        iq_12.class(-4.0f, -6.0f, -2.0f, 3.0f, 4.0f, 1.0f);
        this.class.break(iq_12);
        iq_1 iq_13 = new iq_1(this, 24, 0);
        iq_13.implements = true;
        iq_13.class(1.0f, -6.0f, -2.0f, 3.0f, 4.0f, 1.0f);
        this.class.break(iq_13);
        this.break = new iq_1(this, 0, 16);
        this.break.class(-3.0f, 4.0f, -3.0f, 6.0f, 12.0f, 6.0f);
        this.break.class(0, 34).class(-5.0f, 16.0f, 0.0f, 10.0f, 6.0f, 1.0f);
        this.byte = new iq_1(this, 42, 0);
        this.byte.class(-12.0f, 1.0f, 1.5f, 10.0f, 16.0f, 1.0f);
        this.throws = new iq_1(this, 24, 16);
        this.throws.class(-12.0f, 1.0f, 1.5f);
        this.throws.class(-8.0f, 1.0f, 0.0f, 8.0f, 12.0f, 1.0f);
        this.protected = new iq_1(this, 42, 0);
        this.protected.implements = true;
        this.protected.class(2.0f, 1.0f, 1.5f, 10.0f, 16.0f, 1.0f);
        this.case = new iq_1(this, 24, 16);
        this.case.implements = true;
        this.case.class(12.0f, 1.0f, 1.5f);
        this.case.class(0.0f, 1.0f, 0.0f, 8.0f, 12.0f, 1.0f);
        this.break.break(this.byte);
        this.break.break(this.protected);
        this.byte.break(this.throws);
        this.protected.break(this.case);
    }

    @Override
    public void class(rbv_0 rbv_02, float f2, float f3, float f4, float f5, float f6) {
        if (rbv_02.catch()) {
            this.class.case = f6 * ((float)Math.PI / 180);
            this.class.catch = (float)Math.PI - f5 * ((float)Math.PI / 180);
            this.class.private = (float)Math.PI;
            this.class.class(0.0f, -2.0f, 0.0f);
            this.byte.class(-3.0f, 0.0f, 3.0f);
            this.protected.class(3.0f, 0.0f, 3.0f);
            this.break.case = (float)Math.PI;
            this.byte.case = -0.15707964f;
            this.byte.catch = -1.2566371f;
            this.throws.catch = -1.7278761f;
            this.protected.case = this.byte.case;
            this.protected.catch = -this.byte.catch;
            this.case.catch = -this.throws.catch;
        } else {
            this.class.case = f6 * ((float)Math.PI / 180);
            this.class.catch = f5 * ((float)Math.PI / 180);
            this.class.private = 0.0f;
            this.class.class(0.0f, 0.0f, 0.0f);
            this.byte.class(0.0f, 0.0f, 0.0f);
            this.protected.class(0.0f, 0.0f, 0.0f);
            this.break.case = 0.7853982f + rfU.break(f4 * 0.1f) * 0.15f;
            this.break.catch = 0.0f;
            this.byte.catch = rfU.break(f4 * 1.3f) * (float)Math.PI * 0.25f;
            this.protected.catch = -this.byte.catch;
            this.throws.catch = this.byte.catch * 0.5f;
            this.case.catch = -this.byte.catch * 0.5f;
        }
    }

    @Override
    public Iterable<iq_1> class() {
        return ImmutableList.of((Object)this.class, (Object)this.break);
    }
}

