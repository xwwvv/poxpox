/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.util.Objects;
import java.util.UUID;
import protected.ai_0;
import protected.an;
import protected.ib_0;
import protected.is;
import protected.rYB;
import protected.rcd_2;
import protected.rhd_2;
import protected.rpj_0;
import protected.rrEm;
import protected.rru_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public interface ag {
    public void byte(ib_0 var1);

    public UUID byte();

    default public void class(rhd_2 rhd_22) {
        if (((rYB)rhd_22.throws[7]).B().break(rru_0.abstract) && rhd_22.ro().equals(this.byte())) {
            this.S_();
        }
    }

    default public void class(rrEm rrEm2, rcd_2 rcd_22) {
        this.class(rcd_22.private("AngerTime"));
        if (!rcd_22.break("AngryAt")) {
            this.class((UUID)null);
        } else {
            UUID uUID = rcd_22.class("AngryAt");
            this.class(uUID);
            an an2 = rrEm2.break(uUID);
            if (an2 != null) {
                if (an2 instanceof is) {
                    this.break((is)an2);
                }
                if (an2.BC() == ai_0.rM) {
                    this.break((rhd_2)an2);
                }
            }
        }
    }

    default public void class(rrEm rrEm2, boolean bl2) {
        ib_0 ib_02 = this.I_();
        UUID uUID = this.byte();
        if ((ib_02 == null || ib_02.Sl()) && uUID != null && rrEm2.break(uUID) instanceof is) {
            this.S_();
        } else {
            if (ib_02 != null && !Objects.equals(uUID, ib_02.ro())) {
                this.class(ib_02.ro());
                this.protected();
            }
            if (!(this.class() <= 0 || ib_02 != null && ib_02.BC() == ai_0.rM && bl2)) {
                this.class(this.class() - 1);
                if (this.class() == 0) {
                    this.S_();
                }
            }
        }
    }

    public void class(int var1);

    public void class(UUID var1);

    public int class();

    public void break(ib_0 var1);

    public void break(rhd_2 var1);

    default public void case() {
        this.S_();
        this.protected();
    }

    public void protected();

    public ib_0 I_();

    default public void S_() {
        this.break((ib_0)null);
        this.class((UUID)null);
        this.byte(null);
        this.class(0);
    }

    default public void a_(rcd_2 rcd_22) {
        rcd_22.break("AngerTime", this.class());
        if (this.byte() != null) {
            rcd_22.class("AngryAt", this.byte());
        }
    }

    default public boolean a_(rYB rYB2) {
        return rYB2.B().break(rru_0.long) && this.T_() && this.byte() == null;
    }

    default public boolean T_() {
        return this.class() > 0;
    }

    default public boolean b_(ib_0 ib_02) {
        if (!rpj_0.case.test(ib_02)) {
            return false;
        }
        return ib_02.BC() == ai_0.rM && this.a_((rYB)ib_02.throws[7]) ? true : ib_02.ro().equals(this.byte());
    }
}

