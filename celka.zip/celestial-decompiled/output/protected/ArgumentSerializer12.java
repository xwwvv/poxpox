/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.io.DataOutput;
import java.io.IOException;
import protected.rcc_1;
import protected.rck_1;
import protected.rcl_1;
import protected.rcv_2;
import protected.rcz_1;
import protected.rgP;
import protected.rgn_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.rcn
 */
public class rcn_1
extends rck_1 {
    public static final rcv_2<rcn_1> class = new rcc_1();
    private final int break;

    @Override
    public /* synthetic */ rcz_1 byte() {
        return this.protected();
    }

    rcn_1(int n2) {
        this.break = n2;
    }

    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        return object instanceof rcn_1 && this.break == ((rcn_1)object).break;
    }

    @Override
    public String toString() {
        return String.valueOf(this.break);
    }

    public int hashCode() {
        return this.break;
    }

    public static rcn_1 class(int n2) {
        return n2 >= -128 && n2 <= 1024 ? rcl_1.class[n2 + 128] : new rcn_1(n2);
    }

    @Override
    public void class(DataOutput dataOutput) throws IOException {
        dataOutput.writeInt(this.break);
    }

    @Override
    public rgP class(String string, int n2) {
        return new rgn_0(String.valueOf(this.break)).class(case);
    }

    @Override
    public byte class() {
        return 3;
    }

    public rcv_2<rcn_1> break() {
        return rcn_1.class;
    }

    @Override
    public long throws() {
        return this.break;
    }

    @Override
    public float finally() {
        return this.break;
    }

    @Override
    public short catch() {
        return (short)(this.break & 0xFFFF);
    }

    @Override
    public Number extends() {
        return this.break;
    }

    @Override
    public int case() {
        return this.break;
    }

    @Override
    public double implements() {
        return this.break;
    }

    public rcn_1 protected() {
        return this;
    }

    @Override
    public byte private() {
        return (byte)(this.break & 0xFF);
    }
}

