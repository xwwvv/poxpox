/*
 * Decompiled with CFR 0.152.
 */
package protected;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.Ni
 */
public final class ni_1
extends Enum<ni_1> {
    public static final /* enum */ ni_1 STATIC = new ni_1();
    public static final /* enum */ ni_1 STREAMING = new ni_1();
    private static final /* synthetic */ ni_1[] $VALUES;

    static {
        $VALUES = ni_1.class();
    }

    public static ni_1[] values() {
        return (ni_1[])$VALUES.clone();
    }

    public static ni_1 valueOf(String string) {
        return Enum.valueOf(ni_1.class, string);
    }

    private static /* synthetic */ ni_1[] class() {
        return new ni_1[]{STATIC, STREAMING};
    }
}

