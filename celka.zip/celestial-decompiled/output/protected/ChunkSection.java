/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableSet
 */
package protected;

import com.google.common.collect.ImmutableSet;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.ArrayList;
import java.util.BitSet;
import java.util.HashMap;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.bw;
import protected.di_2;
import protected.du_2;
import protected.ef_2;
import protected.ja_1;
import protected.mb_2;
import protected.rYB;
import protected.rfH;
import protected.ri_1;
import protected.rjU;
import protected.roj_0;
import protected.roq_0;
import protected.rqm_0;
import protected.rvm_0;
import protected.st_1;
import protected.sv_1;
import protected.xc_0;
import protected.xd_0;
import protected.xu_0;
import protected.zc_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.Sj
 */
public class sj_1 {
    private static int[] class;
    private static short[] break;
    private static byte[] byte;
    private static double[] protected;
    private static boolean[] throws;

    private static void byte() {
        protected = new double[2];
    }

    private sj_1() {
    }

    static {
        sj_1.ntfClinit();
    }

    public static st_1 class(roj_0 roj_02) {
        int n2;
        int n3;
        Object[] objectArray;
        HashMap<String, List<rfH>> hashMap = new HashMap<String, List<rfH>>();
        BitSet bitSet = new BitSet(sj_1.class[0]);
        try {
            objectArray = roj_02.byte();
            for (n3 = throws[0]; n3 < byte[0]; ++n3) {
                Object object = objectArray[n3];
                if (object == null) continue;
                rvm_0<xc_0> rvm_02 = ((roq_0)object).implements();
                n2 = n3 << byte[1];
                for (int k = throws[1]; k < byte[2]; ++k) {
                    int n4 = k | n2;
                    for (int i2 = throws[2]; i2 < byte[3]; ++i2) {
                        for (int i3 = throws[3]; i3 < byte[4]; ++i3) {
                            int n5 = st_1.class(i3, n4, i2);
                            xc_0 xc_02 = rvm_02.class(i3, k, i2);
                            boolean[] blArray = sj_1.class(xc_02, roj_02, i3, n4, i2).class();
                            bitSet.set(n5, blArray[throws[4]]);
                            bitSet.set(n5 + throws[5], blArray[throws[6]]);
                            xd_0 xd_02 = xc_02.break();
                            if (!((ImmutableSet)st_1.class[break[0]]).contains((Object)xd_02)) continue;
                            String string2 = ri_1.class(xd_02);
                            hashMap.computeIfAbsent(string2, string -> new ArrayList()).add(new rfH(i3, n4, i2));
                        }
                    }
                }
            }
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        objectArray = new xc_0[break[1]];
        for (n3 = throws[7]; n3 < byte[5]; ++n3) {
            block7: for (int k = throws[8]; k < byte[6]; ++k) {
                for (int i4 = break[2]; i4 >= 0; --i4) {
                    n2 = st_1.class(k, i4, n3);
                    if (!bitSet.get(n2) && !bitSet.get(n2 + throws[9])) continue;
                    objectArray[n3 << sj_1.byte[7] | k] = bw.class(roj_02, k, i4, n3);
                    continue block7;
                }
                objectArray[n3 << sj_1.byte[8] | k] = xu_0.class.continue();
            }
        }
        return new st_1(roj_02.private().break, roj_02.private().byte, bitSet, (xc_0[])objectArray, hashMap, System.currentTimeMillis());
    }

    public static String class(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{79, -62, 0, -90, 22, 16, 90, 54}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    public static xc_0 class(mb_2 mb_22, rqm_0<rYB> rqm_02) {
        switch (((int[])sv_1.class[break[11]])[mb_22.ordinal()]) {
            case 1: {
                return xu_0.class.continue();
            }
            case 2: {
                return xu_0.try.continue();
            }
            case 3: {
                return xu_0.instanceof.continue();
            }
            case 4: {
                if (rqm_02 == rYB.byte) {
                    return xu_0.break.continue();
                }
                if (rqm_02 == rYB.protected) {
                    return xu_0.PR.continue();
                }
                if (rqm_02 != rYB.throws) break;
                return xu_0.Sh.continue();
            }
        }
        return null;
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0xD4E29BAE;
    }

    private static mb_2 class(xc_0 xc_02, roj_0 roj_02, int n2, int n3, int n4) {
        xd_0 xd_02 = xc_02.break();
        if (ef_2.byte(xc_02)) {
            if (ef_2.protected(xc_02)) {
                return (mb_2)((Object)mb_2.staticFields66e4c6f8de393faf832676ed33680249[break[3]]);
            }
            if (n2 != byte[9] && ef_2.protected(bw.class(roj_02, n2 + throws[10], n3, n4)) || n2 != 0 && ef_2.protected(bw.class(roj_02, n2 - throws[11], n3, n4)) || n4 != byte[10] && ef_2.protected(bw.class(roj_02, n2, n3, n4 + throws[12])) || n4 != 0 && ef_2.protected(bw.class(roj_02, n2, n3, n4 - throws[13]))) {
                return (mb_2)((Object)mb_2.staticFields66e4c6f8de393faf832676ed33680249[break[4]]);
            }
            if (n2 == 0 || n2 == byte[11] || n4 == 0 || n4 == byte[12]) {
                rjU rjU2 = xc_02.volatile().byte(roj_02.extends(), new rfH(n2 + (roj_02.private().break << byte[13]), n3, n4 + (roj_02.private().byte << byte[14])));
                if (rjU2.break != protected[0] || rjU2.protected != protected[1]) {
                    return (mb_2)((Object)mb_2.staticFields66e4c6f8de393faf832676ed33680249[break[5]]);
                }
                return (mb_2)((Object)mb_2.staticFields66e4c6f8de393faf832676ed33680249[break[6]]);
            }
            return (mb_2)((Object)mb_2.staticFields66e4c6f8de393faf832676ed33680249[break[7]]);
        }
        if (ef_2.throws(xc_02) || ef_2.break(xc_02)) {
            return (mb_2)((Object)mb_2.staticFields66e4c6f8de393faf832676ed33680249[break[8]]);
        }
        if (xd_02 instanceof ja_1 || xd_02 instanceof zc_2 || xd_02 instanceof du_2 || xd_02 instanceof di_2) {
            return (mb_2)((Object)mb_2.staticFields66e4c6f8de393faf832676ed33680249[break[9]]);
        }
        return (mb_2)((Object)mb_2.staticFields66e4c6f8de393faf832676ed33680249[break[10]]);
    }

    private static void class() {
        short[] sArray = new short[12];
        sArray[1] = 256;
        sArray[2] = 255;
        sArray[3] = 2;
        sArray[4] = 2;
        sArray[5] = 1;
        sArray[6] = 2;
        sArray[7] = 1;
        sArray[8] = 2;
        sArray[10] = 3;
        break = sArray;
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0xAC5138E02B12AC07L;
    }

    private static void break() {
        boolean[] blArray = new boolean[14];
        blArray[5] = true;
        blArray[6] = true;
        blArray[9] = true;
        blArray[10] = true;
        blArray[11] = true;
        blArray[12] = true;
        blArray[13] = true;
        throws = blArray;
    }

    private static void throws() {
        sj_1.class = new int[]{131072};
    }

    private static /* synthetic */ void ntfClinit() {
        sj_1.break();
        sj_1.class();
        sj_1.byte();
        sj_1.protected();
        sj_1.throws();
    }

    private static void protected() {
        byte = new byte[]{16, 4, 16, 16, 16, 16, 16, 4, 4, 15, 15, 15, 15, 4, 4};
    }
}

