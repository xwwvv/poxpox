/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 *  com.mojang.brigadier.context.CommandContext
 *  com.mojang.brigadier.suggestion.Suggestions
 *  com.mojang.brigadier.suggestion.SuggestionsBuilder
 */
package protected;

import com.google.common.collect.Lists;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Stream;
import protected.aq_1;
import protected.aw_1;
import protected.cb_1;
import protected.gR;
import protected.gY;
import protected.qy_1;
import protected.rVm;
import protected.rYB;
import protected.rfH;
import protected.rff;
import protected.rfo;
import protected.rjU;
import protected.rjg_0;
import protected.rjm_0;
import protected.rqm_0;
import protected.rqo_0;
import protected.rzl_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.AX
 */
public class ax_2
implements gR {
    private final aq_1 class;
    private final qy_1 break;
    private int byte = -1;
    private CompletableFuture<Suggestions> protected;

    @Override
    public Collection<String> byte() {
        return this.class.finally().package().protected();
    }

    public ax_2(aq_1 aq_12, qy_1 qy_12) {
        this.class = aq_12;
        this.break = qy_12;
    }

    @Override
    public boolean class(int n2) {
        cb_1 cb_12 = (cb_1)this.break.class[57];
        return cb_12 != null ? cb_12.catch(n2) : n2 == 0;
    }

    @Override
    public CompletableFuture<Suggestions> class(CommandContext<gR> commandContext, SuggestionsBuilder suggestionsBuilder) {
        if (this.protected != null) {
            this.protected.cancel(false);
        }
        this.protected = new CompletableFuture();
        int n2 = ++this.byte;
        this.class.class(new rzl_0(n2, commandContext.getInput()));
        return this.protected;
    }

    public void class(int n2, Suggestions suggestions) {
        if (n2 == this.byte) {
            this.protected.complete(suggestions);
            this.protected = null;
            this.byte = -1;
        }
    }

    private static String class(double d) {
        return String.format(Locale.ROOT, "%.2f", d);
    }

    @Override
    public Collection<String> class() {
        ArrayList arrayList = Lists.newArrayList();
        for (aw_1 aw_12 : this.class.throws()) {
            arrayList.add(aw_12.class().getName());
        }
        return arrayList;
    }

    private static String break(int n2) {
        return Integer.toString(n2);
    }

    @Override
    public Collection<String> break() {
        return (rjg_0)this.break.class[64] != null && ((rjg_0)this.break.class[64]).byte() == rjm_0.ENTITY ? Collections.singleton(((rfo)((rjg_0)this.break.class[64])).class().rz()) : Collections.emptyList();
    }

    @Override
    public Stream<rqo_0> throws() {
        return this.class.protected().byte();
    }

    @Override
    public Collection<gY> catch() {
        rjg_0 rjg_02 = (rjg_0)this.break.class[64];
        if (rjg_02 != null && rjg_02.byte() == rjm_0.BLOCK) {
            rjU rjU2 = rjg_02.case();
            return Collections.singleton(new gY(ax_2.class(rjU2.break), ax_2.class(rjU2.byte), ax_2.class(rjU2.protected)));
        }
        return gR.super.catch();
    }

    @Override
    public Collection<gY> case() {
        rjg_0 rjg_02 = (rjg_0)this.break.class[64];
        if (rjg_02 != null && rjg_02.byte() == rjm_0.BLOCK) {
            rfH rfH2 = ((rff)rjg_02).class();
            return Collections.singleton(new gY(ax_2.break(rfH2.b_()), ax_2.break(rfH2.c_()), ax_2.break(rfH2.d_())));
        }
        return gR.super.case();
    }

    @Override
    public rVm implements() {
        return this.class.package();
    }

    @Override
    public Collection<rqo_0> protected() {
        return this.break.c().class();
    }

    @Override
    public Set<rqm_0<rYB>> private() {
        return this.class.final();
    }
}

