/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.lang.reflect.Constructor;
import protected.rrji_1;
import protected.rrki;
import protected.rrmp_1;
import protected.rrxb_0;
import protected.rrxm_0;
import protected.rrxr_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.rrxS
 */
public class rrxs_0
implements rrji_1 {
    private rrxb_0 class = null;
    private Class[] break = null;
    private boolean byte = false;
    private Constructor protected = null;

    public boolean byte() {
        if (this.byte) {
            return this.protected != null;
        }
        return this.break() != null;
    }

    public rrxs_0(rrxb_0 rrxb_02, Class[] classArray) {
        this.class = rrxb_02;
        this.break = classArray;
        rrxm_0.class(this);
    }

    public Object class(Object ... objectArray) {
        return rrxr_0.class(this, objectArray);
    }

    @Override
    public void class() {
        Constructor constructor = this.break();
    }

    private static Constructor class(Class clazz, Class[] classArray) {
        Constructor<?>[] constructorArray = clazz.getDeclaredConstructors();
        for (int k = 0; k < constructorArray.length; ++k) {
            Constructor<?> constructor = constructorArray[k];
            Class[] classArray2 = constructor.getParameterTypes();
            if (!rrxr_0.class(classArray, classArray2)) continue;
            return constructor;
        }
        return null;
    }

    public Constructor break() {
        if (this.byte) {
            return this.protected;
        }
        this.byte = true;
        Class clazz = this.class.break();
        if (clazz == null) {
            return null;
        }
        try {
            this.protected = rrxs_0.class(clazz, this.break);
            if (this.protected == null) {
                rrmp_1.break("(Reflector) Constructor not present: " + clazz.getName() + ", params: " + rrki.class(this.break));
            }
            if (this.protected != null) {
                this.protected.setAccessible(true);
            }
        }
        catch (Throwable throwable) {
            throwable.printStackTrace();
        }
        return this.protected;
    }

    public void protected() {
        this.byte = true;
        this.protected = null;
    }
}

