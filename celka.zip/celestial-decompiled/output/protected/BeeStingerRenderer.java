/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.HU;
import protected.Hx;
import protected.an;
import protected.fZ;
import protected.ib_0;
import protected.mh_1;
import protected.ml_1;
import protected.ok_2;
import protected.qd_0;
import protected.rfU;
import protected.rjV;
import protected.rje;
import protected.rjj;
import protected.rqo_0;
import protected.tb_2;
import protected.wh_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.TN
 */
public class tn_2<T extends ib_0, M extends wh_0<T>>
extends tb_2<T, M> {
    private static final rqo_0 class = new rqo_0("textures/entity/bee/bee_stinger.png");

    public tn_2(qd_0<T, M> qd_02) {
        super(qd_02);
    }

    @Override
    protected int class(T t2) {
        return ((ib_0)t2).SM();
    }

    private static void class(ok_2 ok_22, rjV rjV2, rjj rjj2, float f2, int n2, float f3, float f4, int n3) {
        ok_22.class(rjV2, f2, (float)n2, 0.0f).break(255, 255, 255, 255).class(f3, f4).byte(fZ.class).break(n3).class(rjj2, 0.0f, 1.0f, 0.0f).class();
    }

    @Override
    protected void class(ml_1 ml_12, Hx hx, int n2, an an2, float f2, float f3, float f4, float f5) {
        float f6 = rfU.byte(f2 * f2 + f4 * f4);
        float f7 = (float)(Math.atan2(f2, f4) * 57.2957763671875);
        float f8 = (float)(Math.atan2(f3, f6) * 57.2957763671875);
        ml_12.class(0.0, 0.0, 0.0);
        ml_12.class(rje.protected.byte(f7 - 90.0f));
        ml_12.class(rje.case.byte(f8));
        float f9 = 0.0f;
        float f10 = 0.125f;
        float f11 = 0.0f;
        float f12 = 0.0625f;
        float f13 = 0.03125f;
        ml_12.class(rje.break.byte(45.0f));
        ml_12.class(0.03125f, 0.03125f, 0.03125f);
        ml_12.class(2.5, 0.0, 0.0);
        ok_2 ok_22 = hx.getBuffer(HU.protected(tn_2.class));
        for (int k = 0; k < 4; ++k) {
            ml_12.class(rje.break.byte(90.0f));
            mh_1 mh_12 = ml_12.byte();
            rjV rjV2 = mh_12.class();
            rjj rjj2 = mh_12.break();
            tn_2.class(ok_22, rjV2, rjj2, -4.5f, -1, 0.0f, 0.0f, n2);
            tn_2.class(ok_22, rjV2, rjj2, 4.5f, -1, 0.125f, 0.0f, n2);
            tn_2.class(ok_22, rjV2, rjj2, 4.5f, 1, 0.125f, 0.0625f, n2);
            tn_2.class(ok_22, rjV2, rjj2, -4.5f, 1, 0.0f, 0.0625f, n2);
        }
    }
}

