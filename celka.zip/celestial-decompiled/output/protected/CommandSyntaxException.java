/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableList
 */
package protected;

import com.google.common.collect.ImmutableList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import protected.rCv;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class Uz {
    private static final Uz class = new Uz((List<rCv<?>>)ImmutableList.of());
    private static final Comparator<rCv<?>> break = Comparator.comparing(rCv2 -> rCv2.class().throws());
    private final List<rCv<?>> byte;

    private Uz(List<rCv<?>> list) {
        this.byte = list;
    }

    public boolean equals(Object object) {
        return this == object || object instanceof Uz && this.byte.equals(((Uz)object).byte);
    }

    public String toString() {
        return this.break();
    }

    public int hashCode() {
        return this.byte.hashCode();
    }

    public Uz class(rCv<?> rCv2) {
        return new Uz((List<rCv<?>>)ImmutableList.builder().addAll(this.byte).add(rCv2).build());
    }

    public static Uz class() {
        return Uz.class;
    }

    public static Uz class(rCv<?> ... rCvArray) {
        return new Uz((List<rCv<?>>)ImmutableList.copyOf((Object[])rCvArray));
    }

    public Uz class(Uz uz) {
        return new Uz((List<rCv<?>>)ImmutableList.builder().addAll(this.byte).addAll(uz.byte).build());
    }

    public String break() {
        return this.byte.stream().sorted(break).map(rCv::toString).collect(Collectors.joining(","));
    }
}

