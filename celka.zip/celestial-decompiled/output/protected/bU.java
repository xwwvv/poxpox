/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.cb_1;
import protected.class;
import protected.ea_0;
import protected.ey_0;
import protected.rdn_1;
import protected.rhz_2;
import protected.rkw_1;
import protected.rkx_1;
import protected.rld_1;
import protected.xc_0;
import protected.xd_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class bU {
    private static float[] break;
    private static short[] byte;
    public Object[] class;
    private static double[] protected;
    private static byte[] throws;
    private static boolean[] case;
    private static int[] catch;

    private static void byte() {
        throws = new byte[]{-1, 9, 3};
    }

    public bU(cb_1 cb_12) {
        HashMap hashMap;
        this.case();
        this.class[bU.byte[0]] = hashMap = new HashMap();
        cb_1 cb_13 = cb_12;
        this.class[bU.byte[1]] = cb_13;
        if (((Boolean)protected.class.instanceof().ry.class[byte[2]]).booleanValue()) {
            Function<xd_0, Double> function;
            double d = this.break();
            Function<Double, Double> function2 = d2 -> d * d2;
            this.class[bU.byte[3]] = function = function2.compose(this::break);
        } else {
            Function<xd_0, Double> function;
            this.class[bU.byte[4]] = function = this::break;
        }
    }

    static {
        bU.ntfClinit();
    }

    public double class(xc_0 xc_02) {
        return (Double)((Map)this.class[byte[5]]).computeIfAbsent(xc_02.break(), (Function)this.class[byte[6]]);
    }

    public static double class(rdn_1 rdn_12, xc_0 xc_02) {
        int n2;
        float f2;
        try {
            f2 = xc_02.private(null, null);
        }
        catch (NullPointerException nullPointerException) {
            return protected[2];
        }
        if (f2 < break[0]) {
            return protected[3];
        }
        float f3 = rdn_12.class(xc_02);
        if (f3 > break[1] && (n2 = ea_0.class(ey_0.this, rdn_12)) > 0 && !rdn_12.class()) {
            f3 += (float)(n2 * n2 + case[9]);
        }
        f3 /= f2;
        if (!xc_02.new() || !rdn_12.class() && rdn_12.break(xc_02)) {
            return f3 / break[2];
        }
        return f3 / break[3];
    }

    public int class(xd_0 xd_02, boolean bl2, boolean bl3) {
        if (!protected.class.instanceof().protected() && bl3) {
            return ((rhz_2)((cb_1)this.class[bU.byte[7]]).implements[bU.byte[8]]).protected;
        }
        int n2 = case[3];
        double d = protected[0];
        int n3 = catch[0];
        boolean bl4 = case[4];
        xc_0 xc_02 = xd_02.continue();
        for (int k = case[5]; k < throws[1]; ++k) {
            int n4;
            rdn_1 rdn_12 = ((rhz_2)((cb_1)this.class[bU.byte[9]]).implements[byte[10]]).extends(k);
            if (!((Boolean)protected.class.instanceof().rS.class[byte[11]]).booleanValue() && rdn_12.break() instanceof rkx_1 || ((Boolean)protected.class.instanceof().Br.class[byte[12]]).booleanValue() && rdn_12.catch() + (Integer)protected.class.instanceof().V.class[byte[13]] >= rdn_12.private() && rdn_12.private() > case[6]) continue;
            double d2 = bU.class(rdn_12, xc_02);
            boolean bl5 = this.class(rdn_12);
            if (d2 > d) {
                d = d2;
                n2 = k;
                n3 = this.break(rdn_12);
                bl4 = bl5;
                continue;
            }
            if (d2 != d || ((n4 = this.break(rdn_12)) >= n3 || !bl5 && bl4) && (!bl2 || bl4 || !bl5)) continue;
            d = d2;
            n2 = k;
            n3 = n4;
            bl4 = bl5;
        }
        return n2;
    }

    public boolean class(rdn_1 rdn_12) {
        return ea_0.class(ey_0.else, rdn_12) > 0 ? case[0] : case[1];
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0x5191CDB60D43B79AL;
    }

    private static void class() {
        short[] sArray = new short[22];
        sArray[1] = 2;
        sArray[3] = 1;
        sArray[4] = 1;
        sArray[6] = 1;
        sArray[7] = 2;
        sArray[8] = 1;
        sArray[9] = 2;
        sArray[10] = 1;
        sArray[14] = 2;
        sArray[15] = 1;
        sArray[18] = 2;
        sArray[19] = 2;
        sArray[20] = 2;
        sArray[21] = 2;
        byte = sArray;
    }

    public int class(xd_0 xd_02, boolean bl2) {
        return this.class(xd_02, bl2, case[2]);
    }

    public static String class(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{0, 93, -125, 33, -4, -94, 49, -75}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0xD6FA95D3;
    }

    private double class(xd_0 xd_02) {
        return ((List)protected.class.instanceof().p.class[byte[16]]).contains(xd_02) ? (Double)protected.class.instanceof().rG.class[byte[17]] : protected[1];
    }

    private int break(rdn_1 rdn_12) {
        if (rdn_12.break() instanceof rkw_1) {
            rkw_1 rkw_12 = (rkw_1)rdn_12.break();
            return rkw_12.private().protected();
        }
        return throws[0];
    }

    private double break(xd_0 xd_02) {
        rdn_1 rdn_12 = ((rhz_2)((cb_1)this.class[bU.byte[14]]).implements[byte[15]]).extends(this.class(xd_02, case[7], case[8]));
        return bU.class(rdn_12, xd_02.continue()) * this.class(xd_02);
    }

    private double break() {
        double d = protected[4];
        if (((cb_1)this.class[byte[18]]).break(rld_1.byte)) {
            d *= protected[5] + (double)(((cb_1)this.class[byte[19]]).byte(rld_1.byte).byte() + case[10]) * protected[6];
        }
        if (((cb_1)this.class[byte[20]]).break(rld_1.protected)) {
            switch (((cb_1)this.class[byte[21]]).byte(rld_1.protected).byte()) {
                case 0: {
                    d *= protected[7];
                    break;
                }
                case 1: {
                    d *= protected[8];
                    break;
                }
                case 2: {
                    d *= protected[9];
                    break;
                }
                default: {
                    d *= protected[10];
                }
            }
        }
        return d;
    }

    private static void throws() {
        catch = new int[]{Integer.MIN_VALUE};
    }

    private static /* synthetic */ void ntfClinit() {
        bU.private();
        bU.class();
        bU.catch();
        bU.protected();
        bU.byte();
        bU.throws();
    }

    private static void catch() {
        protected = new double[]{Double.NEGATIVE_INFINITY, 1.0, -1.0, -1.0, 1.0, 1.0, 0.2, 0.3, 0.09, 0.0027, 8.1E-4};
    }

    private void case() {
        if (this.class == null) {
            Object[] objectArray = this.class = new Object[throws[2]];
        }
    }

    private static void protected() {
        float[] fArray = new float[4];
        fArray[1] = 1.0f;
        fArray[2] = 30.0f;
        fArray[3] = 100.0f;
        break = fArray;
    }

    private static void private() {
        boolean[] blArray = new boolean[11];
        blArray[0] = true;
        blArray[6] = true;
        blArray[8] = true;
        blArray[9] = true;
        blArray[10] = true;
        case = blArray;
    }
}

