/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.rdn_1;

/*
 * Renamed from protected.yp
 */
public interface yp_2 {
    public int getColor(rdn_1 var1, int var2);
}

