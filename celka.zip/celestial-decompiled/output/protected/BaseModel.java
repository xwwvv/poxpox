/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.HU;
import protected.in_1;
import protected.iq_1;
import protected.ml_1;
import protected.ok_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class tt
extends in_1 {
    protected final iq_1 class;

    public tt() {
        this(0, 35, 64, 64);
    }

    public tt(int n2, int n3, int n4, int n5) {
        super(HU::private);
        this.return = n4;
        this.public = n5;
        this.class = new iq_1(this, n2, n3);
        this.class.class(-4.0f, -8.0f, -4.0f, 8.0f, 8.0f, 8.0f, 0.0f);
        this.class.class(0.0f, 0.0f, 0.0f);
    }

    @Override
    public void class(ml_1 ml_12, ok_2 ok_22, int n2, int n3, float f2, float f3, float f4, float f5) {
        this.class.class(ml_12, ok_22, n2, n3, f2, f3, f4, f5);
    }

    public void class(float f2, float f3, float f4) {
        this.class.catch = f3 * ((float)Math.PI / 180);
        this.class.case = f4 * ((float)Math.PI / 180);
    }
}

