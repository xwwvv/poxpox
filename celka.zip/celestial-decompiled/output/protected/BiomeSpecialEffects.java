/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.datafixers.kinds.App
 *  com.mojang.datafixers.kinds.Applicative
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.codecs.RecordCodecBuilder
 */
package protected;

import com.mojang.datafixers.kinds.App;
import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Optional;
import protected.ns_2;
import protected.rYV;
import protected.rYg;
import protected.rYj;
import protected.rqa_0;
import protected.ryq_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.rYW
 */
public class ryw_0 {
    public static final Codec<ryw_0> class = RecordCodecBuilder.create(instance -> instance.group((App)Codec.INT.fieldOf("fog_color").forGetter(ryw_02 -> ryw_02.break), (App)Codec.INT.fieldOf("water_color").forGetter(ryw_02 -> ryw_02.byte), (App)Codec.INT.fieldOf("water_fog_color").forGetter(ryw_02 -> ryw_02.protected), (App)Codec.INT.fieldOf("sky_color").forGetter(ryw_02 -> ryw_02.throws), (App)Codec.INT.optionalFieldOf("foliage_color").forGetter(ryw_02 -> ryw_02.case), (App)Codec.INT.optionalFieldOf("grass_color").forGetter(ryw_02 -> ryw_02.catch), (App)ryq_0.CODEC.optionalFieldOf("grass_color_modifier", (Object)ryq_0.NONE).forGetter(ryw_02 -> ryw_02.private), (App)rYV.class.optionalFieldOf("particle").forGetter(ryw_02 -> ryw_02.implements), (App)rqa_0.class.optionalFieldOf("ambient_sound").forGetter(ryw_02 -> ryw_02.finally), (App)rYj.class.optionalFieldOf("mood_sound").forGetter(ryw_02 -> ryw_02.extends), (App)rYg.class.optionalFieldOf("additions_sound").forGetter(ryw_02 -> ryw_02.native), (App)ns_2.class.optionalFieldOf("music").forGetter(ryw_02 -> ryw_02.volatile)).apply((Applicative)instance, ryw_0::new));
    private final int break;
    private final int byte;
    private final int protected;
    private final int throws;
    private final Optional<Integer> case;
    private final Optional<Integer> catch;
    private final ryq_0 private;
    private final Optional<rYV> implements;
    private final Optional<rqa_0> finally;
    private final Optional<rYj> extends;
    private final Optional<rYg> native;
    private final Optional<ns_2> volatile;

    public int byte() {
        return this.protected;
    }

    ryw_0(int n2, int n3, int n4, int n5, Optional<Integer> optional, Optional<Integer> optional2, ryq_0 ryq_02, Optional<rYV> optional3, Optional<rqa_0> optional4, Optional<rYj> optional5, Optional<rYg> optional6, Optional<ns_2> optional7) {
        this.break = n2;
        this.byte = n3;
        this.protected = n4;
        this.throws = n5;
        this.case = optional;
        this.catch = optional2;
        this.private = ryq_02;
        this.implements = optional3;
        this.finally = optional4;
        this.extends = optional5;
        this.native = optional6;
        this.volatile = optional7;
    }

    public int class() {
        return this.break;
    }

    public int break() {
        return this.byte;
    }

    public Optional<Integer> throws() {
        return this.case;
    }

    public Optional<rYj> finally() {
        return this.extends;
    }

    public ryq_0 catch() {
        return this.private;
    }

    public Optional<rYg> extends() {
        return this.native;
    }

    public Optional<Integer> case() {
        return this.catch;
    }

    public Optional<rqa_0> implements() {
        return this.finally;
    }

    public int protected() {
        return this.throws;
    }

    public Optional<rYV> private() {
        return this.implements;
    }

    public Optional<ns_2> native() {
        return this.volatile;
    }
}

