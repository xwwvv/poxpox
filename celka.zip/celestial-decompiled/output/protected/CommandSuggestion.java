/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.else;
import protected.ru_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public interface this {
    public String byte();

    public ru_1 class();

    public else break();

    public long protected();
}

