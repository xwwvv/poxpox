/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.bl_0;
import protected.rYB;
import protected.rfH;
import protected.rfl;
import protected.rpr_0;
import protected.rrki;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.bv
 */
public abstract class bv_0 {
    private static byte[] break;
    private static boolean[] byte;
    public Object[] class;
    private static short[] protected;

    public bl_0 byte() {
        return (bl_0)this.class[protected[16]];
    }

    public bv_0(rfl rfl2, bl_0[] bl_0Array, int n2) {
        bl_0[] bl_0Array2;
        this.extends();
        Integer n3 = n2;
        this.class[bv_0.protected[0]] = n3;
        this.class[bv_0.protected[1]] = bl_0Array2 = bl_0Array;
        Integer n4 = bl_0Array.length;
        this.class[bv_0.protected[2]] = n4;
        bl_0 bl_02 = bl_0Array[byte[0]];
        this.class[bv_0.protected[3]] = bl_02;
        bl_0 bl_03 = bl_0Array[bl_0Array.length - byte[1]];
        this.class[bv_0.protected[4]] = bl_03;
        rfl rfl3 = rfl2;
        this.class[bv_0.protected[5]] = rfl3;
    }

    static {
        bv_0.ntfClinit();
    }

    public int class() {
        return (Integer)this.class[protected[14]];
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0xFC2F22CA;
    }

    public boolean class(rYB rYB2, rfH rfH2) {
        return this.class(rYB2, rfH2, null);
    }

    public int class(rfH rfH2) {
        if (rfH2 == null || this.catch()) {
            return break[0];
        }
        for (int k = byte[19]; k < ((bl_0[])this.class[protected[11]]).length; ++k) {
            if (!((bl_0[])this.class[protected[12]])[k].equals(rfH2)) continue;
            return k;
        }
        return break[1];
    }

    public static String class(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{93, -76, 49, 60, -46, 62, -77, 8}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    public boolean class(rYB rYB2, rpr_0 rpr_02) {
        bl_0[] bl_0Array = (bl_0[])this.class[protected[7]];
        int n2 = bl_0Array.length;
        for (int k = byte[5]; k < n2; ++k) {
            bl_0 bl_02 = bl_0Array[k];
            if (!rYB2.finally(bl_02.byte(rpr_02))) continue;
            return byte[6];
        }
        return byte[7];
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0x92AAA618048308F7L;
    }

    public boolean class(rYB rYB2) {
        bl_0[] bl_0Array = (bl_0[])this.class[protected[6]];
        int n2 = bl_0Array.length;
        for (int k = byte[2]; k < n2; ++k) {
            bl_0 bl_02 = bl_0Array[k];
            if (!rYB2.finally(bl_02)) continue;
            return byte[3];
        }
        return byte[4];
    }

    public boolean class(rYB rYB2, rfH rfH2, rpr_0 rpr_02) {
        bl_0[] bl_0Array = (bl_0[])this.class[protected[9]];
        int n2 = bl_0Array.length;
        for (int k = byte[11]; k < n2; ++k) {
            bl_0 bl_02 = bl_0Array[k];
            if (!bl_02.equals(rfH2)) continue;
            if (rpr_02 != null) {
                bl_02 = bl_02.byte(rpr_02);
            }
            return !rYB2.finally(bl_02) ? byte[12] : byte[13];
        }
        return byte[14];
    }

    public boolean break(rfH rfH2) {
        if (rfH2 == null || this.catch()) {
            return byte[15];
        }
        bl_0[] bl_0Array = (bl_0[])this.class[protected[10]];
        int n2 = bl_0Array.length;
        for (int k = byte[16]; k < n2; ++k) {
            bl_0 bl_02 = bl_0Array[k];
            if (!bl_02.equals(rfH2)) continue;
            return byte[17];
        }
        return byte[18];
    }

    public boolean break(rYB rYB2, rfH rfH2) {
        bl_0[] bl_0Array = (bl_0[])this.class[protected[8]];
        int n2 = bl_0Array.length;
        for (int k = byte[8]; k < n2; ++k) {
            bl_0 bl_02 = bl_0Array[k];
            if (!rYB2.finally(bl_02.class(rfH2))) continue;
            return byte[9];
        }
        return byte[10];
    }

    public rfl break() {
        return (rfl)this.class[protected[18]];
    }

    public bl_0[] throws() {
        return (bl_0[])this.class[protected[15]];
    }

    private static /* synthetic */ void ntfClinit() {
        bv_0.implements();
        bv_0.private();
        bv_0.finally();
    }

    private static void finally() {
        break = new byte[]{-1, -1, 6, 5};
    }

    public boolean catch() {
        return rrki.break((bl_0[])this.class[protected[13]]);
    }

    private void extends() {
        if (this.class == null) {
            Object[] objectArray = this.class = new Object[break[2]];
            objectArray[bv_0.byte[20]] = byte[21];
            objectArray[bv_0.break[3]] = byte[22];
        }
    }

    public int case() {
        return (Integer)this.class[protected[19]];
    }

    private static void implements() {
        boolean[] blArray = new boolean[23];
        blArray[1] = true;
        blArray[4] = true;
        blArray[7] = true;
        blArray[10] = true;
        blArray[12] = true;
        blArray[17] = true;
        byte = blArray;
    }

    public bl_0 protected() {
        return (bl_0)this.class[protected[17]];
    }

    private static void private() {
        short[] sArray = new short[20];
        sArray[1] = 1;
        sArray[2] = 5;
        sArray[3] = 2;
        sArray[4] = 3;
        sArray[5] = 4;
        sArray[6] = 1;
        sArray[7] = 1;
        sArray[8] = 1;
        sArray[9] = 1;
        sArray[10] = 1;
        sArray[11] = 1;
        sArray[12] = 1;
        sArray[13] = 1;
        sArray[15] = 1;
        sArray[16] = 2;
        sArray[17] = 3;
        sArray[18] = 4;
        sArray[19] = 5;
        protected = sArray;
    }
}

