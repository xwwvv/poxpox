/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.rgP;
import protected.rmj_0;
import protected.rmo_0;
import protected.rmw_0;
import protected.rnW;
import protected.rud_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.An
 */
public class an_1
implements rmo_0 {
    private final rnW class;
    private final rud_1 break;

    public an_1(rnW rnW2, rud_1 rud_12) {
        this.class = rnW2;
        this.break = rud_12;
    }

    @Override
    public rud_1 class() {
        return this.break;
    }

    @Override
    public void class(rgP rgP2, rgP rgP3) {
    }

    @Override
    public void class(rmj_0 rmj_02) {
        this.break.class(rmj_02.break());
        this.break.class(new rmw_0(this.class, this.break));
    }
}

