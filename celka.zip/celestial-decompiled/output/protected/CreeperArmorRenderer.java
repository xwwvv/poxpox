/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.qe_0;
import protected.rej_2;
import protected.rqo_0;
import protected.ta_0;
import protected.th_2;
import protected.tp_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.Tv
 */
public class tv_2
extends th_2<rej_2, ta_0<rej_2>> {
    private static final rqo_0 class = new rqo_0("textures/entity/creeper/creeper_armor.png");
    private final ta_0<rej_2> break = new ta_0(2.0f);

    public tv_2(qe_0<rej_2, ta_0<rej_2>> qe_02) {
        super(qe_02);
    }

    @Override
    protected float class(float f2) {
        return f2 * 0.01f;
    }

    @Override
    protected rqo_0 class() {
        return tv_2.class;
    }

    @Override
    protected tp_0<rej_2> break() {
        return this.break;
    }
}

