/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.ArrayList;
import java.util.Deque;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.Stream;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.c_0;
import protected.double;
import protected.f_0;
import protected.for;
import protected.import;
import protected.q_0;
import protected.sg_0;
import protected.ss_0;
import protected.static;
import protected.switch;
import protected.transient;
import protected.w_0;
import protected.x;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class sS
implements static {
    private static byte[] break;
    private static short[] byte;
    public Object[] class;
    private static boolean[] protected;
    private static String[] throws;

    @Override
    public <E extends Enum<?>> E byte(Class<E> clazz) throws w_0, q_0 {
        return this.protected(clazz, protected[15]);
    }

    @Override
    public <T> T byte(double<T> double_) {
        return this.package().protected(double_);
    }

    @Override
    public <T> T byte(Class<T> clazz, T t2) throws q_0 {
        try {
            T t3 = this.catch().byte(clazz);
            this.throws();
            return t3;
        }
        catch (w_0 w_02) {
            return t2;
        }
    }

    @Override
    public <E extends Enum<?>> E byte(Class<E> clazz, int n2) throws q_0 {
        try {
            return this.protected(clazz, n2);
        }
        catch (w_0 w_02) {
            return null;
        }
    }

    public static String byte(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{-81, 57, -76, -101, 48, -127, -35, 121}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    @Override
    public LinkedList<import> byte() {
        return (LinkedList)this.class[byte[4]];
    }

    @Override
    public <T, O, D extends switch<T, O>> T byte(D d, O o2) {
        return this.break(d, o2, null);
    }

    @Override
    public import byte(int n2) throws q_0 {
        this.private(n2 + protected[9]);
        return (import)((LinkedList)this.class[byte[9]]).get(n2);
    }

    private static void int() {
        short[] sArray = new short[41];
        sArray[1] = 1;
        sArray[2] = 2;
        sArray[3] = 3;
        sArray[4] = 2;
        sArray[5] = 3;
        sArray[6] = 2;
        sArray[7] = 2;
        sArray[8] = 2;
        sArray[9] = 2;
        sArray[10] = 2;
        sArray[11] = 2;
        sArray[12] = 2;
        sArray[13] = 3;
        sArray[14] = 1;
        sArray[15] = 2;
        sArray[16] = 3;
        sArray[17] = 2;
        sArray[18] = 2;
        sArray[19] = 3;
        sArray[20] = 3;
        sArray[21] = 1;
        sArray[22] = 2;
        sArray[23] = 3;
        sArray[24] = 2;
        sArray[25] = 2;
        sArray[26] = 3;
        sArray[27] = 3;
        sArray[28] = 1;
        sArray[29] = 2;
        sArray[30] = 2;
        sArray[31] = 2;
        sArray[32] = 3;
        sArray[33] = 2;
        sArray[34] = 3;
        sArray[35] = 3;
        sArray[36] = 3;
        sArray[37] = 3;
        sArray[39] = 2;
        sArray[40] = 3;
        byte = sArray;
    }

    private sS(f_0 f_02, Deque<import> deque, Deque<import> deque2) {
        LinkedList<import> linkedList;
        LinkedList<import> linkedList2;
        this.continue();
        f_0 f_03 = f_02;
        this.class[sS.byte[0]] = f_03;
        ss_0 ss_02 = new ss_0(this);
        this.class[sS.byte[1]] = ss_02;
        this.class[sS.byte[2]] = linkedList2 = new LinkedList<import>(deque);
        this.class[sS.byte[3]] = linkedList = new LinkedList<import>(deque2);
    }

    public sS(f_0 f_02, List<import> list) {
        this(f_02, new LinkedList<import>(list), new LinkedList<import>());
    }

    static {
        sS.ntfClinit();
    }

    private static void this() {
        boolean[] blArray = new boolean[23];
        blArray[0] = true;
        blArray[2] = true;
        blArray[3] = true;
        blArray[5] = true;
        blArray[6] = true;
        blArray[8] = true;
        blArray[9] = true;
        blArray[14] = true;
        blArray[20] = true;
        blArray[21] = true;
        protected = blArray;
    }

    @Override
    public String class(String string, int n2) throws q_0 {
        this.private(n2 + protected[14]);
        return ((LinkedList)this.class[byte[10]]).stream().skip(n2).map(import::break).reduce((string2, string3) -> string2 + string + string3).orElse(throws[0]);
    }

    @Override
    public <T, O> T class(switch<T, O> switch_) {
        return this.package().throws(switch_, null);
    }

    @Override
    public <T, D extends double<T>> T class(D d, T t2) {
        ArrayList arrayList = new ArrayList((LinkedList)this.class[byte[22]]);
        ArrayList arrayList2 = new ArrayList((Deque)this.class[byte[23]]);
        try {
            return this.break(d);
        }
        catch (Exception exception) {
            ((LinkedList)this.class[byte[24]]).clear();
            ((LinkedList)this.class[byte[25]]).addAll(arrayList);
            ((Deque)this.class[byte[26]]).clear();
            ((Deque)this.class[byte[27]]).addAll(arrayList2);
            return t2;
        }
    }

    @Override
    public <E extends Enum<?>> E class(Class<E> clazz, E e2) throws q_0 {
        try {
            this.byte(clazz);
            return this.implements(clazz);
        }
        catch (w_0 w_02) {
            return e2;
        }
    }

    @Override
    public String class() {
        return ((LinkedList)this.class[byte[29]]).size() > 0 ? ((import)((LinkedList)this.class[byte[30]]).getFirst()).byte() : throws[1];
    }

    @Override
    public <T, O, D extends switch<T, O>> T class(D d, O o2, T t2) {
        ArrayList arrayList = new ArrayList((LinkedList)this.class[byte[15]]);
        ArrayList arrayList2 = new ArrayList((Deque)this.class[byte[16]]);
        try {
            return this.break(d, o2);
        }
        catch (Exception exception) {
            ((LinkedList)this.class[byte[17]]).clear();
            ((LinkedList)this.class[byte[18]]).addAll(arrayList);
            ((Deque)this.class[byte[19]]).clear();
            ((Deque)this.class[byte[20]]).addAll(arrayList2);
            return t2;
        }
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0x51FC798C665A3716L;
    }

    @Override
    public String[] class(String string) {
        return (String[])((LinkedList)this.class[byte[11]]).stream().map(import::break).flatMap(string2 -> Stream.of(string2.split(string))).toArray(String[]::new);
    }

    @Override
    public <T> T class(Class<T> clazz, int n2) throws q_0, w_0 {
        return this.byte(n2).byte(clazz);
    }

    @Override
    public <T> T class(Class<T> clazz, T t2, int n2) throws q_0 {
        try {
            return this.class(clazz, (T)n2);
        }
        catch (w_0 w_02) {
            return t2;
        }
    }

    @Override
    public <T> T class(double<T> double_) throws w_0, q_0 {
        return this.package().break(double_);
    }

    @Override
    public <T extends transient> Stream<String> class(T t2) {
        try {
            return t2.class((for)this.class[byte[28]]);
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return Stream.empty();
        }
    }

    @Override
    public <T, D extends double<T>> T class(Class<D> clazz) {
        return this.package().class(clazz);
    }

    @Override
    public <T, O, D extends switch<T, O>> T class(D d, O o2) throws w_0, q_0 {
        return this.package().break(d, o2);
    }

    @Override
    public <T> T class(Class<T> clazz, T t2) throws q_0 {
        return this.class(clazz, t2, protected[18]);
    }

    @Override
    public void class(int n2) throws c_0 {
        if (((LinkedList)this.class[byte[33]]).size() > n2) {
            throw new c_0(n2 + ((Deque)this.class[byte[34]]).size());
        }
    }

    @Override
    public <T, O, D extends switch<T, O>> T break(D d, O o2) throws w_0, q_0 {
        try {
            return d.class((for)this.class[byte[14]], o2);
        }
        catch (Exception exception) {
            throw new w_0(this.final() ? this.catch() : this.private(), (Throwable)exception);
        }
    }

    @Override
    public <T, D extends double<T>> T break(Class<D> clazz, T t2) {
        return this.package().break(clazz, t2);
    }

    @Override
    public String break(String string) throws q_0 {
        return this.class(string, protected[13]);
    }

    @Override
    public String break() {
        return this.private().break();
    }

    @Override
    public <T> T break(Class<T> clazz, int n2) throws q_0 {
        return this.class(clazz, null, n2);
    }

    @Override
    public <T, O> T break(switch<T, O> switch_) throws w_0, q_0 {
        return this.protected(switch_, null);
    }

    @Override
    public <T, D extends double<T>> T break(D d) throws w_0, q_0 {
        try {
            return d.byte((for)this.class[byte[21]]);
        }
        catch (Exception exception) {
            throw new w_0(this.final() ? this.catch() : this.private(), (Throwable)exception);
        }
    }

    @Override
    public <T, O, D extends switch<T, O>> T break(D d, O o2, T t2) {
        return this.package().class(d, o2, t2);
    }

    @Override
    public <T> T break(Class<T> clazz) throws q_0 {
        return this.byte((switch)((Object)clazz), null);
    }

    @Override
    public boolean break(int n2) {
        return ((LinkedList)this.class[byte[6]]).size() >= n2 ? protected[0] : protected[1];
    }

    @Override
    public <T, O, D extends switch<T, O>> T throws(D d, O o2) {
        return this.class(d, o2, null);
    }

    @Override
    public <T> T throws(Class<T> clazz) throws q_0 {
        return this.break(clazz, protected[19]);
    }

    @Override
    public import throws() throws q_0 {
        this.private(protected[20]);
        import import_ = (import)((LinkedList)this.class[byte[12]]).removeFirst();
        ((Deque)this.class[byte[13]]).add(import_);
        return import_;
    }

    @Override
    public String throws(int n2) throws q_0 {
        return this.byte(n2).break();
    }

    @Override
    public boolean throws(Class<?> clazz, int n2) throws q_0 {
        return this.byte(n2).class(clazz);
    }

    private static /* synthetic */ void ntfClinit() {
        sS.this();
        sS.super();
        sS.int();
        sS.new();
    }

    @Override
    public <E extends Enum<?>> E finally(Class<E> clazz) throws q_0 {
        return this.class((Class)clazz, (Object)null);
    }

    private static int finally(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0x66FDCED2;
    }

    @Override
    public /* synthetic */ static finally() {
        return this.package();
    }

    @Override
    public boolean catch(int n2) {
        return ((LinkedList)this.class[byte[7]]).size() <= n2 ? protected[3] : protected[4];
    }

    @Override
    public import catch() throws q_0 {
        return this.byte(protected[10]);
    }

    @Override
    public <T> T catch(Class<T> clazz) throws w_0, q_0 {
        return this.throws().byte(clazz);
    }

    @Override
    public String extends() throws q_0 {
        return this.throws().break();
    }

    @Override
    public boolean extends(Class<?> clazz) throws q_0 {
        return this.throws(clazz, protected[11]);
    }

    @Override
    public boolean case() {
        return this.case(protected[8]);
    }

    @Override
    public boolean case(int n2) {
        return ((LinkedList)this.class[byte[8]]).size() == n2 ? protected[6] : protected[7];
    }

    @Override
    public <T, D extends double<T>> T case(Class<D> clazz) {
        return this.break(clazz, null);
    }

    private void continue() {
        if (this.class == null) {
            Object[] objectArray = this.class = new Object[break[0]];
        }
    }

    @Override
    public String implements() throws q_0 {
        return this.throws(protected[12]);
    }

    @Override
    public <E extends Enum<?>> E implements(Class<E> clazz) throws w_0, q_0 {
        return this.throws().break(clazz);
    }

    private static void new() {
        break = new byte[]{4};
    }

    public sS package() {
        return new sS((f_0)this.class[byte[38]], (LinkedList)this.class[byte[39]], (Deque)this.class[byte[40]]);
    }

    private static void super() {
        throws = new String[]{new String(""), new String("")};
    }

    @Override
    public Deque<import> protected() {
        return (Deque)this.class[byte[5]];
    }

    @Override
    public <T, D extends double<T>> T protected(D d) {
        return this.class(d, (O)null);
    }

    @Override
    public <T> T protected(Class<T> clazz) throws w_0, q_0 {
        return this.class(clazz, protected[17]);
    }

    @Override
    public void protected(int n2) throws x {
        this.private(n2);
        this.class(n2);
    }

    @Override
    public <E extends Enum<?>> E protected(Class<E> clazz, int n2) throws q_0, w_0 {
        return this.byte(n2).break(clazz);
    }

    @Override
    public <T, O> T protected(switch<T, O> switch_, O o2) throws w_0, q_0 {
        return this.package().break(switch_, o2);
    }

    @Override
    public <E extends Enum<?>> E private(Class<E> clazz) throws q_0 {
        return (E)this.byte((switch)((Object)clazz), protected[16]);
    }

    @Override
    public import private() {
        return !((Deque)this.class[byte[36]]).isEmpty() ? (import)((Deque)this.class[byte[37]]).getLast() : sg_0.class();
    }

    @Override
    public void private(int n2) throws q_0 {
        if (((LinkedList)this.class[byte[31]]).size() < n2) {
            throw new q_0(n2 + ((Deque)this.class[byte[32]]).size());
        }
    }

    @Override
    public boolean final() {
        return this.break(protected[2]);
    }

    @Override
    public boolean volatile() {
        return !((Deque)this.class[byte[35]]).isEmpty() ? protected[21] : protected[22];
    }

    @Override
    public boolean native() {
        return this.catch(protected[5]);
    }
}

