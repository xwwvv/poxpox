/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.util.Optional;
import protected.rRq;
import protected.rfH;
import protected.rrq_0;
import protected.rrw_0;
import protected.rxe_2;
import protected.wv_2;
import protected.xc_0;
import protected.xu_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.WF
 */
class wf_2
extends rrq_0 {
    final /* synthetic */ boolean class;

    wf_2(wv_2 wv_22, boolean bl2) {
        this.class = bl2;
    }

    @Override
    public Optional<Float> class(rrw_0 rrw_02, rRq rRq2, rfH rfH2, xc_0 xc_02, rxe_2 rxe_22) {
        return rfH2.equals(rfH2) && this.class ? Optional.of(Float.valueOf(xu_0.try.extends())) : super.class(rrw_02, rRq2, rfH2, xc_02, rxe_22);
    }
}

