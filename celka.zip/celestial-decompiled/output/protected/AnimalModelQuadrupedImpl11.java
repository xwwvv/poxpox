/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.an;
import protected.wk_0;

/*
 * Renamed from protected.wM
 */
public class wm_0<T extends an>
extends wk_0<T> {
    public wm_0() {
        this(0.0f);
    }

    public wm_0(float f2) {
        super(6, f2, false, 4.0f, 4.0f, 2.0f, 2.0f, 24);
        this.class.class(16, 16).class(-2.0f, 0.0f, -9.0f, 4.0f, 3.0f, 1.0f, f2);
    }
}

