/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 *  com.ibm.icu.lang.UCharacter
 *  com.ibm.icu.text.ArabicShaping
 *  com.ibm.icu.text.Bidi
 *  com.ibm.icu.text.BidiRun
 */
package protected;

import com.google.common.collect.Lists;
import com.ibm.icu.lang.UCharacter;
import com.ibm.icu.text.ArabicShaping;
import com.ibm.icu.text.Bidi;
import com.ibm.icu.text.BidiRun;
import java.util.ArrayList;
import protected.VV;
import protected.rgS;
import protected.rpl;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class Vg {
    public static rpl class(rgS rgS2, boolean bl2) {
        VV vV = VV.class(rgS2, UCharacter::getMirror, Vg::class);
        Bidi bidi = new Bidi(vV.class(), bl2 ? 127 : 126);
        bidi.setReorderingMode(0);
        ArrayList arrayList = Lists.newArrayList();
        int n2 = bidi.countRuns();
        for (int k = 0; k < n2; ++k) {
            BidiRun bidiRun = bidi.getVisualRun(k);
            arrayList.addAll(vV.class(bidiRun.getStart(), bidiRun.getLength(), bidiRun.isOddRun()));
        }
        return rpl.class(arrayList);
    }

    private static String class(String string) {
        try {
            return new ArabicShaping(8).shape(string);
        }
        catch (Exception exception) {
            return string;
        }
    }
}

