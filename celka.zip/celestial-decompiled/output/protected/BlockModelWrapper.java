/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.jq_1;
import protected.rCL;
import protected.rCZ;
import protected.rRg;
import protected.rcn_0;
import protected.rct_0;
import protected.rfH;
import protected.rpr_0;
import protected.rxx;
import protected.xc_0;
import protected.xd_0;
import protected.xu_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.We
 */
public class we_1
extends xd_0 {
    public static final rcn_0 volatile = rct_0.while;

    protected we_1(jq_1 jq_12) {
        super(jq_12);
        this.extends((xc_0)((xc_0)this.abstract.break()).class(volatile, false));
    }

    @Override
    public xc_0 class(xc_0 xc_02, rpr_0 rpr_02, xc_0 xc_03, rRg rRg2, rfH rfH2, rfH rfH3) {
        return rpr_02 != rpr_0.UP ? super.class(xc_02, rpr_02, xc_03, rRg2, rfH2, rfH3) : (xc_0)xc_02.class(volatile, xc_03.class(xu_0.Pt) || xc_03.class(xu_0.Pq));
    }

    @Override
    protected void class(rCL<xd_0, xc_0> rCL2) {
        rCL2.class(new rCZ[]{volatile});
    }

    @Override
    public xc_0 class(rxx rxx2) {
        xc_0 xc_02 = rxx2.int().byte(rxx2.class().final());
        return (xc_0)this.continue().class(volatile, xc_02.class(xu_0.Pt) || xc_02.class(xu_0.Pq));
    }
}

