/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonObject
 */
package protected;

import com.google.gson.JsonObject;
import protected.ho_1;
import protected.hz_1;
import protected.rdn_1;
import protected.rwh_1;
import protected.xf_2;
import protected.xh_2;
import protected.xm_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.XO
 */
public class xo_2
extends hz_1 {
    private final xh_2 class;
    private final xf_2 break;
    private final xf_2 byte;

    public xo_2(ho_1 ho_12, xh_2 xh_22, xf_2 xf_22, xf_2 xf_23) {
        super(xm_2.class, ho_12);
        this.class = xh_22;
        this.break = xf_22;
        this.byte = xf_23;
    }

    @Override
    public JsonObject class(rwh_1 rwh_12) {
        JsonObject jsonObject = super.class(rwh_12);
        jsonObject.add("item", this.class.class());
        jsonObject.add("durability", this.break.protected());
        jsonObject.add("delta", this.byte.protected());
        return jsonObject;
    }

    public boolean class(rdn_1 rdn_12, int n2) {
        if (!this.class.class(rdn_12)) {
            return false;
        }
        if (!this.break.byte(rdn_12.private() - n2)) {
            return false;
        }
        return this.byte.byte(rdn_12.catch() - n2);
    }

    public static xo_2 class(ho_1 ho_12, xh_2 xh_22, xf_2 xf_22) {
        return new xo_2(ho_12, xh_22, xf_22, xf_2.throws);
    }
}

