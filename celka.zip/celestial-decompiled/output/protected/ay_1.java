/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.cj_0;
import protected.gm;
import protected.lo_0;
import protected.qy_1;
import protected.rpl_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.AY
 */
public class ay_1
extends lo_0 {
    ay_1(gm gm2, double d, double d2, double d3, rpl_0 rpl_02) {
        super(gm2, d, d2, d3);
        this.class(qy_1.instanceof().float().break().class(rpl_02));
        this.else = 0.0f;
        this.this = 80;
        this.final = false;
    }

    @Override
    public cj_0 class() {
        return cj_0.class;
    }

    @Override
    public float class(float f2) {
        return 0.5f;
    }
}

