/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.Hx;
import protected.ml_1;
import protected.qe_0;
import protected.rbf;
import protected.rqo_0;
import protected.rrbb;
import protected.rrbn_0;
import protected.tZ;
import protected.tf_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.TZ
 */
public class tz_1
extends tf_1<rbf, tZ<rbf>> {
    private static final rqo_0 class = new rqo_0("textures/entity/cat/cat_collar.png");
    private final tZ<rbf> break = new tZ(0.01f);

    public tz_1(qe_0<rbf, tZ<rbf>> qe_02) {
        super(qe_02);
    }

    @Override
    public void class(ml_1 ml_12, Hx hx, int n2, rbf rbf2, float f2, float f3, float f4, float f5, float f6, float f7) {
        if (rbf2.sZ()) {
            float[] fArray = rbf2.sd().protected();
            if (rrbb.K()) {
                fArray = rrbn_0.class(rbf2.sd(), fArray);
            }
            tz_1.class(this.byte(), this.break, tz_1.class, ml_12, hx, n2, rbf2, f2, f3, f5, f6, f7, f4, fArray[0], fArray[1], fArray[2]);
        }
    }
}

