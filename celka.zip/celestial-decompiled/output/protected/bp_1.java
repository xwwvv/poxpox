/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.BP
 */
public class bp_1 {
    private static byte[] break;
    private static boolean[] byte;
    public static Object[] class;

    private static void byte() {
        boolean[] blArray = new boolean[7];
        blArray[3] = true;
        blArray[5] = true;
        blArray[6] = true;
        byte = blArray;
    }

    static {
        bp_1.ntfClinit();
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0xCB0E9A2E;
    }

    public static String class(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{20, 74, -101, -37, -49, 24, -42, -91}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0x39D93BE3901EDAD8L;
    }

    private static void class() {
        Object[] objectArray = new Object[]{new int[]{1, 2}};
        bp_1.class = objectArray;
    }

    private static void break() {
        break = new byte[]{2};
    }

    private static /* synthetic */ void ntfClinit() {
        bp_1.byte();
        bp_1.break();
        bp_1.class();
    }
}

