/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableSet
 *  it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap
 */
package protected;

import com.google.common.collect.ImmutableSet;
import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.ArrayList;
import java.util.BitSet;
import java.util.List;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.mb_2;
import protected.rYB;
import protected.rfH;
import protected.ri_1;
import protected.rqm_0;
import protected.sj_1;
import protected.xc_0;
import protected.xu_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.St
 */
public class st_1 {
    private static short[] byte;
    private static byte[] protected;
    private static boolean[] throws;
    public static Object[] class;
    private static long[] case;
    public Object[] break;
    private static String[] catch;
    private static int[] private;

    public byte[] byte() {
        return ((BitSet)this.break[byte[31]]).toByteArray();
    }

    public st_1(int n2, int n3, BitSet bitSet, xc_0[] xc_0Array, Map<String, List<rfH>> map, long l2) {
        Map<String, List<rfH>> map2;
        xc_0[] xc_0Array2;
        this.private();
        st_1.class(bitSet);
        Integer n4 = n2;
        this.break[st_1.byte[0]] = n4;
        Integer n5 = n3;
        this.break[st_1.byte[1]] = n5;
        BitSet bitSet2 = bitSet;
        this.break[st_1.byte[2]] = bitSet2;
        this.break[st_1.byte[3]] = xc_0Array2 = xc_0Array;
        int[] nArray = new int[byte[4]];
        this.break[st_1.byte[5]] = nArray;
        this.break[st_1.byte[6]] = map2 = map;
        Long l3 = l2;
        this.break[st_1.byte[7]] = l3;
        if (map.isEmpty()) {
            Object var19_14 = null;
            this.break[st_1.byte[8]] = var19_14;
        } else {
            Int2ObjectOpenHashMap int2ObjectOpenHashMap = new Int2ObjectOpenHashMap();
            this.break[st_1.byte[9]] = int2ObjectOpenHashMap;
            this.protected();
        }
        this.extends();
    }

    static {
        st_1.ntfClinit();
    }

    public xc_0 class(int n2, int n3, int n4, rqm_0<rYB> rqm_02) {
        String string;
        int n5 = st_1.class(n2, n3, n4);
        mb_2 mb_22 = this.break(n5);
        int n6 = n4 << protected[0] | n2;
        if (((int[])this.break[byte[12]])[n6] == n3 && mb_22 != (mb_2)((Object)mb_2.staticFields66e4c6f8de393faf832676ed33680249[byte[13]])) {
            return ((xc_0[])this.break[byte[14]])[n6];
        }
        if ((Int2ObjectOpenHashMap)this.break[byte[15]] != null && (string = (String)((Int2ObjectOpenHashMap)this.break[byte[16]]).get(n5)) != null) {
            return ri_1.break(string).continue();
        }
        if (mb_22 == (mb_2)((Object)mb_2.staticFields66e4c6f8de393faf832676ed33680249[byte[17]])) {
            if (n3 == protected[1] && rqm_02 == rYB.protected) {
                return xu_0.while.continue();
            }
            if (n3 < protected[2] && rqm_02 == rYB.byte) {
                return xu_0.rg.continue();
            }
        }
        return sj_1.class(mb_22, rqm_02);
    }

    public static int class(int n2, int n3, int n4) {
        return n2 << throws[5] | n4 << protected[8] | n3 << protected[9];
    }

    public xc_0[] class() {
        return (xc_0[])this.break[byte[25]];
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0x2D7AC5D8;
    }

    private static void class(BitSet bitSet) {
        if (bitSet.size() > private[0]) {
            throw new IllegalArgumentException(catch[0]);
        }
    }

    public ArrayList<rfH> class(String string) {
        if (((Map)this.break[byte[27]]).get(string) == null) {
            return null;
        }
        ArrayList<rfH> arrayList = new ArrayList<rfH>();
        for (rfH rfH2 : (List)((Map)this.break[byte[28]]).get(string)) {
            arrayList.add(new rfH(rfH2.b_() + (Integer)this.break[byte[29]] * protected[6], rfH2.c_(), rfH2.d_() + (Integer)this.break[byte[30]] * protected[7]));
        }
        return arrayList;
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0xB7405BD34E213711L;
    }

    public Map<String, List<rfH>> break() {
        return (Map)this.break[byte[26]];
    }

    public static String break(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{12, 15, 64, -36, 121, -45, 79, 114}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    private mb_2 break(int n2) {
        return mb_2.class(((BitSet)this.break[byte[18]]).get(n2), ((BitSet)this.break[byte[19]]).get(n2 + throws[0]));
    }

    private static void throws() {
        boolean[] blArray = new boolean[14];
        blArray[0] = true;
        blArray[4] = true;
        blArray[5] = true;
        blArray[7] = true;
        blArray[11] = true;
        blArray[13] = true;
        throws = blArray;
    }

    private static /* synthetic */ void ntfClinit() {
        st_1.throws();
        st_1.volatile();
        st_1.case();
        st_1.finally();
        st_1.native();
        st_1.catch();
        st_1.implements();
    }

    private static void finally() {
        short[] sArray = new short[33];
        sArray[1] = 1;
        sArray[2] = 2;
        sArray[3] = 4;
        sArray[4] = 256;
        sArray[5] = 5;
        sArray[6] = 6;
        sArray[7] = 7;
        sArray[8] = 3;
        sArray[9] = 3;
        sArray[10] = 6;
        sArray[11] = 3;
        sArray[12] = 5;
        sArray[13] = 2;
        sArray[14] = 4;
        sArray[15] = 3;
        sArray[16] = 3;
        sArray[17] = 3;
        sArray[18] = 2;
        sArray[19] = 2;
        sArray[20] = 5;
        sArray[21] = 256;
        sArray[22] = 2;
        sArray[23] = 2;
        sArray[24] = 5;
        sArray[25] = 4;
        sArray[26] = 6;
        sArray[27] = 6;
        sArray[28] = 6;
        sArray[30] = 1;
        sArray[31] = 2;
        sArray[32] = 16384;
        byte = sArray;
    }

    private static void catch() {
        private = new int[]{131072, 131072};
    }

    private void extends() {
        for (int k = throws[1]; k < protected[3]; ++k) {
            block1: for (int i2 = throws[2]; i2 < protected[4]; ++i2) {
                int n2 = k << protected[5] | i2;
                ((int[])this.break[st_1.byte[20]])[n2] = throws[3];
                for (int i3 = byte[21]; i3 >= 0; --i3) {
                    int n3 = st_1.class(i2, i3, k);
                    if (!((BitSet)this.break[byte[22]]).get(n3) && !((BitSet)this.break[byte[23]]).get(n3 + throws[4])) continue;
                    ((int[])this.break[st_1.byte[24]])[n2] = i3;
                    continue block1;
                }
            }
        }
    }

    private static void case() {
        case = new long[1];
    }

    private static void implements() {
        Object[] objectArray = new Object[3];
        Object[] objectArray2 = new Object[]{xu_0.SW, xu_0.Ps, xu_0.re, xu_0.sZ, xu_0.SM, xu_0.SO, xu_0.rD, xu_0.Ec, xu_0.bK, xu_0.bU, xu_0.be, xu_0.ba, xu_0.bi, xu_0.Mr, xu_0.MP, xu_0.MB, xu_0.MS, xu_0.Ms, xu_0.ME, xu_0.MG, xu_0.Mb, xu_0.MM, xu_0.MO, xu_0.Mh, xu_0.MX, xu_0.Pi, xu_0.sl, xu_0.Sv, xu_0.SG, xu_0.sW, xu_0.sz, xu_0.sQ, xu_0.sN, xu_0.sd, xu_0.sk, xu_0.sJ, xu_0.sx, xu_0.sM, xu_0.sO, xu_0.sh, xu_0.sX, xu_0.SE, xu_0.sc, xu_0.C, xu_0.l, xu_0.H, xu_0.y, xu_0.p, xu_0.q, xu_0.T, xu_0.t, xu_0.w, xu_0.I, xu_0.f, xu_0.j, xu_0.V, xu_0.g, xu_0.R, xu_0.Y, xu_0.SX, xu_0.Pj, xu_0.bw, xu_0.U, xu_0.Ss, xu_0.PJ, xu_0.BD};
        objectArray[0] = ImmutableSet.copyOf((Object[])objectArray2);
        objectArray[1] = 131072;
        objectArray[2] = 16384;
        st_1.class = objectArray;
    }

    private final void protected() {
        for (Map.Entry entry : ((Map)this.break[byte[10]]).entrySet()) {
            for (rfH rfH2 : (List)entry.getValue()) {
                ((Int2ObjectOpenHashMap)this.break[byte[11]]).put(st_1.class(rfH2.b_(), rfH2.c_(), rfH2.d_()), (Object)((String)entry.getKey()));
            }
        }
    }

    private void private() {
        if (this.break == null) {
            Object[] objectArray = this.break = new Object[protected[69]];
            objectArray[st_1.throws[9]] = throws[10];
            objectArray[st_1.throws[11]] = throws[12];
            objectArray[st_1.protected[70]] = case[0];
        }
    }

    private static void volatile() {
        catch = new String[]{new String("BitSet of invalid length provided")};
    }

    private static void native() {
        protected = new byte[]{4, 127, 5, 16, 16, 4, 16, 16, 5, 9, 60, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 8, 7, 3, 2};
    }
}

