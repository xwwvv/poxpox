/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableList
 */
package protected;

import com.google.common.collect.ImmutableList;
import protected.iq_1;
import protected.rfU;
import protected.rgx_1;
import protected.wn_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.wz
 */
public class wz_0
extends wn_0<rgx_1> {
    private final iq_1 class;
    private final iq_1 break;
    private final iq_1 byte;
    private final iq_1 protected;
    private final iq_1 throws;
    private final iq_1 case;
    private final iq_1 catch;
    private final iq_1 private;

    public wz_0() {
        this.return = 128;
        this.public = 128;
        int n2 = 16;
        float f2 = 0.0f;
        this.private = new iq_1(this);
        this.private.class(0.0f, -7.0f, -1.5f);
        this.private.class(68, 73).class(-5.0f, -1.0f, -18.0f, 10.0f, 10.0f, 18.0f, 0.0f);
        this.class = new iq_1(this);
        this.class.class(0.0f, 16.0f, -17.0f);
        this.class.class(0, 0).class(-8.0f, -20.0f, -14.0f, 16.0f, 20.0f, 16.0f, 0.0f);
        this.class.class(0, 0).class(-2.0f, -6.0f, -18.0f, 4.0f, 8.0f, 4.0f, 0.0f);
        iq_1 iq_12 = new iq_1(this);
        iq_12.class(-10.0f, -14.0f, -8.0f);
        iq_12.class(74, 55).class(0.0f, -14.0f, -2.0f, 2.0f, 14.0f, 4.0f, 0.0f);
        iq_12.case = 1.0995574f;
        this.class.break(iq_12);
        iq_1 iq_13 = new iq_1(this);
        iq_13.implements = true;
        iq_13.class(8.0f, -14.0f, -8.0f);
        iq_13.class(74, 55).class(0.0f, -14.0f, -2.0f, 2.0f, 14.0f, 4.0f, 0.0f);
        iq_13.case = 1.0995574f;
        this.class.break(iq_13);
        this.break = new iq_1(this);
        this.break.class(0.0f, -2.0f, 2.0f);
        this.break.class(0, 36).class(-8.0f, 0.0f, -16.0f, 16.0f, 3.0f, 16.0f, 0.0f);
        this.class.break(this.break);
        this.private.break(this.class);
        this.byte = new iq_1(this);
        this.byte.class(0, 55).class(-7.0f, -10.0f, -7.0f, 14.0f, 16.0f, 20.0f, 0.0f);
        this.byte.class(0, 91).class(-6.0f, 6.0f, -7.0f, 12.0f, 13.0f, 18.0f, 0.0f);
        this.byte.class(0.0f, 1.0f, 2.0f);
        this.protected = new iq_1(this, 96, 0);
        this.protected.class(-4.0f, 0.0f, -4.0f, 8.0f, 37.0f, 8.0f, 0.0f);
        this.protected.class(-8.0f, -13.0f, 18.0f);
        this.throws = new iq_1(this, 96, 0);
        this.throws.implements = true;
        this.throws.class(-4.0f, 0.0f, -4.0f, 8.0f, 37.0f, 8.0f, 0.0f);
        this.throws.class(8.0f, -13.0f, 18.0f);
        this.case = new iq_1(this, 64, 0);
        this.case.class(-4.0f, 0.0f, -4.0f, 8.0f, 37.0f, 8.0f, 0.0f);
        this.case.class(-8.0f, -13.0f, -5.0f);
        this.catch = new iq_1(this, 64, 0);
        this.catch.implements = true;
        this.catch.class(-4.0f, 0.0f, -4.0f, 8.0f, 37.0f, 8.0f, 0.0f);
        this.catch.class(8.0f, -13.0f, -5.0f);
    }

    @Override
    public void class(rgx_1 rgx_12, float f2, float f3, float f4) {
        super.class(rgx_12, f2, f3, f4);
        int n2 = rgx_12.sc();
        int n3 = rgx_12.sn();
        int n4 = 20;
        int n5 = rgx_12.sN();
        int n6 = 10;
        if (n5 > 0) {
            float f5 = rfU.throws((float)n5 - f4, 10.0f);
            float f6 = (1.0f + f5) * 0.5f;
            float f7 = f6 * f6 * f6 * 12.0f;
            float f8 = f7 * rfU.class(this.private.case);
            this.private.throws = -6.5f + f7;
            this.private.protected = -7.0f - f8;
            float f9 = rfU.class(((float)n5 - f4) / 10.0f * (float)Math.PI * 0.25f);
            this.break.case = 1.5707964f * f9;
            this.break.case = n5 > 5 ? rfU.class(((float)(-4 + n5) - f4) / 4.0f) * (float)Math.PI * 0.4f : 0.15707964f * rfU.class((float)Math.PI * ((float)n5 - f4) / 10.0f);
        } else {
            float f10 = -1.0f;
            float f11 = -1.0f * rfU.class(this.private.case);
            this.private.byte = 0.0f;
            this.private.protected = -7.0f - f11;
            this.private.throws = 5.5f;
            boolean bl2 = n2 > 0;
            this.private.case = bl2 ? 0.2199115f : 0.0f;
            this.break.case = (float)Math.PI * (bl2 ? 0.05f : 0.01f);
            if (bl2) {
                double d = (double)n2 / 40.0;
                this.private.byte = (float)Math.sin(d * 10.0) * 3.0f;
            } else if (n3 > 0) {
                float f12 = rfU.class(((float)(20 - n3) - f4) / 20.0f * (float)Math.PI * 0.25f);
                this.break.case = 1.5707964f * f12;
            }
        }
    }

    @Override
    public void class(rgx_1 rgx_12, float f2, float f3, float f4, float f5, float f6) {
        this.class.case = f6 * ((float)Math.PI / 180);
        this.class.catch = f5 * ((float)Math.PI / 180);
        this.byte.case = 1.5707964f;
        float f7 = 0.4f * f3;
        this.protected.case = rfU.break(f2 * 0.6662f) * f7;
        this.throws.case = rfU.break(f2 * 0.6662f + (float)Math.PI) * f7;
        this.case.case = rfU.break(f2 * 0.6662f + (float)Math.PI) * f7;
        this.catch.case = rfU.break(f2 * 0.6662f) * f7;
    }

    @Override
    public Iterable<iq_1> class() {
        return ImmutableList.of((Object)this.private, (Object)this.byte, (Object)this.protected, (Object)this.throws, (Object)this.case, (Object)this.catch);
    }
}

