/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.brigadier.context.CommandContext
 */
package protected;

import com.mojang.brigadier.context.CommandContext;
import protected.gy_0;
import protected.rRn;
import protected.rnW;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public abstract class rRC<T extends rRC<T>> {
    protected final rRn<T> class;

    public abstract int byte();

    public rRC(rRn<T> rRn2) {
        this.class = rRn2;
    }

    public String toString() {
        return this.break();
    }

    protected /* synthetic */ Object clone() throws CloneNotSupportedException {
        return this.case();
    }

    protected abstract void class(CommandContext<gy_0> var1, String var2);

    public abstract void class(T var1, rnW var2);

    protected void class(rnW rnW2) {
        if (rnW2 != null) {
            this.class.byte.accept(rnW2, (rnW)this.catch());
        }
    }

    protected abstract void class(String var1);

    public abstract String break();

    public void break(CommandContext<gy_0> commandContext, String string) {
        this.class(commandContext, string);
        this.class(((gy_0)commandContext.getSource()).super());
    }

    protected abstract T catch();

    protected abstract T case();
}

