/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 *  it.unimi.dsi.fastutil.ints.IntArrayList
 *  it.unimi.dsi.fastutil.ints.IntList
 *  org.apache.commons.lang3.StringUtils
 *  org.apache.commons.lang3.mutable.MutableBoolean
 *  org.apache.commons.lang3.mutable.MutableInt
 */
package protected;

import com.google.common.collect.Lists;
import com.mojang.blaze3d.systems.RenderSystem;
import it.unimi.dsi.fastutil.ints.IntArrayList;
import it.unimi.dsi.fastutil.ints.IntList;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.ListIterator;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.mutable.MutableBoolean;
import org.apache.commons.lang3.mutable.MutableInt;
import protected.HZ;
import protected.cc_1;
import protected.ch_2;
import protected.cn_2;
import protected.ju_0;
import protected.lD;
import protected.lf_2;
import protected.ln_2;
import protected.ma_1;
import protected.ml_1;
import protected.qj_1;
import protected.rVj;
import protected.rca_1;
import protected.rcd_2;
import protected.rcy_2;
import protected.rdn_1;
import protected.rgF;
import protected.rgP;
import protected.rgc_0;
import protected.rgn;
import protected.rgn_0;
import protected.rhd_2;
import protected.rhz_2;
import protected.rmo;
import protected.rpl;
import protected.rpm;
import protected.rqR;
import protected.rqu_0;
import protected.rrvs;
import protected.ux_1;
import protected.vm_1;
import protected.vs_1;
import protected.vz_2;
import protected.yb_1;
import protected.zh_0;
import protected.zo_0;
import protected.zx_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.ZM
 */
public class zm_0
extends vm_1
implements rrvs {
    private static final rgP class = new rgn("book.editTitle");
    private static final rgP throws = new rgn("book.finalizeWarning");
    private static final rpl case = rpl.class("_", rgc_0.class.class(rgF.BLACK));
    private static final rpl catch = rpl.class("_", rgc_0.class.class(rgF.GRAY));
    private final rhd_2 private;
    private final rdn_1 implements;
    private boolean finally;
    private boolean else;
    private int synchronized;
    private int return;
    private final List<String> public = Lists.newArrayList();
    private String goto = "";
    private final ux_1 while = new ux_1(this::import, this::byte, this::native, this::class, string -> string.length() < 1024 && this.super.break((String)string, 114) <= 128);
    private final ux_1 try = new ux_1(() -> this.goto, string -> {
        this.goto = string;
    }, this::native, this::class, string -> string.length() < 16);
    private long instanceof;
    private int throw = -1;
    private ln_2 interface;
    private ln_2 char;
    private lf_2 abstract;
    private lf_2 long;
    private lf_2 float;
    private lf_2 boolean;
    private final rpm transient;
    private zh_0 for = zh_0.class;
    private rgP double = rgn_0.byte;
    private final rgP switch;

    private void char() {
        ListIterator<String> listIterator = this.public.listIterator(this.public.size());
        while (listIterator.hasPrevious() && listIterator.previous().isEmpty()) {
            listIterator.remove();
        }
    }

    private void byte(String string) {
        if (this.return >= 0 && this.return < this.public.size()) {
            this.public.set(this.return, string);
            this.finally = true;
            this.default();
        }
    }

    private void byte(boolean bl2) {
        if (this.finally) {
            this.char();
            rcy_2 rcy_22 = new rcy_2();
            this.public.stream().map(rca_1::class).forEach(rcy_22::add);
            if (!this.public.isEmpty()) {
                this.implements.class("pages", rcy_22);
            }
            if (bl2) {
                this.implements.class("author", rca_1.class(this.private.sv().getName()));
                this.implements.class("title", rca_1.class(this.goto.trim()));
            }
            int n2 = this.transient == rpm.MAIN_HAND ? ((rhz_2)this.private.implements[1]).protected : 40;
            this.volatile.void().class(new rmo(this.implements, bl2, n2));
        }
    }

    private boolean byte(int n2, int n3, int n4) {
        if (vm_1.private(n2)) {
            this.while.protected();
            return true;
        }
        if (vm_1.catch(n2)) {
            this.while.byte();
            return true;
        }
        if (vm_1.case(n2)) {
            this.while.break();
            return true;
        }
        if (vm_1.throws(n2)) {
            this.while.class();
            return true;
        }
        switch (n2) {
            case 257: 
            case 335: {
                this.while.class("\n");
                return true;
            }
            case 259: {
                this.while.break(-1);
                return true;
            }
            case 261: {
                this.while.break(1);
                return true;
            }
            case 262: {
                this.while.class(1, vm_1.synchronized());
                return true;
            }
            case 263: {
                this.while.class(-1, vm_1.synchronized());
                return true;
            }
            case 264: {
                this.float();
                return true;
            }
            case 265: {
                this.long();
                return true;
            }
            case 266: {
                this.char.catch();
                return true;
            }
            case 267: {
                this.interface.catch();
                return true;
            }
            case 268: {
                this.void();
                return true;
            }
            case 269: {
                this.static();
                return true;
            }
        }
        return false;
    }

    private void byte(int n2) {
        String string = this.import();
        this.while.class(rVj.class(string, -1, n2, false), rVj.class(string, 1, n2, false));
    }

    private void int() {
        if (this.return < this.final() - 1) {
            ++this.return;
        } else {
            this.abstract();
            if (this.return < this.final() - 1) {
                ++this.return;
            }
        }
        this.interface();
        this.const();
    }

    private void long() {
        this.break(-1);
    }

    private void float() {
        this.break(1);
    }

    public zm_0(rhd_2 rhd_22, rdn_1 rdn_12, rpm rpm2) {
        super(rgn_0.byte);
        this.private = rhd_22;
        this.implements = rdn_12;
        this.transient = rpm2;
        rcd_2 rcd_22 = rdn_12.package();
        if (rcd_22 != null) {
            rcy_2 rcy_22 = rcd_22.protected("pages", 8).protected();
            for (int k = 0; k < rcy_22.size(); ++k) {
                this.public.add(rcy_22.implements(k));
            }
        }
        if (this.public.isEmpty()) {
            this.public.add("");
        }
        this.switch = new rgn("book.byAuthor", rhd_22.g()).class(rgF.DARK_GRAY);
        vs_1.INSTANCE.class(this);
    }

    private void interface() {
        this.char.new = !this.else && this.return > 0;
        this.interface.new = !this.else;
        this.abstract.new = !this.else;
        this.long.new = !this.else;
        this.boolean.new = this.else;
        this.float.new = this.else;
        this.float.int = !this.goto.trim().isEmpty();
    }

    @Override
    public void class(ml_1 ml_12, int n2, int n3, float f2) {
        this.class(ml_12);
        this.class((cc_1)null);
        RenderSystem.color4f(1.0f, 1.0f, 1.0f, 1.0f);
        this.volatile.A().class(vz_2.throws);
        int n4 = (this.package - 192) / 2;
        int n5 = 2;
        this.break(ml_12, n4, 2, 0, 0, 192, 192);
        if (this.else) {
            boolean bl2 = this.synchronized / 6 % 2 == 0;
            rpl rpl2 = rpl.class(rpl.class(this.goto, rgc_0.class), bl2 ? case : catch);
            int n6 = this.super.class(zm_0.class);
            this.super.byte(ml_12, zm_0.class, n4 + 36 + (114 - n6) / 2, 34.0f, 0);
            int n7 = this.super.class(rpl2);
            this.super.break(ml_12, rpl2, (float)(n4 + 36 + (114 - n7) / 2), 50.0f, 0);
            int n8 = this.super.class(this.switch);
            this.super.byte(ml_12, this.switch, n4 + 36 + (114 - n8) / 2, 60.0f, 0);
            this.super.class(throws, n4 + 36, 82, 114, 0);
        } else {
            int n9 = this.super.class(this.double);
            this.super.byte(ml_12, this.double, n4 - n9 + 192 - 44, 18.0f, 0);
            zh_0 zh_02 = this.short();
            for (zo_0 zo_02 : zh_02.case) {
                this.super.byte(ml_12, zo_02.byte, zo_02.protected, zo_02.throws, -16777216);
            }
            this.class(zh_02.catch);
            this.class(ml_12, zh_02.byte, zh_02.protected);
        }
        super.class(ml_12, n2, n3, f2);
    }

    static int class(int[] nArray, int n2) {
        int n3 = Arrays.binarySearch(nArray, n2);
        return n3 < 0 ? -(n3 + 2) : n3;
    }

    private HZ class(String string, rVj rVj2, int n2, int n3, int n4, int n5) {
        String string2 = string.substring(n5, n2);
        String string3 = string.substring(n5, n3);
        zx_0 zx_02 = new zx_0((int)rVj2.class(string2), n4);
        zx_0 zx_03 = new zx_0((int)rVj2.class(string3), n4 + 9);
        return this.class(zx_02, zx_03);
    }

    private HZ class(zx_0 zx_02, zx_0 zx_03) {
        zx_0 zx_04 = this.break(zx_02);
        zx_0 zx_05 = this.break(zx_03);
        int n2 = Math.min(zx_04.class, zx_05.class);
        int n3 = Math.max(zx_04.class, zx_05.class);
        int n4 = Math.min(zx_04.break, zx_05.break);
        int n5 = Math.max(zx_04.break, zx_05.break);
        return new HZ(n2, n4, n3 - n2, n5 - n4);
    }

    private void class(ml_1 ml_12, zx_0 zx_02, boolean bl2) {
        if (this.synchronized / 6 % 2 == 0) {
            zx_02 = this.break(zx_02);
            if (!bl2) {
                ch_2.class(ml_12, zx_02.class, zx_02.break - 1, zx_02.class + 1, zx_02.break + 9, -16777216);
            } else {
                this.super.break(ml_12, "_", (float)zx_02.class, (float)zx_02.break, 0);
            }
        }
    }

    @Override
    public boolean class(double d, double d2, int n2, double d3, double d4) {
        if (super.class(d, d2, n2, d3, d4)) {
            return true;
        }
        if (n2 == 0) {
            zh_0 zh_02 = this.short();
            int n3 = zh_02.class(this.super, this.class(new zx_0((int)d, (int)d2)));
            this.while.byte(n3, true);
            this.default();
        }
        return true;
    }

    private zx_0 class(zx_0 zx_02) {
        return new zx_0(zx_02.class - (this.package - 192) / 2 - 36, zx_02.break - 32);
    }

    private void class(String string) {
        if (this.volatile != null) {
            ux_1.class(this.volatile, string);
        }
    }

    @Override
    public boolean class(char c, int n2) {
        if (super.class(c, n2)) {
            return true;
        }
        if (this.else) {
            boolean bl2 = this.try.class(c);
            if (bl2) {
                this.interface();
                this.finally = true;
                return true;
            }
            return false;
        }
        if (rqu_0.class(c)) {
            this.while.class(Character.toString(c));
            this.default();
            return true;
        }
        return false;
    }

    @Override
    public boolean class(int n2, int n3, int n4) {
        if (super.class(n2, n3, n4)) {
            return true;
        }
        if (this.else) {
            return this.protected(n2, n3, n4);
        }
        boolean bl2 = this.byte(n2, n3, n4);
        if (bl2) {
            this.default();
            return true;
        }
        return false;
    }

    private void class(HZ[] hZArray) {
        yb_1 yb_12 = yb_1.class();
        lD lD2 = yb_12.byte();
        RenderSystem.color4f(0.0f, 0.0f, 255.0f, 255.0f);
        RenderSystem.disableTexture();
        RenderSystem.enableColorLogicOp();
        RenderSystem.logicOp(ma_1.OR_REVERSE);
        lD2.class(7, ju_0.super);
        for (HZ hZ : hZArray) {
            int n2 = hZ.class();
            int n3 = hZ.break();
            int n4 = n2 + hZ.byte();
            int n5 = n3 + hZ.protected();
            lD2.class((double)n2, (double)n5, 0.0).class();
            lD2.class((double)n4, (double)n5, 0.0).class();
            lD2.class((double)n4, (double)n3, 0.0).class();
            lD2.class((double)n2, (double)n3, 0.0).class();
        }
        yb_12.break();
        RenderSystem.disableColorLogicOp();
        RenderSystem.enableTexture();
    }

    private /* synthetic */ void class(MutableInt mutableInt, String string, MutableBoolean mutableBoolean, IntList intList, List list, rgc_0 rgc_02, int n2, int n3) {
        int n4 = mutableInt.getAndIncrement();
        String string2 = string.substring(n2, n3);
        mutableBoolean.setValue(string2.endsWith("\n"));
        String string3 = StringUtils.stripEnd((String)string2, (String)" \n");
        int n5 = n4 * 9;
        zx_0 zx_02 = this.break(new zx_0(0, n5));
        intList.add(n2);
        list.add(new zo_0(rgc_02, string3, zx_02.class, zx_02.break));
    }

    private void default() {
        this.for = null;
    }

    private zh_0 short() {
        if (this.for == null) {
            this.for = this.strictfp();
            this.double = new rgn("book.pageIndicator", this.return + 1, this.final());
        }
        return this.for;
    }

    private void void() {
        int n2 = this.while.case();
        int n3 = this.short().class(n2);
        this.while.byte(n3, vm_1.synchronized());
    }

    private void break(int n2) {
        int n3 = this.while.case();
        int n4 = this.short().class(n3, n2);
        this.while.byte(n4, vm_1.synchronized());
    }

    private zx_0 break(zx_0 zx_02) {
        return new zx_0(zx_02.class + (this.package - 192) / 2 + 36, zx_02.break + 32);
    }

    @Override
    public boolean break(double d, double d2, int n2) {
        if (super.break(d, d2, n2)) {
            return true;
        }
        if (n2 == 0) {
            long l2 = rqR.break();
            zh_0 zh_02 = this.short();
            int n3 = zh_02.class(this.super, this.class(new zx_0((int)d, (int)d2)));
            if (n3 >= 0) {
                if (n3 == this.throw && l2 - this.instanceof < 250L) {
                    if (!this.while.private()) {
                        this.byte(n3);
                    } else {
                        this.while.protected();
                    }
                } else {
                    this.while.byte(n3, vm_1.synchronized());
                }
                this.default();
            }
            this.throw = n3;
            this.instanceof = l2;
        }
        return true;
    }

    private void const() {
        this.while.throws();
        this.default();
    }

    private String import() {
        return this.return >= 0 && this.return < this.public.size() ? this.public.get(this.return) : "";
    }

    private void package() {
        if (this.return > 0) {
            --this.return;
        }
        this.interface();
        this.const();
    }

    private void static() {
        zh_0 zh_02 = this.short();
        int n2 = this.while.case();
        int n3 = zh_02.break(n2);
        this.while.byte(n3, vm_1.synchronized());
    }

    private boolean protected(int n2, int n3, int n4) {
        switch (n2) {
            case 257: 
            case 335: {
                if (!this.goto.isEmpty()) {
                    this.byte(true);
                    this.volatile.break((vm_1)null);
                }
                return true;
            }
            case 259: {
                this.try.break(-1);
                this.interface();
                this.finally = true;
                return true;
            }
        }
        return false;
    }

    @Override
    public void private() {
        super.private();
        ++this.synchronized;
    }

    private void abstract() {
        if (this.final() < 100) {
            this.public.add("");
            this.finally = true;
        }
    }

    private int final() {
        return this.public.size();
    }

    private String native() {
        return this.volatile != null ? ux_1.break(this.volatile) : "";
    }

    private zh_0 strictfp() {
        int n2;
        zx_0 zx_02;
        boolean bl2;
        String string = this.import();
        if (string.isEmpty()) {
            return zh_0.class;
        }
        int n3 = this.while.case();
        int n4 = this.while.catch();
        IntArrayList intArrayList = new IntArrayList();
        ArrayList arrayList = Lists.newArrayList();
        MutableInt mutableInt = new MutableInt();
        MutableBoolean mutableBoolean = new MutableBoolean();
        rVj rVj2 = this.super.break();
        rVj2.class(string, 114, rgc_0.class, true, (arg_0, arg_1, arg_2) -> this.class(mutableInt, string, mutableBoolean, (IntList)intArrayList, arrayList, arg_0, arg_1, arg_2));
        int[] nArray = intArrayList.toIntArray();
        boolean bl3 = bl2 = n3 == string.length();
        if (bl2 && mutableBoolean.isTrue()) {
            zx_02 = new zx_0(0, arrayList.size() * 9);
        } else {
            int n5 = zm_0.class(nArray, n3);
            n2 = this.super.break(string.substring(nArray[n5], n3));
            zx_02 = new zx_0(n2, n5 * 9);
        }
        ArrayList arrayList2 = Lists.newArrayList();
        if (n3 != n4) {
            int n6;
            n2 = Math.min(n3, n4);
            int n7 = Math.max(n3, n4);
            int n8 = zm_0.class(nArray, n2);
            if (n8 == (n6 = zm_0.class(nArray, n7))) {
                int n9 = n8 * 9;
                int n10 = nArray[n8];
                arrayList2.add(this.class(string, rVj2, n2, n7, n9, n10));
            } else {
                int n11 = n8 + 1 > nArray.length ? string.length() : nArray[n8 + 1];
                arrayList2.add(this.class(string, rVj2, n2, n11, n8 * 9, nArray[n8]));
                for (int k = n8 + 1; k < n6; ++k) {
                    int n12 = k * 9;
                    String string2 = string.substring(nArray[k], nArray[k + 1]);
                    int n13 = (int)rVj2.class(string2);
                    arrayList2.add(this.class(new zx_0(0, n12), new zx_0(n13, n12 + 9)));
                }
                arrayList2.add(this.class(string, rVj2, nArray[n6], n7, n6 * 9, nArray[n6]));
            }
        }
        return new zh_0(string, zx_02, bl2, nArray, arrayList.toArray(new zo_0[0]), arrayList2.toArray(new HZ[0]));
    }

    @Override
    public boolean aO_() {
        return true;
    }

    @Override
    protected void v_() {
        this.default();
        ((qj_1)this.volatile.class[23]).class(true);
        this.long = this.class(new lf_2(this.package / 2 - 100, 196, 98, 20, new rgn("book.signButton"), lf_22 -> {
            this.else = true;
            this.interface();
        }));
        this.abstract = this.class(new lf_2(this.package / 2 + 2, 196, 98, 20, cn_2.byte, lf_22 -> {
            this.volatile.break((vm_1)null);
            this.byte(false);
        }));
        this.float = this.class(new lf_2(this.package / 2 - 100, 196, 98, 20, new rgn("book.finalizeButton"), lf_22 -> {
            if (this.else) {
                this.byte(true);
                this.volatile.break((vm_1)null);
            }
        }));
        this.boolean = this.class(new lf_2(this.package / 2 + 2, 196, 98, 20, cn_2.protected, lf_22 -> {
            if (this.else) {
                this.else = false;
            }
            this.interface();
        }));
        int n2 = (this.package - 192) / 2;
        int n3 = 2;
        this.interface = this.class(new ln_2(n2 + 116, 159, true, lf_22 -> this.int(), true));
        this.char = this.class(new ln_2(n2 + 43, 159, false, lf_22 -> this.package(), true));
        this.interface();
    }

    @Override
    public void w_() {
        super.w_();
        ((qj_1)this.volatile.class[23]).class(false);
    }
}

