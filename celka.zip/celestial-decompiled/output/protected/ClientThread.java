/*
 * Decompiled with CFR 0.152.
 */
package protected;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.main.Main;
import protected.qy_1;

/*
 * Renamed from protected.AE
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class ae_2
extends Thread {
    final /* synthetic */ qy_1 class;

    public ae_2(String string, qy_1 qy_12) {
        this.class = qy_12;
        super(string);
    }

    @Override
    public void run() {
        try {
            RenderSystem.initGameThread(true);
            this.class.double();
        }
        catch (Throwable throwable) {
            Main.class.error("Exception in client thread", throwable);
        }
    }
}

