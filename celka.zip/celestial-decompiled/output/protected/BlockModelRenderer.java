/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.util.Random;
import protected.jq_1;
import protected.kx_2;
import protected.qz_1;
import protected.rCL;
import protected.rCZ;
import protected.rCm;
import protected.rRq;
import protected.rYB;
import protected.rct_0;
import protected.rfH;
import protected.rjC;
import protected.rjm;
import protected.rrEm;
import protected.xc_0;
import protected.xd_0;
import protected.xf_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.WC
 */
public class wc_1
extends xf_0
implements kx_2 {
    public static final rCm volatile = rct_0.y;
    protected static final rjC final = xd_0.class(2.0, 0.0, 2.0, 14.0, 12.0, 14.0);
    private final qz_1 package;

    protected wc_1(qz_1 qz_12, jq_1 jq_12) {
        super(jq_12);
        this.package = qz_12;
        this.extends((xc_0)((xc_0)this.abstract.break()).class(volatile, 0));
    }

    @Override
    public boolean class(rYB rYB2, Random random, rfH rfH2, xc_0 xc_02) {
        return (double)rYB2.int.nextFloat() < 0.45;
    }

    @Override
    public void class(rrEm rrEm2, Random random, rfH rfH2, xc_0 xc_02) {
        this.class(rrEm2, rfH2, xc_02, random);
    }

    @Override
    protected void class(rCL<xd_0, xc_0> rCL2) {
        rCL2.class(new rCZ[]{volatile});
    }

    @Override
    public boolean class(rRq rRq2, rfH rfH2, xc_0 xc_02, boolean bl2) {
        return true;
    }

    @Override
    public rjC class(xc_0 xc_02, rRq rRq2, rfH rfH2, rjm rjm2) {
        return final;
    }

    public void class(rrEm rrEm2, rfH rfH2, xc_0 xc_02, Random random) {
        if (xc_02.byte(volatile) == 0) {
            rrEm2.class(rfH2, (xc_0)xc_02.class(volatile), 4);
        } else {
            this.package.class(rrEm2, rrEm2.else().implements(), rfH2, xc_02, random);
        }
    }

    @Override
    public void class(xc_0 xc_02, rrEm rrEm2, rfH rfH2, Random random) {
        if (rrEm2.package(rfH2.final()) >= 9 && random.nextInt(7) == 0) {
            this.class(rrEm2, rfH2, xc_02, random);
        }
    }
}

