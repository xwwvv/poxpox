/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.regex.Pattern;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.bb_0;
import protected.bm_0;
import protected.class;
import protected.rVi;
import protected.rfH;
import protected.rfm_1;
import protected.rfu_2;
import protected.rgF;
import protected.rgn_0;
import protected.rrjm_0;
import protected.rrlp_1;
import protected.rrlq_1;
import protected.rrlu_2;
import protected.rus_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.bG
 */
public class bg_0
extends bb_0 {
    private static byte[] protected;
    private static boolean[] throws;
    public static Object[] class;
    private static short[] case;
    private static String[] catch;
    public Object[] break;

    public bg_0(class clazz, bm_0 bm_02) {
        super(clazz, bm_02);
        this.final();
    }

    static {
        bg_0.ntfClinit();
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0x319E8DB678B005E0L;
    }

    @Override
    public void class(rrlu_2 rrlu_22) {
        rus_2<?> rus_22 = rrlu_22.class();
        if (rus_22 instanceof rfu_2) {
            rfu_2 rfu_22 = (rfu_2)rus_22;
            rus_22 = rfu_22.byte();
            if (rfu_22.break() != rfm_1.ACTIONBAR || rus_22 == null) {
                return;
            }
            String string = rus_22.byte();
            if (((Pattern)rrjm_0.class[case[6]]).matcher(string).find()) {
                this.implements();
            }
        }
    }

    @Override
    public void class() {
        super.class();
        this.catch();
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0xF35A2775;
    }

    @Override
    public void class(rrlp_1 rrlp_12) {
        this.final();
        if (rrlp_12.case() == (rrlq_1)((Object)rrlq_1.staticFields2d4389a28d3a3bcfbac26ede38e74314[case[0]])) {
            rfH rfH2 = rrlp_12.class();
            if (!rfH2.equals((rfH)this.break[case[1]])) {
                rfH rfH3 = rfH2;
                this.break[bg_0.case[2]] = rfH3;
                Integer n2 = throws[0];
                this.break[bg_0.case[3]] = n2;
            } else {
                bg_0 bg_02 = this;
                int n3 = (Integer)bg_02.break[case[4]] + throws[1];
                Integer n4 = n3;
                bg_02.break[bg_0.case[5]] = n4;
                if (n3 >= protected[0]) {
                    this.implements();
                    this.catch();
                }
            }
        }
    }

    public static String class(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{41, -15, -72, -80, -113, -32, -78, 82}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    private static void throws() {
        Object[] objectArray = new Object[]{15};
        bg_0.class = objectArray;
    }

    private static /* synthetic */ void ntfClinit() {
        bg_0.private();
        bg_0.extends();
        bg_0.case();
        bg_0.finally();
        bg_0.throws();
    }

    private static void finally() {
        protected = new byte[]{15, 2, 15};
    }

    private void catch() {
        this.final();
        Object var5_1 = null;
        this.break[bg_0.case[7]] = var5_1;
        Integer n2 = throws[2];
        this.break[bg_0.case[8]] = n2;
    }

    private static void extends() {
        catch = new String[]{new String("\u041d\u0430\u0439\u0434\u0435\u043d \u043f\u0440\u0438\u0432\u0430\u0442")};
    }

    private static void case() {
        short[] sArray = new short[9];
        sArray[0] = 2;
        sArray[3] = 1;
        sArray[4] = 1;
        sArray[5] = 1;
        sArray[8] = 1;
        case = sArray;
    }

    private void implements() {
        rVi rVi2 = new rgn_0(catch[0]).class(rgF.GRAY);
        this.class(rVi2);
        this.catch();
    }

    private static void private() {
        boolean[] blArray = new boolean[7];
        blArray[0] = true;
        blArray[1] = true;
        blArray[3] = true;
        blArray[5] = true;
        throws = blArray;
    }

    private void final() {
        if (this.break == null) {
            Object[] objectArray = this.break = new Object[protected[1]];
            objectArray[bg_0.throws[3]] = throws[4];
        }
    }
}

