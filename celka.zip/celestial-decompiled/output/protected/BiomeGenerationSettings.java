/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableList
 *  com.google.common.collect.ImmutableMap
 *  com.mojang.datafixers.DataFixUtils
 *  com.mojang.datafixers.kinds.App
 *  com.mojang.datafixers.kinds.Applicative
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.Keyable
 *  com.mojang.serialization.MapCodec
 *  com.mojang.serialization.codecs.RecordCodecBuilder
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
package protected;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import com.mojang.datafixers.DataFixUtils;
import com.mojang.datafixers.kinds.App;
import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.Keyable;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import java.util.function.Supplier;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import protected.rDg;
import protected.rKu;
import protected.rdm_0;
import protected.reP;
import protected.rpH;
import protected.rqR;
import protected.rrrZ;
import protected.rrsa_1;
import protected.rrsr_1;
import protected.rrsy_1;
import protected.ruo_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.rYv
 */
public class ryv_0 {
    public static final Logger class = LogManager.getLogger();
    public static final ryv_0 break = new ryv_0(() -> rrsy_1.int, (Map<rKu, List<Supplier<rdm_0<?>>>>)ImmutableMap.of(), (List<List<Supplier<rDg<?, ?>>>>)ImmutableList.of(), (List<Supplier<reP<?, ?>>>)ImmutableList.of());
    public static final MapCodec<ryv_0> byte = RecordCodecBuilder.mapCodec(instance -> instance.group((App)rrsr_1.break.fieldOf("surface_builder").forGetter(ryv_02 -> ryv_02.protected), (App)Codec.simpleMap(rKu.field_236074_c_, (Codec)rdm_0.byte.promotePartial((Consumer)((Object)rqR.class("Carver: ", arg_0 -> ((Logger)ryv_0.class).error(arg_0)))), (Keyable)rpH.class(rKu.values())).fieldOf("carvers").forGetter(ryv_02 -> ryv_02.throws), (App)rDg.byte.promotePartial((Consumer)((Object)rqR.class("Feature: ", arg_0 -> ((Logger)ryv_0.class).error(arg_0)))).listOf().fieldOf("features").forGetter(ryv_02 -> ryv_02.case), (App)reP.byte.promotePartial((Consumer)((Object)rqR.class("Structure start: ", arg_0 -> ((Logger)ryv_0.class).error(arg_0)))).fieldOf("starts").forGetter(ryv_02 -> ryv_02.catch)).apply((Applicative)instance, ryv_0::new));
    private final Supplier<rrsr_1<?>> protected;
    private final Map<rKu, List<Supplier<rdm_0<?>>>> throws;
    private final List<List<Supplier<rDg<?, ?>>>> case;
    private final List<Supplier<reP<?, ?>>> catch;
    private final List<rDg<?, ?>> private;

    public List<List<Supplier<rDg<?, ?>>>> byte() {
        return this.case;
    }

    ryv_0(Supplier<rrsr_1<?>> supplier, Map<rKu, List<Supplier<rdm_0<?>>>> map, List<List<Supplier<rDg<?, ?>>>> list, List<Supplier<reP<?, ?>>> list2) {
        this.protected = supplier;
        this.throws = map;
        this.case = list;
        this.catch = list2;
        this.private = (List)list.stream().flatMap(Collection::stream).map(Supplier::get).flatMap(rDg::protected).filter(rDg2 -> rDg2.throws == ruo_0.protected).collect(ImmutableList.toImmutableList());
    }

    public List<Supplier<rdm_0<?>>> class(rKu rKu2) {
        return (List)this.throws.getOrDefault(rKu2, (List<Supplier<rdm_0<?>>>)ImmutableList.of());
    }

    public reP<?, ?> class(reP<?, ?> reP2) {
        return (reP)DataFixUtils.orElse(this.catch.stream().map(Supplier::get).filter(reP3 -> reP3.protected == reP2.protected).findAny(), reP2);
    }

    public Collection<Supplier<reP<?, ?>>> class() {
        return this.catch;
    }

    public boolean class(rrrZ<?> rrrZ2) {
        return this.catch.stream().anyMatch(supplier -> ((reP)supplier.get()).protected == rrrZ2);
    }

    public List<rDg<?, ?>> break() {
        return this.private;
    }

    public rrsa_1 throws() {
        return this.protected.get().class();
    }

    public Supplier<rrsr_1<?>> protected() {
        return this.protected;
    }
}

