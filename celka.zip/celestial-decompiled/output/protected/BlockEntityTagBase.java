/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.rYB;
import protected.rcd_2;
import protected.rcz_1;
import protected.rdn_1;
import protected.rdy_2;
import protected.rkf_1;
import protected.rqo_0;
import protected.rwn_2;
import protected.rxk_1;
import protected.rxo_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.rWX
 */
public class rwx_2
extends rwn_2 {
    public rwx_2(rqo_0 rqo_02) {
        super(rqo_02);
    }

    @Override
    public boolean class(int n2, int n3) {
        return n2 * n3 >= 2;
    }

    @Override
    public rdn_1 class(rxk_1 rxk_12) {
        Object object;
        rdn_1 rdn_12 = rdn_1.break;
        rdn_1 rdn_13 = rdn_1.break;
        for (int k = 0; k < rxk_12.else(); ++k) {
            object = rxk_12.extends(k);
            if (((rdn_1)object).class()) continue;
            if (((rdn_1)object).break() instanceof rxo_0) {
                rdn_12 = object;
                continue;
            }
            if (((rdn_1)object).break() != rdy_2.kN) continue;
            rdn_13 = ((rdn_1)object).implements();
        }
        if (rdn_13.class()) {
            return rdn_13;
        }
        rcd_2 rcd_22 = rdn_12.break("BlockEntityTag");
        object = rcd_22 == null ? new rcd_2() : rcd_22.catch();
        ((rcd_2)object).break("Base", ((rxo_0)rdn_12.break()).byte().break());
        rdn_13.class("BlockEntityTag", (rcz_1)object);
        return rdn_13;
    }

    @Override
    public boolean class(rxk_1 rxk_12, rYB rYB2) {
        rdn_1 rdn_12 = rdn_1.break;
        rdn_1 rdn_13 = rdn_1.break;
        for (int k = 0; k < rxk_12.else(); ++k) {
            rdn_1 rdn_14 = rxk_12.extends(k);
            if (rdn_14.class()) continue;
            if (rdn_14.break() instanceof rxo_0) {
                if (!rdn_13.class()) {
                    return false;
                }
                rdn_13 = rdn_14;
                continue;
            }
            if (rdn_14.break() != rdy_2.kN) {
                return false;
            }
            if (!rdn_12.class()) {
                return false;
            }
            if (rdn_14.break("BlockEntityTag") != null) {
                return false;
            }
            rdn_12 = rdn_14;
        }
        return !rdn_12.class() && !rdn_13.class();
    }

    @Override
    public rkf_1<?> W_() {
        return rkf_1.native;
    }
}

