/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.Y;
import protected.bu_1;
import protected.class;
import protected.ps_1;
import protected.pv_2;
import protected.q;
import protected.rYB;
import protected.raa_1;
import protected.rhd_2;
import protected.rnp_0;
import protected.rns_0;
import protected.rrfp;
import protected.rrfq;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.Bc
 */
public class bc_1
extends pv_2 {
    private static short[] break;
    private static byte[] byte;

    private void byte(rYB rYB2, rns_0 rns_02, rnp_0 rnp_02) {
        for (rhd_2 rhd_22 : rYB2.continue()) {
            if (rhd_22 == ((ps_1)this.class[break[9]]).catch()) continue;
            raa_1 raa_12 = rns_02.break(rhd_22.i(), rnp_02);
            Float f2 = Float.valueOf(raa_12.break());
            rhd_22.implements[bc_1.break[10]] = f2;
        }
    }

    public bc_1(class clazz) {
        super(clazz);
    }

    static {
        bc_1.ntfClinit();
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0x2CE19C72;
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0x988B82DE71C94D17L;
    }

    private static void class() {
        short[] sArray = new short[11];
        sArray[1] = 1;
        sArray[2] = 1;
        sArray[4] = 1;
        sArray[5] = 1;
        sArray[6] = 24;
        sArray[7] = 1;
        sArray[8] = 24;
        sArray[9] = 1;
        sArray[10] = 24;
        break = sArray;
    }

    private void class(rYB rYB2, rns_0 rns_02, rnp_0 rnp_02) {
        for (rhd_2 rhd_22 : rYB2.continue()) {
            if (rhd_22 == ((ps_1)this.class[break[5]]).catch()) continue;
            raa_1 raa_12 = rns_02.break(rhd_22.i(), rnp_02);
            Float f2 = Float.valueOf(raa_12.break());
            rhd_22.implements[bc_1.break[6]] = f2;
        }
    }

    @Override
    public void class(q q2) {
        if (q2.class() == (Y)((Object)Y.staticFields22c81230f53b33f2a682b4198db24cc4[break[0]])) {
            if ((rrfq)((Object)rrfp.class[break[1]]) == null) {
                return;
            }
            rYB rYB2 = ((ps_1)this.class[break[2]]).case();
            rns_0 rns_02 = rYB2.package();
            switch (((int[])bu_1.class[break[3]])[((rrfq)((Object)rrfp.class[break[4]])).ordinal()]) {
                case 1: {
                    rnp_0 rnp_02 = rns_02.class(byte[0]);
                    if (rnp_02 == null) break;
                    this.break(rYB2, rns_02, rnp_02);
                    break;
                }
                case 2: {
                    rnp_0 rnp_03 = rns_02.class(byte[1]);
                    if (rnp_03 == null) break;
                    this.class(rYB2, rns_02, rnp_03);
                    break;
                }
                case 3: {
                    rnp_0 rnp_04 = rns_02.class(byte[2]);
                    if (rnp_04 == null) break;
                    this.byte(rYB2, rns_02, rnp_04);
                }
            }
        }
    }

    private static void break() {
        byte = new byte[]{2, 2, 2};
    }

    private void break(rYB rYB2, rns_0 rns_02, rnp_0 rnp_02) {
        for (rhd_2 rhd_22 : rYB2.continue()) {
            if (rhd_22 == ((ps_1)this.class[break[7]]).catch() || rhd_22.Pp()) continue;
            raa_1 raa_12 = rns_02.break(rhd_22.i(), rnp_02);
            Float f2 = Float.valueOf(raa_12.break());
            rhd_22.implements[bc_1.break[8]] = f2;
        }
    }

    public static String break(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{70, 19, -50, 48, 76, -42, 113, 1}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    private static /* synthetic */ void ntfClinit() {
        bc_1.class();
        bc_1.break();
    }
}

