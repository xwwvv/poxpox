/*
 * Decompiled with CFR 0.152.
 */
package protected;

import com.mojang.blaze3d.systems.RenderSystem;
import java.util.Optional;
import java.util.function.Predicate;
import protected.Hx;
import protected.an;
import protected.cm_1;
import protected.hd_0;
import protected.hh_0;
import protected.ju_0;
import protected.lD;
import protected.ly_0;
import protected.ml_1;
import protected.pb_0;
import protected.pe_0;
import protected.ph_0;
import protected.pj_0;
import protected.pm_0;
import protected.po_0;
import protected.pr_0;
import protected.ps;
import protected.ps_0;
import protected.px;
import protected.px_0;
import protected.qy_1;
import protected.rfH;
import protected.rfl;
import protected.rfo;
import protected.rhj_1;
import protected.rjU;
import protected.rjV;
import protected.rjo;
import protected.ya_1;
import protected.yb_1;
import protected.yd_2;
import protected.yg_2;
import protected.yi_2;
import protected.yo_2;
import protected.yr_2;
import protected.yu_1;
import protected.yv_1;
import protected.yx_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.yK
 */
public class yk_2 {
    public final ps class = new ps();
    public final yd_2 break;
    public final yd_2 byte;
    public final yd_2 protected;
    public final yd_2 throws;
    public final yd_2 case;
    public final yv_1 catch;
    public final ph_0 private;
    public final yd_2 implements;
    public final yd_2 finally;
    public final yd_2 extends;
    public final yd_2 native;
    public final pe_0 volatile;
    public final px_0 final;
    public final yi_2 package;
    public final pm_0 int;
    public final yu_1 new;
    public final ya_1 continue;
    private boolean super;

    public yk_2(qy_1 qy_12) {
        this.break = new pj_0(qy_12);
        this.byte = new yg_2(qy_12);
        this.protected = new pr_0(qy_12);
        this.throws = new yo_2(qy_12);
        this.case = new ps_0(qy_12);
        this.catch = new yv_1();
        this.private = new ph_0(qy_12);
        this.implements = new pb_0(qy_12);
        this.finally = new px();
        this.extends = new po_0(qy_12);
        this.native = new yr_2(qy_12);
        this.volatile = new pe_0(qy_12);
        this.final = new px_0();
        this.package = new yi_2(qy_12);
        this.int = new pm_0(qy_12);
        this.new = new yu_1(qy_12);
        this.continue = new ya_1();
    }

    public static void class(String string, double d, double d2, double d3, int n2) {
        yk_2.class(string, d, d2, d3, n2, 0.02f);
    }

    public static void class(String string, int n2, int n3, int n4, int n5) {
        yk_2.class(string, (double)n2 + 0.5, (double)n3 + 0.5, (double)n4 + 0.5, n5);
    }

    public static void class(double d, double d2, double d3, double d4, double d5, double d6, float f2, float f3, float f4, float f5) {
        yb_1 yb_12 = yb_1.class();
        lD lD2 = yb_12.byte();
        lD2.class(5, ju_0.this);
        yx_1.class(lD2, d, d2, d3, d4, d5, d6, f2, f3, f4, f5);
        yb_12.break();
    }

    public static void class(rfl rfl2, float f2, float f3, float f4, float f5) {
        yk_2.class(rfl2.class, rfl2.break, rfl2.byte, rfl2.protected, rfl2.throws, rfl2.case, f2, f3, f4, f5);
    }

    public static void class(String string, double d, double d2, double d3, int n2, float f2) {
        yk_2.class(string, d, d2, d3, n2, f2, true, 0.0f, false);
    }

    public static void class(String string, double d, double d2, double d3, int n2, float f2, boolean bl2, float f3, boolean bl3) {
        qy_1 qy_12 = qy_1.instanceof();
        ly_0 ly_02 = ((hh_0)qy_12.class[16]).finally();
        if (ly_02.private() && qy_12.case().protected != null) {
            cm_1 cm_12 = (cm_1)qy_12.class[15];
            double d4 = ly_02.break().break;
            double d5 = ly_02.break().byte;
            double d6 = ly_02.break().protected;
            RenderSystem.pushMatrix();
            RenderSystem.translatef((float)(d - d4), (float)(d2 - d5) + 0.07f, (float)(d3 - d6));
            RenderSystem.normal3f(0.0f, 1.0f, 0.0f);
            RenderSystem.multMatrix(new rjV(ly_02.case()));
            RenderSystem.scalef(f2, -f2, f2);
            RenderSystem.enableTexture();
            if (bl3) {
                RenderSystem.disableDepthTest();
            } else {
                RenderSystem.enableDepthTest();
            }
            RenderSystem.depthMask(true);
            RenderSystem.scalef(-1.0f, 1.0f, 1.0f);
            float f4 = bl2 ? (float)(-cm_12.break(string)) / 2.0f : 0.0f;
            RenderSystem.enableAlphaTest();
            hd_0 hd_02 = Hx.class(yb_1.class().byte());
            cm_12.class(string, f4 -= f3 / f2, 0.0f, n2, false, rjo.class().byte(), (Hx)hd_02, bl3, 0, 0xF000F0);
            hd_02.break();
            RenderSystem.color4f(1.0f, 1.0f, 1.0f, 1.0f);
            RenderSystem.enableDepthTest();
            RenderSystem.popMatrix();
        }
    }

    public void class() {
        this.class.class();
        this.break.class();
        this.byte.class();
        this.protected.class();
        this.throws.class();
        this.case.class();
        this.catch.class();
        this.private.class();
        this.implements.class();
        this.finally.class();
        this.extends.class();
        this.native.class();
        this.volatile.class();
        this.final.class();
        this.package.class();
        this.int.class();
        this.new.class();
        this.continue.class();
    }

    public void class(ml_1 ml_12, hd_0 hd_02, double d, double d2, double d3) {
        if (this.super && !qy_1.instanceof().E()) {
            this.byte.class(ml_12, hd_02, d, d2, d3);
        }
    }

    public static Optional<an> class(an an3, int n2) {
        int n3;
        Predicate<an> predicate;
        rfl rfl2;
        rjU rjU2;
        rjU rjU3;
        if (an3 == null) {
            return Optional.empty();
        }
        rjU rjU4 = an3.new(1.0f);
        rfo rfo2 = rhj_1.class(an3, rjU4, rjU3 = rjU4.throws(rjU2 = an3.break(1.0f).class((double)n2)), rfl2 = an3.rN().break(rjU2).class(1.0), predicate = an2 -> !an2.native() && an2.rY(), n3 = n2 * n2);
        if (rfo2 == null) {
            return Optional.empty();
        }
        return rjU4.implements(rfo2.case()) > (double)n3 ? Optional.empty() : Optional.of(rfo2.class());
    }

    public static void class(rfH rfH2, rfH rfH3, float f2, float f3, float f4, float f5) {
        ly_0 ly_02 = ((hh_0)qy_1.instanceof().class[16]).finally();
        if (ly_02.private()) {
            rjU rjU2 = ly_02.break().throws();
            rfl rfl2 = new rfl(rfH2, rfH3).protected(rjU2);
            yk_2.class(rfl2, f2, f3, f4, f5);
        }
    }

    public static void class(rfH rfH2, float f2, float f3, float f4, float f5, float f6) {
        ly_0 ly_02 = ((hh_0)qy_1.instanceof().class[16]).finally();
        if (ly_02.private()) {
            rjU rjU2 = ly_02.break().throws();
            rfl rfl2 = new rfl(rfH2).protected(rjU2).class(f2);
            yk_2.class(rfl2, f3, f4, f5, f6);
        }
    }

    public boolean break() {
        this.super = !this.super;
        return this.super;
    }
}

