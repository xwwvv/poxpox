/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.an;
import protected.case;
import protected.k_0;
import protected.rs_2;
import protected.static;
import protected.try;
import protected.x;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.sX
 */
public class sx_0
extends try {
    private static boolean[] break;
    private static short[] throws;
    private static String[] case;
    private static byte[] catch;

    public sx_0(case case_) {
        String[] stringArray = new String[break[0]];
        stringArray[sx_0.break[1]] = case[0];
        super(case_, stringArray);
    }

    static {
        sx_0.ntfClinit();
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0xDA0BDFC;
    }

    @Override
    public void class(String string, static static_) throws x {
        static_.class(break[2]);
        an an2 = b_.catch();
        if (an2 == null) {
            throw new k_0(case[1]);
        }
        ((case)this.class[throws[0]]).import().break(new rs_2(an2.Bs()));
        this.case(case[2]);
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0x1639C818EACD7329L;
    }

    @Override
    public Stream<String> break(String string, static static_) {
        return Stream.empty();
    }

    public static String break(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{0, 1, 14, 58, 113, 15, -16, -74}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    private static void throws() {
        case = new String[]{new String("come"), new String("\u0412\u0430\u0448 \u0438\u0433\u0440\u043e\u043a \u043d\u0435 \u043d\u0430\u0439\u0434\u0435\u043d"), new String("\u0418\u0434\u0451\u043c"), new String("\u0423\u043a\u0430\u0437\u044b\u0432\u0430\u0435\u0442 Baritone \u043d\u0430\u043f\u0440\u0430\u0432\u0438\u0442\u044c\u0441\u044f \u043a \u0432\u0430\u0448\u0435\u0439 \u043a\u0430\u043c\u0435\u0440\u0435"), new String("\u0423\u043a\u0430\u0437\u044b\u0432\u0430\u0435\u0442 Baritone \u043d\u0430\u043f\u0440\u0430\u0432\u0438\u0442\u044c\u0441\u044f \u043a \u0432\u0430\u0448\u0435\u0439 \u043a\u0430\u043c\u0435\u0440\u0435"), new String(""), new String("\u042d\u0442\u043e \u043c\u043e\u0436\u0435\u0442 \u0431\u044b\u0442\u044c \u043f\u043e\u043b\u0435\u0437\u043d\u043e \u0432 \u0447\u0438\u0442 \u043a\u043b\u0438\u0435\u043d\u0442\u0430\u0445, \u0433\u0434\u0435 FreeCamera \u043d\u0435 \u043f\u0435\u0440\u0435\u043c\u0435\u0449\u0430\u0435\u0442 \u043f\u043e\u0437\u0438\u0446\u0438\u044e \u0438\u0433\u0440\u043e\u043a\u0430"), new String(""), new String("\u0418\u0441\u043f\u043e\u043b\u044c\u0437\u043e\u0432\u0430\u043d\u0438\u0435:"), new String("> come")};
    }

    private static /* synthetic */ void ntfClinit() {
        sx_0.finally();
        sx_0.throws();
        sx_0.extends();
        sx_0.protected();
    }

    private static void finally() {
        boolean[] blArray = new boolean[6];
        blArray[0] = true;
        blArray[4] = true;
        blArray[5] = true;
        break = blArray;
    }

    @Override
    public List<String> catch() {
        String[] stringArray = new String[catch[0]];
        stringArray[sx_0.break[3]] = case[4];
        stringArray[sx_0.break[4]] = case[5];
        stringArray[sx_0.catch[1]] = case[6];
        stringArray[sx_0.catch[2]] = case[7];
        stringArray[sx_0.catch[3]] = case[8];
        stringArray[sx_0.catch[4]] = case[9];
        return Arrays.asList(stringArray);
    }

    private static void extends() {
        throws = new short[1];
    }

    @Override
    public boolean case() {
        return break[5];
    }

    @Override
    public String implements() {
        return case[3];
    }

    private static void protected() {
        catch = new byte[]{6, 2, 3, 4, 5};
    }
}

