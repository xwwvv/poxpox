/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.util.Random;
import protected.jq_1;
import protected.kd_2;
import protected.kx_2;
import protected.rCL;
import protected.rCm;
import protected.rRR;
import protected.rRg;
import protected.rRq;
import protected.rYB;
import protected.rcn_0;
import protected.rct_0;
import protected.rfH;
import protected.rjC;
import protected.rjm;
import protected.rls;
import protected.rlt_2;
import protected.rpr_0;
import protected.rrEm;
import protected.rxe_2;
import protected.rxg_2;
import protected.rxx;
import protected.xc_0;
import protected.xd_0;
import protected.xf_0;
import protected.xu_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.Wy
 */
public class wy_2
extends xf_0
implements kx_2,
kd_2 {
    public static final rCm volatile = rct_0.l;
    public static final rcn_0 final = rct_0.throw;
    protected static final rjC package = xd_0.class(6.0, 0.0, 6.0, 10.0, 6.0, 10.0);
    protected static final rjC int = xd_0.class(3.0, 0.0, 3.0, 13.0, 6.0, 13.0);
    protected static final rjC new = xd_0.class(2.0, 0.0, 2.0, 14.0, 6.0, 14.0);
    protected static final rjC continue = xd_0.class(2.0, 0.0, 2.0, 14.0, 7.0, 14.0);

    protected wy_2(jq_1 jq_12) {
        super(jq_12);
        this.extends((xc_0)((xc_0)((xc_0)this.abstract.break()).class(volatile, 1)).class(final, true));
    }

    @Override
    public xc_0 class(rxx rxx2) {
        xc_0 xc_02 = rxx2.int().byte(rxx2.class());
        if (xc_02.class(this)) {
            return (xc_0)xc_02.class(volatile, Math.min(4, xc_02.byte(volatile) + 1));
        }
        rxe_2 rxe_22 = rxx2.int().break(rxx2.class());
        boolean bl2 = rxe_22.class() == rxg_2.byte;
        return (xc_0)super.class(rxx2).class(final, bl2);
    }

    @Override
    public void class(rrEm rrEm2, Random random, rfH rfH2, xc_0 xc_02) {
        if (!wy_2.private(xc_02) && rrEm2.byte(rfH2.break()).class(rls.s)) {
            int n2 = 5;
            int n3 = 1;
            int n4 = 2;
            int n5 = 0;
            int n6 = rfH2.b_() - 2;
            int n7 = 0;
            for (int k = 0; k < 5; ++k) {
                for (int i2 = 0; i2 < n3; ++i2) {
                    int n8 = 2 + rfH2.c_() - 1;
                    for (int i3 = n8 - 2; i3 < n8; ++i3) {
                        xc_0 xc_03;
                        rfH rfH3 = new rfH(n6 + k, i3, rfH2.d_() - n7 + i2);
                        if (rfH3 == rfH2 || random.nextInt(6) != 0 || !rrEm2.byte(rfH3).class(xu_0.try) || !(xc_03 = rrEm2.byte(rfH3.break())).class(rls.s)) continue;
                        rrEm2.class(rfH3, (xc_0)xu_0.hr.continue().class(volatile, random.nextInt(4) + 1), 3);
                    }
                }
                if (n5 < 2) {
                    n3 += 2;
                    ++n7;
                } else {
                    n3 -= 2;
                    --n7;
                }
                ++n5;
            }
            rrEm2.class(rfH2, (xc_0)xc_02.class(volatile, 4), 2);
        }
    }

    @Override
    protected void class(rCL<xd_0, xc_0> rCL2) {
        rCL2.class(volatile, final);
    }

    @Override
    public boolean class(rRq rRq2, rfH rfH2, xc_0 xc_02, boolean bl2) {
        return true;
    }

    @Override
    public boolean class(rYB rYB2, Random random, rfH rfH2, xc_0 xc_02) {
        return true;
    }

    @Override
    public rjC class(xc_0 xc_02, rRq rRq2, rfH rfH2, rjm rjm2) {
        switch (xc_02.byte(volatile)) {
            default: {
                return package;
            }
            case 2: {
                return int;
            }
            case 3: {
                return new;
            }
            case 4: 
        }
        return continue;
    }

    @Override
    public boolean class(xc_0 xc_02, rRq rRq2, rfH rfH2, rlt_2 rlt_22) {
        return false;
    }

    @Override
    public boolean class(xc_0 xc_02, rRR rRR2, rfH rfH2) {
        rfH rfH3 = rfH2.break();
        return this.catch(rRR2.byte(rfH3), rRR2, rfH3);
    }

    @Override
    public xc_0 class(xc_0 xc_02, rpr_0 rpr_02, xc_0 xc_03, rRg rRg2, rfH rfH2, rfH rfH3) {
        if (!xc_02.class(rRg2, rfH2)) {
            return xu_0.class.continue();
        }
        if (xc_02.byte(final).booleanValue()) {
            rRg2.extends().class(rfH2, rxg_2.byte, rxg_2.byte.class(rRg2));
        }
        return super.class(xc_02, rpr_02, xc_03, rRg2, rfH2, rfH3);
    }

    @Override
    public boolean class(xc_0 xc_02, rxx rxx2) {
        return rxx2.volatile().break() == this.case() && xc_02.byte(volatile) < 4 ? true : super.class(xc_02, rxx2);
    }

    @Override
    public rxe_2 throws(xc_0 xc_02) {
        return xc_02.byte(final) != false ? rxg_2.byte.class(false) : super.throws(xc_02);
    }

    @Override
    protected boolean catch(xc_0 xc_02, rRq rRq2, rfH rfH2) {
        return !xc_02.extends(rRq2, rfH2).class(rpr_0.UP).break() || xc_02.protected(rRq2, rfH2, rpr_0.UP);
    }

    public static boolean private(xc_0 xc_02) {
        return xc_02.byte(final) == false;
    }
}

