/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.Co;
import protected.ch_0;
import protected.gm;

public class CD
extends Co {
    protected CD(gm gm2, double d, double d2, double d3, double d4, double d5, double d6, float f2, ch_0 ch_02) {
        super(gm2, d, d2, d3, 0.1f, 0.1f, 0.1f, d4, d5, d6, f2, ch_02, 0.3f, 8, 0.004, true);
    }
}

