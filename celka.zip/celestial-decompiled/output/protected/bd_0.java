/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.util.Comparator;
import protected.ib_0;
import protected.rrze_1;

/*
 * Renamed from protected.bd
 */
public interface bd_0
extends Comparator<ib_0>,
rrze_1 {
}

