/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.Y;
import protected.class;
import protected.pi_2;
import protected.pv_2;
import protected.q;
import protected.rrfk_1;
import protected.rrfp;
import protected.rrfq;
import protected.rrlh_2;
import protected.rrqj_1;
import protected.rrvu_0;
import protected.rrze_1;
import protected.rrzr_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.BZ
 */
public class bz_1
extends pv_2 {
    private static byte[] protected;
    public static Object[] break;
    private static short[] throws;
    private static String[] case;
    public Object[] byte;
    private static boolean[] catch;

    private static void byte() {
        short[] sArray = new short[14];
        sArray[1] = 1;
        sArray[2] = 4;
        sArray[6] = 1;
        sArray[7] = 4;
        sArray[11] = 5;
        throws = sArray;
    }

    public bz_1(class clazz) {
        super(clazz);
        this.protected();
    }

    static {
        bz_1.ntfClinit();
    }

    private static void class() {
        protected = new byte[]{2, 3, 4, 5};
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0x9591CDC588DF8199L;
    }

    @Override
    public void class(rrlh_2 rrlh_22) {
        Matcher matcher;
        this.protected();
        if (rrlh_22.protected() != null || (rrfq)((Object)rrfp.class[throws[6]]) != (rrfq)((Object)rrfq.staticFields8f8c034c8eef39ccbbc33e665d937d16[throws[7]])) {
            return;
        }
        if (((Boolean)this.byte[throws[8]]).booleanValue() && (matcher = ((Pattern)break[throws[9]]).matcher(rrlh_22.class())).find()) {
            String string = matcher.group(catch[4]);
            String string2 = matcher.group(protected[0]);
            String string3 = matcher.group(protected[1]);
            String string4 = matcher.group(protected[2]);
            String string5 = matcher.group(protected[3]);
            ((rrvu_0)rrvu_0.staticFields795d62f6fe74334786edf14455ec3bfd[throws[10]]).class((rrzr_1)rrqj_1.class[throws[11]], string4, string5, string3, string2, string);
            rrze_1.a_("\u0412\u044b \u0431\u044b\u043b\u0438 \u0437\u0430\u0431\u0430\u043d\u0435\u043d\u044b \u0437\u0430 " + string4, catch[5]);
            Boolean bl2 = catch[6];
            this.byte[bz_1.throws[12]] = bl2;
        }
    }

    @Override
    public void class(rrfk_1 rrfk_12) {
        this.protected();
        super.class(rrfk_12);
        Boolean bl2 = catch[7];
        this.byte[bz_1.throws[13]] = bl2;
    }

    @Override
    public void class(q q2) {
        this.protected();
        if (q2.class() == (Y)((Object)Y.staticFields22c81230f53b33f2a682b4198db24cc4[throws[0]])) {
            if ((rrfq)((Object)rrfp.class[throws[1]]) != (rrfq)((Object)rrfq.staticFields8f8c034c8eef39ccbbc33e665d937d16[throws[2]])) {
                return;
            }
            pi_2 pi_22 = ((class)this.class[throws[3]]).native().protected();
            boolean bl2 = pi_22 != null && pi_22.class().break() ? catch[0] : catch[1];
            boolean bl3 = ((class)this.class[throws[4]]).synchronized().class();
            Boolean bl4 = bl2 || bl3 ? catch[2] : catch[3];
            this.byte[bz_1.throws[5]] = bl4;
        }
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0x1EFDC891;
    }

    private static void break() {
        boolean[] blArray = new boolean[13];
        blArray[0] = true;
        blArray[2] = true;
        blArray[4] = true;
        blArray[9] = true;
        blArray[12] = true;
        catch = blArray;
    }

    public static String break(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{104, -47, 14, -121, 37, 14, -125, -37}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    private static void throws() {
        Object[] objectArray = new Object[]{Pattern.compile(case[0])};
        break = objectArray;
    }

    private static /* synthetic */ void ntfClinit() {
        bz_1.break();
        bz_1.case();
        bz_1.byte();
        bz_1.class();
        bz_1.throws();
    }

    private static void case() {
        case = new String[]{new String("\u0412\u044b \u0431\u044b\u043b\u0438 \u043a\u0438\u043a\u043d\u0443\u0442\u044b \u0441 \u0441\u0435\u0440\u0432\u0435\u0440\u0430 (.*?):[\\s\\S]*?\u0411\u0430\u043d \u0432\u044b\u0434\u0430\u043d: (.*)\\s+\u0411\u0430\u043d \u043e\u0442: (.*)\\s+\u0412\u0430\u0448 \u043d\u0438\u043a: .*\\s+\u041f\u043e \u043f\u0440\u0438\u0447\u0438\u043d\u0435: ([\\s\\S]*?)\\s+\u0420\u0430\u0437\u0431\u0430\u043d \u0447\u0435\u0440\u0435\u0437: (.*)")};
    }

    private void protected() {
        if (this.byte == null) {
            Object[] objectArray = this.byte = new Object[catch[9]];
            objectArray[bz_1.catch[10]] = catch[11];
        }
    }
}

