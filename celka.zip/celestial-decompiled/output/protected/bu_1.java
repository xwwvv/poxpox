/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.Bu
 */
public class bu_1 {
    private static byte[] break;
    private static boolean[] byte;
    public static Object[] class;

    private static void byte() {
        Object[] objectArray = new Object[1];
        int[] nArray = new int[10];
        nArray[0] = 2;
        nArray[2] = 1;
        nArray[3] = 3;
        objectArray[0] = nArray;
        bu_1.class = objectArray;
    }

    static {
        bu_1.ntfClinit();
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0x7C4BB8B48C3119FCL;
    }

    public static String class(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{25, 41, 57, -116, 57, -68, -69, -16}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0xF1C1BE58;
    }

    private static void class() {
        boolean[] blArray = new boolean[7];
        blArray[2] = true;
        blArray[6] = true;
        byte = blArray;
    }

    private static void break() {
        break = new byte[]{2, 2, 3, 3};
    }

    private static /* synthetic */ void ntfClinit() {
        bu_1.class();
        bu_1.break();
        bu_1.byte();
    }
}

