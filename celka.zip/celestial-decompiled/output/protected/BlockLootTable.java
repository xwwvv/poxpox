/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableSet
 *  com.google.common.collect.Maps
 *  com.google.common.collect.Sets
 */
package protected;

import com.google.common.collect.ImmutableSet;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Stream;
import protected.df_1;
import protected.dn_2;
import protected.do_2;
import protected.du_2;
import protected.ey_0;
import protected.hh_2;
import protected.ht_2;
import protected.js_2;
import protected.kf_1;
import protected.rCZ;
import protected.rCo;
import protected.rCp;
import protected.rcf_0;
import protected.rdb_1;
import protected.rdy_2;
import protected.rfH;
import protected.rna_2;
import protected.rni_2;
import protected.rnj_2;
import protected.rnm_1;
import protected.rnn_1;
import protected.rnp_2;
import protected.rns_1;
import protected.rns_2;
import protected.rnv_1;
import protected.rpH;
import protected.rpl_0;
import protected.rqa_1;
import protected.rql_2;
import protected.rqm_2;
import protected.rqn_1;
import protected.rqo_0;
import protected.rqo_2;
import protected.rqq_1;
import protected.rqq_2;
import protected.rqr_2;
import protected.rqt_1;
import protected.rqx_1;
import protected.rqz_1;
import protected.rvl_0;
import protected.rwa_2;
import protected.rwd_1;
import protected.rwe_1;
import protected.rwg_1;
import protected.rwj_1;
import protected.rwk_1;
import protected.rwl_2;
import protected.rwn_1;
import protected.rwq_1;
import protected.rwy_2;
import protected.rza_2;
import protected.rzb_2;
import protected.rzg_2;
import protected.rzk_1;
import protected.rzl_1;
import protected.rzl_2;
import protected.rzn_2;
import protected.rzv_1;
import protected.wd_1;
import protected.wg_1;
import protected.wp_1;
import protected.ws_2;
import protected.wy_2;
import protected.xU;
import protected.xY;
import protected.xb;
import protected.xc_2;
import protected.xd_0;
import protected.xf_2;
import protected.xh_0;
import protected.xl;
import protected.xo_0;
import protected.xu_0;
import protected.xx_2;
import protected.zo_2;
import protected.zq_2;
import protected.zz_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.Uv
 */
public class uv_0
implements Consumer<BiConsumer<rqo_0, rza_2>> {
    private static final rqq_2 class = rql_2.class(xx_2.class().class(new ht_2(ey_0.else, xf_2.break(1))));
    private static final rqq_2 break = uv_0.class.class();
    private static final rqq_2 byte = rql_2.class(xx_2.class().class(rdy_2.JJ));
    private static final rqq_2 protected = byte.class(uv_0.class);
    private static final rqq_2 throws = protected.class();
    private static final Set<rdb_1> case = (Set)Stream.of(xu_0.SX, xu_0.Sv, xu_0.hB, xu_0.sM, xu_0.sh, xu_0.sd, xu_0.sJ, xu_0.sW, xu_0.sQ, xu_0.bD, xu_0.MX, xu_0.Mb, xu_0.MM, xu_0.ME, xu_0.MS, xu_0.MO, xu_0.bi, xu_0.Ms, xu_0.MP, xu_0.ba, xu_0.be, xu_0.MB, xu_0.MG, xu_0.Mh, xu_0.bU, xu_0.Mr).map(rpl_0::case).collect(ImmutableSet.toImmutableSet());
    private static final float[] catch = new float[]{0.05f, 0.0625f, 0.083333336f, 0.1f};
    private static final float[] private = new float[]{0.025f, 0.027777778f, 0.03125f, 0.041666668f, 0.1f};
    private final Map<rqo_0, rza_2> implements = Maps.newHashMap();

    public void byte(xd_0 xd_02) {
        this.class(xd_02, xd_02);
    }

    private static rza_2 byte(xd_0 xd_02, rpl_0 rpl_02) {
        return uv_0.class(xd_02, (rzg_2)uv_0.class((rpl_0)xd_02, ((rzk_1)rwe_1.class(rpl_02).break(rnv_1.class(rzv_1.class(-6.0f, 2.0f)))).break(rnn_1.class(rwd_1.class(0)))));
    }

    private void byte(xd_0 xd_02, xd_0 xd_03) {
        rza_2 rza_22 = uv_0.byte(xd_02, rwe_1.class(xd_02).break(rqt_1.class(ey_0.return, 0.33f, 0.55f, 0.77f, 1.0f)));
        this.class(xd_02, rza_22);
        this.class(xd_03, rza_22);
    }

    private static rza_2 byte(xd_0 xd_02, rdb_1 rdb_12) {
        return rzl_2.break().class(uv_0.class((rpl_0)xd_02, rzn_2.class().class(rwy_2.class(1)).class((rzg_2<?>)rwe_1.class(rdb_12).break(rnv_1.class(rwn_1.class(3, 0.53333336f))))));
    }

    private static rza_2 byte(rpl_0 rpl_02) {
        return rzl_2.break().class(uv_0.class((rpl_0)xu_0.SA, rzn_2.class().class(rwy_2.class(1)).class(rwe_1.class(xu_0.SA)))).class(uv_0.class(rpl_02, rzn_2.class().class(rwy_2.class(1)).class(rwe_1.class(rpl_02))));
    }

    private static rza_2 byte(xd_0 xd_02, rzg_2<?> rzg_22) {
        return uv_0.class(xd_02, protected, rzg_22);
    }

    private static rza_2 class(xd_0 xd_02, xd_0 xd_03, float ... fArray) {
        return uv_0.byte(xd_02, ((rzk_1)uv_0.class((rpl_0)xd_02, rwe_1.class(xd_03))).break(rqt_1.class(ey_0.return, fArray))).class(rzn_2.class().class(rwy_2.class(1)).break(throws).class((rzg_2<?>)((rzk_1)uv_0.class((rpl_0)xd_02, rwe_1.class(rdy_2.OD).break(rnv_1.class(rzv_1.class(1.0f, 2.0f))))).break(rqt_1.class(ey_0.return, 0.02f, 0.022222223f, 0.025f, 0.033333335f, 0.1f))));
    }

    private static rza_2 class(xd_0 xd_02, rzg_2<?> rzg_22) {
        return uv_0.class(xd_02, uv_0.class, rzg_22);
    }

    private void class(xd_0 xd_02, rza_2 rza_22) {
        this.implements.put(xd_02.throws(), rza_22);
    }

    private static rza_2 class(xd_0 xd_02, rdb_1 rdb_12, rdb_1 rdb_13, rqq_2 rqq_22) {
        return uv_0.class((rpl_0)xd_02, rzl_2.break().class(rzn_2.class().class(((rzk_1)rwe_1.class(rdb_12).break(rqq_22)).class(rwe_1.class(rdb_13)))).class(rzn_2.class().break(rqq_22).class((rzg_2<?>)rwe_1.class(rdb_13).break(rqr_2.class(ey_0.return, 0.5714286f, 3)))));
    }

    private static rza_2 class(xd_0 xd_02, rdb_1 rdb_12) {
        return uv_0.class(xd_02, (rzg_2)uv_0.class((rpl_0)xd_02, rwe_1.class(rdb_12).break(rqr_2.class(ey_0.return))));
    }

    private static <T> T class(rpl_0 rpl_02, rwg_1<T> rwg_12) {
        return !case.contains(rpl_02.case()) ? rwg_12.class(rnm_1.byte()) : rwg_12.protected();
    }

    private static <T> T class(rpl_0 rpl_02, rwj_1<T> rwj_12) {
        return !case.contains(rpl_02.case()) ? rwj_12.class(rqq_1.byte()) : rwj_12.protected();
    }

    private static <T extends Comparable<T> & rpH> rza_2 class(xd_0 xd_02, rCZ<T> rCZ2, T t2) {
        return rzl_2.break().class(uv_0.class((rpl_0)xd_02, rzn_2.class().class(rwy_2.class(1)).class((rzg_2<?>)rwe_1.class(xd_02).break(rqm_2.class(xd_02).class(js_2.class().class(rCZ2, t2))))));
    }

    private static rza_2 class(xd_0 xd_02, rqq_2 rqq_22, rzg_2<?> rzg_22) {
        return rzl_2.break().class(rzn_2.class().class(rwy_2.class(1)).class(((rzk_1)rwe_1.class(xd_02).break(rqq_22)).class(rzg_22)));
    }

    public void class(BiConsumer<rqo_0, rza_2> biConsumer) {
        this.protected(xu_0.byte);
        this.protected(xu_0.protected);
        this.protected(xu_0.throws);
        this.protected(xu_0.case);
        this.protected(xu_0.catch);
        this.protected(xu_0.private);
        this.protected(xu_0.finally);
        this.protected(xu_0.extends);
        this.protected(xu_0.volatile);
        this.protected(xu_0.final);
        this.protected(xu_0.package);
        this.protected(xu_0.int);
        this.protected(xu_0.new);
        this.protected(xu_0.continue);
        this.protected(xu_0.super);
        this.protected(xu_0.this);
        this.protected(xu_0.else);
        this.protected(xu_0.synchronized);
        this.protected(xu_0.return);
        this.protected(xu_0.public);
        this.protected(xu_0.goto);
        this.protected(xu_0.throw);
        this.protected(xu_0.interface);
        this.protected(xu_0.abstract);
        this.protected(xu_0.long);
        this.protected(xu_0.static);
        this.protected(xu_0.import);
        this.protected(xu_0.short);
        this.protected(xu_0.default);
        this.protected(xu_0.const);
        this.protected(xu_0.strictfp);
        this.protected(xu_0.boolean);
        this.protected(xu_0.transient);
        this.protected(xu_0.for);
        this.protected(xu_0.double);
        this.protected(xu_0.switch);
        this.protected(xu_0.r);
        this.protected(xu_0.Xd);
        this.protected(xu_0.XZ);
        this.protected(xu_0.P);
        this.protected(xu_0.B);
        this.protected(xu_0.S);
        this.protected(xu_0.s);
        this.protected(xu_0.E);
        this.protected(xu_0.G);
        this.protected(xu_0.b);
        this.protected(xu_0.M);
        this.protected(xu_0.O);
        this.protected(xu_0.h);
        this.protected(xu_0.X);
        this.protected(xu_0.J);
        this.protected(xu_0.XF);
        this.protected(xu_0.XW);
        this.protected(xu_0.N);
        this.protected(xu_0.c);
        this.protected(xu_0.Z);
        this.protected(xu_0.F);
        this.protected(xu_0.L);
        this.protected(xu_0.A);
        this.protected(xu_0.n);
        this.protected(xu_0.o);
        this.protected(xu_0.K);
        this.protected(xu_0.D);
        this.protected(xu_0.rB);
        this.protected(xu_0.rs);
        this.protected(xu_0.rE);
        this.protected(xu_0.rG);
        this.protected(xu_0.rb);
        this.protected(xu_0.rM);
        this.protected(xu_0.rO);
        this.protected(xu_0.rh);
        this.protected(xu_0.rX);
        this.protected(xu_0.rJ);
        this.protected(xu_0.rx);
        this.protected(xu_0.rd);
        this.protected(xu_0.rk);
        this.protected(xu_0.rW);
        this.protected(xu_0.rz);
        this.protected(xu_0.rQ);
        this.protected(xu_0.rN);
        this.protected(xu_0.ru);
        this.protected(xu_0.rm);
        this.protected(xu_0.rZ);
        this.protected(xu_0.rv);
        this.protected(xu_0.rF);
        this.protected(xu_0.rL);
        this.protected(xu_0.rA);
        this.protected(xu_0.rn);
        this.protected(xu_0.rC);
        this.protected(xu_0.rl);
        this.protected(xu_0.rH);
        this.protected(xu_0.ry);
        this.protected(xu_0.rp);
        this.protected(xu_0.rq);
        this.protected(xu_0.rT);
        this.protected(xu_0.rt);
        this.protected(xu_0.rw);
        this.protected(xu_0.rI);
        this.protected(xu_0.rV);
        this.protected(xu_0.rg);
        this.protected(xu_0.Jd);
        this.protected(xu_0.rR);
        this.protected(xu_0.rU);
        this.protected(xu_0.ra);
        this.protected(xu_0.Pr);
        this.protected(xu_0.PP);
        this.protected(xu_0.PE);
        this.protected(xu_0.PG);
        this.protected(xu_0.Pb);
        this.protected(xu_0.PM);
        this.protected(xu_0.PO);
        this.protected(xu_0.Ph);
        this.protected(xu_0.PJ);
        this.protected(xu_0.Px);
        this.protected(xu_0.Pd);
        this.protected(xu_0.Pu);
        this.protected(xu_0.Pm);
        this.protected(xu_0.Pv);
        this.protected(xu_0.PF);
        this.protected(xu_0.PL);
        this.protected(xu_0.PA);
        this.protected(xu_0.Pn);
        this.protected(xu_0.PC);
        this.protected(xu_0.PH);
        this.protected(xu_0.Pp);
        this.protected(xu_0.Pw);
        this.protected(xu_0.Pf);
        this.protected(xu_0.Pj);
        this.protected(xu_0.PV);
        this.protected(xu_0.Pg);
        this.protected(xu_0.PR);
        this.protected(xu_0.PY);
        this.protected(xu_0.Po);
        this.protected(xu_0.PK);
        this.protected(xu_0.PD);
        this.protected(xu_0.PU);
        this.protected(xu_0.Br);
        this.protected(xu_0.BP);
        this.protected(xu_0.BS);
        this.protected(xu_0.Bc);
        this.protected(xu_0.Bu);
        this.protected(xu_0.Bm);
        this.protected(xu_0.BZ);
        this.protected(xu_0.Bv);
        this.protected(xu_0.BF);
        this.protected(xu_0.BL);
        this.protected(xu_0.BA);
        this.protected(xu_0.Bn);
        this.protected(xu_0.BC);
        this.protected(xu_0.Bf);
        this.protected(xu_0.BU);
        this.protected(xu_0.Be);
        this.protected(xu_0.Ba);
        this.protected(xu_0.Sr);
        this.protected(xu_0.SP);
        this.protected(xu_0.SB);
        this.protected(xu_0.SS);
        this.protected(xu_0.Sb);
        this.protected(xu_0.Sh);
        this.protected(xu_0.SJ);
        this.protected(xu_0.Sd);
        this.protected(xu_0.Sz);
        this.protected(xu_0.SN);
        this.protected(xu_0.Sc);
        this.protected(xu_0.Su);
        this.protected(xu_0.Sm);
        this.protected(xu_0.SF);
        this.protected(xu_0.SL);
        this.protected(xu_0.SA);
        this.protected(xu_0.sB);
        this.protected(xu_0.sS);
        this.protected(xu_0.ss);
        this.protected(xu_0.sE);
        this.protected(xu_0.sG);
        this.protected(xu_0.sb);
        this.protected(xu_0.sM);
        this.protected(xu_0.sh);
        this.protected(xu_0.sJ);
        this.protected(xu_0.sW);
        this.protected(xu_0.sQ);
        this.protected(xu_0.sc);
        this.protected(xu_0.su);
        this.protected(xu_0.sm);
        this.protected(xu_0.sv);
        this.protected(xu_0.sF);
        this.protected(xu_0.sL);
        this.protected(xu_0.sA);
        this.protected(xu_0.sn);
        this.protected(xu_0.sH);
        this.protected(xu_0.sy);
        this.protected(xu_0.sp);
        this.protected(xu_0.sq);
        this.protected(xu_0.sT);
        this.protected(xu_0.sw);
        this.protected(xu_0.sI);
        this.protected(xu_0.sf);
        this.protected(xu_0.sj);
        this.protected(xu_0.sV);
        this.protected(xu_0.sg);
        this.protected(xu_0.sR);
        this.protected(xu_0.sY);
        this.protected(xu_0.so);
        this.protected(xu_0.sK);
        this.protected(xu_0.sD);
        this.protected(xu_0.sU);
        this.protected(xu_0.se);
        this.protected(xu_0.sa);
        this.protected(xu_0.si);
        this.protected(xu_0.Er);
        this.protected(xu_0.Ez);
        this.protected(xu_0.EQ);
        this.protected(xu_0.EN);
        this.protected(xu_0.Eu);
        this.protected(xu_0.Em);
        this.protected(xu_0.EZ);
        this.protected(xu_0.Ev);
        this.protected(xu_0.EF);
        this.protected(xu_0.EL);
        this.protected(xu_0.EA);
        this.protected(xu_0.Ey);
        this.protected(xu_0.Ep);
        this.protected(xu_0.Eq);
        this.protected(xu_0.ET);
        this.protected(xu_0.Et);
        this.protected(xu_0.Ew);
        this.protected(xu_0.EI);
        this.protected(xu_0.Ef);
        this.protected(xu_0.Ej);
        this.protected(xu_0.EV);
        this.protected(xu_0.Eg);
        this.protected(xu_0.ER);
        this.protected(xu_0.EY);
        this.protected(xu_0.Eo);
        this.protected(xu_0.EK);
        this.protected(xu_0.ED);
        this.protected(xu_0.EU);
        this.protected(xu_0.Ee);
        this.protected(xu_0.Ea);
        this.protected(xu_0.GI);
        this.protected(xu_0.Gf);
        this.protected(xu_0.Gj);
        this.protected(xu_0.GV);
        this.protected(xu_0.bO);
        this.protected(xu_0.bh);
        this.protected(xu_0.bX);
        this.protected(xu_0.bJ);
        this.protected(xu_0.bx);
        this.protected(xu_0.bd);
        this.protected(xu_0.bk);
        this.protected(xu_0.bW);
        this.protected(xu_0.bz);
        this.protected(xu_0.bQ);
        this.protected(xu_0.bN);
        this.protected(xu_0.bc);
        this.protected(xu_0.bu);
        this.protected(xu_0.bm);
        this.protected(xu_0.bn);
        this.protected(xu_0.bH);
        this.protected(xu_0.by);
        this.protected(xu_0.bp);
        this.protected(xu_0.bq);
        this.protected(xu_0.bV);
        this.protected(xu_0.bg);
        this.protected(xu_0.bR);
        this.protected(xu_0.bY);
        this.protected(xu_0.bK);
        this.protected(xu_0.Jb);
        this.protected(xu_0.MJ);
        this.protected(xu_0.Mx);
        this.protected(xu_0.Md);
        this.protected(xu_0.Mk);
        this.protected(xu_0.MW);
        this.protected(xu_0.Mz);
        this.protected(xu_0.MQ);
        this.protected(xu_0.MN);
        this.protected(xu_0.Mc);
        this.protected(xu_0.Mu);
        this.protected(xu_0.Mm);
        this.protected(xu_0.MZ);
        this.protected(xu_0.Mv);
        this.protected(xu_0.MF);
        this.protected(xu_0.ML);
        this.protected(xu_0.MA);
        this.protected(xu_0.Mn);
        this.protected(xu_0.MC);
        this.protected(xu_0.Ml);
        this.protected(xu_0.MH);
        this.protected(xu_0.My);
        this.protected(xu_0.Mp);
        this.protected(xu_0.Mq);
        this.protected(xu_0.MT);
        this.protected(xu_0.Mt);
        this.protected(xu_0.Mw);
        this.protected(xu_0.MI);
        this.protected(xu_0.Mf);
        this.protected(xu_0.Mj);
        this.protected(xu_0.MV);
        this.protected(xu_0.Mg);
        this.protected(xu_0.MR);
        this.protected(xu_0.MY);
        this.protected(xu_0.Mo);
        this.protected(xu_0.MK);
        this.protected(xu_0.MD);
        this.protected(xu_0.MU);
        this.protected(xu_0.Me);
        this.protected(xu_0.Ma);
        this.protected(xu_0.Mi);
        this.protected(xu_0.Or);
        this.protected(xu_0.OP);
        this.protected(xu_0.OB);
        this.protected(xu_0.OS);
        this.protected(xu_0.Os);
        this.protected(xu_0.OE);
        this.protected(xu_0.OG);
        this.protected(xu_0.Ob);
        this.protected(xu_0.OM);
        this.protected(xu_0.Oh);
        this.protected(xu_0.OJ);
        this.protected(xu_0.Ox);
        this.protected(xu_0.Od);
        this.protected(xu_0.Ok);
        this.protected(xu_0.OW);
        this.protected(xu_0.hB);
        this.protected(xu_0.SX);
        this.protected(xu_0.hs);
        this.protected(xu_0.hO);
        this.protected(xu_0.hh);
        this.protected(xu_0.hX);
        this.protected(xu_0.hJ);
        this.protected(xu_0.hx);
        this.protected(xu_0.hd);
        this.protected(xu_0.hk);
        this.protected(xu_0.hW);
        this.protected(xu_0.hz);
        this.protected(xu_0.hQ);
        this.protected(xu_0.hN);
        this.protected(xu_0.hc);
        this.protected(xu_0.hu);
        this.protected(xu_0.hm);
        this.protected(xu_0.ht);
        this.protected(xu_0.hw);
        this.protected(xu_0.hI);
        this.protected(xu_0.hf);
        this.protected(xu_0.hj);
        this.protected(xu_0.hV);
        this.protected(xu_0.hg);
        this.protected(xu_0.hR);
        this.protected(xu_0.hY);
        this.protected(xu_0.ho);
        this.protected(xu_0.hK);
        this.protected(xu_0.hD);
        this.protected(xu_0.he);
        this.protected(xu_0.hU);
        this.protected(xu_0.Jh);
        this.protected(xu_0.JX);
        this.protected(xu_0.Jk);
        this.protected(xu_0.Jc);
        this.protected(xu_0.Xx);
        this.protected(xu_0.Xk);
        this.protected(xu_0.XQ);
        this.protected(xu_0.XN);
        this.protected(xu_0.Xm);
        this.protected(xu_0.Xv);
        this.protected(xu_0.XA);
        this.protected(xu_0.Xn);
        this.protected(xu_0.Xq);
        this.protected(xu_0.XT);
        this.protected(xu_0.Xf);
        this.protected(xu_0.XV);
        this.protected(xu_0.XR);
        this.protected(xu_0.Xo);
        this.protected(xu_0.XD);
        this.protected(xu_0.Xe);
        this.protected(xu_0.JP);
        this.protected(xu_0.XI);
        this.protected(xu_0.Xj);
        this.protected(xu_0.Xg);
        this.protected(xu_0.XY);
        this.protected(xu_0.XK);
        this.protected(xu_0.XU);
        this.protected(xu_0.Jr);
        this.protected(xu_0.JJ);
        this.protected(xu_0.Jx);
        this.protected(xu_0.Ju);
        this.protected(xu_0.JL);
        this.protected(xu_0.Jl);
        this.protected(xu_0.Jm);
        this.protected(xu_0.JZ);
        this.protected(xu_0.JH);
        this.protected(xu_0.Jn);
        this.protected(xu_0.JA);
        this.protected(xu_0.JF);
        this.protected(xu_0.Jp);
        this.protected(xu_0.JT);
        this.protected(xu_0.Jt);
        this.protected(xu_0.Jw);
        this.protected(xu_0.JI);
        this.protected(xu_0.Jf);
        this.protected(xu_0.Jj);
        this.protected(xu_0.Bj);
        this.protected(xu_0.Xc);
        this.protected(xu_0.Xp);
        this.class(xu_0.PS, (rpl_0)xu_0.finally);
        this.class(xu_0.SQ, rdy_2.Oa);
        this.class(xu_0.bt, (rpl_0)xu_0.finally);
        this.class(xu_0.OO, (rpl_0)xu_0.OM);
        this.class(xu_0.hS, (rpl_0)xu_0.hs);
        this.class(xu_0.break, (xd_0 xd_02) -> uv_0.break(xd_02, (rpl_0)xu_0.volatile));
        this.class(xu_0.implements, (xd_0 xd_02) -> uv_0.break(xd_02, (rpl_0)xu_0.finally));
        this.class(xu_0.native, (xd_0 xd_02) -> uv_0.break(xd_02, (rpl_0)xu_0.finally));
        this.class(xu_0.Bi, (xd_0 xd_02) -> uv_0.break(xd_02, (rpl_0)xu_0.finally));
        this.class(xu_0.Oz, (xd_0 xd_02) -> uv_0.break(xd_02, (rpl_0)xu_0.OJ));
        this.class(xu_0.OQ, (xd_0 xd_02) -> uv_0.break(xd_02, (rpl_0)xu_0.Ox));
        this.class(xu_0.ON, (xd_0 xd_02) -> uv_0.break(xd_02, (rpl_0)xu_0.Od));
        this.class(xu_0.Oc, (xd_0 xd_02) -> uv_0.break(xd_02, (rpl_0)xu_0.Ok));
        this.class(xu_0.Ou, (xd_0 xd_02) -> uv_0.break(xd_02, (rpl_0)xu_0.OW));
        this.class(xu_0.XL, (xd_0 xd_02) -> uv_0.break(xd_02, (rpl_0)xu_0.PR));
        this.class(xu_0.Xz, (xd_0 xd_02) -> uv_0.break(xd_02, (rpl_0)xu_0.PR));
        this.class(xu_0.rj, (xd_0 xd_02) -> uv_0.class(xd_02, rdy_2.XM, rwy_2.class(3)));
        this.class(xu_0.PI, (xd_0 xd_02) -> uv_0.class(xd_02, rdy_2.XE, rwy_2.class(4)));
        this.class(xu_0.SW, (xd_0 xd_02) -> uv_0.class(xd_02, (rpl_0)xu_0.rg, rwy_2.class(8)));
        this.class(xu_0.Pt, (xd_0 xd_02) -> uv_0.class(xd_02, rdy_2.hU, rwy_2.class(4)));
        this.class(xu_0.bC, uv_0.class((rpl_0)rdy_2.kO, rzv_1.class(0.0f, 1.0f)));
        this.break(xu_0.Sn);
        this.break(xu_0.SC);
        this.break(xu_0.Sl);
        this.break(xu_0.SH);
        this.break(xu_0.Sy);
        this.break(xu_0.Sp);
        this.break(xu_0.Sq);
        this.break(xu_0.ST);
        this.break(xu_0.St);
        this.break(xu_0.Sw);
        this.break(xu_0.SI);
        this.break(xu_0.Sf);
        this.break(xu_0.Sj);
        this.break(xu_0.SV);
        this.break(xu_0.Sg);
        this.break(xu_0.SR);
        this.break(xu_0.SY);
        this.break(xu_0.So);
        this.break(xu_0.SK);
        this.break(xu_0.SD);
        this.break(xu_0.SU);
        this.break(xu_0.Se);
        this.break(xu_0.Sa);
        this.break(xu_0.Si);
        this.break(xu_0.hE);
        this.break(xu_0.JW);
        this.break(xu_0.Jz);
        this.break(xu_0.JQ);
        this.break(xu_0.JN);
        this.class(xu_0.GK, uv_0::throws);
        this.class(xu_0.GY, uv_0::throws);
        this.class(xu_0.bB, uv_0::throws);
        this.class(xu_0.bP, uv_0::throws);
        this.class(xu_0.GD, uv_0::throws);
        this.class(xu_0.El, uv_0::throws);
        this.class(xu_0.Go, uv_0::throws);
        this.class(xu_0.bs, uv_0::throws);
        this.class(xu_0.Gg, uv_0::throws);
        this.class(xu_0.br, uv_0::throws);
        this.class(xu_0.EC, uv_0::throws);
        this.class(xu_0.En, uv_0::throws);
        this.class(xu_0.bM, uv_0::throws);
        this.class(xu_0.bE, uv_0::throws);
        this.class(xu_0.bG, uv_0::throws);
        this.class(xu_0.Ga, uv_0::throws);
        this.class(xu_0.bb, uv_0::throws);
        this.class(xu_0.Gi, uv_0::throws);
        this.class(xu_0.GR, uv_0::throws);
        this.class(xu_0.bS, uv_0::throws);
        this.class(xu_0.GU, uv_0::throws);
        this.class(xu_0.Ge, uv_0::throws);
        this.class(xu_0.hZ, uv_0::throws);
        this.class(xu_0.hv, uv_0::throws);
        this.class(xu_0.hF, uv_0::throws);
        this.class(xu_0.hL, uv_0::throws);
        this.class(xu_0.hA, uv_0::throws);
        this.class(xu_0.hn, uv_0::throws);
        this.class(xu_0.hC, uv_0::throws);
        this.class(xu_0.hl, uv_0::throws);
        this.class(xu_0.hH, uv_0::throws);
        this.class(xu_0.hy, uv_0::throws);
        this.class(xu_0.hp, uv_0::throws);
        this.class(xu_0.hq, uv_0::throws);
        this.class(xu_0.hT, uv_0::throws);
        this.class(xu_0.Xt, uv_0::throws);
        this.class(xu_0.Xw, uv_0::throws);
        this.class(xu_0.Jv, uv_0::throws);
        this.class(xu_0.JC, uv_0::throws);
        this.class(xu_0.Jq, uv_0::throws);
        this.class(xu_0.bL, uv_0::class);
        this.class(xu_0.bv, uv_0::class);
        this.class(xu_0.bA, uv_0::class);
        this.class(xu_0.PZ, uv_0::class);
        this.class(xu_0.bF, uv_0::class);
        this.class(xu_0.PX, uv_0::class);
        this.class(xu_0.bZ, uv_0::class);
        this.class(xu_0.Xi, uv_0::class);
        this.class(xu_0.Xa, uv_0::class);
        this.class(xu_0.Y, (xd_0 xd_02) -> uv_0.class(xd_02, xb.volatile, rCp.HEAD));
        this.class(xu_0.j, (xd_0 xd_02) -> uv_0.class(xd_02, xb.volatile, rCp.HEAD));
        this.class(xu_0.V, (xd_0 xd_02) -> uv_0.class(xd_02, xb.volatile, rCp.HEAD));
        this.class(xu_0.I, (xd_0 xd_02) -> uv_0.class(xd_02, xb.volatile, rCp.HEAD));
        this.class(xu_0.t, (xd_0 xd_02) -> uv_0.class(xd_02, xb.volatile, rCp.HEAD));
        this.class(xu_0.g, (xd_0 xd_02) -> uv_0.class(xd_02, xb.volatile, rCp.HEAD));
        this.class(xu_0.y, (xd_0 xd_02) -> uv_0.class(xd_02, xb.volatile, rCp.HEAD));
        this.class(xu_0.w, (xd_0 xd_02) -> uv_0.class(xd_02, xb.volatile, rCp.HEAD));
        this.class(xu_0.q, (xd_0 xd_02) -> uv_0.class(xd_02, xb.volatile, rCp.HEAD));
        this.class(xu_0.H, (xd_0 xd_02) -> uv_0.class(xd_02, xb.volatile, rCp.HEAD));
        this.class(xu_0.f, (xd_0 xd_02) -> uv_0.class(xd_02, xb.volatile, rCp.HEAD));
        this.class(xu_0.l, (xd_0 xd_02) -> uv_0.class(xd_02, xb.volatile, rCp.HEAD));
        this.class(xu_0.T, (xd_0 xd_02) -> uv_0.class(xd_02, xb.volatile, rCp.HEAD));
        this.class(xu_0.R, (xd_0 xd_02) -> uv_0.class(xd_02, xb.volatile, rCp.HEAD));
        this.class(xu_0.C, (xd_0 xd_02) -> uv_0.class(xd_02, xb.volatile, rCp.HEAD));
        this.class(xu_0.p, (xd_0 xd_02) -> uv_0.class(xd_02, xb.volatile, rCp.HEAD));
        this.class(xu_0.GP, (xd_0 xd_02) -> uv_0.class(xd_02, du_2.volatile, rcf_0.LOWER));
        this.class(xu_0.Gr, (xd_0 xd_02) -> uv_0.class(xd_02, du_2.volatile, rcf_0.LOWER));
        this.class(xu_0.GS, (xd_0 xd_02) -> uv_0.class(xd_02, du_2.volatile, rcf_0.LOWER));
        this.class(xu_0.GB, (xd_0 xd_02) -> uv_0.class(xd_02, du_2.volatile, rcf_0.LOWER));
        this.class(xu_0.rf, rzl_2.break().class(uv_0.class((rpl_0)xu_0.rf, rzn_2.class().class(rwy_2.class(1)).class((rzg_2<?>)rwe_1.class(xu_0.rf).break(rqm_2.class(xu_0.rf).class(js_2.class().class(zq_2.volatile, false)))))));
        this.class(xu_0.Sx, (xd_0 xd_02) -> rzl_2.break().class(rzn_2.class().class(rwy_2.class(1)).class((rzg_2)uv_0.class((rpl_0)xd_02, rwe_1.class(rdy_2.Xv).break((rna_2)rnv_1.class(rwy_2.class(3)).break(rqm_2.class(xd_02).class(js_2.class().class(xY.volatile, 2))))))));
        this.class(xu_0.hr, (xd_0 xd_02) -> rzl_2.break().class(rzn_2.class().class(rwy_2.class(1)).class((rzg_2)uv_0.class((rpl_0)xu_0.hr, ((rzk_1)((rzk_1)rwe_1.class(xd_02).break((rna_2)rnv_1.class(rwy_2.class(2)).break(rqm_2.class(xd_02).class(js_2.class().class(wy_2.volatile, 2))))).break((rna_2)rnv_1.class(rwy_2.class(3)).break(rqm_2.class(xd_02).class(js_2.class().class(wy_2.volatile, 3))))).break((rna_2)rnv_1.class(rwy_2.class(4)).break(rqm_2.class(xd_02).class(js_2.class().class(wy_2.volatile, 4))))))));
        this.class(xu_0.JG, (xd_0 xd_02) -> rzl_2.break().class(rzn_2.class().class((rzg_2)uv_0.class((rpl_0)xd_02, rwe_1.class(rdy_2.WE)))).class(rzn_2.class().class(rwe_1.class(rdy_2.Xg)).break(rqm_2.class(xd_02).class(js_2.class().class(xU.volatile, 8)))));
        this.class(xu_0.Sv, uv_0::case);
        this.class(xu_0.SG, uv_0::case);
        this.class(xu_0.re, uv_0::case);
        this.class(xu_0.v, uv_0::case);
        this.class(xu_0.st, uv_0::case);
        this.class(xu_0.SE, uv_0::case);
        this.class(xu_0.Ps, uv_0::case);
        this.class(xu_0.sl, uv_0::case);
        this.class(xu_0.sZ, uv_0::case);
        this.class(xu_0.hi, uv_0::case);
        this.class(xu_0.Xr, uv_0::case);
        this.class(xu_0.ha, uv_0::case);
        this.class(xu_0.XP, uv_0::case);
        this.class(xu_0.XB, uv_0::case);
        this.class(xu_0.XS, uv_0::case);
        this.class(xu_0.Xs, uv_0::case);
        this.class(xu_0.XE, uv_0::case);
        this.class(xu_0.XG, uv_0::case);
        this.class(xu_0.Xb, uv_0::class);
        this.class(xu_0.XM, uv_0::class);
        this.class(xu_0.XO, uv_0::class);
        this.class(xu_0.bD, uv_0::catch);
        this.class(xu_0.MX, uv_0::catch);
        this.class(xu_0.Mb, uv_0::catch);
        this.class(xu_0.MM, uv_0::catch);
        this.class(xu_0.ME, uv_0::catch);
        this.class(xu_0.MS, uv_0::catch);
        this.class(xu_0.MO, uv_0::catch);
        this.class(xu_0.bi, uv_0::catch);
        this.class(xu_0.Ms, uv_0::catch);
        this.class(xu_0.MP, uv_0::catch);
        this.class(xu_0.ba, uv_0::catch);
        this.class(xu_0.be, uv_0::catch);
        this.class(xu_0.MB, uv_0::catch);
        this.class(xu_0.MG, uv_0::catch);
        this.class(xu_0.Mh, uv_0::catch);
        this.class(xu_0.bU, uv_0::catch);
        this.class(xu_0.Mr, uv_0::catch);
        this.class(xu_0.Gu, uv_0::private);
        this.class(xu_0.Gz, uv_0::private);
        this.class(xu_0.GQ, uv_0::private);
        this.class(xu_0.Gk, uv_0::private);
        this.class(xu_0.Gx, uv_0::private);
        this.class(xu_0.GN, uv_0::private);
        this.class(xu_0.GO, uv_0::private);
        this.class(xu_0.Gd, uv_0::private);
        this.class(xu_0.GX, uv_0::private);
        this.class(xu_0.GM, uv_0::private);
        this.class(xu_0.Gb, uv_0::private);
        this.class(xu_0.GJ, uv_0::private);
        this.class(xu_0.GW, uv_0::private);
        this.class(xu_0.Gc, uv_0::private);
        this.class(xu_0.GG, uv_0::private);
        this.class(xu_0.Gh, uv_0::private);
        this.class(xu_0.sd, (xd_0 xd_02) -> rzl_2.break().class(uv_0.class((rpl_0)xd_02, rzn_2.class().class(rwy_2.class(1)).class((rzg_2<?>)rwe_1.class(xd_02).break(rns_1.class(rnj_2.BLOCK_ENTITY).class("SkullOwner", "SkullOwner"))))));
        this.class(xu_0.JM, uv_0::implements);
        this.class(xu_0.JO, uv_0::finally);
        this.class(xu_0.k, (xd_0 xd_02) -> uv_0.class(xd_02, xu_0.synchronized, catch));
        this.class(xu_0.z, (xd_0 xd_02) -> uv_0.class(xd_02, xu_0.public, catch));
        this.class(xu_0.W, (xd_0 xd_02) -> uv_0.class(xd_02, xu_0.return, private));
        this.class(xu_0.d, (xd_0 xd_02) -> uv_0.class(xd_02, xu_0.else, catch));
        this.class(xu_0.x, (xd_0 xd_02) -> uv_0.break(xd_02, xu_0.this, catch));
        this.class(xu_0.Q, (xd_0 xd_02) -> uv_0.break(xd_02, xu_0.goto, catch));
        rqo_2 rqo_22 = rqm_2.class(xu_0.bT).class(js_2.class().class(xh_0.volatile, 3));
        this.class(xu_0.bT, uv_0.class(xu_0.bT, rdy_2.kX, rdy_2.kJ, rqo_22));
        rqo_2 rqo_23 = rqm_2.class(xu_0.PB).class(js_2.class().class(do_2.final, 7));
        this.class(xu_0.PB, uv_0.class(xu_0.PB, rdy_2.hB, rdy_2.hP, rqo_23));
        rqo_2 rqo_24 = rqm_2.class(xu_0.sr).class(js_2.class().class(xl.final, 7));
        this.class(xu_0.sr, uv_0.class((rpl_0)xu_0.sr, rzl_2.break().class(rzn_2.class().class(rwe_1.class(rdy_2.ds))).class(rzn_2.class().break(rqo_24).class((rzg_2<?>)rwe_1.class(rdy_2.ds).break(rqr_2.class(ey_0.return, 0.5714286f, 3))))));
        rqo_2 rqo_25 = rqm_2.class(xu_0.sP).class(js_2.class().class(ws_2.final, 7));
        this.class(xu_0.sP, uv_0.class((rpl_0)xu_0.sP, rzl_2.break().class(rzn_2.class().class(rwe_1.class(rdy_2.dE))).class(rzn_2.class().break(rqo_25).class((rzg_2<?>)rwe_1.class(rdy_2.dE).break(rqr_2.class(ey_0.return, 0.5714286f, 3)))).class(rzn_2.class().break(rqo_25).class((rzg_2<?>)rwe_1.class(rdy_2.db).break(rqn_1.class(0.02f))))));
        this.class(xu_0.XJ, (xd_0 xd_02) -> uv_0.class((rpl_0)xd_02, rzl_2.break().class(rzn_2.class().break(rqm_2.class(xu_0.XJ).class(js_2.class().class(zz_2.volatile, 3))).class(rwe_1.class(rdy_2.WQ)).break(rnv_1.class(rzv_1.class(2.0f, 3.0f))).break(rqr_2.break(ey_0.return))).class(rzn_2.class().break(rqm_2.class(xu_0.XJ).class(js_2.class().class(zz_2.volatile, 2))).class(rwe_1.class(rdy_2.WQ)).break(rnv_1.class(rzv_1.class(1.0f, 2.0f))).break(rqr_2.break(ey_0.return)))));
        this.class(xu_0.Bt, (xd_0 xd_02) -> uv_0.byte(xd_02, xu_0.rq));
        this.class(xu_0.Bw, (xd_0 xd_02) -> uv_0.byte(xd_02, xu_0.rT));
        this.class(xu_0.float, (xd_0 xd_02) -> uv_0.class(xd_02, rdy_2.Oh));
        this.class(xu_0.Sk, (xd_0 xd_02) -> uv_0.class(xd_02, rdy_2.dP));
        this.class(xu_0.sC, (xd_0 xd_02) -> uv_0.class(xd_02, rdy_2.dv));
        this.class(xu_0.ri, (xd_0 xd_02) -> uv_0.class(xd_02, rdy_2.OJ));
        this.class(xu_0.void, (xd_0 xd_02) -> uv_0.class(xd_02, (rzg_2)uv_0.class((rpl_0)xd_02, ((rzk_1)rwe_1.class(rdy_2.JF).break(rnv_1.class(rzv_1.class(2.0f, 6.0f)))).break(rqr_2.class(ey_0.return)))));
        this.class(xu_0.m, (xd_0 xd_02) -> uv_0.class(xd_02, (rzg_2)uv_0.class((rpl_0)xd_02, ((rzk_1)rwe_1.class(rdy_2.XF).break(rnv_1.class(rzv_1.class(4.0f, 9.0f)))).break(rqr_2.class(ey_0.return)))));
        this.class(xu_0.U, (xd_0 xd_02) -> uv_0.byte(xd_02, (rzg_2)uv_0.class((rpl_0)xd_02, rwe_1.class(rdy_2.Oa))));
        this.class(xu_0.i, (xd_0 xd_02) -> uv_0.break(xd_02, (rzg_2)uv_0.class((rpl_0)xd_02, rwe_1.class(rdy_2.OD).break(rnv_1.class(rzv_1.class(0.0f, 2.0f))))));
        this.class(xu_0.Xu, uv_0::protected);
        this.class(xu_0.rr, uv_0::protected);
        this.class(xu_0.BD, uv_0::protected);
        this.class(xu_0.rP, uv_0.native(xu_0.rr));
        this.class(xu_0.GE, (xd_0 xd_02) -> uv_0.break(xd_02, xu_0.a));
        this.class(xu_0.Gs, (xd_0 xd_02) -> uv_0.break(xd_02, xu_0.e));
        this.class(xu_0.BK, (xd_0 xd_02) -> uv_0.break(xd_02, rdy_2.JW));
        this.class(xu_0.BY, (xd_0 xd_02) -> uv_0.byte(xd_02, rdy_2.JW));
        this.class(xu_0.Bo, (xd_0 xd_02) -> uv_0.break(xd_02, rdy_2.Jk));
        this.class(xu_0.BR, (xd_0 xd_02) -> uv_0.byte(xd_02, rdy_2.Jk));
        this.class(xu_0.bl, (xd_0 xd_02) -> rzl_2.break().class(rzn_2.class().class(rwy_2.class(1)).class((rzg_2<?>)((rzk_1)uv_0.class((rpl_0)xd_02, rwe_1.class(xd_02))).break(rqx_1.class(rzb_2.THIS)))));
        this.class(xu_0.a, uv_0::extends);
        this.class(xu_0.e, uv_0::extends);
        this.class(xu_0.Pa, (xd_0 xd_02) -> uv_0.class(xd_02, (rzg_2)uv_0.class((rpl_0)xd_02, ((rzk_1)((rzk_1)rwe_1.class(rdy_2.XW).break(rnv_1.class(rzv_1.class(2.0f, 4.0f)))).break(rqr_2.break(ey_0.return))).break(rnn_1.class(rwd_1.class(1, 4))))));
        this.class(xu_0.Bg, (xd_0 xd_02) -> uv_0.class(xd_02, (rzg_2)uv_0.class((rpl_0)xd_02, ((rzk_1)((rzk_1)rwe_1.class(rdy_2.Jx).break(rnv_1.class(rzv_1.class(3.0f, 7.0f)))).break(rqr_2.break(ey_0.return))).break(rnn_1.class(rwd_1.break(9))))));
        this.class(xu_0.Pl, (xd_0 xd_02) -> uv_0.class(xd_02, (rzg_2)uv_0.class((rpl_0)xd_02, ((rzk_1)rwe_1.class(rdy_2.hD).break(rnv_1.class(rzv_1.class(4.0f, 5.0f)))).break(rqr_2.break(ey_0.return)))));
        this.class(xu_0.EH, (xd_0 xd_02) -> uv_0.class(xd_02, (rzg_2)uv_0.class((rpl_0)xd_02, ((rzk_1)((rzk_1)rwe_1.class(rdy_2.dn).break(rnv_1.class(rzv_1.class(2.0f, 3.0f)))).break(rqr_2.break(ey_0.return))).break(rnn_1.class(rwd_1.class(1, 5))))));
        this.class(xu_0.Ss, (xd_0 xd_02) -> rzl_2.break().class(uv_0.class((rpl_0)xd_02, rzn_2.class().class(rwy_2.class(1)).class((rzg_2<?>)((rzk_1)rwe_1.class(rdy_2.JL).break((rna_2)rnv_1.class(rzv_1.class(2.0f, 4.0f)).break(rqm_2.class(xd_02).class(js_2.class().class(kf_1.volatile, 3))))).break((rna_2)rqr_2.break(ey_0.return).break(rqm_2.class(xd_02).class(js_2.class().class(kf_1.volatile, 3))))))));
        this.class(xu_0.Pq, (xd_0 xd_02) -> rzl_2.break().class(rzn_2.class().break(rqx_1.class(rzb_2.THIS)).class(rwl_2.class(new rzg_2[]{rwl_2.class(new rzg_2[]{rwe_1.class(rdy_2.hU).break(rqm_2.class(xd_02).class(js_2.class().class(wd_1.volatile, true))), ((rzk_1)rwe_1.class(rdy_2.hU).break(rqm_2.class(xd_02).class(js_2.class().class(wd_1.volatile, 2)))).break(rnv_1.class(rwy_2.class(2))), ((rzk_1)rwe_1.class(rdy_2.hU).break(rqm_2.class(xd_02).class(js_2.class().class(wd_1.volatile, 3)))).break(rnv_1.class(rwy_2.class(3))), ((rzk_1)rwe_1.class(rdy_2.hU).break(rqm_2.class(xd_02).class(js_2.class().class(wd_1.volatile, 4)))).break(rnv_1.class(rwy_2.class(4))), ((rzk_1)rwe_1.class(rdy_2.hU).break(rqm_2.class(xd_02).class(js_2.class().class(wd_1.volatile, 5)))).break(rnv_1.class(rwy_2.class(5))), ((rzk_1)rwe_1.class(rdy_2.hU).break(rqm_2.class(xd_02).class(js_2.class().class(wd_1.volatile, 6)))).break(rnv_1.class(rwy_2.class(6))), ((rzk_1)rwe_1.class(rdy_2.hU).break(rqm_2.class(xd_02).class(js_2.class().class(wd_1.volatile, 7)))).break(rnv_1.class(rwy_2.class(7))), rwe_1.class(rdy_2.hU).break(rnv_1.class(rwy_2.class(8)))}).break(break), rwl_2.class(new rzg_2[]{rwe_1.class(xu_0.Pq).break(rqm_2.class(xd_02).class(js_2.class().class(wd_1.volatile, true))), ((rzg_2)rwe_1.class(xu_0.Pq).break(rnv_1.class(rwy_2.class(2)))).break(rqm_2.class(xd_02).class(js_2.class().class(wd_1.volatile, 2))), ((rzg_2)rwe_1.class(xu_0.Pq).break(rnv_1.class(rwy_2.class(3)))).break(rqm_2.class(xd_02).class(js_2.class().class(wd_1.volatile, 3))), ((rzg_2)rwe_1.class(xu_0.Pq).break(rnv_1.class(rwy_2.class(4)))).break(rqm_2.class(xd_02).class(js_2.class().class(wd_1.volatile, 4))), ((rzg_2)rwe_1.class(xu_0.Pq).break(rnv_1.class(rwy_2.class(5)))).break(rqm_2.class(xd_02).class(js_2.class().class(wd_1.volatile, 5))), ((rzg_2)rwe_1.class(xu_0.Pq).break(rnv_1.class(rwy_2.class(6)))).break(rqm_2.class(xd_02).class(js_2.class().class(wd_1.volatile, 6))), ((rzg_2)rwe_1.class(xu_0.Pq).break(rnv_1.class(rwy_2.class(7)))).break(rqm_2.class(xd_02).class(js_2.class().class(wd_1.volatile, 7))), rwe_1.class(xu_0.Pt)})}))));
        this.class(xu_0.char, (xd_0 xd_02) -> uv_0.class(xd_02, uv_0.class((rpl_0)xd_02, ((rzk_1)rwe_1.class(rdy_2.hn).break(rqt_1.class(ey_0.return, 0.1f, 0.14285715f, 0.25f, 1.0f))).class(rwe_1.class(xd_02)))));
        this.class(xu_0.Xh, (xd_0 xd_02) -> uv_0.class(xd_02, (rzg_2)uv_0.class((rpl_0)xd_02, rwe_1.class(rdy_2.OX).break(rnv_1.class(rwy_2.class(2))))));
        this.class(xu_0.Jy, (xd_0 xd_02) -> uv_0.class(xd_02, uv_0.class((rpl_0)xd_02, ((rzk_1)((rzg_2)rwe_1.class(rdy_2.JF).break(rnv_1.class(rzv_1.class(2.0f, 5.0f)))).break(rqt_1.class(ey_0.return, 0.1f, 0.14285715f, 0.25f, 1.0f))).class(rwe_1.class(xd_02)))));
        this.class(xu_0.XX, (xd_0 xd_02) -> uv_0.class(xd_02, (rzg_2)uv_0.class((rpl_0)xd_02, rwe_1.class(rdy_2.BQ).break(rnv_1.class(rwy_2.class(1))))));
        this.byte(xu_0.u);
        this.byte(xu_0.Bs);
        this.byte(xu_0.BE);
        this.byte(xu_0.BG);
        this.byte(xu_0.Bb);
        this.byte(xu_0.BM);
        this.byte(xu_0.BO);
        this.byte(xu_0.Bh);
        this.byte(xu_0.BX);
        this.byte(xu_0.BJ);
        this.byte(xu_0.Bx);
        this.byte(xu_0.Bd);
        this.byte(xu_0.Bk);
        this.byte(xu_0.BW);
        this.byte(xu_0.Bz);
        this.byte(xu_0.BQ);
        this.byte(xu_0.BN);
        this.byte(xu_0.BV);
        this.byte(xu_0.EP);
        this.byte(xu_0.EB);
        this.byte(xu_0.ES);
        this.byte(xu_0.Es);
        this.byte(xu_0.EE);
        this.byte(xu_0.EG);
        this.byte(xu_0.Eb);
        this.byte(xu_0.EM);
        this.byte(xu_0.EO);
        this.byte(xu_0.Eh);
        this.byte(xu_0.EX);
        this.byte(xu_0.EJ);
        this.byte(xu_0.Ex);
        this.byte(xu_0.Ed);
        this.byte(xu_0.Ek);
        this.byte(xu_0.EW);
        this.byte(xu_0.PT);
        this.byte(xu_0.Ei);
        this.byte(xu_0.hP);
        this.byte(xu_0.OX);
        this.byte(xu_0.BI);
        this.byte(xu_0.Om);
        this.byte(xu_0.OZ);
        this.byte(xu_0.Ov);
        this.byte(xu_0.OF);
        this.byte(xu_0.OL);
        this.byte(xu_0.OA);
        this.byte(xu_0.On);
        this.byte(xu_0.OC);
        this.byte(xu_0.Ol);
        this.byte(xu_0.OH);
        this.byte(xu_0.Oy);
        this.byte(xu_0.Op);
        this.byte(xu_0.Oq);
        this.byte(xu_0.OT);
        this.byte(xu_0.Ot);
        this.byte(xu_0.Ow);
        this.byte(xu_0.OI);
        this.byte(xu_0.Of);
        this.byte(xu_0.Oj);
        this.byte(xu_0.OV);
        this.class(xu_0.Bl, xu_0.break);
        this.class(xu_0.BH, xu_0.volatile);
        this.class(xu_0.By, xu_0.BL);
        this.class(xu_0.Bp, xu_0.BA);
        this.class(xu_0.Bq, xu_0.Bn);
        this.class(xu_0.BT, xu_0.BC);
        this.byte(xu_0.XC, xu_0.Xl);
        this.byte(xu_0.XH, xu_0.Xy);
        this.class(xu_0.BB, uv_0.class());
        this.class(xu_0.bj, uv_0.class());
        this.class(xu_0.rD, uv_0.class());
        this.class(xu_0.ro, uv_0.class());
        this.class(xu_0.rK, uv_0.class());
        this.class(xu_0.Pi, uv_0.class());
        HashSet hashSet = Sets.newHashSet();
        for (xd_0 xd_03 : rvl_0.strictfp) {
            rqo_0 rqo_02 = xd_03.throws();
            if (rqo_02 == rzl_1.class || !hashSet.add(rqo_02)) continue;
            rza_2 rza_22 = this.implements.remove(rqo_02);
            if (rza_22 == null) {
                throw new IllegalStateException(String.format("Missing loottable '%s' for '%s'", rqo_02, rvl_0.strictfp.break(xd_03)));
            }
            biConsumer.accept(rqo_02, rza_22);
        }
        if (!this.implements.isEmpty()) {
            throw new IllegalStateException("Created block loot tables for non-blocks: " + this.implements.keySet());
        }
    }

    private static rza_2 class(xd_0 xd_02, rpl_0 rpl_02, rwk_1 rwk_12) {
        return uv_0.class(xd_02, (rzg_2)uv_0.class((rpl_0)xd_02, rwe_1.class(rpl_02).break(rnv_1.class(rwk_12))));
    }

    public static rza_2 class(xd_0 xd_02) {
        return uv_0.class(xd_02, dn_2.new, rcf_0.LOWER);
    }

    public void class(xd_0 xd_02, xd_0 xd_03) {
        this.class(xd_02, uv_0.break(xd_03));
    }

    public void class(xd_0 xd_02, rpl_0 rpl_02) {
        this.class(xd_02, uv_0.class(rpl_02));
    }

    private static rza_2 class(rpl_0 rpl_02, rwk_1 rwk_12) {
        return rzl_2.break().class(rzn_2.class().class(rwy_2.class(1)).class((rzg_2)uv_0.class(rpl_02, rwe_1.class(rpl_02).break(rnv_1.class(rwk_12)))));
    }

    private static rza_2 class(rpl_0 rpl_02) {
        return rzl_2.break().class(uv_0.class(rpl_02, rzn_2.class().class(rwy_2.class(1)).class(rwe_1.class(rpl_02))));
    }

    private void class(xd_0 xd_02, Function<xd_0, rza_2> function) {
        this.class(xd_02, function.apply(xd_02));
    }

    public static rza_2 class() {
        return rzl_2.break();
    }

    @Override
    public /* synthetic */ void accept(Object object) {
        this.class((BiConsumer)object);
    }

    private static rza_2 break(rpl_0 rpl_02) {
        return rzl_2.break().class(rzn_2.class().break(uv_0.class).class(rwy_2.class(1)).class(rwe_1.class(rpl_02)));
    }

    private static rza_2 break(xd_0 xd_02, xd_0 xd_03) {
        rwa_2 rwa_22 = ((rzk_1)((rzg_2)rwe_1.class(xd_03).break(rnv_1.class(rwy_2.class(2)))).break(byte)).class((rzg_2<?>)((rzk_1)uv_0.class((rpl_0)xd_02, rwe_1.class(rdy_2.hP))).break(rqn_1.class(0.125f)));
        return rzl_2.break().class(rzn_2.class().class(rwa_22).break(rqm_2.class(xd_02).class(js_2.class().class(du_2.volatile, rcf_0.LOWER))).break(rqz_1.class(xc_2.class().class(hh_2.class().class(xd_02).class(js_2.class().class(du_2.volatile, rcf_0.UPPER).break()).break()), new rfH(0, 1, 0)))).class(rzn_2.class().class(rwa_22).break(rqm_2.class(xd_02).class(js_2.class().class(du_2.volatile, rcf_0.UPPER))).break(rqz_1.class(xc_2.class().class(hh_2.class().class(xd_02).class(js_2.class().class(du_2.volatile, rcf_0.LOWER).break()).break()), new rfH(0, -1, 0))));
    }

    private static rza_2 break(xd_0 xd_02, rdb_1 rdb_12) {
        return rzl_2.break().class(uv_0.class((rpl_0)xd_02, rzn_2.class().class(rwy_2.class(1)).class((rzg_2<?>)((rzk_1)((rzk_1)((rzk_1)((rzk_1)((rzk_1)((rzk_1)((rzk_1)rwe_1.class(rdb_12).break((rna_2)rnv_1.class(rwn_1.class(3, 0.06666667f)).break(rqm_2.class(xd_02).class(js_2.class().class(zo_2.volatile, false))))).break((rna_2)rnv_1.class(rwn_1.class(3, 0.13333334f)).break(rqm_2.class(xd_02).class(js_2.class().class(zo_2.volatile, true))))).break((rna_2)rnv_1.class(rwn_1.class(3, 0.2f)).break(rqm_2.class(xd_02).class(js_2.class().class(zo_2.volatile, 2))))).break((rna_2)rnv_1.class(rwn_1.class(3, 0.26666668f)).break(rqm_2.class(xd_02).class(js_2.class().class(zo_2.volatile, 3))))).break((rna_2)rnv_1.class(rwn_1.class(3, 0.33333334f)).break(rqm_2.class(xd_02).class(js_2.class().class(zo_2.volatile, 4))))).break((rna_2)rnv_1.class(rwn_1.class(3, 0.4f)).break(rqm_2.class(xd_02).class(js_2.class().class(zo_2.volatile, 5))))).break((rna_2)rnv_1.class(rwn_1.class(3, 0.46666667f)).break(rqm_2.class(xd_02).class(js_2.class().class(zo_2.volatile, 6))))).break((rna_2)rnv_1.class(rwn_1.class(3, 0.53333336f)).break(rqm_2.class(xd_02).class(js_2.class().class(zo_2.volatile, 7)))))));
    }

    private static rza_2 break(xd_0 xd_02, rpl_0 rpl_02) {
        return uv_0.class(xd_02, (rzg_2)uv_0.class((rpl_0)xd_02, rwe_1.class(rpl_02)));
    }

    private static rza_2 break(xd_0 xd_02, xd_0 xd_03, float ... fArray) {
        return uv_0.class(xd_02, xd_03, fArray).class(rzn_2.class().class(rwy_2.class(1)).break(throws).class((rzg_2<?>)((rzk_1)uv_0.class((rpl_0)xd_02, rwe_1.class(rdy_2.Ob))).break(rqt_1.class(ey_0.return, 0.005f, 0.0055555557f, 0.00625f, 0.008333334f, 0.025f))));
    }

    private static rza_2 break(xd_0 xd_02, rzg_2<?> rzg_22) {
        return uv_0.class(xd_02, byte, rzg_22);
    }

    public void break(xd_0 xd_03) {
        this.class(xd_03, (xd_0 xd_02) -> uv_0.byte(((df_1)xd_02).break()));
    }

    private static rza_2 throws(xd_0 xd_02) {
        return rzl_2.break().class(rzn_2.class().class(rwy_2.class(1)).class((rzg_2)uv_0.class((rpl_0)xd_02, rwe_1.class(xd_02).break((rna_2)rnv_1.class(rwy_2.class(2)).break(rqm_2.class(xd_02).class(js_2.class().class(wg_1.volatile, rCo.DOUBLE)))))));
    }

    private static rza_2 finally(xd_0 xd_02) {
        return rzl_2.break().class(rzn_2.class().class(rwy_2.class(1)).class(((rzg_2)((rzk_1)((rzk_1)rwe_1.class(xd_02).break(uv_0.class)).break(rns_1.class(rnj_2.BLOCK_ENTITY).class("Bees", "BlockEntityTag.Bees"))).break(rqa_1.class(xd_02).class(xo_0.final))).class(rwe_1.class(xd_02))));
    }

    private static rza_2 catch(xd_0 xd_02) {
        return rzl_2.break().class(uv_0.class((rpl_0)xd_02, rzn_2.class().class(rwy_2.class(1)).class((rzg_2<?>)((rzk_1)((rzk_1)rwe_1.class(xd_02).break(rnp_2.class(rns_2.BLOCK_ENTITY))).break(rns_1.class(rnj_2.BLOCK_ENTITY).class("Lock", "BlockEntityTag.Lock").class("LootTable", "BlockEntityTag.LootTable").class("LootTableSeed", "BlockEntityTag.LootTableSeed"))).break(rni_2.byte().class(rwq_1.class(wp_1.final))))));
    }

    private static rza_2 extends(xd_0 xd_02) {
        return uv_0.break(xd_02, (rzg_2)uv_0.class((rpl_0)xd_02, ((rzk_1)rwe_1.class(rdy_2.hP).break(rqn_1.class(0.125f))).break(rqr_2.class(ey_0.return, 2))));
    }

    private static rza_2 case(xd_0 xd_02) {
        return rzl_2.break().class(uv_0.class((rpl_0)xd_02, rzn_2.class().class(rwy_2.class(1)).class((rzg_2<?>)rwe_1.class(xd_02).break(rnp_2.class(rns_2.BLOCK_ENTITY)))));
    }

    private static rza_2 implements(xd_0 xd_02) {
        return rzl_2.break().class(rzn_2.class().break(uv_0.class).class(rwy_2.class(1)).class((rzg_2<?>)((rzk_1)rwe_1.class(xd_02).break(rns_1.class(rnj_2.BLOCK_ENTITY).class("Bees", "BlockEntityTag.Bees"))).break(rqa_1.class(xd_02).class(xo_0.final))));
    }

    private static rza_2 protected(rpl_0 rpl_02) {
        return rzl_2.break().class(rzn_2.class().class(rwy_2.class(1)).break(byte).class(rwe_1.class(rpl_02)));
    }

    public void protected(xd_0 xd_02) {
        this.class(xd_02, (rpl_0)xd_02);
    }

    private static rza_2 private(xd_0 xd_02) {
        return rzl_2.break().class(uv_0.class((rpl_0)xd_02, rzn_2.class().class(rwy_2.class(1)).class((rzg_2<?>)((rzk_1)rwe_1.class(xd_02).break(rnp_2.class(rns_2.BLOCK_ENTITY))).break(rns_1.class(rnj_2.BLOCK_ENTITY).class("Patterns", "BlockEntityTag.Patterns")))));
    }

    private static rza_2 native(xd_0 xd_02) {
        return rzl_2.break().class(rzn_2.class().break(byte).class((rzg_2<?>)rwe_1.class(xd_02).break(rnv_1.class(rwy_2.class(2)))));
    }
}

