/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.util.Arrays;
import java.util.Comparator;
import protected.rfU;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.Vd
 */
public final class vd_0
extends Enum<vd_0> {
    public static final /* enum */ vd_0 OFF = new vd_0(0, "options.off");
    public static final /* enum */ vd_0 FAST = new vd_0(1, "options.clouds.fast");
    public static final /* enum */ vd_0 FANCY = new vd_0(2, "options.clouds.fancy");
    private static final vd_0[] BY_ID;
    private final int id;
    private final String key;
    private static final /* synthetic */ vd_0[] $VALUES;

    private static /* synthetic */ vd_0[] byte() {
        return new vd_0[]{OFF, FAST, FANCY};
    }

    private vd_0(int n3, String string2) {
        this.id = n3;
        this.key = string2;
    }

    static {
        $VALUES = vd_0.byte();
        BY_ID = (vd_0[])Arrays.stream(vd_0.values()).sorted(Comparator.comparingInt(vd_0::class)).toArray(vd_0[]::new);
    }

    public static vd_0[] values() {
        return (vd_0[])$VALUES.clone();
    }

    public static vd_0 valueOf(String string) {
        return Enum.valueOf(vd_0.class, string);
    }

    public int class() {
        return this.id;
    }

    public static vd_0 class(int n2) {
        return BY_ID[rfU.break(n2, BY_ID.length)];
    }

    public String break() {
        return this.key;
    }
}

