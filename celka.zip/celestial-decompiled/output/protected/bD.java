/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.bV;
import protected.pm_2;
import protected.rqr_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class bD
extends rqr_0 {
    private static short[] volatile;
    private static boolean[] final;
    private static float[] package;
    public Object[] class;
    private static double[] int;

    public bD(bV bV2) {
        this.catch();
        bV bV3 = bV2;
        this.class[bD.volatile[0]] = bV3;
    }

    static {
        bD.ntfClinit();
    }

    public static String class(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{-128, 76, -90, -35, -44, -48, -91, -20}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    @Override
    public void class(boolean bl2) {
        this.catch();
        this.break = package[0];
        this.byte = package[1];
        this.private = ((bV)this.class[volatile[1]]).class((pm_2)((Object)pm_2.staticFieldsd2ae74894aa334618e73ed450cdbde1f[volatile[2]]));
        this.protected = ((bV)this.class[volatile[3]]).class((pm_2)((Object)pm_2.staticFieldsd2ae74894aa334618e73ed450cdbde1f[volatile[4]]));
        if (this.protected) {
            this.byte += package[2];
        }
        if (this.throws = ((bV)this.class[volatile[5]]).class((pm_2)((Object)pm_2.staticFieldsd2ae74894aa334618e73ed450cdbde1f[volatile[6]]))) {
            this.byte -= package[3];
        }
        if (this.case = ((bV)this.class[volatile[7]]).class((pm_2)((Object)pm_2.staticFieldsd2ae74894aa334618e73ed450cdbde1f[volatile[8]]))) {
            this.break += package[4];
        }
        if (this.catch = ((bV)this.class[volatile[9]]).class((pm_2)((Object)pm_2.staticFieldsd2ae74894aa334618e73ed450cdbde1f[volatile[10]]))) {
            this.break -= package[5];
        }
        if (this.implements = ((bV)this.class[volatile[11]]).class((pm_2)((Object)pm_2.staticFieldsd2ae74894aa334618e73ed450cdbde1f[volatile[12]]))) {
            this.break = (float)((double)this.break * int[0]);
            this.byte = (float)((double)this.byte * int[1]);
        }
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0xD14A4332;
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0x18CF9FE9DD41E07FL;
    }

    private static void throws() {
        float[] fArray = new float[6];
        fArray[2] = 1.0f;
        fArray[3] = 1.0f;
        fArray[4] = 1.0f;
        fArray[5] = 1.0f;
        package = fArray;
    }

    private static /* synthetic */ void ntfClinit() {
        bD.implements();
        bD.case();
        bD.throws();
        bD.private();
    }

    private void catch() {
        if (this.class == null) {
            Object[] objectArray = this.class = new Object[final[0]];
        }
    }

    private static void case() {
        short[] sArray = new short[13];
        sArray[2] = 6;
        sArray[6] = 1;
        sArray[8] = 2;
        sArray[10] = 3;
        sArray[12] = 7;
        volatile = sArray;
    }

    private static void implements() {
        final = new boolean[]{true};
    }

    private static void private() {
        int = new double[]{0.3, 0.3};
    }
}

