/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.rpb_0;

/*
 * Renamed from protected.xT
 * Illegal identifiers - consider using --renameillegalidents true
 */
class xt_0 {
    static final /* synthetic */ int[] class;

    static {
        xt_0.class = new int[rpb_0.values().length];
        try {
            xt_0.class[rpb_0.X.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            xt_0.class[rpb_0.Z.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            xt_0.class[rpb_0.Y.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}

