/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.rfH;
import protected.xd_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.xQ
 */
public class xq_0 {
    private final rfH class;
    private final xd_0 break;
    private final int byte;
    private final int protected;

    public int byte() {
        return this.byte;
    }

    public xq_0(rfH rfH2, xd_0 xd_02, int n2, int n3) {
        this.class = rfH2;
        this.break = xd_02;
        this.byte = n2;
        this.protected = n3;
    }

    public boolean equals(Object object) {
        if (!(object instanceof xq_0)) {
            return false;
        }
        xq_0 xq_02 = (xq_0)object;
        return this.class.equals(xq_02.class) && this.byte == xq_02.byte && this.protected == xq_02.protected && this.break == xq_02.break;
    }

    public String toString() {
        return "TE(" + this.class + ")," + this.byte + "," + this.protected + "," + this.break;
    }

    public int hashCode() {
        int n2 = this.class.hashCode();
        n2 = 31 * n2 + this.break.hashCode();
        n2 = 31 * n2 + this.byte;
        return 31 * n2 + this.protected;
    }

    public rfH class() {
        return this.class;
    }

    public xd_0 break() {
        return this.break;
    }

    public int protected() {
        return this.protected;
    }
}

