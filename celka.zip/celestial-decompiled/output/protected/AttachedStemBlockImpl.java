/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableMap
 *  com.google.common.collect.Maps
 */
package protected;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Maps;
import java.util.Map;
import protected.jq_1;
import protected.ke_2;
import protected.rCL;
import protected.rCZ;
import protected.rRg;
import protected.rRq;
import protected.rcc_0;
import protected.rdb_1;
import protected.rdn_1;
import protected.rdy_2;
import protected.rfH;
import protected.rjC;
import protected.rjm;
import protected.rpa;
import protected.rpr_0;
import protected.rqd_0;
import protected.xc_0;
import protected.xd_0;
import protected.xf_0;
import protected.xu_0;
import protected.zh_2;
import protected.zo_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.xr
 */
public class xr_0
extends xf_0 {
    public static final rcc_0 volatile = ke_2.p;
    private final zh_2 final;
    private static final Map<rpr_0, rjC> package = Maps.newEnumMap((Map)ImmutableMap.of((Object)rpr_0.SOUTH, (Object)xd_0.class(6.0, 0.0, 6.0, 10.0, 10.0, 16.0), (Object)rpr_0.WEST, (Object)xd_0.class(0.0, 0.0, 6.0, 10.0, 10.0, 10.0), (Object)rpr_0.NORTH, (Object)xd_0.class(6.0, 0.0, 0.0, 10.0, 10.0, 10.0), (Object)rpr_0.EAST, (Object)xd_0.class(6.0, 0.0, 6.0, 16.0, 10.0, 10.0)));

    protected xr_0(zh_2 zh_22, jq_1 jq_12) {
        super(jq_12);
        this.extends((xc_0)((xc_0)this.abstract.break()).class(volatile, rpr_0.NORTH));
        this.final = zh_22;
    }

    @Override
    public xc_0 class(xc_0 xc_02, rqd_0 rqd_02) {
        return (xc_0)xc_02.class(volatile, rqd_02.class(xc_02.byte(volatile)));
    }

    @Override
    public xc_0 class(xc_0 xc_02, rpa rpa2) {
        return xc_02.class(rpa2.class(xc_02.byte(volatile)));
    }

    @Override
    protected void class(rCL<xd_0, xc_0> rCL2) {
        rCL2.class(new rCZ[]{volatile});
    }

    @Override
    public rdn_1 class(rRq rRq2, rfH rfH2, xc_0 xc_02) {
        return new rdn_1(this.break());
    }

    @Override
    public xc_0 class(xc_0 xc_02, rpr_0 rpr_02, xc_0 xc_03, rRg rRg2, rfH rfH2, rfH rfH3) {
        return !xc_03.class(this.final) && rpr_02 == xc_02.byte(volatile) ? (xc_0)this.final.break().continue().class(zo_2.volatile, 7) : super.class(xc_02, rpr_02, xc_03, rRg2, rfH2, rfH3);
    }

    @Override
    public rjC class(xc_0 xc_02, rRq rRq2, rfH rfH2, rjm rjm2) {
        return package.get(xc_02.byte(volatile));
    }

    protected rdb_1 break() {
        if (this.final == xu_0.Pg) {
            return rdy_2.Jk;
        }
        return this.final == xu_0.Bg ? rdy_2.JW : rdy_2.class;
    }

    @Override
    protected boolean catch(xc_0 xc_02, rRq rRq2, rfH rfH2) {
        return xc_02.class(xu_0.PS);
    }
}

