/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.serialization.Codec
 */
package protected;

import com.mojang.serialization.Codec;
import java.util.Random;
import java.util.stream.Stream;
import protected.reX;
import protected.rfH;
import protected.rrba_1;
import protected.rrbd_1;
import protected.rrbe_1;
import protected.rrbg_1;
import protected.rrbi_1;
import protected.rrbj_1;
import protected.rrbk_1;
import protected.rrbo_1;
import protected.rrbr_1;
import protected.rrbu_1;
import protected.rrbv_1;
import protected.rrby_1;
import protected.rrsa_2;
import protected.rrsb_1;
import protected.rrsb_2;
import protected.rrsc_1;
import protected.rrsc_2;
import protected.rrsd_2;
import protected.rrse_2;
import protected.rrsg_2;
import protected.rrsh_1;
import protected.rrsh_2;
import protected.rrsj_2;
import protected.rrsk_2;
import protected.rrsl_1;
import protected.rrsm_1;
import protected.rrsm_2;
import protected.rrsn_1;
import protected.rrsn_2;
import protected.rrsp_2;
import protected.rrsq_2;
import protected.rrsr_2;
import protected.rrss_1;
import protected.rrss_2;
import protected.rrsv_2;
import protected.rrsw_2;
import protected.rrsx_1;
import protected.rrsx_2;
import protected.rrsz_1;
import protected.rrsz_2;
import protected.ruj_0;
import protected.rvl_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.rrSu
 */
public abstract class rrsu_2<DC extends rrsx_1> {
    public static final rrsu_2<rrsq_2> class = rrsu_2.class("nope", new rrsc_2(rrsq_2.class));
    public static final rrsu_2<rrbr_1> break = rrsu_2.class("chance", new rrby_1(rrbr_1.class));
    public static final rrsu_2<ruj_0> byte = rrsu_2.class("count", new rrba_1(ruj_0.class));
    public static final rrsu_2<rrsn_2> protected = rrsu_2.class("count_noise", new rrbe_1(rrsn_2.class));
    public static final rrsu_2<rrsh_1> throws = rrsu_2.class("count_noise_biased", new rrbu_1(rrsh_1.class));
    public static final rrsu_2<rrbj_1> case = rrsu_2.class("count_extra", new rrbk_1(rrbj_1.class));
    public static final rrsu_2<rrsq_2> catch = rrsu_2.class("square", new rrsn_1(rrsq_2.class));
    public static final rrsu_2<rrsq_2> private = rrsu_2.class("heightmap", new rrsh_2<rrsq_2>(rrsq_2.class));
    public static final rrsu_2<rrsq_2> implements = rrsu_2.class("heightmap_spread_double", new rrsx_2<rrsq_2>(rrsq_2.class));
    public static final rrsu_2<rrsq_2> finally = rrsu_2.class("top_solid_heightmap", new rrsc_1(rrsq_2.class));
    public static final rrsu_2<rrsq_2> extends = rrsu_2.class("heightmap_world_surface", new rrsj_2(rrsq_2.class));
    public static final rrsu_2<rrsl_1> native = rrsu_2.class("range", new rrsz_1(rrsl_1.class));
    public static final rrsu_2<rrsl_1> volatile = rrsu_2.class("range_biased", new rrsm_1(rrsl_1.class));
    public static final rrsu_2<rrsl_1> final = rrsu_2.class("range_very_biased", new rrsv_2(rrsl_1.class));
    public static final rrsu_2<rrsb_2> package = rrsu_2.class("depth_average", new rrss_2(rrsb_2.class));
    public static final rrsu_2<rrsq_2> int = rrsu_2.class("spread_32_above", new rrsa_2(rrsq_2.class));
    public static final rrsu_2<rrbg_1> new = rrsu_2.class("carving_mask", new rrbv_1(rrbg_1.class));
    public static final rrsu_2<ruj_0> continue = rrsu_2.class("fire", new rrsg_2(ruj_0.class));
    public static final rrsu_2<rrsq_2> super = rrsu_2.class("magma", new rrsz_2(rrsq_2.class));
    public static final rrsu_2<rrsq_2> this = rrsu_2.class("emerald_ore", new rrsm_2(rrsq_2.class));
    public static final rrsu_2<rrbr_1> else = rrsu_2.class("lava_lake", new rrsk_2(rrbr_1.class));
    public static final rrsu_2<rrbr_1> synchronized = rrsu_2.class("water_lake", new rrsw_2(rrbr_1.class));
    public static final rrsu_2<ruj_0> return = rrsu_2.class("glowstone", new rrsb_1(ruj_0.class));
    public static final rrsu_2<rrsq_2> public = rrsu_2.class("end_gateway", new rrss_1(rrsq_2.class));
    public static final rrsu_2<rrsq_2> goto = rrsu_2.class("dark_oak_tree", new rrbi_1(rrsq_2.class));
    public static final rrsu_2<rrsq_2> while = rrsu_2.class("iceberg", new rrsd_2(rrsq_2.class));
    public static final rrsu_2<rrsq_2> try = rrsu_2.class("end_island", new rrse_2(rrsq_2.class));
    public static final rrsu_2<rrsp_2> instanceof = rrsu_2.class("decorated", new rrsr_2(rrsp_2.class));
    public static final rrsu_2<ruj_0> throw = rrsu_2.class("count_multilayer", new rrbd_1(ruj_0.class));
    private final Codec<rrbo_1<DC>> interface;

    public rrsu_2(Codec<DC> codec) {
        this.interface = codec.fieldOf("config").xmap(rrsx_12 -> new rrbo_1<rrsx_1>(this, (rrsx_1)rrsx_12), rrbo_1::break).codec();
    }

    public String toString() {
        return this.getClass().getSimpleName() + "@" + Integer.toHexString(this.hashCode());
    }

    private static <T extends rrsx_1, G extends rrsu_2<T>> G class(String string, G g2) {
        return (G)rvl_0.class(rvl_0.j, string, g2);
    }

    public abstract Stream<rfH> class(reX var1, Random var2, DC var3, rfH var4);

    public Codec<rrbo_1<DC>> class() {
        return this.interface;
    }

    public rrbo_1<DC> break(DC DC2) {
        return new rrbo_1<DC>(this, DC2);
    }
}

