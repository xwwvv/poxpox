/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.jj_1;
import protected.jq_1;
import protected.rRR;
import protected.rRg;
import protected.rfH;
import protected.rls;
import protected.rpr_0;
import protected.xc_0;
import protected.xd_0;
import protected.xu_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.Wa
 */
public class wa_1
extends jj_1 {
    public wa_1(jq_1 jq_12) {
        super(jq_12, 2.0f);
    }

    public static boolean class(xd_0 xd_02) {
        return xd_02.class(rls.n);
    }

    @Override
    public boolean class(xc_0 xc_02, rRR rRR2, rfH rfH2) {
        return wa_1.class(rRR2.byte(rfH2.break()).break());
    }

    @Override
    public xc_0 class(xc_0 xc_02, rpr_0 rpr_02, xc_0 xc_03, rRg rRg2, rfH rfH2, rfH rfH3) {
        return this.class(xc_02, rRg2, rfH2) ? this.continue() : xu_0.class.continue();
    }

    @Override
    protected boolean catch(xc_0 xc_02) {
        return true;
    }
}

