/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.rVi;
import protected.rgP;
import protected.rgn;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.cN
 */
public class cn_2 {
    public static final rgP class = new rgn("options.on");
    public static final rgP break = new rgn("options.off");
    public static final rgP byte = new rgn("gui.done");
    public static final rgP protected = new rgn("gui.cancel");
    public static final rgP throws = new rgn("gui.yes");
    public static final rgP case = new rgn("gui.no");
    public static final rgP catch = new rgn("gui.proceed");
    public static final rgP private = new rgn("gui.back");
    public static final rgP implements = new rgn("connect.failed");

    public static rgP class(boolean bl2) {
        return bl2 ? cn_2.class : break;
    }

    public static rVi class(rgP rgP2, boolean bl2) {
        return new rgn(bl2 ? "options.on.composed" : "options.off.composed", rgP2);
    }
}

