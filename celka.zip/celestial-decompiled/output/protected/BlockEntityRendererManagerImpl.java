/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonObject
 */
package protected;

import com.google.gson.JsonObject;
import java.util.Collection;
import protected.an;
import protected.ho_1;
import protected.hy_1;
import protected.hz_1;
import protected.rdn_1;
import protected.rse_0;
import protected.rwh_1;
import protected.rzq_2;
import protected.rzr_2;
import protected.xh_2;
import protected.xp_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.XB
 */
public class xb_2
extends hz_1 {
    private final xh_2 class;
    private final ho_1 break;
    private final xh_2 byte;

    public xb_2(ho_1 ho_12, xh_2 xh_22, ho_1 ho_13, xh_2 xh_23) {
        super(xp_2.class, ho_12);
        this.class = xh_22;
        this.break = ho_13;
        this.byte = xh_23;
    }

    @Override
    public JsonObject class(rwh_1 rwh_12) {
        JsonObject jsonObject = super.class(rwh_12);
        jsonObject.add("rod", this.class.class());
        jsonObject.add("entity", this.break.class(rwh_12));
        jsonObject.add("item", this.byte.class());
        return jsonObject;
    }

    public boolean class(rdn_1 rdn_12, rzr_2 rzr_22, Collection<rdn_1> collection) {
        if (!this.class.class(rdn_12)) {
            return false;
        }
        if (!this.break.class(rzr_22)) {
            return false;
        }
        if (this.byte != xh_2.class) {
            Object object;
            boolean bl2 = false;
            an an2 = rzr_22.break(rzq_2.class);
            if (an2 instanceof rse_0 && this.byte.class(((rse_0)(object = (rse_0)an2)).protected())) {
                bl2 = true;
            }
            for (rdn_1 rdn_13 : collection) {
                if (!this.byte.class(rdn_13)) continue;
                bl2 = true;
                break;
            }
            if (!bl2) {
                return false;
            }
        }
        return true;
    }

    public static xb_2 class(xh_2 xh_22, hy_1 hy_12, xh_2 xh_23) {
        return new xb_2(ho_1.class, xh_22, ho_1.class(hy_12), xh_23);
    }
}

