/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.datafixers.kinds.App
 *  com.mojang.datafixers.kinds.Applicative
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.codecs.RecordCodecBuilder
 */
package protected;

import com.mojang.datafixers.kinds.App;
import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Random;
import protected.rlq_2;
import protected.rlx_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class rYV {
    public static final Codec<rYV> class = RecordCodecBuilder.create(instance -> instance.group((App)rlq_2.L.fieldOf("options").forGetter(rYV2 -> rYV2.break), (App)Codec.FLOAT.fieldOf("probability").forGetter(rYV2 -> Float.valueOf(rYV2.byte))).apply((Applicative)instance, rYV::new));
    private final rlx_1 break;
    private final float byte;

    public rYV(rlx_1 rlx_12, float f2) {
        this.break = rlx_12;
        this.byte = f2;
    }

    public rlx_1 class() {
        return this.break;
    }

    public boolean class(Random random) {
        return random.nextFloat() <= this.byte;
    }
}

