/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.rfH;
import protected.rs_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.bx
 */
public class bx_0
extends rs_2 {
    public Object[] break;
    private static boolean[] byte;
    private static float[] protected;
    private static byte[] throws;
    private static short[] case;

    public boolean byte() {
        this.throws();
        return (Boolean)this.break[case[2]];
    }

    public bx_0(rfH rfH2, float f2, boolean bl2) {
        super(rfH2);
        this.throws();
        Float f3 = Float.valueOf(f2);
        this.break[bx_0.case[0]] = f3;
        Boolean bl3 = bl2;
        this.break[bx_0.case[1]] = bl3;
    }

    static {
        bx_0.ntfClinit();
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0xB0930210;
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0x7315025C28F89EE2L;
    }

    public static String break(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{-108, -90, 6, 72, -42, 7, -38, 75}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    private void throws() {
        if (this.break == null) {
            Object[] objectArray = this.break = new Object[throws[0]];
            objectArray[bx_0.byte[0]] = Float.valueOf(protected[0]);
            objectArray[bx_0.byte[1]] = byte[2];
        }
    }

    private static /* synthetic */ void ntfClinit() {
        bx_0.catch();
        bx_0.case();
        bx_0.implements();
        bx_0.private();
    }

    private static void catch() {
        boolean[] blArray = new boolean[3];
        blArray[1] = true;
        byte = blArray;
    }

    private static void case() {
        short[] sArray = new short[4];
        sArray[1] = 1;
        sArray[2] = 1;
        case = sArray;
    }

    private static void implements() {
        protected = new float[1];
    }

    public float protected() {
        this.throws();
        return ((Float)this.break[case[3]]).floatValue();
    }

    private static void private() {
        throws = new byte[]{2};
    }
}

