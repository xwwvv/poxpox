/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.rfH;

/*
 * Renamed from protected.yj
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class yj_2 {
    public final rfH class;
    public final String break;
    public final int byte;
    public final int protected;
    public final boolean throws;
    public final long case;

    public yj_2(rfH rfH2, String string, int n2, int n3, boolean bl2, long l2) {
        this.class = rfH2;
        this.break = string;
        this.byte = n2;
        this.protected = n3;
        this.throws = bl2;
        this.case = l2;
    }
}

