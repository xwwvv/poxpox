/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.FileAttribute;
import java.security.Key;
import java.util.ArrayList;
import java.util.BitSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.class;
import protected.continue;
import protected.rYB;
import protected.rfH;
import protected.ri_1;
import protected.rqm_0;
import protected.st_1;
import protected.xc_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.Sw
 */
public class sw_1
implements continue {
    public static Object[] class;
    public Object[] break;
    private static boolean[] byte;
    private static byte[] protected;
    private static String[] throws;
    private static short[] case;
    private static long[] catch;
    private static int[] private;

    public synchronized void byte(String string) {
        if (!((Boolean)this.break[case[12]]).booleanValue()) {
            return;
        }
        this.byte();
        try {
            Path path;
            Path path2 = Paths.get(string, new String[byte[6]]);
            if (!Files.exists(path2, new LinkOption[byte[7]])) {
                Files.createDirectories(path2, new FileAttribute[byte[8]]);
            }
            if (!Files.exists(path = sw_1.class(path2, (Integer)this.break[case[13]], (Integer)this.break[case[14]]), new LinkOption[byte[9]])) {
                Files.createFile(path, new FileAttribute[byte[10]]);
            }
            try (FileOutputStream fileOutputStream = new FileOutputStream(path.toFile());
                 GZIPOutputStream gZIPOutputStream = new GZIPOutputStream((OutputStream)fileOutputStream, case[15]);
                 DataOutputStream dataOutputStream = new DataOutputStream(gZIPOutputStream);){
                Object object;
                int n2;
                int n3;
                dataOutputStream.writeInt(private[0]);
                for (n3 = byte[11]; n3 < protected[10]; ++n3) {
                    for (n2 = byte[12]; n2 < protected[11]; ++n2) {
                        st_1 st_12 = ((st_1[][])this.break[case[16]])[n3][n2];
                        if (st_12 == null) {
                            dataOutputStream.write(byte[13]);
                            continue;
                        }
                        dataOutputStream.write(byte[14]);
                        object = st_12.byte();
                        dataOutputStream.write((byte[])object);
                        dataOutputStream.write(new byte[case[17] - ((byte[])object).length]);
                    }
                }
                for (n3 = byte[15]; n3 < protected[12]; ++n3) {
                    for (n2 = byte[16]; n2 < protected[13]; ++n2) {
                        if (((st_1[][])this.break[case[18]])[n3][n2] == null) continue;
                        for (int k = byte[17]; k < case[19]; ++k) {
                            dataOutputStream.writeUTF(ri_1.class(((st_1[][])this.break[case[20]])[n3][n2].class()[k].break()));
                        }
                    }
                }
                for (n3 = byte[18]; n3 < protected[14]; ++n3) {
                    for (n2 = byte[19]; n2 < protected[15]; ++n2) {
                        if (((st_1[][])this.break[case[21]])[n3][n2] == null) continue;
                        Map<String, List<rfH>> map = ((st_1[][])this.break[case[22]])[n3][n2].break();
                        dataOutputStream.writeShort(map.entrySet().size());
                        object = map.entrySet().iterator();
                        while (object.hasNext()) {
                            Map.Entry entry = (Map.Entry)object.next();
                            dataOutputStream.writeUTF((String)entry.getKey());
                            dataOutputStream.writeShort(((List)entry.getValue()).size());
                            for (rfH rfH2 : (List)entry.getValue()) {
                                dataOutputStream.writeByte((byte)(rfH2.d_() << protected[16] | rfH2.b_()));
                                dataOutputStream.writeByte((byte)rfH2.c_());
                            }
                        }
                    }
                }
                for (n3 = byte[20]; n3 < protected[17]; ++n3) {
                    for (n2 = byte[21]; n2 < protected[18]; ++n2) {
                        if (((st_1[][])this.break[case[23]])[n3][n2] == null) continue;
                        dataOutputStream.writeLong((Long)((st_1[][])this.break[sw_1.case[24]])[n3][n2].break[case[25]]);
                    }
                }
            }
            Boolean bl2 = byte[22];
            this.break[sw_1.case[26]] = bl2;
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    public synchronized void byte() {
        long l2 = (Long)protected.class.instanceof().strictfp.class[case[37]];
        if (l2 < catch[2]) {
            return;
        }
        long l3 = System.currentTimeMillis();
        long l4 = l3 - l2 * catch[3];
        for (int k = byte[42]; k < protected[44]; ++k) {
            for (int i2 = byte[43]; i2 < protected[45]; ++i2) {
                if (((st_1[][])this.break[case[38]])[k][i2] == null || (Long)((st_1[][])this.break[sw_1.case[39]])[k][i2].break[case[40]] >= l4) continue;
                System.out.println("Removing chunk " + (k + protected[46] * (Integer)this.break[case[41]]) + "," + (i2 + protected[47] * (Integer)this.break[case[42]]) + " because it was cached " + (l3 - (Long)((st_1[][])this.break[sw_1.case[43]])[k][i2].break[case[44]]) / catch[4] + " seconds ago, and max age is " + l2);
                ((st_1[][])this.break[sw_1.case[45]])[k][i2] = null;
            }
        }
    }

    public sw_1(int n2, int n3, rqm_0<rYB> rqm_02) {
        rqm_0<rYB> rqm_03;
        st_1[][] st_1Array;
        this.private();
        this.break[sw_1.case[0]] = st_1Array = new st_1[protected[0]][protected[1]];
        Integer n4 = n2;
        this.break[sw_1.case[1]] = n4;
        Integer n5 = n3;
        this.break[sw_1.case[2]] = n5;
        Boolean bl2 = byte[0];
        this.break[sw_1.case[3]] = bl2;
        this.break[sw_1.case[4]] = rqm_03 = rqm_02;
    }

    static {
        sw_1.ntfClinit();
    }

    @Override
    public int class() {
        return (Integer)this.break[case[52]];
    }

    private static Path class(Path path, int n2, int n3) {
        String[] stringArray = new String[byte[46]];
        stringArray[sw_1.byte[47]] = "r." + n2 + "." + n3 + ".bcr";
        return Paths.get(path.toString(), stringArray);
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0x9A341802;
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0x63078CBC909A7FD4L;
    }

    @Override
    public boolean class(int n2, int n3) {
        return ((st_1[][])this.break[case[7]])[n2 >> protected[6]][n3 >> protected[7]] != null ? byte[1] : byte[2];
    }

    @Override
    public xc_0 class(int n2, int n3, int n4) {
        st_1 st_12 = ((st_1[][])this.break[case[5]])[n2 >> protected[2]][n4 >> protected[3]];
        if (st_12 != null) {
            return st_12.class(n2 & protected[4], n3, n4 & protected[5], (rqm_0)this.break[case[6]]);
        }
        return null;
    }

    public synchronized void class(int n2, int n3, st_1 st_12) {
        ((st_1[][])this.break[sw_1.case[10]])[n2][n3] = st_12;
        Boolean bl2 = byte[5];
        this.break[sw_1.case[11]] = bl2;
    }

    public synchronized void class(String string) {
        try {
            Path path;
            Path path2 = Paths.get(string, new String[byte[23]]);
            if (!Files.exists(path2, new LinkOption[byte[24]])) {
                Files.createDirectories(path2, new FileAttribute[byte[25]]);
            }
            if (!Files.exists(path = sw_1.class(path2, (Integer)this.break[case[27]], (Integer)this.break[case[28]]), new LinkOption[byte[26]])) {
                return;
            }
            long l2 = System.nanoTime() / catch[0];
            try (FileInputStream fileInputStream = new FileInputStream(path.toFile());
                 GZIPInputStream gZIPInputStream = new GZIPInputStream((InputStream)fileInputStream, private[1]);
                 DataInputStream dataInputStream = new DataInputStream(gZIPInputStream);){
                int n2;
                int n3;
                int n4;
                int n5 = dataInputStream.readInt();
                if (n5 != private[2]) {
                    throw new IOException("Bad magic value " + n5);
                }
                boolean[][] blArray = new boolean[protected[19]][protected[20]];
                BitSet[][] bitSetArray = new BitSet[protected[21]][protected[22]];
                Map[][] mapArray = new Map[protected[23]][protected[24]];
                xc_0[][][] xc_0Array = new xc_0[protected[25]][protected[26]][];
                long[][] lArray = new long[protected[27]][protected[28]];
                for (n4 = byte[27]; n4 < protected[29]; ++n4) {
                    block22: for (n3 = byte[28]; n3 < protected[30]; ++n3) {
                        n2 = dataInputStream.read();
                        switch (n2) {
                            case 1: {
                                byte[] byArray = new byte[case[29]];
                                dataInputStream.readFully(byArray);
                                bitSetArray[n4][n3] = BitSet.valueOf(byArray);
                                mapArray[n4][n3] = new HashMap();
                                xc_0Array[n4][n3] = new xc_0[case[30]];
                                blArray[n4][n3] = byte[29];
                                continue block22;
                            }
                            case 0: {
                                continue block22;
                            }
                            default: {
                                throw new IOException(throws[0]);
                            }
                        }
                    }
                }
                for (n4 = byte[30]; n4 < protected[31]; ++n4) {
                    for (n3 = byte[31]; n3 < protected[32]; ++n3) {
                        if (!blArray[n4][n3]) continue;
                        for (n2 = byte[32]; n2 < case[31]; ++n2) {
                            xc_0Array[n4][n3][n2] = ri_1.break(dataInputStream.readUTF()).continue();
                        }
                    }
                }
                for (n4 = byte[33]; n4 < protected[33]; ++n4) {
                    for (n3 = byte[34]; n3 < protected[34]; ++n3) {
                        if (!blArray[n4][n3]) continue;
                        n2 = dataInputStream.readShort() & private[3];
                        for (int k = byte[35]; k < n2; ++k) {
                            String string2 = dataInputStream.readUTF();
                            ri_1.break(string2);
                            ArrayList<rfH> arrayList = new ArrayList<rfH>();
                            mapArray[n4][n3].put(string2, arrayList);
                            int n6 = dataInputStream.readShort() & private[4];
                            if (n6 == 0) {
                                n6 = private[5];
                            }
                            for (int i2 = byte[36]; i2 < n6; ++i2) {
                                byte by = dataInputStream.readByte();
                                int n7 = by & protected[35];
                                int n8 = by >>> protected[36] & protected[37];
                                int n9 = dataInputStream.readByte() & case[32];
                                arrayList.add(new rfH(n7, n9, n8));
                            }
                        }
                    }
                }
                for (n4 = byte[37]; n4 < protected[38]; ++n4) {
                    for (n3 = byte[38]; n3 < protected[39]; ++n3) {
                        if (!blArray[n4][n3]) continue;
                        lArray[n4][n3] = dataInputStream.readLong();
                    }
                }
                for (n4 = byte[39]; n4 < protected[40]; ++n4) {
                    for (n3 = byte[40]; n3 < protected[41]; ++n3) {
                        if (!blArray[n4][n3]) continue;
                        n2 = (Integer)this.break[case[33]];
                        int n10 = (Integer)this.break[case[34]];
                        int n11 = n4 + protected[42] * n2;
                        int n12 = n3 + protected[43] * n10;
                        ((st_1[][])this.break[sw_1.case[35]])[n4][n3] = new st_1(n11, n12, bitSetArray[n4][n3], xc_0Array[n4][n3], mapArray[n4][n3], lArray[n4][n3]);
                    }
                }
            }
            this.byte();
            Boolean bl2 = byte[41];
            this.break[sw_1.case[36]] = bl2;
            long l3 = System.nanoTime() / catch[1];
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    @Override
    public int break() {
        return (Integer)this.break[case[51]];
    }

    public static String break(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{36, -107, -116, 120, 114, -56, 73, 69}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    private static void throws() {
        Object[] objectArray = new Object[]{(byte)0, (byte)1, 456022910};
        sw_1.class = objectArray;
    }

    private static /* synthetic */ void ntfClinit() {
        sw_1.catch();
        sw_1.implements();
        sw_1.native();
        sw_1.finally();
        sw_1.extends();
        sw_1.case();
        sw_1.throws();
    }

    private static void finally() {
        short[] sArray = new short[53];
        sArray[1] = 1;
        sArray[2] = 2;
        sArray[3] = 4;
        sArray[4] = 3;
        sArray[6] = 3;
        sArray[11] = 4;
        sArray[12] = 4;
        sArray[13] = 1;
        sArray[14] = 2;
        sArray[15] = 16384;
        sArray[17] = 16384;
        sArray[19] = 256;
        sArray[25] = 7;
        sArray[26] = 4;
        sArray[27] = 1;
        sArray[28] = 2;
        sArray[29] = 16384;
        sArray[30] = 256;
        sArray[31] = 256;
        sArray[32] = 255;
        sArray[33] = 1;
        sArray[34] = 2;
        sArray[36] = 4;
        sArray[40] = 7;
        sArray[41] = 1;
        sArray[42] = 2;
        sArray[44] = 7;
        sArray[48] = 7;
        sArray[49] = 7;
        sArray[51] = 1;
        sArray[52] = 2;
        case = sArray;
    }

    private static void catch() {
        boolean[] blArray = new boolean[56];
        blArray[1] = true;
        blArray[5] = true;
        blArray[14] = true;
        blArray[29] = true;
        blArray[46] = true;
        blArray[48] = true;
        blArray[54] = true;
        blArray[55] = true;
        byte = blArray;
    }

    private static void extends() {
        protected = new byte[]{32, 32, 4, 4, 15, 15, 4, 4, 32, 32, 32, 32, 32, 32, 32, 32, 4, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 15, 4, 15, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 5, 2, 4, 3, 2};
    }

    private static void case() {
        private = new int[]{456022910, 32768, 456022910, 65535, 65535, 65536, 456022910};
    }

    private static void implements() {
        throws = new String[]{new String("Malformed stream")};
    }

    public synchronized st_1 protected() {
        st_1 st_12 = null;
        for (int k = byte[44]; k < protected[48]; ++k) {
            for (int i2 = byte[45]; i2 < protected[49]; ++i2) {
                if (((st_1[][])this.break[case[46]])[k][i2] == null || st_12 != null && (Long)((st_1[][])this.break[sw_1.case[47]])[k][i2].break[case[48]] <= (Long)st_12.break[case[49]]) continue;
                st_12 = ((st_1[][])this.break[case[50]])[k][i2];
            }
        }
        return st_12;
    }

    public ArrayList<rfH> protected(String string) {
        ArrayList<rfH> arrayList = new ArrayList<rfH>();
        for (int k = byte[3]; k < protected[8]; ++k) {
            for (int i2 = byte[4]; i2 < protected[9]; ++i2) {
                ArrayList<rfH> arrayList2;
                if (((st_1[][])this.break[case[8]])[k][i2] == null || (arrayList2 = ((st_1[][])this.break[case[9]])[k][i2].class(string)) == null) continue;
                arrayList.addAll(arrayList2);
            }
        }
        return arrayList;
    }

    private void private() {
        if (this.break == null) {
            Object[] objectArray = this.break = new Object[protected[50]];
            objectArray[sw_1.byte[48]] = byte[49];
            objectArray[sw_1.protected[51]] = byte[50];
            objectArray[sw_1.protected[52]] = byte[51];
        }
    }

    private static void native() {
        long[] lArray = new long[5];
        lArray[0] = 1000000L;
        lArray[1] = 1000000L;
        lArray[3] = 1000L;
        lArray[4] = 1000L;
        catch = lArray;
    }
}

