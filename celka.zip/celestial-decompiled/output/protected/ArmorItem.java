/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableMultimap
 *  com.google.common.collect.ImmutableMultimap$Builder
 *  com.google.common.collect.Multimap
 */
package protected;

import com.google.common.collect.ImmutableMultimap;
import com.google.common.collect.Multimap;
import java.util.List;
import java.util.UUID;
import protected.UT;
import protected.Uq;
import protected.an;
import protected.dq_2;
import protected.eU;
import protected.ib_0;
import protected.id_0;
import protected.ij_0;
import protected.iq_0;
import protected.is;
import protected.ix_0;
import protected.rYB;
import protected.rdb_1;
import protected.rdb_2;
import protected.rdn_1;
import protected.rdo_2;
import protected.rfH;
import protected.rfl;
import protected.rhd_2;
import protected.rpj_0;
import protected.rpm;
import protected.rpx;
import protected.rxe_0;
import protected.rxq_1;
import protected.rxs_0;
import protected.rym_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class rxS
extends rdb_1
implements eU {
    private static final UUID[] finally = new UUID[]{UUID.fromString("845DB27C-C624-495F-8C9F-6020A9A58B6B"), UUID.fromString("D8499B04-0E66-4726-AB29-64469D734E0D"), UUID.fromString("9F3D476D-C118-4544-8365-64846904B48E"), UUID.fromString("2AD3F246-FEE1-4E67-B886-69FD380BB150")};
    public static final UT class = new rxs_0();
    protected final rxq_1 break;
    private final int extends;
    private final float native;
    protected final float byte;
    protected final rdb_2 protected;
    private final Multimap<ij_0, ix_0> volatile;

    public rxq_1 byte() {
        return this.break;
    }

    public rxS(rdb_2 rdb_22, rxq_1 rxq_12, rdo_2 rdo_22) {
        super(rdo_22.break(rdb_22.class(rxq_12)));
        this.protected = rdb_22;
        this.break = rxq_12;
        this.extends = rdb_22.break(rxq_12);
        this.native = rdb_22.throws();
        this.byte = rdb_22.case();
        dq_2.class(this, rxS.class);
        ImmutableMultimap.Builder builder = ImmutableMultimap.builder();
        UUID uUID = finally[rxq_12.break()];
        builder.put((Object)iq_0.implements, (Object)new ix_0(uUID, "Armor modifier", (double)this.extends, id_0.ADDITION));
        builder.put((Object)iq_0.finally, (Object)new ix_0(uUID, "Armor toughness", (double)this.native, id_0.ADDITION));
        if (rdb_22 == rxe_0.NETHERITE) {
            builder.put((Object)iq_0.byte, (Object)new ix_0(uUID, "Armor knockback resistance", (double)this.byte, id_0.ADDITION));
        }
        this.volatile = builder.build();
    }

    @Override
    public rym_1<rdn_1> class(rYB rYB2, rhd_2 rhd_22, rpm rpm2) {
        rdn_1 rdn_12 = rhd_22.protected(rpm2);
        rxq_1 rxq_12 = is.finally(rdn_12);
        rdn_1 rdn_13 = rhd_22.class(rxq_12);
        if (rdn_13.class()) {
            rhd_22.class(rxq_12, rdn_12.implements());
            rdn_12.throws(0);
            return rym_1.class(rdn_12, rYB2.import());
        }
        return rym_1.protected(rdn_12);
    }

    @Override
    public Multimap<ij_0, ix_0> class(rxq_1 rxq_12) {
        return rxq_12 == this.break ? this.volatile : super.class(rxq_12);
    }

    public static boolean class(Uq uq, rdn_1 rdn_12) {
        rfH rfH2 = uq.protected().break(uq.throws().byte(dq_2.volatile));
        List<an> list = uq.catch().class(ib_0.class, new rfl(rfH2), rpj_0.catch.and(new rpx(rdn_12)));
        if (list.isEmpty()) {
            return false;
        }
        ib_0 ib_02 = (ib_0)list.get(0);
        rxq_1 rxq_12 = is.finally(rdn_12);
        rdn_1 rdn_13 = rdn_12.class(1);
        ib_02.class(rxq_12, rdn_13);
        if (ib_02 instanceof is) {
            ((is)ib_02).class(rxq_12, 2.0f);
            ((is)ib_02).b();
        }
        return true;
    }

    @Override
    public boolean class(rdn_1 rdn_12, rdn_1 rdn_13) {
        return this.protected.byte().class(rdn_13) || super.class(rdn_12, rdn_13);
    }

    public rdb_2 throws() {
        return this.protected;
    }

    public int catch() {
        return this.extends;
    }

    @Override
    public int protected() {
        return this.protected.class();
    }

    public float private() {
        return this.native;
    }
}

