/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.ib_0;
import protected.iq_1;
import protected.is;
import protected.iy_2;
import protected.ml_1;
import protected.rdn_1;
import protected.rdy_2;
import protected.rfU;
import protected.rpZ;
import protected.rpm;
import protected.tq_0;
import protected.tw_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.wL
 */
public class wl_0<T extends is>
extends tw_1<T> {
    public wl_0() {
        this(0.0f, false);
    }

    public wl_0(float f2, boolean bl2) {
        super(f2);
        if (!bl2) {
            this.protected = new iq_1(this, 40, 16);
            this.protected.class(-1.0f, -2.0f, -1.0f, 2.0f, 12.0f, 2.0f, f2);
            this.protected.class(-5.0f, 2.0f, 0.0f);
            this.throws = new iq_1(this, 40, 16);
            this.throws.implements = true;
            this.throws.class(-1.0f, -2.0f, -1.0f, 2.0f, 12.0f, 2.0f, f2);
            this.throws.class(5.0f, 2.0f, 0.0f);
            this.case = new iq_1(this, 0, 16);
            this.case.class(-1.0f, 0.0f, -1.0f, 2.0f, 12.0f, 2.0f, f2);
            this.case.class(-2.0f, 12.0f, 0.0f);
            this.catch = new iq_1(this, 0, 16);
            this.catch.implements = true;
            this.catch.class(-1.0f, 0.0f, -1.0f, 2.0f, 12.0f, 2.0f, f2);
            this.catch.class(2.0f, 12.0f, 0.0f);
        }
    }

    @Override
    public void class(rpZ rpZ2, ml_1 ml_12) {
        float f2 = rpZ2 == rpZ.RIGHT ? 1.0f : -1.0f;
        iq_1 iq_12 = this.class(rpZ2);
        iq_12.byte += f2;
        iq_12.class(ml_12);
        iq_12.byte -= f2;
    }

    @Override
    public void class(T t2, float f2, float f3, float f4, float f5, float f6) {
        super.class(t2, f2, f3, f4, f5, f6);
        rdn_1 rdn_12 = ((ib_0)t2).ss();
        if (((is)t2).v() && (rdn_12.class() || rdn_12.break() != rdy_2.OM)) {
            float f7 = rfU.class(this.final * (float)Math.PI);
            float f8 = rfU.class((1.0f - (1.0f - this.final) * (1.0f - this.final)) * (float)Math.PI);
            this.protected.private = 0.0f;
            this.throws.private = 0.0f;
            this.protected.catch = -(0.1f - f7 * 0.6f);
            this.throws.catch = 0.1f - f7 * 0.6f;
            this.protected.case = -1.5707964f;
            this.throws.case = -1.5707964f;
            this.protected.case -= f7 * 1.2f - f8 * 0.4f;
            this.throws.case -= f7 * 1.2f - f8 * 0.4f;
            iy_2.class(this.protected, this.throws, f4);
        }
    }

    @Override
    public void class(T t2, float f2, float f3, float f4) {
        this.implements = tq_0.EMPTY;
        this.private = tq_0.EMPTY;
        rdn_1 rdn_12 = ((ib_0)t2).protected(rpm.MAIN_HAND);
        if (rdn_12.break() == rdy_2.OM && ((is)t2).v()) {
            if (((is)t2).Su() == rpZ.RIGHT) {
                this.implements = tq_0.BOW_AND_ARROW;
            } else {
                this.private = tq_0.BOW_AND_ARROW;
            }
        }
        super.class(t2, f2, f3, f4);
    }
}

