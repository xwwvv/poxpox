/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.regex.Pattern;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.bh_2;
import protected.bn_2;
import protected.sx_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.SJ
 */
public class sj_2
extends bn_2 {
    private static boolean[] protected;
    private static short[] throws;
    public Object[] byte;
    private static String[] case;

    public sj_2() {
        super(case[0], (Pattern[])bh_2.class[throws[0]]);
        this.extends();
    }

    static {
        sj_2.ntfClinit();
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0x66435B911CB55B8FL;
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0x4CBD2DDF;
    }

    @Override
    public void throws(String string) {
        this.extends();
        super.throws(string);
        sx_2 sx_22 = sx_2.break(string);
        this.byte[sj_2.throws[1]] = sx_22;
        if ((sx_2)((Object)this.byte[throws[2]]) != null) {
            this.protected(((sx_2)((Object)this.byte[throws[3]])).class() + " " + this.throws().toLowerCase());
        }
    }

    private static /* synthetic */ void ntfClinit() {
        sj_2.finally();
        sj_2.implements();
        sj_2.private();
    }

    private static void finally() {
        protected = new boolean[]{true};
    }

    public sx_2 catch() {
        this.extends();
        return (sx_2)((Object)this.byte[throws[4]]);
    }

    public static String catch(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{65, 50, -34, 93, 115, -35, 102, 23}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    private void extends() {
        if (this.byte == null) {
            Object[] objectArray = this.byte = new Object[protected[0]];
        }
    }

    private static void implements() {
        case = new String[]{new String("\u0410\u0438\u0440-\u0434\u0440\u043e\u043f")};
    }

    private static void private() {
        short[] sArray = new short[5];
        sArray[0] = 4;
        throws = sArray;
    }
}

