/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.bd_1;
import protected.class;
import protected.pv_2;
import protected.rVi;
import protected.rgP;
import protected.rgn_0;
import protected.rnb_0;
import protected.rrfp;
import protected.rrfq;
import protected.rrlf_2;
import protected.rrlv_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.Bx
 */
public class bx_1
extends pv_2 {
    private static byte[] byte;
    private static short[] protected;
    private static boolean[] throws;
    public static Object[] break;
    private static String[] case;

    private static void byte() {
        Object[] objectArray = new Object[]{new bd_1(), Map.of(case[2], case[3]), Map.of(case[4], case[5], case[6], case[7])};
        break = objectArray;
    }

    public bx_1(class clazz) {
        super(clazz);
    }

    static {
        bx_1.ntfClinit();
    }

    @Override
    public void class(rrlf_2 rrlf_22) {
        if (!this.case()) {
            return;
        }
        rnb_0 rnb_02 = rrlf_22.break();
        rgP rgP2 = rrlf_22.class();
        String string = rgP2.getString();
        if (rnb_02.class() != null && rnb_02.class().contains(case[1])) {
            return;
        }
        if (!rgP2.protected().isEmpty()) {
            return;
        }
        for (Map.Entry entry : ((Map)break[protected[2]]).entrySet()) {
            String string2 = (String)entry.getKey();
            String string3 = (String)entry.getValue();
            if (!string.equals(string2)) continue;
            string = string.replace(string2, string3);
        }
        rrlf_22.class(string.isEmpty() ? rgn_0.byte : new rgn_0(string));
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0xF53A0C54EDBFB1B2L;
    }

    private static void class() {
        short[] sArray = new short[7];
        sArray[1] = 1;
        sArray[2] = 2;
        sArray[3] = 1;
        sArray[4] = 2;
        sArray[5] = 1;
        protected = sArray;
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0x2B704818;
    }

    @Override
    public void class(rrlv_2 rrlv_22) {
        Object object;
        if (!this.case()) {
            return;
        }
        rnb_0 rnb_02 = rrlv_22.break();
        rgP rgP2 = rrlv_22.class();
        String string = rgP2.getString();
        if (string.isEmpty() || rnb_02.class() != null && rnb_02.class().contains(case[0])) {
            return;
        }
        rVi rVi2 = rgP2.throws();
        if (rVi2 instanceof rgn_0) {
            rgn_0 rgn_02 = (rgn_0)rVi2;
            object = rgn_02.private();
            for (Map.Entry entry : ((Map)break[protected[0]]).entrySet()) {
                String string2 = (String)entry.getKey();
                String string3 = (String)entry.getValue();
                if (!((String)object).contains(string2)) continue;
                object = ((String)object).replace(string2, string3);
            }
            rVi2 = new rgn_0((String)object);
        }
        for (int k = throws[0]; k < rgP2.protected().size(); ++k) {
            object = rgP2.protected().get(k);
            String string4 = object.getString();
            if (string4.isBlank() || ((Map)break[protected[1]]).containsKey(string4)) continue;
            rVi2.class((rgP)object);
            rVi2.class(object.class());
        }
        rrlv_22.class(rVi2);
    }

    public static String break(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{-1, 6, 109, -9, -98, -45, 55, 36}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    private static void break() {
        case = new String[]{new String("-"), new String("-"), new String("\u25cf"), new String(""), new String(" \u00a7e"), new String(""), new String(" \u00a7r"), new String("")};
    }

    private static void throws() {
        boolean[] blArray = new boolean[5];
        blArray[1] = true;
        blArray[4] = true;
        throws = blArray;
    }

    private static /* synthetic */ void ntfClinit() {
        bx_1.throws();
        bx_1.break();
        bx_1.class();
        bx_1.protected();
        bx_1.byte();
    }

    private boolean case() {
        return (rrfq)((Object)rrfp.class[protected[3]]) == (rrfq)((Object)rrfq.staticFields8f8c034c8eef39ccbbc33e665d937d16[protected[4]]) || (rrfq)((Object)rrfp.class[protected[5]]) == (rrfq)((Object)rrfq.staticFields8f8c034c8eef39ccbbc33e665d937d16[protected[6]]) ? throws[1] : throws[2];
    }

    private static void protected() {
        byte = new byte[]{2, 3};
    }
}

