/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.LinkedList;
import java.util.ListIterator;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.bl;
import protected.bp;
import protected.class;
import protected.ro_1;
import protected.rpr_0;
import protected.ru_1;
import protected.ry_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.by
 */
public class by_0
implements ro_1 {
    private static byte[] break;
    private static boolean[] byte;
    private static short[] protected;
    public Object[] class;

    @Override
    public ry_1[] byte() {
        return (ry_1[])this.class[protected[7]];
    }

    @Override
    public synchronized ry_1 byte(ry_1 ry_12, rpr_0 rpr_02, int n2) {
        ListIterator<ry_1> listIterator = ((LinkedList)this.class[protected[13]]).listIterator();
        while (listIterator.hasNext()) {
            ry_1 ry_13 = (ry_1)listIterator.next();
            if (ry_13 != ry_12) continue;
            listIterator.remove();
            listIterator.add(ry_13.class(rpr_02, n2));
            this.implements();
            return (ry_1)listIterator.previous();
        }
        return null;
    }

    public by_0(class clazz) {
        ry_1[] ry_1Array;
        LinkedList linkedList;
        this.finally();
        this.class[by_0.protected[0]] = linkedList = new LinkedList();
        this.class[by_0.protected[1]] = ry_1Array = new ry_1[byte[0]];
        new bp(clazz, this);
    }

    static {
        by_0.ntfClinit();
    }

    @Override
    public void class() {
        ((LinkedList)this.class[protected[14]]).clear();
        this.implements();
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0x4E6E49D5482DC03CL;
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0x4976CCA;
    }

    @Override
    public ry_1 class(ru_1 ru_12, ru_1 ru_13) {
        return this.break(new bl(ru_12, ru_13));
    }

    public static String class(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{-91, 115, 107, 48, -51, 107, 10, 74}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    @Override
    public synchronized ry_1 class(ry_1 ry_12, rpr_0 rpr_02, int n2) {
        ListIterator<ry_1> listIterator = ((LinkedList)this.class[protected[11]]).listIterator();
        while (listIterator.hasNext()) {
            ry_1 ry_13 = (ry_1)listIterator.next();
            if (ry_13 != ry_12) continue;
            listIterator.remove();
            listIterator.add(ry_13.byte(rpr_02, n2));
            this.implements();
            return (ry_1)listIterator.previous();
        }
        return null;
    }

    @Override
    public synchronized ry_1 class(ry_1 ry_12) {
        ((LinkedList)this.class[protected[5]]).remove(ry_12);
        this.implements();
        return ry_12;
    }

    @Override
    public synchronized ry_1 break(ry_1 ry_12) {
        ((LinkedList)this.class[protected[4]]).add(ry_12);
        this.implements();
        return ry_12;
    }

    @Override
    public ry_1 break() {
        return (ry_1)((LinkedList)this.class[protected[10]]).peekLast();
    }

    @Override
    public synchronized ry_1 break(ry_1 ry_12, rpr_0 rpr_02, int n2) {
        ListIterator<ry_1> listIterator = ((LinkedList)this.class[protected[12]]).listIterator();
        while (listIterator.hasNext()) {
            ry_1 ry_13 = (ry_1)listIterator.next();
            if (ry_13 != ry_12) continue;
            listIterator.remove();
            listIterator.add(ry_13.break(rpr_02, n2));
            this.implements();
            return (ry_1)listIterator.previous();
        }
        return null;
    }

    @Override
    public synchronized ry_1[] throws() {
        ry_1[] ry_1Array = this.byte();
        ((LinkedList)this.class[protected[6]]).clear();
        this.implements();
        return ry_1Array;
    }

    private static /* synthetic */ void ntfClinit() {
        by_0.catch();
        by_0.private();
        by_0.case();
    }

    private void finally() {
        if (this.class == null) {
            Object[] objectArray = this.class = new Object[break[0]];
        }
    }

    private static void catch() {
        boolean[] blArray = new boolean[3];
        blArray[2] = true;
        byte = blArray;
    }

    private static void case() {
        break = new byte[]{2};
    }

    private void implements() {
        ry_1[] ry_1Array;
        this.class[by_0.protected[3]] = ry_1Array = ((LinkedList)this.class[protected[2]]).toArray(new ry_1[byte[1]]);
    }

    @Override
    public synchronized ry_1 protected() {
        if (((LinkedList)this.class[protected[8]]).size() == byte[2]) {
            return (ry_1)((LinkedList)this.class[protected[9]]).peekFirst();
        }
        return null;
    }

    private static void private() {
        short[] sArray = new short[15];
        sArray[1] = 1;
        sArray[3] = 1;
        sArray[7] = 1;
        protected = sArray;
    }
}

