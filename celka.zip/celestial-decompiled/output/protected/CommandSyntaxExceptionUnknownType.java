/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.u_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.z
 */
public class z_0
extends u_0 {
    private static boolean[] class;
    private static String[] break;

    public z_0(Class<?> clazz) {
        Object[] objectArray = new Object[z_0.class[0]];
        objectArray[z_0.class[1]] = clazz.getSimpleName();
        super(String.format(break[0], objectArray));
    }

    static {
        z_0.ntfClinit();
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0x3FC534FDEA3A7A9FL;
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0xE881A71B;
    }

    private static void class() {
        boolean[] blArray = new boolean[2];
        blArray[0] = true;
        z_0.class = blArray;
    }

    public static String class(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{-24, -79, -14, -1, 10, -127, 48, -67}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    private static void break() {
        break = new String[]{new String("\u041d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u043d\u0430\u0439\u0442\u0438 \u043e\u0431\u0440\u0430\u0431\u043e\u0442\u0447\u0438\u043a \u0434\u043b\u044f \u0442\u0438\u043f\u0430 %s")};
    }

    private static /* synthetic */ void ntfClinit() {
        z_0.class();
        z_0.break();
    }
}

