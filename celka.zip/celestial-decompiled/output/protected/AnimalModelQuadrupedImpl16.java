/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.au_0;
import protected.iq_1;
import protected.rfU;
import protected.rml_1;
import protected.wk_0;
import protected.wp_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.wS
 */
public class ws_0<T extends rml_1>
extends wk_0<T> {
    private float catch;
    private float private;
    private float implements;

    public ws_0(int n2, float f2) {
        super(n2, f2, true, 23.0f, 4.8f, 2.7f, 3.0f, 49);
        this.return = 64;
        this.public = 64;
        this.class = new iq_1(this, 0, 6);
        this.class.class(-6.5f, -5.0f, -4.0f, 13.0f, 10.0f, 9.0f);
        this.class.class(0.0f, 11.5f, -17.0f);
        this.class.class(45, 16).class(-3.5f, 0.0f, -6.0f, 7.0f, 5.0f, 2.0f);
        this.class.class(52, 25).class(-8.5f, -8.0f, -1.0f, 5.0f, 4.0f, 1.0f);
        this.class.class(52, 25).class(3.5f, -8.0f, -1.0f, 5.0f, 4.0f, 1.0f);
        this.break = new iq_1(this, 0, 25);
        this.break.class(-9.5f, -13.0f, -6.5f, 19.0f, 26.0f, 13.0f);
        this.break.class(0.0f, 10.0f, 0.0f);
        int n3 = 9;
        int n4 = 6;
        this.byte = new iq_1(this, 40, 0);
        this.byte.class(-3.0f, 0.0f, -3.0f, 6.0f, 9.0f, 6.0f);
        this.byte.class(-5.5f, 15.0f, 9.0f);
        this.protected = new iq_1(this, 40, 0);
        this.protected.class(-3.0f, 0.0f, -3.0f, 6.0f, 9.0f, 6.0f);
        this.protected.class(5.5f, 15.0f, 9.0f);
        this.throws = new iq_1(this, 40, 0);
        this.throws.class(-3.0f, 0.0f, -3.0f, 6.0f, 9.0f, 6.0f);
        this.throws.class(-5.5f, 15.0f, -9.0f);
        this.case = new iq_1(this, 40, 0);
        this.case.class(-3.0f, 0.0f, -3.0f, 6.0f, 9.0f, 6.0f);
        this.case.class(5.5f, 15.0f, -9.0f);
    }

    @Override
    public void class(T t2, float f2, float f3, float f4, float f5, float f6) {
        super.class(t2, f2, f3, f4, f5, f6);
        boolean bl2 = ((rml_1)t2).L() > 0;
        boolean bl3 = ((rml_1)t2).n();
        int n2 = ((rml_1)t2).sc();
        boolean bl4 = ((rml_1)t2).sd();
        boolean bl5 = ((rml_1)t2).sl();
        if (bl2) {
            this.class.catch = 0.35f * rfU.class(0.6f * f4);
            this.class.private = 0.35f * rfU.class(0.6f * f4);
            this.throws.case = -0.75f * rfU.class(0.3f * f4);
            this.case.case = 0.75f * rfU.class(0.3f * f4);
        } else {
            this.class.private = 0.0f;
        }
        if (bl3) {
            if (n2 < 15) {
                this.class.case = -0.7853982f * (float)n2 / 14.0f;
            } else if (n2 < 20) {
                float f7 = (n2 - 15) / 5;
                this.class.case = -0.7853982f + 0.7853982f * f7;
            }
        }
        if (this.catch > 0.0f) {
            this.break.case = wp_0.class(this.break.case, 1.7407963f, this.catch);
            this.class.case = wp_0.class(this.class.case, 1.5707964f, this.catch);
            this.throws.private = -0.27079642f;
            this.case.private = 0.27079642f;
            this.byte.private = 0.5707964f;
            this.protected.private = -0.5707964f;
            if (bl4) {
                this.class.case = 1.5707964f + 0.2f * rfU.class(f4 * 0.6f);
                this.throws.case = -0.4f - 0.2f * rfU.class(f4 * 0.6f);
                this.case.case = -0.4f - 0.2f * rfU.class(f4 * 0.6f);
            }
            if (bl5) {
                this.class.case = 2.1707964f;
                this.throws.case = -0.9f;
                this.case.case = -0.9f;
            }
        } else {
            this.byte.private = 0.0f;
            this.protected.private = 0.0f;
            this.throws.private = 0.0f;
            this.case.private = 0.0f;
        }
        if (this.private > 0.0f) {
            this.byte.case = -0.6f * rfU.class(f4 * 0.15f);
            this.protected.case = 0.6f * rfU.class(f4 * 0.15f);
            this.throws.case = 0.3f * rfU.class(f4 * 0.25f);
            this.case.case = -0.3f * rfU.class(f4 * 0.25f);
            this.class.case = wp_0.class(this.class.case, 1.5707964f, this.private);
        }
        if (this.implements > 0.0f) {
            this.class.case = wp_0.class(this.class.case, 2.0561945f, this.implements);
            this.byte.case = -0.5f * rfU.class(f4 * 0.5f);
            this.protected.case = 0.5f * rfU.class(f4 * 0.5f);
            this.throws.case = 0.5f * rfU.class(f4 * 0.5f);
            this.case.case = -0.5f * rfU.class(f4 * 0.5f);
        }
    }

    @Override
    public void class(T t2, float f2, float f3, float f4) {
        super.class(t2, f2, f3, f4);
        this.catch = ((rml_1)t2).throw(f4);
        this.private = ((rml_1)t2).interface(f4);
        this.implements = ((au_0)t2).n_() ? 0.0f : ((rml_1)t2).char(f4);
    }
}

