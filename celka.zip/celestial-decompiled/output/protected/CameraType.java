/*
 * Decompiled with CFR 0.152.
 */
package protected;

@FunctionalInterface
public interface VY {
    public boolean test(char var1);
}

