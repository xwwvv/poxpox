/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.regex.Pattern;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.bl_2;
import protected.bn_2;
import protected.bv_2;
import protected.by_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.Bj
 */
public class bj_2
extends bn_2
implements by_1 {
    private static String[] protected;
    public Object[] byte;
    private static short[] throws;
    private static boolean[] case;

    public bj_2() {
        super(protected[0], (Pattern[])bl_2.class[throws[0]]);
        this.finally();
    }

    static {
        bj_2.ntfClinit();
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0x4A97529B933612FDL;
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0x1D4079EE;
    }

    @Override
    public String class() {
        this.finally();
        if ((bv_2)((Object)this.byte[throws[4]]) == null) {
            return null;
        }
        return ((bv_2)((Object)this.byte[throws[5]])).class();
    }

    @Override
    public void throws(String string) {
        this.finally();
        super.throws(string);
        bv_2 bv_22 = bv_2.break(string);
        this.byte[bj_2.throws[1]] = bv_22;
        if ((bv_2)((Object)this.byte[throws[2]]) != null) {
            this.protected(((bv_2)((Object)this.byte[throws[3]])).class() + " " + this.throws().toLowerCase());
        }
    }

    private static /* synthetic */ void ntfClinit() {
        bj_2.catch();
        bj_2.private();
        bj_2.implements();
    }

    private void finally() {
        if (this.byte == null) {
            Object[] objectArray = this.byte = new Object[case[0]];
        }
    }

    public static String catch(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{66, 50, -67, 87, -42, 3, 12, 66}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    private static void catch() {
        case = new boolean[]{true};
    }

    private static void implements() {
        short[] sArray = new short[6];
        sArray[0] = 20;
        throws = sArray;
    }

    private static void private() {
        protected = new String[]{new String("\u0410\u043b\u0442\u0430\u0440\u044c")};
    }
}

