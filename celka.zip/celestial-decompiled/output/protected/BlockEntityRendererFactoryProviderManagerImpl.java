/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 *  com.google.common.collect.Maps
 *  com.google.common.collect.Sets
 */
package protected;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.mojang.blaze3d.systems.RenderSystem;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;
import protected.Hx;
import protected.cb_1;
import protected.ex_0;
import protected.gm;
import protected.hh_0;
import protected.ly_0;
import protected.ml_1;
import protected.ps;
import protected.qy_1;
import protected.rfH;
import protected.rfU;
import protected.rja;
import protected.rqg_0;
import protected.yd_2;
import protected.yf_1;
import protected.yj_2;
import protected.yk_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.yI
 */
public class yi_2
implements yd_2 {
    private final qy_1 class;
    private final Map<rfH, yj_2> break = Maps.newHashMap();
    private final Map<UUID, yf_1> byte = Maps.newHashMap();
    private UUID protected;

    private void byte() {
        long l2 = ((gm)this.class.class[56]).r() - 20L;
        this.break.entrySet().removeIf(entry -> ((yj_2)entry.getValue()).case < l2);
    }

    private void byte(yf_1 yf_12) {
        boolean bl2 = this.protected(yf_12);
        int n2 = 0;
        yi_2.class(yf_12.byte, n2++, yf_12.toString(), -1, 0.03f);
        if (yf_12.throws == null) {
            yi_2.class(yf_12.byte, n2++, "No hive", -98404, 0.02f);
        } else {
            yi_2.class(yf_12.byte, n2++, "Hive: " + this.class(yf_12, yf_12.throws), -256, 0.02f);
        }
        if (yf_12.case == null) {
            yi_2.class(yf_12.byte, n2++, "No flower", -98404, 0.02f);
        } else {
            yi_2.class(yf_12.byte, n2++, "Flower: " + this.class(yf_12, yf_12.case), -256, 0.02f);
        }
        for (String string : yf_12.private) {
            yi_2.class(yf_12.byte, n2++, string, -16711936, 0.02f);
        }
        if (bl2) {
            this.break(yf_12);
        }
        if (yf_12.catch > 0) {
            int n3 = yf_12.catch < 600 ? -3355444 : -23296;
            yi_2.class(yf_12.byte, n2++, "Travelling: " + yf_12.catch + " ticks", n3, 0.02f);
        }
    }

    public yi_2(qy_1 qy_12) {
        this.class = qy_12;
    }

    private static void class(ex_0 ex_02, int n2, String string, int n3, float f2) {
        double d = 2.4;
        double d2 = 0.25;
        rfH rfH2 = new rfH(ex_02);
        double d3 = (double)rfH2.b_() + 0.5;
        double d4 = ex_02.break() + 2.4 + (double)n2 * 0.25;
        double d5 = (double)rfH2.d_() + 0.5;
        float f3 = 0.5f;
        yk_2.class(string, d3, d4, d5, n3, f2, false, 0.5f, true);
    }

    private static void class(String string, rfH rfH2, int n2, int n3) {
        double d = 1.3;
        double d2 = 0.2;
        double d3 = (double)rfH2.b_() + 0.5;
        double d4 = (double)rfH2.c_() + 1.3 + (double)n2 * 0.2;
        double d5 = (double)rfH2.d_() + 0.5;
        yk_2.class(string, d3, d4, d5, n3, 0.02f, true, 0.0f, true);
    }

    private static void class(rfH rfH2, float f2, float f3, float f4, float f5, float f6) {
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        yk_2.class(rfH2, f2, f3, f4, f5, f6);
    }

    private static void class(String string, yj_2 yj_22, int n2, int n3) {
        rfH rfH2 = yj_22.class;
        yi_2.class(string, rfH2, n2, n3);
    }

    private void class(yj_2 yj_22, Collection<UUID> collection) {
        int n2 = 0;
        if (!collection.isEmpty()) {
            yi_2.class("Blacklisted by " + yi_2.class(collection), yj_22, n2++, -65536);
        }
        yi_2.class("Out: " + yi_2.class(this.break(yj_22.class)), yj_22, n2++, -3355444);
        if (yj_22.byte == 0) {
            yi_2.class("In: -", yj_22, n2++, -256);
        } else if (yj_22.byte == 1) {
            yi_2.class("In: 1 bee", yj_22, n2++, -256);
        } else {
            yi_2.class("In: " + yj_22.byte + " bees", yj_22, n2++, -256);
        }
        yi_2.class("Honey: " + yj_22.protected, yj_22, n2++, -23296);
        yi_2.class(yj_22.break + (yj_22.throws ? " (sedated)" : ""), yj_22, n2++, -1);
    }

    private String class(yf_1 yf_12, rfH rfH2) {
        float f2 = rfU.class(rfH2.class(yf_12.byte.class(), yf_12.byte.break(), yf_12.byte.byte(), true));
        double d = (double)Math.round(f2 * 10.0f) / 10.0;
        return rfH2.this() + " (dist " + d + ")";
    }

    @Override
    public void class(ml_1 ml_12, Hx hx, double d, double d2, double d3) {
        RenderSystem.pushMatrix();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableTexture();
        this.byte();
        this.break();
        this.protected();
        RenderSystem.enableTexture();
        RenderSystem.disableBlend();
        RenderSystem.popMatrix();
        if (!((cb_1)this.class.class[57]).native()) {
            this.implements();
        }
    }

    public void class(yf_1 yf_12) {
        this.byte.put(yf_12.class, yf_12);
    }

    public void class(yj_2 yj_22) {
        this.break.put(yj_22.class, yj_22);
    }

    @Override
    public void class() {
        this.break.clear();
        this.byte.clear();
        this.protected = null;
    }

    private void class(rfH rfH2, List<String> list) {
        float f2 = 0.05f;
        yi_2.class(rfH2, 0.05f, 0.2f, 0.2f, 1.0f, 0.3f);
        yi_2.class("" + list, rfH2, 0, -256);
        yi_2.class("Ghost Hive", rfH2, 1, -65536);
    }

    private static void class(rfH rfH2) {
        float f2 = 0.05f;
        yi_2.class(rfH2, 0.05f, 0.2f, 0.2f, 1.0f, 0.3f);
    }

    private static String class(Collection<UUID> collection) {
        if (collection.isEmpty()) {
            return "-";
        }
        return collection.size() > 3 ? collection.size() + " bees" : collection.stream().map(rqg_0::class).collect(Collectors.toSet()).toString();
    }

    private Collection<UUID> break(rfH rfH2) {
        return this.byte.values().stream().filter(yf_12 -> yf_12.class(rfH2)).map(yf_1::class).collect(Collectors.toSet());
    }

    private void break() {
        this.byte.entrySet().removeIf(entry -> ((gm)this.class.class[56]).break(((yf_1)entry.getValue()).break) == null);
    }

    private void break(yf_1 yf_12) {
        if (yf_12.protected != null) {
            ps.class(yf_12.protected, 0.5f, false, false, this.catch().break().class(), this.catch().break().break(), this.catch().break().byte());
        }
    }

    private Map<rfH, Set<UUID>> throws() {
        HashMap hashMap = Maps.newHashMap();
        this.byte.values().forEach(yf_12 -> yf_12.implements.forEach(rfH3 -> hashMap.computeIfAbsent(rfH3, rfH2 -> Sets.newHashSet()).add(yf_12.class())));
        return hashMap;
    }

    private boolean throws(yf_1 yf_12) {
        cb_1 cb_12 = (cb_1)this.class.class[57];
        rfH rfH2 = new rfH(cb_12.rx(), yf_12.byte.break(), cb_12.BO());
        rfH rfH3 = new rfH(yf_12.byte);
        return rfH2.class(rfH3, 30.0);
    }

    private ly_0 catch() {
        return ((hh_0)this.class.class[16]).finally();
    }

    private void case() {
        HashMap hashMap = Maps.newHashMap();
        this.byte.values().stream().filter(yf_1::byte).forEach(yf_12 -> hashMap.computeIfAbsent(yf_12.case, rfH2 -> Sets.newHashSet()).add(yf_12.class()));
        hashMap.entrySet().forEach(entry -> {
            rfH rfH2 = (rfH)entry.getKey();
            Set set = (Set)entry.getValue();
            Set set2 = set.stream().map(rqg_0::class).collect(Collectors.toSet());
            int n2 = 1;
            yi_2.class(set2.toString(), rfH2, n2++, -256);
            yi_2.class("Flower", rfH2, n2++, -1);
            float f2 = 0.05f;
            yi_2.class(rfH2, 0.05f, 0.8f, 0.8f, 0.0f, 0.3f);
        });
    }

    private void implements() {
        yk_2.class(this.class.catch(), 8).ifPresent(an2 -> {
            this.protected = an2.ro();
        });
    }

    private void protected() {
        rfH rfH2 = this.catch().byte();
        this.byte.values().forEach(yf_12 -> {
            if (this.throws((yf_1)yf_12)) {
                this.byte((yf_1)yf_12);
            }
        });
        this.case();
        for (rfH rfH4 : this.break.keySet()) {
            if (!rfH2.class(rfH4, 30.0)) continue;
            yi_2.class(rfH4);
        }
        Map<rfH, Set<UUID>> map = this.throws();
        this.break.values().forEach(yj_22 -> {
            if (rfH2.class(yj_22.class, 30.0)) {
                Set set = (Set)map.get(yj_22.class);
                this.class((yj_2)yj_22, set == null ? Sets.newHashSet() : set);
            }
        });
        this.private().forEach((rfH3, list) -> {
            if (rfH2.class((rja)rfH3, 30.0)) {
                this.class((rfH)rfH3, (List<String>)list);
            }
        });
    }

    private boolean protected(yf_1 yf_12) {
        return Objects.equals(this.protected, yf_12.class);
    }

    private Map<rfH, List<String>> private() {
        HashMap hashMap = Maps.newHashMap();
        for (yf_1 yf_12 : this.byte.values()) {
            if (yf_12.throws == null || this.break.containsKey(yf_12.throws)) continue;
            hashMap.computeIfAbsent(yf_12.throws, rfH2 -> Lists.newArrayList()).add(yf_12.break());
        }
        return hashMap;
    }
}

