/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.util.function.Predicate;
import protected.ib_0;
import protected.is;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.ay
 */
public class ay_0 {
    public static final ay_0 class = new ay_0();
    private double break = -1.0;
    private boolean byte;
    private boolean protected;
    private boolean throws;
    private boolean case;
    private boolean catch = true;
    private Predicate<ib_0> private;

    public ay_0 byte() {
        this.throws = true;
        return this;
    }

    public boolean class(ib_0 ib_02, ib_0 ib_03) {
        if (ib_02 == ib_03) {
            return false;
        }
        if (ib_03.native()) {
            return false;
        }
        if (!ib_03.BM()) {
            return false;
        }
        if (!this.byte && ib_03.rg()) {
            return false;
        }
        if (this.private != null && !this.private.test(ib_03)) {
            return false;
        }
        if (ib_02 != null) {
            if (!this.case) {
                if (!ib_02.catch(ib_03)) {
                    return false;
                }
                if (!ib_02.class(ib_03.BC())) {
                    return false;
                }
            }
            if (!this.protected && ib_02.final(ib_03)) {
                return false;
            }
            if (this.break > 0.0) {
                double d = this.catch ? ib_03.goto(ib_02) : 1.0;
                double d2 = Math.max(this.break * d, 2.0);
                double d3 = ib_02.class(ib_03.rx(), ib_03.re(), ib_03.BO());
                if (d3 > d2 * d2) {
                    return false;
                }
            }
            if (!this.throws && ib_02 instanceof is && !((is)ib_02).goto().class(ib_03)) {
                return false;
            }
        }
        return true;
    }

    public ay_0 class(Predicate<ib_0> predicate) {
        this.private = predicate;
        return this;
    }

    public ay_0 class() {
        this.byte = true;
        return this;
    }

    public ay_0 class(double d) {
        this.break = d;
        return this;
    }

    public ay_0 break() {
        this.protected = true;
        return this;
    }

    public ay_0 throws() {
        this.catch = false;
        return this;
    }

    public ay_0 protected() {
        this.case = true;
        return this;
    }
}

