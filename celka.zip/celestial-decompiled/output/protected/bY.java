/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.bK;
import protected.bo;
import protected.bo_1;
import protected.class;
import protected.gh_2;
import protected.rc_1;
import protected.rn_1;
import protected.rp_2;
import protected.rr_2;
import protected.ru_1;
import protected.rz_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class bY
implements rr_2 {
    private static short[] break;
    public Object[] class;
    private static boolean[] byte;
    private static byte[] protected;

    @Override
    public boolean byte() {
        return !((List)this.class[break[69]]).isEmpty() ? byte[9] : byte[10];
    }

    public bY(class clazz) {
        ArrayList arrayList;
        HashSet hashSet;
        this.finally();
        class clazz2 = clazz;
        this.class[bY.break[0]] = clazz2;
        this.class[bY.break[1]] = hashSet = new HashSet();
        this.class[bY.break[2]] = arrayList = new ArrayList();
        clazz.s().class(new bo(this));
    }

    static {
        bY.ntfClinit();
    }

    public static String class(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{59, -124, -104, 88, -35, -18, 59, -88}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    @Override
    public void class(rz_2 rz_22) {
        rz_22.protected();
        ((HashSet)this.class[break[3]]).add(rz_22);
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0x61D9B8EA;
    }

    @Override
    public HashSet<rz_2> class() {
        return (HashSet)this.class[break[68]];
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0x702C7D4096E8CF6DL;
    }

    public boolean class(rp_2 rp_22) {
        gh_2 gh_22 = ((class)this.class[break[54]]).while().new();
        if (gh_22 != null) {
            if (rp_22.break(gh_22.class().protected())) {
                return byte[0];
            }
            return !rp_22.equals(gh_22.class().byte()) ? byte[1] : byte[2];
        }
        return byte[3];
    }

    public boolean break(rp_2 rp_22) {
        ru_1 ru_12;
        rp_2 rp_23;
        gh_2 gh_22 = ((class)this.class[break[55]]).while().new();
        if (gh_22 != null && (rp_23 = gh_22.class().byte()).break(ru_12 = gh_22.class().protected()) && !rp_22.break(ru_12)) {
            return byte[4];
        }
        return byte[5];
    }

    @Override
    public Optional<rn_1> break() {
        return Optional.ofNullable((rn_1)this.class[break[11]]);
    }

    @Override
    public rz_2 throws() {
        return this.class().stream().filter(rz_2::byte).findFirst().orElse(null);
    }

    private static /* synthetic */ void ntfClinit() {
        bY.native();
        bY.extends();
        bY.implements();
    }

    private void finally() {
        if (this.class == null) {
            Object[] objectArray = this.class = new Object[protected[0]];
        }
    }

    public void catch() {
        rz_2 rz_22 = (rz_2)this.class[break[12]];
        this.class[bY.break[13]] = rz_22;
        Object var7_2 = null;
        this.class[bY.break[14]] = var7_2;
        bo_1 bo_12 = ((class)this.class[break[15]]).while();
        rn_1 rn_12 = this.private();
        this.class[bY.break[16]] = rn_12;
        if ((rn_1)this.class[break[17]] == null) {
            bo_12.synchronized();
            bo_12.class((rp_2)null);
            return;
        }
        if (!Objects.equals((rz_2)this.class[break[18]], (rz_2)this.class[break[19]]) && (rc_1)((Object)((rn_1)this.class[bY.break[20]]).class[break[21]]) != (rc_1)((Object)rc_1.staticFields8c829f9bf33c3c2bb018688b591a16ef[break[22]]) && (rz_2)this.class[break[23]] != null && !((rz_2)this.class[break[24]]).catch()) {
            bo_12.synchronized();
        }
        switch (((int[])bK.class[break[25]])[((rc_1)((Object)((rn_1)this.class[bY.break[26]]).class[break[27]])).ordinal()]) {
            case 1: {
                bo_12.final();
                break;
            }
            case 2: {
                bo_12.class((rp_2)((rn_1)this.class[bY.break[28]]).class[break[29]]);
                bo_12.synchronized();
                break;
            }
            case 3: {
                if (bo_12.catch() || bo_12.case().isPresent()) break;
                bo_12.class((rn_1)this.class[break[30]]);
                break;
            }
            case 4: {
                if (bo_12.catch() || bo_12.case().isPresent()) break;
                bo_12.class((rn_1)this.class[break[31]]);
                break;
            }
            case 5: {
                if ((rp_2)((rn_1)this.class[bY.break[32]]).class[break[33]] == null) break;
                ((class)this.class[break[34]]).while().class((rn_1)this.class[break[35]]);
                break;
            }
            default: {
                throw new IllegalStateException();
            }
        }
    }

    private static void extends() {
        short[] sArray = new short[70];
        sArray[1] = 1;
        sArray[2] = 2;
        sArray[3] = 1;
        sArray[5] = 3;
        sArray[6] = 4;
        sArray[7] = 5;
        sArray[8] = 2;
        sArray[9] = 1;
        sArray[10] = 4;
        sArray[11] = 5;
        sArray[12] = 4;
        sArray[13] = 3;
        sArray[14] = 4;
        sArray[16] = 5;
        sArray[17] = 5;
        sArray[18] = 4;
        sArray[19] = 3;
        sArray[20] = 5;
        sArray[21] = 1;
        sArray[22] = 1;
        sArray[23] = 3;
        sArray[24] = 3;
        sArray[26] = 5;
        sArray[27] = 1;
        sArray[28] = 5;
        sArray[30] = 5;
        sArray[31] = 5;
        sArray[32] = 5;
        sArray[35] = 5;
        sArray[36] = 5;
        sArray[39] = 5;
        sArray[40] = 1;
        sArray[41] = 5;
        sArray[43] = 5;
        sArray[45] = 5;
        sArray[47] = 5;
        sArray[49] = 5;
        sArray[51] = 5;
        sArray[53] = 5;
        sArray[56] = 1;
        sArray[57] = 2;
        sArray[58] = 2;
        sArray[59] = 2;
        sArray[60] = 2;
        sArray[61] = 2;
        sArray[62] = 3;
        sArray[65] = 1;
        sArray[66] = 5;
        sArray[67] = 4;
        sArray[68] = 1;
        sArray[69] = 2;
        break = sArray;
    }

    public void case() {
        ((class)this.class[break[4]]).s().native();
        Object var7_1 = null;
        this.class[bY.break[5]] = var7_1;
        Object var8_2 = null;
        this.class[bY.break[6]] = var8_2;
        Object var9_3 = null;
        this.class[bY.break[7]] = var9_3;
        ((List)this.class[break[8]]).clear();
        for (rz_2 rz_22 : (HashSet)this.class[break[9]]) {
            rz_22.protected();
            if (!rz_22.byte() || rz_22.catch()) continue;
            throw new IllegalStateException(rz_22.break());
        }
    }

    private static void implements() {
        protected = new byte[]{6};
    }

    @Override
    public Optional<rz_2> protected() {
        return Optional.ofNullable((rz_2)this.class[break[10]]);
    }

    public rn_1 private() {
        for (rz_2 rz_22 : (HashSet)this.class[break[56]]) {
            if (rz_22.byte()) {
                if (((List)this.class[break[57]]).contains(rz_22)) continue;
                ((List)this.class[break[58]]).add(byte[6], rz_22);
                continue;
            }
            ((List)this.class[break[59]]).remove(rz_22);
        }
        ((List)this.class[break[60]]).sort(Comparator.comparingDouble(rz_2::case).reversed());
        Iterator<rz_2> iterator = ((List)this.class[break[61]]).iterator();
        while (iterator.hasNext()) {
            rz_2 rz_22;
            rn_1 rn_12 = rz_22.class(Objects.equals(rz_22 = (rz_2)iterator.next(), (rz_2)this.class[break[62]]) && ((class)this.class[break[63]]).while().int() ? byte[7] : byte[8], ((class)this.class[break[64]]).while().else());
            if (rn_12 == null) {
                if (!rz_22.byte()) continue;
                throw new IllegalStateException(rz_22.break() + " actively returned null PathingCommand");
            }
            if ((rc_1)((Object)rn_12.class[break[65]]) == (rc_1)((Object)rc_1.staticFields8c829f9bf33c3c2bb018688b591a16ef[break[66]])) continue;
            rz_2 rz_23 = rz_22;
            this.class[bY.break[67]] = rz_23;
            if (!rz_22.catch()) {
                iterator.forEachRemaining(rz_2::protected);
            }
            return rn_12;
        }
        return null;
    }

    void volatile() {
        if ((rn_1)this.class[break[36]] == null) {
            return;
        }
        bo_1 bo_12 = ((class)this.class[break[37]]).while();
        switch (((int[])bK.class[break[38]])[((rc_1)((Object)((rn_1)this.class[bY.break[39]]).class[break[40]])).ordinal()]) {
            case 3: {
                if ((rp_2)((rn_1)this.class[bY.break[41]]).class[break[42]] == null || this.class((rp_2)((rn_1)this.class[bY.break[43]]).class[break[44]]) || this.break((rp_2)((rn_1)this.class[bY.break[45]]).class[break[46]])) {
                    bo_12.this();
                }
                bo_12.class((rn_1)this.class[break[47]]);
                break;
            }
            case 4: {
                if (((Boolean)protected.class.instanceof().Pb.class[break[48]]).booleanValue() && ((rp_2)((rn_1)this.class[bY.break[49]]).class[break[50]] == null || this.break((rp_2)((rn_1)this.class[bY.break[51]]).class[break[52]]))) {
                    bo_12.this();
                }
                bo_12.class((rn_1)this.class[break[53]]);
                break;
            }
        }
    }

    private static void native() {
        boolean[] blArray = new boolean[11];
        blArray[1] = true;
        blArray[4] = true;
        blArray[7] = true;
        blArray[9] = true;
        byte = blArray;
    }
}

