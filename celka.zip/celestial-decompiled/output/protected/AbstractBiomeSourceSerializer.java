/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.lang.reflect.Constructor;
import java.util.Arrays;
import protected.rsa_2;
import protected.rsc_2;
import protected.rsf_1;
import protected.rsf_2;
import protected.rsh_1;
import protected.rsi_2;
import protected.rsl_1;
import protected.rsl_2;
import protected.rsn_2;
import protected.rst_1;
import protected.rsu_2;
import protected.rsv_2;
import protected.rsy_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.rST
 */
public class rst_2<T extends rsl_1> {
    private static rst_2<?>[] native = new rst_2[0];
    public static final rst_2<rsn_2> class = rst_2.class(rsn_2.class, "HoldingPattern");
    public static final rst_2<rsi_2> break = rst_2.class(rsi_2.class, "StrafePlayer");
    public static final rst_2<rsh_1> byte = rst_2.class(rsh_1.class, "LandingApproach");
    public static final rst_2<rsy_2> protected = rst_2.class(rsy_2.class, "Landing");
    public static final rst_2<rsf_1> throws = rst_2.class(rsf_1.class, "Takeoff");
    public static final rst_2<rsa_2> case = rst_2.class(rsa_2.class, "SittingFlaming");
    public static final rst_2<rst_1> catch = rst_2.class(rst_1.class, "SittingScanning");
    public static final rst_2<rsv_2> private = rst_2.class(rsv_2.class, "SittingAttacking");
    public static final rst_2<rsf_2> implements = rst_2.class(rsf_2.class, "ChargingPlayer");
    public static final rst_2<rsl_2> finally = rst_2.class(rsl_2.class, "Dying");
    public static final rst_2<rsc_2> extends = rst_2.class(rsc_2.class, "Hover");
    private final Class<? extends rsl_1> volatile;
    private final int final;
    private final String package;

    public static int byte() {
        return native.length;
    }

    private rst_2(int n2, Class<? extends rsl_1> clazz, String string) {
        this.final = n2;
        this.volatile = clazz;
        this.package = string;
    }

    public String toString() {
        return this.package + " (#" + this.final + ")";
    }

    private static <T extends rsl_1> rst_2<T> class(Class<T> clazz, String string) {
        rst_2<T> rst_22 = new rst_2<T>(native.length, clazz, string);
        native = Arrays.copyOf(native, native.length + 1);
        rst_2.native[rst_22.break()] = rst_22;
        return rst_22;
    }

    public rsl_1 class(rsu_2 rsu_22) {
        try {
            Constructor<rsl_1> constructor = this.class();
            return constructor.newInstance(rsu_22);
        }
        catch (Exception exception) {
            throw new Error(exception);
        }
    }

    public static rst_2<?> class(int n2) {
        return n2 >= 0 && n2 < native.length ? native[n2] : rst_2.class;
    }

    protected Constructor<? extends rsl_1> class() throws NoSuchMethodException {
        return this.volatile.getConstructor(rsu_2.class);
    }

    public int break() {
        return this.final;
    }
}

