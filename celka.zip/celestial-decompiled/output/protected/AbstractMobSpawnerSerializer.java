/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.util.Map;
import protected.iC;
import protected.ib_0;
import protected.il;
import protected.rpz_1;
import protected.rrEm;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.rPm
 */
public abstract class rpm_1<E extends ib_0> {
    protected final Map<il<?>, iC> break;
    private rpz_1 class = rpz_1.STOPPED;
    private long byte;
    private final int protected;
    private final int throws;

    protected void byte(rrEm rrEm2, E e2, long l2) {
    }

    public rpm_1(Map<il<?>, iC> map) {
        this(map, 60);
    }

    public rpm_1(Map<il<?>, iC> map, int n2, int n3) {
        this.protected = n2;
        this.throws = n3;
        this.break = map;
    }

    public rpm_1(Map<il<?>, iC> map, int n2) {
        this(map, n2, n2);
    }

    public String toString() {
        return this.getClass().getSimpleName();
    }

    private boolean class(E e2) {
        for (Map.Entry<il<?>, iC> entry : this.break.entrySet()) {
            il<?> il2 = entry.getKey();
            iC iC2 = entry.getValue();
            if (((ib_0)e2).SF().class(il2, iC2)) continue;
            return false;
        }
        return true;
    }

    protected boolean class(rrEm rrEm2, E e2, long l2) {
        return false;
    }

    protected boolean class(long l2) {
        return l2 > this.byte;
    }

    protected boolean class(rrEm rrEm2, E e2) {
        return true;
    }

    public rpz_1 class() {
        return this.class;
    }

    protected void break(rrEm rrEm2, E e2, long l2) {
    }

    public final boolean throws(rrEm rrEm2, E e2, long l2) {
        if (this.class(e2) && this.class(rrEm2, e2)) {
            this.class = rpz_1.RUNNING;
            int n2 = this.protected + rrEm2.long().nextInt(this.throws + 1 - this.protected);
            this.byte = l2 + (long)n2;
            this.protected(rrEm2, e2, l2);
            return true;
        }
        return false;
    }

    public final void catch(rrEm rrEm2, E e2, long l2) {
        this.class = rpz_1.STOPPED;
        this.break(rrEm2, e2, l2);
    }

    public final void case(rrEm rrEm2, E e2, long l2) {
        if (!this.class(l2) && this.class(rrEm2, e2, l2)) {
            this.byte(rrEm2, e2, l2);
        } else {
            this.catch(rrEm2, e2, l2);
        }
    }

    protected void protected(rrEm rrEm2, E e2, long l2) {
    }
}

