/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.stream.Stream;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.class;
import protected.j;
import protected.ps_1;
import protected.pv_2;
import protected.rfH;
import protected.rfl;
import protected.rrfp;
import protected.rrfq;
import protected.rrnc_0;
import protected.rrnn_0;
import protected.rrnq_0;
import protected.rrqx_1;
import protected.sc_2;
import protected.sm_1;
import protected.sn_2;
import protected.su_2;
import protected.sz_1;
import protected.sz_2;
import protected.xc_0;
import protected.xd_0;
import protected.xu_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.SQ
 */
public class sq_2
extends pv_2 {
    public Object[] break;
    private static short[] protected;
    private static boolean[] throws;
    private static byte[] case;
    public static Object[] byte;

    private static void byte() {
        boolean[] blArray = new boolean[14];
        blArray[0] = true;
        blArray[2] = true;
        blArray[5] = true;
        blArray[8] = true;
        blArray[10] = true;
        blArray[11] = true;
        blArray[12] = true;
        throws = blArray;
    }

    public sq_2(class clazz) {
        super(clazz);
        HashMap hashMap;
        this.protected();
        this.break[sq_2.protected[0]] = hashMap = new HashMap();
    }

    static {
        sq_2.ntfClinit();
    }

    @Override
    public void class(j j2) {
        this.protected();
        if (((Map)this.break[protected[7]]).isEmpty()) {
            return;
        }
        if (((Map)this.break[protected[8]]).size() >= (Integer)byte[protected[9]] && ((ps_1)this.class[protected[10]]).catch() != null && ((ps_1)this.class[protected[11]]).case() != null) {
            boolean bl2;
            HashSet<xd_0> hashSet = new HashSet<xd_0>(((Map)this.break[protected[12]]).values());
            sz_1 sz_12 = sz_1.class(hashSet);
            sz_2 sz_22 = sz_2.class(hashSet);
            boolean bl3 = sz_12 != null ? throws[0] : throws[1];
            boolean bl4 = bl2 = sz_22 != null ? throws[2] : throws[3];
            if (bl3 || bl2) {
                sc_2 sc_22 = bl3 ? new su_2() : new sn_2();
                sc_22.class((Map)this.break[protected[13]]);
                if (sc_22.protected() && !sc_22.throws()) {
                    rfl rfl2 = sc_22.byte();
                    if (bl3) {
                        ((rrqx_1)rrqx_1.staticFields09f1f28026cd378cb9df490a64ac8f2a[protected[14]]).finally().class(rrnn_0.class(sz_12, rfl2));
                    } else {
                        ((rrqx_1)rrqx_1.staticFields09f1f28026cd378cb9df490a64ac8f2a[protected[15]]).finally().class(rrnq_0.class(sz_22, rfl2));
                    }
                }
            }
        }
        ((Map)this.break[protected[16]]).clear();
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0xAE75BE30930E21A8L;
    }

    @Override
    public void class(rrnc_0 rrnc_02) {
        this.protected();
        if (!rrnc_02.break() || (rrfq)((Object)rrfp.class[protected[1]]) != (rrfq)((Object)rrfq.staticFields8f8c034c8eef39ccbbc33e665d937d16[protected[2]]) && (rrfq)((Object)rrfp.class[protected[3]]) != (rrfq)((Object)rrfq.staticFields8f8c034c8eef39ccbbc33e665d937d16[protected[4]])) {
            return;
        }
        rfH rfH2 = rrnc_02.byte();
        xc_0 xc_02 = rrnc_02.class();
        if (xc_02.catch()) {
            return;
        }
        xd_0 xd_02 = xc_02.break();
        if (((Set)byte[protected[5]]).contains(xd_02)) {
            ((Map)this.break[protected[6]]).put(rfH2.int(), xd_02);
        }
    }

    private static void class() {
        case = new byte[]{2, 16, 16, 2, 16, 16, 2};
    }

    private static /* synthetic */ int class(Object object) {
        return ((sm_1)object).case();
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0x759A0762;
    }

    private static /* synthetic */ Stream break(Object object) {
        return ((sm_1)object).throws();
    }

    public static String break(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{-105, 35, -74, 41, 120, -45, -112, 45}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    private static void break() {
        short[] sArray = new short[17];
        sArray[1] = 1;
        sArray[2] = 2;
        sArray[3] = 1;
        sArray[4] = 4;
        sArray[9] = 1;
        sArray[10] = 1;
        sArray[11] = 1;
        protected = sArray;
    }

    private static void throws() {
        Object[] objectArray = new Object[2];
        Object[] objectArray2 = new Object[]{xu_0.EA, xu_0.hY, xu_0.EZ, xu_0.Pq, xu_0.Mn, xu_0.PT, xu_0.case, xu_0.Jl, xu_0.by, xu_0.Ge, xu_0.catch, xu_0.BJ, xu_0.Bd, xu_0.Sh, xu_0.bg, xu_0.hV, xu_0.Bs, xu_0.Ju, xu_0.JI, xu_0.bY, xu_0.hD, xu_0.bV, xu_0.SS, xu_0.Em, xu_0.bs, xu_0.Jw, xu_0.Ev, xu_0.bR, xu_0.EH, xu_0.hc, xu_0.hL, xu_0.Jd, xu_0.Jk, xu_0.PD, xu_0.SP, xu_0.bH, xu_0.Pt, xu_0.JF, xu_0.By, xu_0.hN, xu_0.JA, xu_0.Jv, xu_0.Ei, xu_0.Ea, xu_0.Bp, xu_0.sq, xu_0.Jc, xu_0.El, xu_0.MR, xu_0.Ba, xu_0.Bq, xu_0.JC, xu_0.JL, xu_0.throws, xu_0.volatile, xu_0.bq, xu_0.bp, xu_0.Jn, xu_0.bS, xu_0.hK, xu_0.BT, xu_0.bX, xu_0.sp, xu_0.hm, xu_0.OJ, xu_0.Jy, xu_0.sy, xu_0.JJ, xu_0.bO, xu_0.Jm, xu_0.hl};
        objectArray[0] = Set.of(objectArray2);
        objectArray[1] = 2;
        byte = objectArray;
    }

    private static /* synthetic */ void ntfClinit() {
        sq_2.byte();
        sq_2.break();
        sq_2.class();
        sq_2.throws();
    }

    private void protected() {
        if (this.break == null) {
            Object[] objectArray = this.break = new Object[throws[11]];
        }
    }
}

