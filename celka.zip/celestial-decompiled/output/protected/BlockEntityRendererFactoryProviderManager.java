/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.Hx;
import protected.ml_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.yD
 */
public interface yd_2 {
    public void class(ml_1 var1, Hx var2, double var3, double var5, double var7);

    default public void class() {
    }
}

