/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.util.List;
import java.util.Map;
import protected.VD;
import protected.oo_1;
import protected.rCF;
import protected.rCZ;
import protected.rRR;
import protected.rRq;
import protected.rYB;
import protected.rcd_2;
import protected.rdb_1;
import protected.rdh_1;
import protected.rdn_1;
import protected.rdo_2;
import protected.rdx_1;
import protected.rfH;
import protected.rgP;
import protected.rhd_2;
import protected.rhn_2;
import protected.rhx_1;
import protected.rjm;
import protected.rnW;
import protected.rqa_0;
import protected.rql_0;
import protected.rqs;
import protected.rxx;
import protected.ryo_2;
import protected.ryz_1;
import protected.xc_0;
import protected.xd_0;
import protected.zr_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.rxJ
 */
public class rxj_0
extends rdb_1 {
    @Deprecated
    private final xd_0 class;

    public xc_0 byte(rxx rxx2) {
        xc_0 xc_02 = this.catch().class(rxx2);
        return xc_02 != null && this.break(rxx2, xc_02) ? xc_02 : null;
    }

    public rxj_0(xd_0 xd_02, rdo_2 rdo_22) {
        super(rdo_22);
        this.class = xd_02;
    }

    protected boolean class(rxx rxx2, xc_0 xc_02) {
        return rxx2.int().class(rxx2.class(), xc_02, 11);
    }

    private static <T extends Comparable<T>> xc_0 class(xc_0 xc_02, rCZ<T> rCZ2, String string) {
        return rCZ2.break(string).map(comparable -> (xc_0)xc_02.class(rCZ2, comparable)).orElse(xc_02);
    }

    public void class(Map<xd_0, rdb_1> map, rdb_1 rdb_12) {
        map.put(this.catch(), rdb_12);
    }

    @Override
    public void class(rdn_1 rdn_12, rYB rYB2, List<rgP> list, VD vD) {
        super.class(rdn_12, rYB2, list, vD);
        this.catch().class(rdn_12, (rRq)rYB2, list, vD);
    }

    @Override
    public void class(rdx_1 rdx_12, rqs<rdn_1> rqs2) {
        if (this.class(rdx_12)) {
            this.catch().class(rdx_12, rqs2);
        }
    }

    public static boolean class(rYB rYB2, rhd_2 rhd_22, rfH rfH2, rdn_1 rdn_12) {
        ryo_2 ryo_22;
        rnW rnW2 = rYB2.const();
        if (rnW2 == null) {
            return false;
        }
        rcd_2 rcd_22 = rdn_12.break("BlockEntityTag");
        if (rcd_22 != null && (ryo_22 = rYB2.class(rfH2)) != null) {
            if (!(rYB2.continue || !ryo_22.ac_() || rhd_22 != null && rhd_22.sU())) {
                return false;
            }
            rcd_2 rcd_23 = ryo_22.class(new rcd_2());
            rcd_2 rcd_24 = rcd_23.catch();
            rcd_23.class(rcd_22);
            rcd_23.break("x", rfH2.b_());
            rcd_23.break("y", rfH2.c_());
            rcd_23.break("z", rfH2.d_());
            if (!rcd_23.equals(rcd_24)) {
                ryo_22.class(rYB2.byte(rfH2), rcd_23);
                ryo_22.break();
                return true;
            }
        }
        return false;
    }

    @Override
    public ryz_1 class(rdh_1 rdh_12) {
        ryz_1 ryz_12 = this.class(new rxx(rdh_12));
        return !ryz_12.class() && this.super() ? this.class(rdh_12.int(), rdh_12.final(), rdh_12.package()).class() : ryz_12;
    }

    public ryz_1 class(rxx rxx2) {
        if (!rxx2.break()) {
            return ryz_1.FAIL;
        }
        rxx rxx3 = this.break(rxx2);
        if (rxx3 == null) {
            return ryz_1.FAIL;
        }
        xc_0 xc_02 = this.byte(rxx3);
        if (xc_02 == null) {
            return ryz_1.FAIL;
        }
        if (!this.class(rxx3, xc_02)) {
            return ryz_1.FAIL;
        }
        rfH rfH2 = rxx3.class();
        rYB rYB2 = rxx3.int();
        rhd_2 rhd_22 = rxx3.final();
        rdn_1 rdn_12 = rxx3.volatile();
        xc_0 xc_03 = rYB2.byte(rfH2);
        xd_0 xd_02 = xc_03.break();
        if (xd_02 == xc_02.break()) {
            xc_03 = this.class(rfH2, rYB2, rdn_12, xc_03);
            this.class(rfH2, rYB2, rhd_22, rdn_12, xc_03);
            xd_02.class(rYB2, rfH2, xc_03, rhd_22, rdn_12);
            if (rhd_22 instanceof rhn_2) {
                oo_1.goto.class((rhn_2)rhd_22, rfH2, rdn_12);
            }
        }
        zr_2 zr_22 = xc_03.package();
        rYB2.class(rhd_22, rfH2, this.class(xc_03), rql_0.BLOCKS, (zr_22.class() + 1.0f) / 2.0f, zr_22.break() * 0.8f);
        if (rhd_22 == null || !((rhx_1)rhd_22.implements[18]).protected) {
            rdn_12.catch(1);
        }
        return ryz_1.class(rYB2.continue);
    }

    protected rqa_0 class(xc_0 xc_02) {
        return xc_02.package().throws();
    }

    private xc_0 class(rfH rfH2, rYB rYB2, rdn_1 rdn_12, xc_0 xc_02) {
        xc_0 xc_03 = xc_02;
        rcd_2 rcd_22 = rdn_12.package();
        if (rcd_22 != null) {
            rcd_2 rcd_23 = rcd_22.int("BlockStateTag");
            rCF<xd_0, xc_0> rCF2 = xc_02.break().new();
            for (String string : rcd_23.protected()) {
                rCZ<?> rCZ2 = rCF2.class(string);
                if (rCZ2 == null) continue;
                String string2 = rcd_23.byte(string).native();
                xc_03 = rxj_0.class(xc_03, rCZ2, string2);
            }
        }
        if (xc_03 != xc_02) {
            rYB2.class(rfH2, xc_03, 2);
        }
        return xc_03;
    }

    protected boolean class(rfH rfH2, rYB rYB2, rhd_2 rhd_22, rdn_1 rdn_12, xc_0 xc_02) {
        return rxj_0.class(rYB2, rhd_22, rfH2, rdn_12);
    }

    protected boolean break(rxx rxx2, xc_0 xc_02) {
        rhd_2 rhd_22 = rxx2.final();
        rjm rjm2 = rhd_22 == null ? rjm.break() : rjm.class(rhd_22);
        return (!this.throws() || xc_02.class((rRR)rxx2.int(), rxx2.class())) && rxx2.int().class(xc_02, rxx2.class(), rjm2);
    }

    public rxx break(rxx rxx2) {
        return rxx2;
    }

    @Override
    public String break() {
        return this.catch().volatile();
    }

    protected boolean throws() {
        return true;
    }

    public xd_0 catch() {
        return this.class;
    }
}

