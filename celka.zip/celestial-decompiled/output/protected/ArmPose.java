/*
 * Decompiled with CFR 0.152.
 */
package protected;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.tQ
 */
public final class tq_0
extends Enum<tq_0> {
    public static final /* enum */ tq_0 EMPTY = new tq_0(false);
    public static final /* enum */ tq_0 ITEM = new tq_0(false);
    public static final /* enum */ tq_0 BLOCK = new tq_0(false);
    public static final /* enum */ tq_0 BOW_AND_ARROW = new tq_0(true);
    public static final /* enum */ tq_0 THROW_SPEAR = new tq_0(false);
    public static final /* enum */ tq_0 CROSSBOW_CHARGE = new tq_0(true);
    public static final /* enum */ tq_0 CROSSBOW_HOLD = new tq_0(true);
    private final boolean field_241656_h_;
    private static final /* synthetic */ tq_0[] $VALUES;

    private tq_0(boolean bl2) {
        this.field_241656_h_ = bl2;
    }

    static {
        $VALUES = tq_0.break();
    }

    public static tq_0[] values() {
        return (tq_0[])$VALUES.clone();
    }

    public static tq_0 valueOf(String string) {
        return Enum.valueOf(tq_0.class, string);
    }

    public boolean class() {
        return this.field_241656_h_;
    }

    private static /* synthetic */ tq_0[] break() {
        return new tq_0[]{EMPTY, ITEM, BLOCK, BOW_AND_ARROW, THROW_SPEAR, CROSSBOW_CHARGE, CROSSBOW_HOLD};
    }
}

