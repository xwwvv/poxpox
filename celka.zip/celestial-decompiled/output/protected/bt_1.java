/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.aw_1;
import protected.bl_2;
import protected.rrje;
import protected.rrze_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.Bt
 */
public abstract class bt_1
implements rrze_1 {
    private static byte[] class;
    public Object[] break;
    private static short[] byte;
    private static boolean[] protected;

    public aw_1 byte() {
        return (aw_1)this.break[byte[8]];
    }

    public static String byte(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{54, 32, -99, 117, -75, 112, 24, 75}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    public bt_1(String string) {
        this.break();
        String string2 = string;
        this.break[bt_1.byte[0]] = string2;
        String string3 = string;
        this.break[bt_1.byte[1]] = string3;
    }

    static {
        bt_1.ntfClinit();
    }

    public void class(aw_1 aw_12) {
        aw_1 aw_13 = aw_12;
        this.break[bt_1.byte[11]] = aw_13;
    }

    private static void class() {
        bt_1.class = new byte[]{3};
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0x4BE0E5CF;
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0x8326DB3B4F28845EL;
    }

    private void break() {
        if (this.break == null) {
            Object[] objectArray = this.break = new Object[bt_1.class[0]];
        }
    }

    public void throws(String string) {
        Matcher matcher = ((Pattern)bl_2.class[byte[2]]).matcher(string);
        if (matcher.find()) {
            String string2 = matcher.group(protected[0]);
            aw_1 aw_12 = import.void().class(string2);
            this.break[bt_1.byte[3]] = aw_12;
        }
    }

    public String throws() {
        return (String)this.break[byte[6]];
    }

    private static /* synthetic */ void ntfClinit() {
        bt_1.catch();
        bt_1.private();
        bt_1.class();
    }

    private static void catch() {
        protected = new boolean[]{true};
    }

    public void case(String string) {
        String string2 = string;
        this.break[bt_1.byte[10]] = string2;
    }

    public boolean case() {
        return ((rrje)((Object)rrje.staticFields67a5399629443d9d93e54c2de6d74063[byte[4]])).protected((String)this.break[byte[5]]);
    }

    public void protected(String string) {
        String string2 = string;
        this.break[bt_1.byte[9]] = string2;
    }

    public String protected() {
        return (String)this.break[byte[7]];
    }

    private static void private() {
        short[] sArray = new short[12];
        sArray[1] = 1;
        sArray[2] = 3;
        sArray[3] = 2;
        sArray[7] = 1;
        sArray[8] = 2;
        sArray[10] = 1;
        sArray[11] = 2;
        byte = sArray;
    }
}

