/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableList
 *  com.google.common.collect.ImmutableSet
 *  com.mojang.datafixers.util.Pair
 */
package protected;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableSet;
import com.mojang.datafixers.util.Pair;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.Random;
import java.util.Set;
import protected.ai_0;
import protected.an;
import protected.iX;
import protected.iZ;
import protected.ia_0;
import protected.ib_0;
import protected.il;
import protected.iq;
import protected.is;
import protected.rYB;
import protected.rbh_0;
import protected.rbk_0;
import protected.rbm_0;
import protected.rbn_0;
import protected.rbo_0;
import protected.rbq_0;
import protected.rbx_0;
import protected.rbz_0;
import protected.rdb_1;
import protected.rdn_1;
import protected.rdy_2;
import protected.reg_1;
import protected.rfH;
import protected.rhd_2;
import protected.rjU;
import protected.rlc_0;
import protected.rpb_1;
import protected.rpc_1;
import protected.rpe_2;
import protected.rph_2;
import protected.rpj_0;
import protected.rpj_2;
import protected.rpm;
import protected.rpm_1;
import protected.rpn_2;
import protected.rpo_2;
import protected.rpq_1;
import protected.rpq_2;
import protected.rps_1;
import protected.rps_2;
import protected.rpy_2;
import protected.rqa_0;
import protected.rqb;
import protected.rqn;
import protected.rqt;
import protected.rrEm;
import protected.rrg_1;
import protected.rrk_1;
import protected.rrl_2;
import protected.rrm_2;
import protected.rrn_1;
import protected.rrn_2;
import protected.rro_1;
import protected.rro_2;
import protected.rrp_1;
import protected.rrq_2;
import protected.rrr_1;
import protected.rru_0;
import protected.rru_1;
import protected.rrv_1;
import protected.rrw_1;
import protected.rry_2;
import protected.rse_0;
import protected.rxS;
import protected.rxe_0;
import protected.ryz_1;
import protected.rzl_1;
import protected.rzl_2;
import protected.rzp_2;
import protected.rzq_2;
import protected.rzz_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.rbW
 */
public class rbw_0 {
    public static final rdb_1 class = rdy_2.Od;
    private static final rqb break = rqt.class(30, 120);
    private static final rqb byte = rqt.class(10, 40);
    private static final rqb protected = rqt.class(10, 30);
    private static final rqb throws = rqt.class(5, 20);
    private static final rqb case = rqt.class(5, 7);
    private static final rqb catch = rqt.class(5, 7);
    private static final Set<rdb_1> private = ImmutableSet.of((Object)rdy_2.hC, (Object)rdy_2.hl);

    private static void byte(rbk_0 rbk_02, ib_0 ib_02) {
        rbw_0.volatile(rbk_02).stream().filter(rbm_02 -> rbm_02 instanceof rbk_0).forEach(rbm_02 -> rbw_0.protected((rbk_0)rbm_02, ib_02));
    }

    private static rpo_2<rfH> byte() {
        return rpo_2.class(il.J, 1.0f, 8, false);
    }

    protected static void byte(rbm_0 rbm_02, ib_0 ib_02) {
        if (rbw_0.throws(ib_02)) {
            rbm_02.SF().break(il.interface);
            rbm_02.SF().class(il.short, ib_02.ro(), 600L);
            if (ib_02.BC() == ai_0.long && rbm_02.throws()) {
                rbw_0.byte(rbm_02);
            }
            if (ib_02.BC() == ai_0.rM && ((rYB)rbm_02.throws[7]).B().break(rru_0.long)) {
                rbm_02.SF().class(il.default, true, 600L);
            }
        }
    }

    protected static void byte(rbk_0 rbk_02) {
        if (rbw_0.else(rbk_02) && !rbk_02.Sn().class()) {
            rbk_02.a_(rbk_02.Sn());
            rbk_02.class(rpm.OFF_HAND, rdn_1.break);
        }
    }

    private static void byte(rbk_0 rbk_02, rdn_1 rdn_12) {
        if (rbw_0.public(rbk_02)) {
            rbk_02.a_(rbk_02.protected(rpm.OFF_HAND));
        }
        rbk_02.final(rdn_12);
    }

    private static void byte(iZ<rbk_0> iZ2) {
        iZ2.class(iq.native, 10, (ImmutableList<rpm_1<rbk_0>>)ImmutableList.of(rbw_0.byte(), (Object)new rro_1(rbw_0::break, 14.0f), new rrp_1<rbk_0>(rbm_0::sx, rbw_0::extends), new rpn_2<rbk_0>(rbk_02 -> !rbk_02.sQ(), new rrv_1(2, 1.0f)), new rpn_2<rbk_0>(rbk_0::sQ, new rrv_1(4, 0.6f)), new rry_2(ImmutableList.of((Object)Pair.of((Object)new rro_1(ai_0.d, 8.0f), (Object)1), (Object)Pair.of((Object)new rpc_1(0.6f, 2, 1), (Object)1), (Object)Pair.of((Object)new rrq_2(10, 20), (Object)1)))), il.double);
    }

    private static boolean byte(rdb_1 rdb_12) {
        return private.contains(rdb_12);
    }

    protected static void byte(rbm_0 rbm_02) {
        rbm_02.SF().class(il.for, true, break.class(((rYB)rbm_02.throws[7]).int));
    }

    private static boolean byte(ib_0 ib_02) {
        return ib_02.class(rdy_2.kU);
    }

    private static boolean int(rbk_0 rbk_02) {
        return !rbw_0.new(rbk_02);
    }

    private static boolean this(rbk_0 rbk_02) {
        return rbk_02.SF().class(il.X);
    }

    protected static void class(rbm_0 rbm_03) {
        rbw_0.throws(rbm_03).forEach(rbm_02 -> rbw_0.break(rbm_02).ifPresent(rhd_22 -> rbw_0.byte(rbm_02, (ib_0)rhd_22)));
    }

    private static boolean class(rbk_0 rbk_02, an an2) {
        if (!(an2 instanceof is)) {
            return false;
        }
        is is2 = (is)an2;
        return !is2.n_() || !is2.BM() || rbw_0.private((ib_0)rbk_02) || rbw_0.private(is2) || is2 instanceof rbk_0 && is2.ra() == null;
    }

    protected static iZ<?> class(rbk_0 rbk_02, iZ<rbk_0> iZ2) {
        rbw_0.class(iZ2);
        rbw_0.break(iZ2);
        rbw_0.protected(iZ2);
        rbw_0.break(rbk_02, iZ2);
        rbw_0.byte(iZ2);
        rbw_0.throws(iZ2);
        rbw_0.case(iZ2);
        iZ2.class((Set<iq>)ImmutableSet.of((Object)iq.class));
        iZ2.break(iq.break);
        iZ2.byte();
        return iZ2;
    }

    public static void class(rhd_2 rhd_22, boolean bl2) {
        List<rbk_0> list = ((rYB)rhd_22.throws[7]).class(rbk_0.class, rhd_22.rN().class(16.0));
        list.stream().filter(rbw_0::protected).filter(rbk_02 -> !bl2 || ia_0.byte(rbk_02, rhd_22)).forEach(rbk_02 -> {
            if (((rYB)rbk_02.throws[7]).B().break(rru_0.long)) {
                rbw_0.protected((rbm_0)rbk_02, (ib_0)rhd_22);
            } else {
                rbw_0.byte((rbm_0)rbk_02, (ib_0)rhd_22);
            }
        });
    }

    protected static boolean class(rbk_0 rbk_02, rdn_1 rdn_12) {
        rdb_1 rdb_12 = rdn_12.break();
        if (rdb_12.class(rlc_0.const)) {
            return false;
        }
        if (rbw_0.return(rbk_02) && rbk_02.SF().class(il.package)) {
            return false;
        }
        if (rbw_0.break(rdb_12)) {
            return rbw_0.goto(rbk_02);
        }
        boolean bl2 = rbk_02.native(rdn_12);
        if (rdb_12 == rdy_2.JF) {
            return bl2;
        }
        if (rbw_0.byte(rdb_12)) {
            return !rbw_0.this(rbk_02) && bl2;
        }
        if (!rbw_0.class(rdb_12)) {
            return rbk_02.package(rdn_12);
        }
        return rbw_0.goto(rbk_02) && bl2;
    }

    private static boolean class(ib_0 ib_02, ib_0 ib_03) {
        if (ib_03.BC() != ai_0.long) {
            return false;
        }
        return new Random(((rYB)ib_02.throws[7]).r()).nextFloat() < 0.1f;
    }

    public static boolean class(ai_0 ai_02) {
        return ai_02 == ai_0.rb || ai_02 == ai_0.rS;
    }

    protected static void class(rbm_0 rbm_02, ib_0 ib_02) {
        if (!rbm_02.SF().byte(iq.final) && rbw_0.throws(ib_02) && !ia_0.class((ib_0)rbm_02, ib_02, 4.0)) {
            if (ib_02.BC() == ai_0.rM && ((rYB)rbm_02.throws[7]).B().break(rru_0.long)) {
                rbw_0.protected(rbm_02, ib_02);
                rbw_0.class(rbm_02);
            } else {
                rbw_0.byte(rbm_02, ib_02);
                rbw_0.break(rbm_02, ib_02);
            }
        }
    }

    private static rqa_0 class(rbk_0 rbk_02, iq iq2) {
        if (iq2 == iq.extends) {
            return rqn.hr;
        }
        if (rbk_02.sJ()) {
            return rqn.hE;
        }
        if (iq2 == iq.final && rbw_0.native(rbk_02)) {
            return rqn.hE;
        }
        if (iq2 == iq.volatile) {
            return rqn.Oa;
        }
        if (iq2 == iq.native) {
            return rqn.hP;
        }
        if (rbw_0.case((ib_0)rbk_02)) {
            return rqn.hS;
        }
        return rbw_0.synchronized(rbk_02) ? rqn.hE : rqn.Oi;
    }

    private static void class(iZ<rbk_0> iZ2) {
        iZ2.class(iq.class, 0, (ImmutableList<rpm_1<rbk_0>>)ImmutableList.of((Object)new rrk_1(45, 90), (Object)new rpy_2(), (Object)new rrg_1(), rbw_0.protected(), rbw_0.throws(), new rbz_0(), new rbo_0(120), (Object)new rrn_2(300, rbw_0::class), new rrw_1()));
    }

    public static boolean class(ib_0 ib_02) {
        for (rdn_1 rdn_12 : ib_02.PV()) {
            rdb_1 rdb_12 = rdn_12.break();
            if (!(rdb_12 instanceof rxS) || ((rxS)rdb_12).throws() != rxe_0.GOLD) continue;
            return true;
        }
        return false;
    }

    protected static void class(rbk_0 rbk_02, ib_0 ib_02) {
        if (!(ib_02 instanceof rbk_0)) {
            if (rbw_0.public(rbk_02)) {
                rbw_0.class(rbk_02, false);
            }
            iZ<rbk_0> iZ2 = rbk_02.SF();
            iZ2.break(il.double);
            iZ2.break(il.switch);
            iZ2.break(il.const);
            if (ib_02 instanceof rhd_2) {
                iZ2.class(il.transient, true, 400L);
            }
            rbw_0.catch(rbk_02).ifPresent(ib_03 -> {
                if (ib_03.BC() != ib_02.BC()) {
                    iZ2.break(il.while);
                }
            });
            if (rbk_02.n_()) {
                iZ2.class(il.while, ib_02, 100L);
                if (rbw_0.throws(ib_02)) {
                    rbw_0.break((rbm_0)rbk_02, ib_02);
                }
            } else if (ib_02.BC() == ai_0.long && rbw_0.new(rbk_02)) {
                rbw_0.throws(rbk_02, ib_02);
                rbw_0.byte(rbk_02, ib_02);
            } else {
                rbw_0.class((rbm_0)rbk_02, ib_02);
            }
        }
    }

    protected static void class(rbk_0 rbk_02) {
        int n2 = break.class(((rYB)rbk_02.throws[7]).int);
        rbk_02.SF().class(il.for, true, n2);
    }

    public static ryz_1 class(rbk_0 rbk_02, rhd_2 rhd_22, rpm rpm2) {
        rdn_1 rdn_12 = rhd_22.protected(rpm2);
        if (rbw_0.break(rbk_02, rdn_12)) {
            rdn_1 rdn_13 = rdn_12.class(1);
            rbw_0.byte(rbk_02, rdn_13);
            rbw_0.protected((ib_0)rbk_02);
            rbw_0.final(rbk_02);
            return ryz_1.CONSUME;
        }
        return ryz_1.PASS;
    }

    protected static void class(rbk_0 rbk_02, rse_0 rse_02) {
        rdn_1 rdn_12;
        rbw_0.final(rbk_02);
        if (rse_02.protected().break() == rdy_2.JF) {
            rbk_02.class((an)rse_02, rse_02.protected().char());
            rdn_12 = rse_02.protected();
            rse_02.PD();
        } else {
            rbk_02.class((an)rse_02, 1);
            rdn_12 = rbw_0.class(rse_02);
        }
        rdb_1 rdb_12 = rdn_12.break();
        if (rbw_0.class(rdb_12)) {
            rbk_02.SF().break(il.strictfp);
            rbw_0.byte(rbk_02, rdn_12);
            rbw_0.protected((ib_0)rbk_02);
        } else if (rbw_0.byte(rdb_12) && !rbw_0.this(rbk_02)) {
            rbw_0.continue(rbk_02);
        } else {
            boolean bl2 = rbk_02.catch(rdn_12);
            if (!bl2) {
                rbw_0.protected(rbk_02, rdn_12);
            }
        }
    }

    private static rry_2<rbk_0> class() {
        return new rry_2<rbk_0>((List<Pair<rpm_1<rbk_0>, Integer>>)ImmutableList.of((Object)Pair.of((Object)new rro_1(ai_0.rM, 8.0f), (Object)1), (Object)Pair.of((Object)new rro_1(ai_0.d, 8.0f), (Object)1), (Object)Pair.of((Object)new rro_1(8.0f), (Object)1), (Object)Pair.of((Object)new rrq_2(30, 60), (Object)1)));
    }

    private static rdn_1 class(rse_0 rse_02) {
        rdn_1 rdn_12 = rse_02.protected();
        rdn_1 rdn_13 = rdn_12.class(1);
        if (rdn_12.class()) {
            rse_02.PD();
        } else {
            rse_02.break(rdn_12);
        }
        return rdn_13;
    }

    protected static void class(rbk_0 rbk_02, boolean bl2) {
        rdn_1 rdn_12 = rbk_02.protected(rpm.OFF_HAND);
        rbk_02.class(rpm.OFF_HAND, rdn_1.break);
        if (rbk_02.sx()) {
            boolean bl3;
            boolean bl4 = rbw_0.break(rdn_12.break());
            if (bl2 && bl4) {
                rbw_0.class(rbk_02, rbw_0.implements(rbk_02));
            } else if (!bl4 && !(bl3 = rbk_02.catch(rdn_12))) {
                rbw_0.protected(rbk_02, rdn_12);
            }
        } else {
            boolean bl5 = rbk_02.catch(rdn_12);
            if (!bl5) {
                rdn_1 rdn_13 = rbk_02.ss();
                if (rbw_0.class(rdn_13.break())) {
                    rbw_0.protected(rbk_02, rdn_13);
                } else {
                    rbw_0.class(rbk_02, Collections.singletonList(rdn_13));
                }
                rbk_02.volatile(rdn_12);
            }
        }
    }

    protected static boolean class(rdb_1 rdb_12) {
        return rdb_12.class(rlc_0.strictfp);
    }

    private static void class(rbk_0 rbk_02, List<rdn_1> list, rjU rjU2) {
        if (!list.isEmpty()) {
            rbk_02.class(rpm.OFF_HAND);
            for (rdn_1 rdn_12 : list) {
                ia_0.class((ib_0)rbk_02, rdn_12, rjU2.break(0.0, 1.0, 0.0));
            }
        }
    }

    private static void class(rbk_0 rbk_02, List<rdn_1> list) {
        Optional<rhd_2> optional = rbk_02.SF().byte(il.extends);
        if (optional.isPresent()) {
            rbw_0.class(rbk_02, optional.get(), list);
        } else {
            rbw_0.break(rbk_02, list);
        }
    }

    private static void class(rbk_0 rbk_02, rhd_2 rhd_22, List<rdn_1> list) {
        rbw_0.class(rbk_02, list, rhd_22.Ps());
    }

    private static void break(rbk_0 rbk_02, iZ<rbk_0> iZ2) {
        iZ2.class(iq.extends, 10, (ImmutableList<rpm_1<rbk_0>>)ImmutableList.of(new rrn_1(ib_02 -> !rbw_0.break(rbk_02, ib_02)), new rpn_2<rbk_0>(rbw_0::byte, new rrm_2(5, 0.75f)), (Object)new rru_1(1.0f), (Object)new rro_2(20), new rpj_2(), new rbh_0(), new rpe_2<rbk_0>(rbw_0::finally, il.package)), il.package);
    }

    public static Optional<rhd_2> break(rbm_0 rbm_02) {
        return rbm_02.SF().class(il.native) ? rbm_02.SF().byte(il.native) : Optional.empty();
    }

    protected static void break(rbm_0 rbm_03, ib_0 ib_02) {
        rbw_0.throws(rbm_03).forEach(rbm_02 -> {
            if (ib_02.BC() != ai_0.long || rbm_02.throws() && ((reg_1)ib_02).sd()) {
                rbw_0.throws(rbm_02, ib_02);
            }
        });
    }

    public static boolean break(ib_0 ib_02) {
        return ib_02.BC() == ai_0.rM && ib_02.class(rbw_0::class);
    }

    private static boolean break(rdb_1 rdb_12) {
        return rdb_12 == rbw_0.class;
    }

    private static void break(iZ<rbk_0> iZ2) {
        iZ2.class(iq.break, 10, (ImmutableList<rpm_1<rbk_0>>)ImmutableList.of((Object)new rro_1(rbw_0::break, 14.0f), new rrp_1<rbk_0>(rbm_0::sx, rbw_0::extends), new rpn_2<rbk_0>(rbk_0::throws, new rbq_0()), rbw_0.byte(), rbw_0.case(), rbw_0.class(), rbw_0.break(), (Object)new rrl_2(ai_0.rM, 4)));
    }

    protected static boolean break(rbk_0 rbk_02, rdn_1 rdn_12) {
        return !rbw_0.return(rbk_02) && !rbw_0.else(rbk_02) && rbk_02.sx() && rbw_0.break(rdn_12.break());
    }

    private static void break(rbk_0 rbk_02, List<rdn_1> list) {
        rbw_0.class(rbk_02, list, rbw_0.super(rbk_02));
    }

    protected static void break(rbk_0 rbk_02) {
        iZ<rbk_0> iZ2 = rbk_02.SF();
        iq iq2 = iZ2.protected().orElse(null);
        iZ2.class((List<iq>)ImmutableList.of((Object)iq.volatile, (Object)iq.extends, (Object)iq.final, (Object)iq.native, (Object)iq.package, (Object)iq.break));
        iq iq3 = iZ2.protected().orElse(null);
        if (iq2 != iq3) {
            rbw_0.protected(rbk_02).ifPresent(rbk_02::class);
        }
        rbk_02.case(iZ2.class(il.package));
        if (!iZ2.class(il.super) && rbw_0.private(rbk_02)) {
            rbk_02.BH();
        }
        if (!iZ2.class(il.double)) {
            iZ2.break(il.switch);
        }
        rbk_02.else(iZ2.class(il.switch));
    }

    private static rry_2<rbk_0> break() {
        return new rry_2<rbk_0>((List<Pair<rpm_1<rbk_0>, Integer>>)ImmutableList.of((Object)Pair.of((Object)new rpc_1(0.6f), (Object)2), (Object)Pair.of(rrr_1.class(ai_0.d, 8, il.new, 0.6f, 2), (Object)2), (Object)Pair.of(new rpn_2<ib_0>(rbw_0::catch, new rpq_1(0.6f, 3)), (Object)2), (Object)Pair.of((Object)new rrq_2(30, 60), (Object)1)));
    }

    private static boolean break(rbk_0 rbk_02, ib_0 ib_02) {
        return rbw_0.extends(rbk_02).filter(ib_03 -> ib_03 == ib_02).isPresent();
    }

    private static List<rbm_0> throws(rbm_0 rbm_02) {
        return rbm_02.SF().byte(il.S).orElse((List<rbm_0>)ImmutableList.of());
    }

    private static void throws(rbk_0 rbk_02, ib_0 ib_02) {
        rbk_02.SF().break(il.short);
        rbk_02.SF().break(il.package);
        rbk_02.SF().break(il.volatile);
        rbk_02.SF().class(il.while, ib_02, throws.class(((rYB)rbk_02.throws[7]).int));
        rbw_0.byte((rbm_0)rbk_02);
    }

    protected static boolean throws(rbk_0 rbk_02) {
        return rbk_02.SF().class(il.for) || rbw_0.volatile(rbk_02).stream().anyMatch(rbm_02 -> rbm_02.SF().class(il.for));
    }

    private static rps_1<rbk_0, ib_0> throws() {
        return new rps_1<rbk_0, ib_0>(rbw_0::finally, il.b, il.while, case);
    }

    private static void throws(rbm_0 rbm_02, ib_0 ib_02) {
        Optional<ib_0> optional = rbw_0.case(rbm_02);
        ib_0 ib_03 = ia_0.class((ib_0)rbm_02, optional, ib_02);
        if (!optional.isPresent() || optional.get() != ib_03) {
            rbw_0.byte(rbm_02, ib_03);
        }
    }

    private static void throws(iZ<rbk_0> iZ2) {
        iZ2.class(iq.final, 10, (ImmutableList<rpm_1<rbk_0>>)ImmutableList.of(rpo_2.break(il.while, 1.0f, 12, true), rbw_0.class(), rbw_0.break(), new rpe_2<rbk_0>(rbw_0::package, il.while)), il.while);
    }

    private static boolean throws(ib_0 ib_02) {
        return rpj_0.case.test(ib_02);
    }

    private static boolean finally(rbk_0 rbk_02) {
        iZ<rbk_0> iZ2 = rbk_02.SF();
        if (iZ2.class(il.b)) {
            ib_0 ib_02 = iZ2.byte(il.b).get();
            return rbk_02.class((an)ib_02, 6.0);
        }
        return false;
    }

    public static Optional<ib_0> catch(rbk_0 rbk_02) {
        return rbk_02.SF().class(il.while) ? rbk_02.SF().byte(il.while) : Optional.empty();
    }

    private static boolean catch(ib_0 ib_02) {
        return !rbw_0.case(ib_02);
    }

    private static Optional<? extends ib_0> extends(rbk_0 rbk_02) {
        Optional<ib_0> optional;
        iZ<rbk_0> iZ2 = rbk_02.SF();
        if (rbw_0.finally(rbk_02)) {
            return Optional.empty();
        }
        Optional<ib_0> optional2 = ia_0.class((ib_0)rbk_02, il.short);
        if (optional2.isPresent() && rbw_0.throws(optional2.get())) {
            return optional2;
        }
        if (iZ2.class(il.default) && (optional = iZ2.byte(il.native)).isPresent()) {
            return optional;
        }
        optional = iZ2.byte(il.import);
        if (optional.isPresent()) {
            return optional;
        }
        Optional<rhd_2> optional3 = iZ2.byte(il.B);
        return optional3.isPresent() && rbw_0.throws(optional3.get()) ? optional3 : Optional.empty();
    }

    private static boolean goto(rbk_0 rbk_02) {
        return rbk_02.Sn().class() || !rbw_0.class(rbk_02.Sn().break());
    }

    private static Optional<ib_0> case(rbm_0 rbm_02) {
        return ia_0.class((ib_0)rbm_02, il.short);
    }

    private static boolean case(ib_0 ib_02) {
        return ib_02.SF().class(il.h);
    }

    protected static void case(rbk_0 rbk_02) {
        rbw_0.volatile(rbk_02).forEach(rbw_0::byte);
    }

    private static rph_2<rbk_0> case() {
        return new rph_2<rbk_0>(new rps_1<rbk_0, an>(rbk_0::n_, il.P, il.super, protected), byte);
    }

    private static void case(iZ<rbk_0> iZ2) {
        iZ2.class(iq.package, 10, (ImmutableList<rpm_1<rbk_0>>)ImmutableList.of(new rpb_1(0.8f), (Object)new rro_1(rbw_0::break, 8.0f), new rpn_2<rbk_0>(an::Pm, rbw_0.class()), new rpq_2(8, rbw_0::class)), il.super);
    }

    private static void continue(rbk_0 rbk_02) {
        rbk_02.SF().class(il.X, true, 200L);
    }

    private static boolean else(rbk_0 rbk_02) {
        return rbk_02.SF().class(il.const);
    }

    private static List<rdn_1> implements(rbk_0 rbk_02) {
        rzl_2 rzl_22 = ((rYB)rbk_02.throws[7]).const().o().class(rzl_1.l);
        return rzl_22.class(new rzp_2((rrEm)((rYB)rbk_02.throws[7])).class(rzq_2.class, rbk_02).class(((rYB)rbk_02.throws[7]).int).class(rzz_2.private));
    }

    private static boolean new(rbk_0 rbk_02) {
        int n2 = rbk_02.SF().byte(il.M).orElse(0) + 1;
        int n3 = rbk_02.SF().byte(il.O).orElse(0);
        return n3 > n2;
    }

    private static boolean package(rbk_0 rbk_02) {
        iZ<rbk_0> iZ2 = rbk_02.SF();
        if (!iZ2.class(il.while)) {
            return true;
        }
        ib_0 ib_02 = iZ2.byte(il.while).get();
        ai_0<?> ai_02 = ib_02.BC();
        if (ai_02 == ai_0.long) {
            return rbw_0.int(rbk_02);
        }
        if (rbw_0.class(ai_02)) {
            return !iZ2.break(il.b, ib_02);
        }
        return false;
    }

    private static boolean return(rbk_0 rbk_02) {
        return rbk_02.SF().class(il.transient);
    }

    private static rjU super(rbk_0 rbk_02) {
        rjU rjU2 = iX.break(rbk_02, 4, 2);
        return rjU2 == null ? rbk_02.Ps() : rjU2;
    }

    private static boolean public(rbk_0 rbk_02) {
        return !rbk_02.Sn().class();
    }

    private static void protected(rbk_0 rbk_02, rdn_1 rdn_12) {
        rdn_1 rdn_13 = rbk_02.extends(rdn_12);
        rbw_0.break(rbk_02, Collections.singletonList(rdn_13));
    }

    private static rps_1<rbk_0, ib_0> protected() {
        return new rps_1<rbk_0, ib_0>(rbk_0::n_, il.import, il.while, catch);
    }

    public static Optional<rqa_0> protected(rbk_0 rbk_02) {
        return rbk_02.SF().protected().map(iq2 -> rbw_0.class(rbk_02, iq2));
    }

    private static void protected(iZ<rbk_0> iZ2) {
        iZ2.class(iq.volatile, 10, (ImmutableList<rpm_1<rbk_0>>)ImmutableList.of(new rps_2<rbk_0>(rbw_0::goto, 1.0f, true, 9), new rbx_0(9), new rbn_0(200, 200)), il.const);
    }

    protected static boolean protected(rbm_0 rbm_02) {
        return rbm_02.SF().byte(iq.break);
    }

    private static void protected(ib_0 ib_02) {
        ib_02.SF().class(il.const, true, 120L);
    }

    private static void protected(rbm_0 rbm_02, ib_0 ib_02) {
        Optional<rhd_2> optional = rbw_0.break(rbm_02);
        if (optional.isPresent()) {
            rbw_0.byte(rbm_02, (ib_0)optional.get());
        } else {
            rbw_0.byte(rbm_02, ib_02);
        }
    }

    private static void protected(rbk_0 rbk_02, ib_0 ib_02) {
        iZ<rbk_0> iZ2 = rbk_02.SF();
        ib_0 ib_03 = ia_0.class((ib_0)rbk_02, iZ2.byte(il.while), ib_02);
        ib_03 = ia_0.class((ib_0)rbk_02, iZ2.byte(il.package), ib_03);
        rbw_0.throws(rbk_02, ib_03);
    }

    private static boolean private(ib_0 ib_02) {
        return ib_02.SF().class(il.public);
    }

    private static boolean private(rbk_0 rbk_02) {
        if (!rbk_02.n_()) {
            return false;
        }
        an an2 = rbk_02.ra();
        return an2 instanceof rbk_0 && ((rbk_0)an2).n_() || an2 instanceof reg_1 && ((reg_1)an2).n_();
    }

    private static void final(rbk_0 rbk_02) {
        rbk_02.SF().break(il.volatile);
        rbk_02.public().final();
    }

    private static List<rbm_0> volatile(rbk_0 rbk_02) {
        return rbk_02.SF().byte(il.s).orElse((List<rbm_0>)ImmutableList.of());
    }

    private static boolean synchronized(rbk_0 rbk_02) {
        return rbk_02.SF().class(il.J);
    }

    private static boolean native(rbk_0 rbk_02) {
        iZ<rbk_0> iZ2 = rbk_02.SF();
        return !iZ2.class(il.while) ? false : iZ2.byte(il.while).get().class((an)rbk_02, 12.0);
    }
}

