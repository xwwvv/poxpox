/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.brigadier.arguments.BoolArgumentType
 *  com.mojang.brigadier.arguments.DoubleArgumentType
 *  com.mojang.brigadier.arguments.FloatArgumentType
 *  com.mojang.brigadier.arguments.IntegerArgumentType
 *  com.mojang.brigadier.arguments.LongArgumentType
 *  com.mojang.brigadier.arguments.StringArgumentType
 */
package protected;

import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.arguments.FloatArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.LongArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import protected.YR;
import protected.YV;
import protected.Yg;
import protected.Yj;
import protected.re_0;
import protected.rg_0;
import protected.yy_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class Yf {
    public static boolean class(byte by) {
        return (by & 1) != 0;
    }

    public static byte class(boolean bl2, boolean bl3) {
        byte by = 0;
        if (bl2) {
            by = (byte)(by | 1);
        }
        if (bl3) {
            by = (byte)(by | 2);
        }
        return by;
    }

    public static void class() {
        rg_0.class("brigadier:bool", BoolArgumentType.class, new re_0<BoolArgumentType>(BoolArgumentType::bool));
        rg_0.class("brigadier:float", FloatArgumentType.class, new YV());
        rg_0.class("brigadier:double", DoubleArgumentType.class, new Yj());
        rg_0.class("brigadier:integer", IntegerArgumentType.class, new Yg());
        rg_0.class("brigadier:long", LongArgumentType.class, new YR());
        rg_0.class("brigadier:string", StringArgumentType.class, new yy_0());
    }

    public static boolean break(byte by) {
        return (by & 2) != 0;
    }
}

