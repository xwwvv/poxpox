/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonNull
 *  com.google.gson.JsonObject
 */
package protected;

import com.google.gson.JsonElement;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;
import protected.rfH;
import protected.rpY;
import protected.rrEm;
import protected.xf_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.XQ
 */
public class xq_2 {
    public static final xq_2 class = new xq_2(xf_2.throws);
    private final xf_2 break;

    private xq_2(xf_2 xf_22) {
        this.break = xf_22;
    }

    public boolean class(rrEm rrEm2, rfH rfH2) {
        if (this == xq_2.class) {
            return true;
        }
        if (!rrEm2.synchronized(rfH2)) {
            return false;
        }
        return this.break.byte(rrEm2.package(rfH2));
    }

    public static xq_2 class(JsonElement jsonElement) {
        if (jsonElement != null && !jsonElement.isJsonNull()) {
            JsonObject jsonObject = rpY.private(jsonElement, "light");
            xf_2 xf_22 = xf_2.class(jsonObject.get("light"));
            return new xq_2(xf_22);
        }
        return xq_2.class;
    }

    public JsonElement class() {
        if (this == xq_2.class) {
            return JsonNull.INSTANCE;
        }
        JsonObject jsonObject = new JsonObject();
        jsonObject.add("light", this.break.protected());
        return jsonObject;
    }
}

