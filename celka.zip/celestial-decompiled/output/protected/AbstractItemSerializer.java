/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.util.function.Supplier;
import protected.iD;
import protected.iK;
import protected.iU;
import protected.iV;
import protected.iY;
import protected.ia;
import protected.ie_0;
import protected.ig_0;
import protected.ii;
import protected.io_0;
import protected.ir_0;
import protected.rqo_0;
import protected.rrb_2;
import protected.rrr_2;
import protected.rrs_1;
import protected.rrs_2;
import protected.rvl_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.rrP
 */
public class rrp_2<U extends rrr_2<?>> {
    public static final rrp_2<iV> class = rrp_2.class("dummy", iV::new);
    public static final rrp_2<rrs_1> break = rrp_2.class("nearest_items", rrs_1::new);
    public static final rrp_2<iD> byte = rrp_2.class("nearest_living_entities", iD::new);
    public static final rrp_2<iU> protected = rrp_2.class("nearest_players", iU::new);
    public static final rrp_2<iK> throws = rrp_2.class("nearest_bed", iK::new);
    public static final rrp_2<iY> case = rrp_2.class("hurt_by", iY::new);
    public static final rrp_2<rrs_2> catch = rrp_2.class("villager_hostiles", rrs_2::new);
    public static final rrp_2<rrb_2> private = rrp_2.class("villager_babies", rrb_2::new);
    public static final rrp_2<ii> implements = rrp_2.class("secondary_pois", ii::new);
    public static final rrp_2<ig_0> finally = rrp_2.class("golem_detected", ig_0::new);
    public static final rrp_2<ia> extends = rrp_2.class("piglin_specific_sensor", ia::new);
    public static final rrp_2<ie_0> native = rrp_2.class("piglin_brute_specific_sensor", ie_0::new);
    public static final rrp_2<ir_0> volatile = rrp_2.class("hoglin_specific_sensor", ir_0::new);
    public static final rrp_2<io_0> final = rrp_2.class("nearest_adult", io_0::new);
    private final Supplier<U> package;

    private rrp_2(Supplier<U> supplier) {
        this.package = supplier;
    }

    public U class() {
        return (U)((rrr_2)this.package.get());
    }

    private static <U extends rrr_2<?>> rrp_2<U> class(String string, Supplier<U> supplier) {
        return rvl_0.class(rvl_0.k, new rqo_0(string), new rrp_2<U>(supplier));
    }
}

