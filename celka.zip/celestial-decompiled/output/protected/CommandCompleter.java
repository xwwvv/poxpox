/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.util.stream.Stream;
import protected.for;
import protected.x;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public interface transient {
    public Stream<String> class(for var1) throws x;
}

