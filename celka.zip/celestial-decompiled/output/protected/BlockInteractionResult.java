/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.jq_1;
import protected.rYB;
import protected.rdn_1;
import protected.rdy_2;
import protected.rfH;
import protected.rff;
import protected.rhd_2;
import protected.rpb_0;
import protected.rpm;
import protected.rpr_0;
import protected.rql_0;
import protected.rqn;
import protected.rse_0;
import protected.ryz_1;
import protected.xc_0;
import protected.xr_0;
import protected.xu_0;
import protected.xy_0;
import protected.zh_2;
import protected.zo_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.WO
 */
public class wo_2
extends zh_2 {
    protected wo_2(jq_1 jq_12) {
        super(jq_12);
    }

    @Override
    public ryz_1 class(xc_0 xc_02, rYB rYB2, rfH rfH2, rhd_2 rhd_23, rpm rpm2, rff rff2) {
        rdn_1 rdn_12 = rhd_23.protected(rpm2);
        if (rdn_12.break() == rdy_2.JJ) {
            if (!rYB2.continue) {
                rpr_0 rpr_02 = rff2.break();
                rpr_0 rpr_03 = rpr_02.final() == rpb_0.Y ? rhd_23.Pg().case() : rpr_02;
                rYB2.class((rhd_2)null, rfH2, rqn.XS, rql_0.BLOCKS, 1.0f, 1.0f);
                rYB2.class(rfH2, (xc_0)xu_0.Br.continue().class(xy_0.volatile, rpr_03), 11);
                rse_0 rse_02 = new rse_0(rYB2, (double)rfH2.b_() + 0.5 + (double)rpr_03.implements() * 0.65, (double)rfH2.c_() + 0.1, (double)rfH2.d_() + 0.5 + (double)rpr_03.extends() * 0.65, new rdn_1(rdy_2.Jk, 4));
                rse_02.catch(0.05 * (double)rpr_03.implements() + rYB2.int.nextDouble() * 0.02, 0.05, 0.05 * (double)rpr_03.extends() + rYB2.int.nextDouble() * 0.02);
                rYB2.a_(rse_02);
                rdn_12.class(1, rhd_23, (T rhd_22) -> rhd_22.byte(rpm2));
            }
            return ryz_1.class(rYB2.continue);
        }
        return super.class(xc_02, rYB2, rfH2, rhd_23, rpm2, rff2);
    }

    @Override
    public zo_2 break() {
        return (zo_2)xu_0.Bo;
    }

    @Override
    public xr_0 implements() {
        return (xr_0)xu_0.BR;
    }
}

