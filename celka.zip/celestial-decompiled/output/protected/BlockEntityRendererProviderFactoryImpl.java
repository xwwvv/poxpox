/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonNull
 *  com.google.gson.JsonObject
 *  com.google.gson.JsonPrimitive
 *  com.mojang.brigadier.ImmutableStringReader
 *  com.mojang.brigadier.Message
 *  com.mojang.brigadier.StringReader
 *  com.mojang.brigadier.exceptions.CommandSyntaxException
 *  com.mojang.brigadier.exceptions.DynamicCommandExceptionType
 *  com.mojang.brigadier.exceptions.SimpleCommandExceptionType
 */
package protected;

import com.google.gson.JsonElement;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import com.mojang.brigadier.ImmutableStringReader;
import com.mojang.brigadier.Message;
import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.DynamicCommandExceptionType;
import com.mojang.brigadier.exceptions.SimpleCommandExceptionType;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.Supplier;
import protected.rgn;
import protected.rpY;
import protected.xv_2;
import protected.xz_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.Xu
 */
public abstract class xu_2<T extends Number> {
    public static final SimpleCommandExceptionType class = new SimpleCommandExceptionType((Message)new rgn("argument.range.empty"));
    public static final SimpleCommandExceptionType break = new SimpleCommandExceptionType((Message)new rgn("argument.range.swapped"));
    protected final T byte;
    protected final T protected;

    public boolean byte() {
        return this.byte == null && this.protected == null;
    }

    protected xu_2(T t2, T t3) {
        this.byte = t2;
        this.protected = t3;
    }

    protected static <T extends Number, R extends xu_2<T>> R class(StringReader stringReader, xv_2<T, R> xv_22, Function<String, T> function, Supplier<DynamicCommandExceptionType> supplier, Function<T, T> function2) throws CommandSyntaxException {
        if (!stringReader.canRead()) {
            throw xu_2.class.createWithContext((ImmutableStringReader)stringReader);
        }
        int n2 = stringReader.getCursor();
        try {
            Number number;
            Number number2 = (Number)xu_2.class(xu_2.class(stringReader, function, supplier), function2);
            if (stringReader.canRead(2) && stringReader.peek() == '.' && stringReader.peek(1) == '.') {
                stringReader.skip();
                stringReader.skip();
                number = (Number)xu_2.class(xu_2.class(stringReader, function, supplier), function2);
                if (number2 == null && number == null) {
                    throw xu_2.class.createWithContext((ImmutableStringReader)stringReader);
                }
            } else {
                number = number2;
            }
            if (number2 == null && number == null) {
                throw xu_2.class.createWithContext((ImmutableStringReader)stringReader);
            }
            return xv_22.create(stringReader, number2, number);
        }
        catch (CommandSyntaxException commandSyntaxException) {
            stringReader.setCursor(n2);
            throw new CommandSyntaxException(commandSyntaxException.getType(), commandSyntaxException.getRawMessage(), commandSyntaxException.getInput(), n2);
        }
    }

    protected static <T extends Number, R extends xu_2<T>> R class(JsonElement jsonElement, R r, BiFunction<JsonElement, String, T> biFunction, xz_1<T, R> xz_12) {
        if (jsonElement != null && !jsonElement.isJsonNull()) {
            if (rpY.break(jsonElement)) {
                Number number = (Number)biFunction.apply(jsonElement, "value");
                return xz_12.create(number, number);
            }
            JsonObject jsonObject = rpY.private(jsonElement, "value");
            Number number = jsonObject.has("min") ? (Number)((Number)biFunction.apply(jsonObject.get("min"), "min")) : (Number)null;
            Number number2 = jsonObject.has("max") ? (Number)((Number)biFunction.apply(jsonObject.get("max"), "max")) : (Number)null;
            return xz_12.create(number, number2);
        }
        return r;
    }

    private static boolean class(StringReader stringReader) {
        char c = stringReader.peek();
        if ((c < '0' || c > '9') && c != '-') {
            if (c != '.') {
                return false;
            }
            return !stringReader.canRead(2) || stringReader.peek(1) != '.';
        }
        return true;
    }

    private static <T> T class(T t2, Function<T, T> function) {
        return t2 == null ? null : (T)function.apply(t2);
    }

    private static <T extends Number> T class(StringReader stringReader, Function<String, T> function, Supplier<DynamicCommandExceptionType> supplier) throws CommandSyntaxException {
        int n2 = stringReader.getCursor();
        while (stringReader.canRead() && xu_2.class(stringReader)) {
            stringReader.skip();
        }
        String string = stringReader.getString().substring(n2, stringReader.getCursor());
        if (string.isEmpty()) {
            return (T)((Number)null);
        }
        try {
            return (T)((Number)function.apply(string));
        }
        catch (NumberFormatException numberFormatException) {
            throw supplier.get().createWithContext((ImmutableStringReader)stringReader, (Object)string);
        }
    }

    public T class() {
        return this.byte;
    }

    public T break() {
        return this.protected;
    }

    public JsonElement protected() {
        if (this.byte()) {
            return JsonNull.INSTANCE;
        }
        if (this.byte != null && this.byte.equals(this.protected)) {
            return new JsonPrimitive(this.byte);
        }
        JsonObject jsonObject = new JsonObject();
        if (this.byte != null) {
            jsonObject.addProperty("min", this.byte);
        }
        if (this.protected != null) {
            jsonObject.addProperty("max", this.protected);
        }
        return jsonObject;
    }
}

