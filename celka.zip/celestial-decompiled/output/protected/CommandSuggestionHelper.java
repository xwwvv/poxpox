/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.function.Supplier;
import protected.qj_1;
import protected.qy_1;
import protected.rVj;
import protected.rfU;
import protected.rgF;
import protected.rqR;
import protected.rqu_0;
import protected.vm_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.ux
 */
public class ux_1 {
    private final Supplier<String> class;
    private final Consumer<String> break;
    private final Supplier<String> byte;
    private final Consumer<String> protected;
    private final Predicate<String> throws;
    private int case;
    private int catch;

    private int byte(int n2) {
        return rfU.class(n2, 0, this.class.get().length());
    }

    public void byte(int n2, boolean bl2) {
        this.case = this.byte(n2);
        this.class(bl2);
    }

    public static Consumer<String> byte(qy_1 qy_12) {
        return string -> ux_1.class(qy_12, string);
    }

    private String byte(String string) {
        if (this.catch == this.case) {
            return string;
        }
        int n2 = Math.min(this.case, this.catch);
        int n3 = Math.max(this.case, this.catch);
        String string2 = string.substring(0, n2) + string.substring(n3);
        this.catch = this.case = n2;
        return string2;
    }

    public void byte() {
        this.protected.accept(this.break(this.class.get()));
    }

    private void byte(boolean bl2) {
        this.case = this.class.get().length();
        this.class(bl2);
    }

    public ux_1(Supplier<String> supplier, Consumer<String> consumer, Supplier<String> supplier2, Consumer<String> consumer2, Predicate<String> predicate) {
        this.class = supplier;
        this.break = consumer;
        this.byte = supplier2;
        this.protected = consumer2;
        this.throws = predicate;
        this.throws();
    }

    public void class(int n2, int n3) {
        int n4 = this.class.get().length();
        this.case = rfU.class(n2, 0, n4);
        this.catch = rfU.class(n3, 0, n4);
    }

    public static void class(qy_1 qy_12, String string) {
        ((qj_1)qy_12.class[23]).class(string);
    }

    public void class() {
        String string = this.class.get();
        this.protected.accept(this.break(string));
        this.break.accept(this.byte(string));
    }

    public static Supplier<String> class(qy_1 qy_12) {
        return () -> ux_1.break(qy_12);
    }

    public void class(String string) {
        this.class(this.class.get(), string);
    }

    private void class(String string, String string2) {
        if (this.catch != this.case) {
            string = this.byte(string);
        }
        this.case = rfU.class(this.case, 0, string.length());
        String string3 = new StringBuilder(string).insert(this.case, string2).toString();
        if (this.throws.test(string3)) {
            this.break.accept(string3);
            this.catch = this.case = Math.min(string3.length(), this.case + string2.length());
        }
    }

    public boolean class(int n2) {
        if (vm_1.private(n2)) {
            this.protected();
            return true;
        }
        if (vm_1.catch(n2)) {
            this.byte();
            return true;
        }
        if (vm_1.case(n2)) {
            this.break();
            return true;
        }
        if (vm_1.throws(n2)) {
            this.class();
            return true;
        }
        if (n2 == 259) {
            this.break(-1);
            return true;
        }
        if (n2 == 261) {
            this.break(1);
        } else {
            if (n2 == 263) {
                if (vm_1.else()) {
                    this.break(-1, vm_1.synchronized());
                } else {
                    this.class(-1, vm_1.synchronized());
                }
                return true;
            }
            if (n2 == 262) {
                if (vm_1.else()) {
                    this.break(1, vm_1.synchronized());
                } else {
                    this.class(1, vm_1.synchronized());
                }
                return true;
            }
            if (n2 == 268) {
                this.break(vm_1.synchronized());
                return true;
            }
            if (n2 == 269) {
                this.byte(vm_1.synchronized());
                return true;
            }
        }
        return false;
    }

    public boolean class(char c) {
        if (rqu_0.class(c)) {
            this.class(this.class.get(), Character.toString(c));
        }
        return true;
    }

    private void class(boolean bl2) {
        if (!bl2) {
            this.catch = this.case;
        }
    }

    public void class(int n2, boolean bl2) {
        this.case = rqR.class(this.class.get(), this.case, n2);
        this.class(bl2);
    }

    private void break(boolean bl2) {
        this.case = 0;
        this.class(bl2);
    }

    public void break() {
        this.class(this.class.get(), this.byte.get());
        this.catch = this.case;
    }

    public void break(int n2) {
        String string = this.class.get();
        if (!string.isEmpty()) {
            String string2;
            if (this.catch != this.case) {
                string2 = this.byte(string);
            } else {
                int n3 = rqR.class(string, this.case, n2);
                int n4 = Math.min(n3, this.case);
                int n5 = Math.max(n3, this.case);
                string2 = new StringBuilder(string).delete(n4, n5).toString();
                if (n2 < 0) {
                    this.catch = this.case = n4;
                }
            }
            this.break.accept(string2);
        }
    }

    public void break(int n2, boolean bl2) {
        this.case = rVj.class(this.class.get(), n2, this.case, true);
        this.class(bl2);
    }

    public static String break(qy_1 qy_12) {
        return rgF.class(((qj_1)qy_12.class[23]).class().replaceAll("\\r", ""));
    }

    private String break(String string) {
        int n2 = Math.min(this.case, this.catch);
        int n3 = Math.max(this.case, this.catch);
        return string.substring(n2, n3);
    }

    public void throws() {
        this.byte(false);
    }

    public int catch() {
        return this.catch;
    }

    public int case() {
        return this.case;
    }

    public void protected() {
        this.catch = 0;
        this.case = this.class.get().length();
    }

    public boolean private() {
        return this.case != this.catch;
    }
}

