/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.case;
import protected.static;
import protected.try;
import protected.x;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.sh
 */
public class sh_0
extends try {
    private static byte[] break;
    private static String[] throws;
    private static short[] case;
    private static boolean[] catch;

    public sh_0(case case_) {
        String[] stringArray = new String[catch[0]];
        stringArray[sh_0.catch[1]] = throws[0];
        super(case_, stringArray);
    }

    static {
        sh_0.ntfClinit();
    }

    @Override
    public void class(String string, static static_) throws x {
        static_.class(catch[2]);
        ((case)this.class[case[0]]).float();
        this.case(throws[1]);
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0xBA46705D;
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0x1098305651E174BCL;
    }

    @Override
    public Stream<String> break(String string, static static_) {
        return Stream.empty();
    }

    public static String break(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{-91, 37, -20, -29, -70, -108, 104, -61}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    private static void throws() {
        throws = new String[]{new String("click"), new String("\u0412\u044b\u043f\u043e\u043b\u043d\u044f\u044e!"), new String("\u041e\u0442\u043a\u0440\u044b\u0432\u0430\u0435\u0442 \u043c\u0435\u043d\u044e \u0441 \u043a\u043b\u0438\u043a\u043e\u043c"), new String("\u041a\u043e\u043c\u0430\u043d\u0434\u0430 \"click\" \u043e\u0442\u043a\u0440\u044b\u0432\u0430\u0435\u0442 \u043c\u0435\u043d\u044e \u0433\u0434\u0435 \u0432\u044b \u043c\u043e\u0436\u0435\u0442\u0435 \u0432\u044b\u0431\u0440\u0430\u0442\u044c \u043b\u044e\u0431\u0443\u044e \u0446\u0435\u043b\u044c \u043a\u043b\u0438\u043a\u043d\u0443\u0432 \u043f\u043e \u043d\u0435\u0439."), new String(""), new String("\u0418\u0441\u043f\u043e\u043b\u044c\u0437\u043e\u0432\u0430\u043d\u0438\u0435:"), new String("> click")};
    }

    private static /* synthetic */ void ntfClinit() {
        sh_0.finally();
        sh_0.throws();
        sh_0.extends();
        sh_0.protected();
    }

    private static void finally() {
        boolean[] blArray = new boolean[6];
        blArray[0] = true;
        blArray[4] = true;
        blArray[5] = true;
        catch = blArray;
    }

    @Override
    public List<String> catch() {
        String[] stringArray = new String[break[0]];
        stringArray[sh_0.catch[3]] = throws[3];
        stringArray[sh_0.catch[4]] = throws[4];
        stringArray[sh_0.break[1]] = throws[5];
        stringArray[sh_0.break[2]] = throws[6];
        return Arrays.asList(stringArray);
    }

    private static void extends() {
        case = new short[1];
    }

    @Override
    public boolean case() {
        return catch[5];
    }

    @Override
    public String implements() {
        return throws[2];
    }

    private static void protected() {
        break = new byte[]{4, 2, 3};
    }
}

