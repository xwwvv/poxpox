/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.serialization.Codec
 */
package protected;

import com.mojang.serialization.Codec;
import protected.rld_2;
import protected.rlx_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.rLz
 */
public abstract class rlz_2<T extends rlx_1> {
    private final boolean class;
    private final rld_2<T> break;

    protected rlz_2(boolean bl2, rld_2<T> rld_22) {
        this.class = bl2;
        this.break = rld_22;
    }

    public abstract Codec<T> break();

    public boolean throws() {
        return this.class;
    }

    public rld_2<T> case() {
        return this.break;
    }
}

