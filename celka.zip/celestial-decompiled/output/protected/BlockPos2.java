/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.rfH;
import protected.rja;
import protected.rpr_0;
import protected.ru_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.bL
 */
public class bl_0
extends ru_1 {
    private static short[] catch;

    public bl_0 byte(rpr_0 rpr_02) {
        return new bl_0((Integer)this.break[catch[0]] + rpr_02.implements(), (Integer)this.break[catch[1]] + rpr_02.finally(), (Integer)this.break[catch[2]] + rpr_02.extends());
    }

    public bl_0(int n2, int n3, int n4) {
        super(n2, n3, n4);
    }

    static {
        bl_0.continue();
    }

    public bl_0 class(rja rja2) {
        return new bl_0((Integer)this.break[catch[6]] + rja2.b_(), (Integer)this.break[catch[7]] + rja2.c_(), (Integer)this.break[catch[8]] + rja2.d_());
    }

    @Override
    public /* synthetic */ ru_1 class(int n2, int n3, int n4) {
        return this.protected(n2, n3, n4);
    }

    @Override
    public /* synthetic */ ru_1 class(rpr_0 rpr_02) {
        return this.byte(rpr_02);
    }

    public static String break(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{69, 35, 61, 89, 99, -104, -9, -78}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    @Override
    public /* synthetic */ rfH break(int n2, int n3, int n4) {
        return this.protected(n2, n3, n4);
    }

    @Override
    public /* synthetic */ rfH break(rja rja2) {
        return this.class(rja2);
    }

    @Override
    public /* synthetic */ rfH break(rpr_0 rpr_02) {
        return this.byte(rpr_02);
    }

    private static long case(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0xF8496C3F97012D44L;
    }

    private static void continue() {
        short[] sArray = new short[9];
        sArray[1] = 1;
        sArray[2] = 2;
        sArray[4] = 1;
        sArray[5] = 2;
        sArray[7] = 1;
        sArray[8] = 2;
        catch = sArray;
    }

    private static int package(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0x8A6D3E7;
    }

    public bl_0 protected(int n2, int n3, int n4) {
        return new bl_0((Integer)this.break[catch[3]] + n2, (Integer)this.break[catch[4]] + n3, (Integer)this.break[catch[5]] + n4);
    }
}

