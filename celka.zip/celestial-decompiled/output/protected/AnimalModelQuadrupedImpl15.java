/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.util.Arrays;
import protected.an;
import protected.iq_1;
import protected.wn_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.wr
 */
public class wr_0<T extends an>
extends wn_0<T> {
    private final iq_1[] class = new iq_1[6];

    public wr_0() {
        this.class[0] = new iq_1(this, 0, 10);
        this.class[1] = new iq_1(this, 0, 0);
        this.class[2] = new iq_1(this, 0, 0);
        this.class[3] = new iq_1(this, 0, 0);
        this.class[4] = new iq_1(this, 0, 0);
        this.class[5] = new iq_1(this, 44, 10);
        int n2 = 20;
        int n3 = 8;
        int n4 = 16;
        int n5 = 4;
        this.class[0].class(-10.0f, -8.0f, -1.0f, 20.0f, 16.0f, 2.0f, 0.0f);
        this.class[0].class(0.0f, 4.0f, 0.0f);
        this.class[5].class(-9.0f, -7.0f, -1.0f, 18.0f, 14.0f, 1.0f, 0.0f);
        this.class[5].class(0.0f, 4.0f, 0.0f);
        this.class[1].class(-8.0f, -9.0f, -1.0f, 16.0f, 8.0f, 2.0f, 0.0f);
        this.class[1].class(-9.0f, 4.0f, 0.0f);
        this.class[2].class(-8.0f, -9.0f, -1.0f, 16.0f, 8.0f, 2.0f, 0.0f);
        this.class[2].class(9.0f, 4.0f, 0.0f);
        this.class[3].class(-8.0f, -9.0f, -1.0f, 16.0f, 8.0f, 2.0f, 0.0f);
        this.class[3].class(0.0f, 4.0f, -7.0f);
        this.class[4].class(-8.0f, -9.0f, -1.0f, 16.0f, 8.0f, 2.0f, 0.0f);
        this.class[4].class(0.0f, 4.0f, 7.0f);
        this.class[0].case = 1.5707964f;
        this.class[1].catch = 4.712389f;
        this.class[2].catch = 1.5707964f;
        this.class[3].catch = (float)Math.PI;
        this.class[5].case = -1.5707964f;
    }

    @Override
    public void class(T t2, float f2, float f3, float f4, float f5, float f6) {
        this.class[5].protected = 4.0f - f4;
    }

    @Override
    public Iterable<iq_1> class() {
        return Arrays.asList(this.class);
    }
}

