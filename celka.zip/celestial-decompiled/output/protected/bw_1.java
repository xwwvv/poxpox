/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Objects;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.rjU;
import protected.rqR;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.BW
 */
public class bw_1 {
    public Object[] class;
    private static byte[] break;
    private static boolean[] byte;
    private static long[] protected;
    private static short[] throws;

    public int byte() {
        return (Integer)this.class[throws[7]];
    }

    public bw_1(rjU rjU2, int n2) {
        this.private();
        Long l2 = rqR.break();
        this.class[bw_1.throws[9]] = l2;
        rjU rjU3 = rjU2;
        this.class[bw_1.throws[10]] = rjU3;
        Integer n3 = n2;
        this.class[bw_1.throws[11]] = n3;
    }

    static {
        bw_1.ntfClinit();
    }

    public boolean equals(Object object) {
        if (this == object) {
            return byte[0];
        }
        if (object == null || this.getClass() != object.getClass()) {
            return byte[1];
        }
        bw_1 bw_12 = (bw_1)object;
        return ((Integer)this.class[throws[0]]).intValue() == ((Integer)bw_12.class[throws[1]]).intValue() && Objects.equals((rjU)this.class[throws[2]], (rjU)bw_12.class[throws[3]]) ? byte[2] : byte[3];
    }

    public int hashCode() {
        Object[] objectArray = new Object[break[0]];
        objectArray[bw_1.byte[4]] = (rjU)this.class[throws[4]];
        objectArray[bw_1.byte[5]] = (int)((Integer)this.class[throws[5]]);
        return Objects.hash(objectArray);
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0x52B705A;
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0xC50CCCC7BC1EA199L;
    }

    public long class() {
        return (Long)this.class[throws[8]];
    }

    public static String class(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{-100, 69, -24, -33, -10, -91, -49, 61}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    public rjU break() {
        return (rjU)this.class[throws[6]];
    }

    private static void throws() {
        protected = new long[1];
    }

    private static /* synthetic */ void ntfClinit() {
        bw_1.protected();
        bw_1.throws();
        bw_1.catch();
        bw_1.case();
    }

    private static void catch() {
        short[] sArray = new short[12];
        sArray[0] = 1;
        sArray[1] = 1;
        sArray[5] = 1;
        sArray[7] = 1;
        sArray[8] = 2;
        sArray[9] = 2;
        sArray[11] = 1;
        throws = sArray;
    }

    private static void case() {
        break = new byte[]{2, 3, 2};
    }

    private static void protected() {
        boolean[] blArray = new boolean[8];
        blArray[0] = true;
        blArray[2] = true;
        blArray[5] = true;
        blArray[6] = true;
        byte = blArray;
    }

    private void private() {
        if (this.class == null) {
            Object[] objectArray = this.class = new Object[break[1]];
            objectArray[bw_1.byte[6]] = byte[7];
            objectArray[bw_1.break[2]] = protected[0];
        }
    }
}

