/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.List;
import java.util.stream.Stream;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.double;
import protected.for;
import protected.rgP;
import protected.rhd_2;
import protected.v_0;
import protected.x;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.B
 */
public class b_0
extends Enum<b_0>
implements double<rhd_2> {
    private static String[] strings08d11b4a38f53d99ba3c071826b34fcc;
    private static short[] shorts08d11b4a38f53d99ba3c071826b34fcc;
    public static Object[] staticFields08d11b4a38f53d99ba3c071826b34fcc;
    private static boolean[] booleans08d11b4a38f53d99ba3c071826b34fcc;
    private static byte[] bytes08d11b4a38f53d99ba3c071826b34fcc;

    private static void byte() {
        strings08d11b4a38f53d99ba3c071826b34fcc = new String[]{new String("INSTANCE")};
    }

    @Override
    public /* synthetic */ Object byte(for for_) throws x {
        return this.break(for_);
    }

    static {
        b_0.ntfClinit();
    }

    public static b_0[] values() {
        return (b_0[])((b_0[])staticFields08d11b4a38f53d99ba3c071826b34fcc[shorts08d11b4a38f53d99ba3c071826b34fcc[0]]).clone();
    }

    public static b_0 valueOf(String string) {
        return Enum.valueOf(b_0.class, string);
    }

    public static String class(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{-84, -61, 116, -7, 54, -127, -125, -94}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    @Override
    public Stream<String> class(for for_) throws x {
        return new v_0().break(b_0.protected(for_).stream().map(rhd_2::g).map(rgP::getString)).class(for_.class().extends()).break().protected();
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0x46D4CD9E93915BB6L;
    }

    private static void class() {
        boolean[] blArray = new boolean[5];
        blArray[0] = true;
        blArray[4] = true;
        booleans08d11b4a38f53d99ba3c071826b34fcc = blArray;
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0x3F774A39;
    }

    private static void break() {
        Object[] objectArray;
        objectArray = new Object[]{new b_0(), new b_0[]{(b_0)objectArray[0]}};
        staticFields08d11b4a38f53d99ba3c071826b34fcc = objectArray;
    }

    public rhd_2 break(for for_) throws x {
        String string = for_.class().extends();
        return b_0.protected(for_).stream().filter(rhd_22 -> rhd_22.g().getString().equalsIgnoreCase(string)).findFirst().orElse(null);
    }

    private static void throws() {
        bytes08d11b4a38f53d99ba3c071826b34fcc = new byte[]{2};
    }

    private static /* synthetic */ void ntfClinit() {
        b_0.class();
        b_0.byte();
        b_0.case();
        b_0.throws();
        b_0.break();
    }

    private static void case() {
        short[] sArray = new short[2];
        sArray[0] = 1;
        shorts08d11b4a38f53d99ba3c071826b34fcc = sArray;
    }

    private static List<? extends rhd_2> protected(for for_) {
        return for_.break().throw().case().continue();
    }

    private static /* synthetic */ b_0[] protected() {
        b_0[] b_0Array = new b_0[booleans08d11b4a38f53d99ba3c071826b34fcc[0]];
        b_0Array[b_0.booleans08d11b4a38f53d99ba3c071826b34fcc[1]] = (b_0)staticFields08d11b4a38f53d99ba3c071826b34fcc[shorts08d11b4a38f53d99ba3c071826b34fcc[1]];
        return b_0Array;
    }
}

