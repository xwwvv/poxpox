/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.bw_0;
import protected.rfH;
import protected.rs_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.bQ
 */
public class bq_0
extends rs_2 {
    private static short[] break;
    private static boolean[] byte;

    private static void byte() {
        short[] sArray = new short[2];
        sArray[1] = 2;
        break = sArray;
    }

    public bq_0(bw_0 bw_02, rfH rfH2) {
        super(rfH2);
    }

    static {
        bq_0.ntfClinit();
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0x814558C2;
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0xF360DE4BCF75638FL;
    }

    @Override
    public boolean break(int n2, int n3, int n4) {
        return (Integer)this.class[break[0]] == n2 && (Integer)this.class[break[1]] == n4 ? byte[0] : byte[1];
    }

    public static String break(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{-36, -63, -58, 88, 34, -100, 68, 33}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    private static /* synthetic */ void ntfClinit() {
        bq_0.protected();
        bq_0.byte();
    }

    private static void protected() {
        boolean[] blArray = new boolean[2];
        blArray[0] = true;
        byte = blArray;
    }
}

