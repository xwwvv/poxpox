/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.is;
import protected.rYB;
import protected.rdn_1;
import protected.rhd_2;
import protected.rhz_2;
import protected.rja_1;
import protected.rji_1;
import protected.rjs_2;
import protected.rjt_2;
import protected.rjw_1;
import protected.rjy_1;
import protected.rke_2;
import protected.rkw_2;
import protected.rqo_0;
import protected.rwr_2;
import protected.rxd_1;
import protected.rxk_1;
import protected.rxn_2;
import protected.rxq_1;
import protected.rxu_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.rJT
 */
public class rjt_1
extends rji_1<rxk_1> {
    public static final rqo_0 class = new rqo_0("textures/atlas/blocks.png");
    public static final rqo_0 break = new rqo_0("item/empty_armor_slot_helmet");
    public static final rqo_0 byte = new rqo_0("item/empty_armor_slot_chestplate");
    public static final rqo_0 protected = new rqo_0("item/empty_armor_slot_leggings");
    public static final rqo_0 catch = new rqo_0("item/empty_armor_slot_boots");
    public static final rqo_0 private = new rqo_0("item/empty_armor_slot_shield");
    public static final rqo_0[] implements = new rqo_0[]{catch, protected, byte, break};
    public static final rxq_1[] finally = new rxq_1[]{rxq_1.HEAD, rxq_1.CHEST, rxq_1.LEGS, rxq_1.FEET};
    private final rxk_1 native = new rxk_1(this, 2, 2);
    private final rxd_1 volatile = new rxd_1();
    public final boolean extends;
    private final rhd_2 final;

    @Override
    public int byte() {
        return this.native.protected();
    }

    public rjt_1(rhz_2 rhz_22, boolean bl2, rhd_2 rhd_22) {
        super(null, 0);
        int n2;
        this.extends = bl2;
        this.final = rhd_22;
        this.break(new rjs_2(rhz_22.throws, this.native, this.volatile, 0, 154, 28));
        for (n2 = 0; n2 < 2; ++n2) {
            for (int k = 0; k < 2; ++k) {
                this.break(new rjy_1(this.native, k + n2 * 2, 98 + k * 18, 18 + n2 * 18));
            }
        }
        for (n2 = 0; n2 < 4; ++n2) {
            rxq_1 rxq_12 = finally[n2];
            this.break(new rjt_2(this, rhz_22, 39 - n2, 8, 8 + n2 * 18, rxq_12));
        }
        for (n2 = 0; n2 < 3; ++n2) {
            for (int k = 0; k < 9; ++k) {
                this.break(new rjy_1(rhz_22, k + (n2 + 1) * 9, 8 + k * 18, 84 + n2 * 18));
            }
        }
        for (n2 = 0; n2 < 9; ++n2) {
            this.break(new rjy_1(rhz_22, n2, 8 + n2 * 18, 142));
        }
        this.break(new rjw_1(this, rhz_22, 40, 77, 62));
    }

    @Override
    public rdn_1 class(rhd_2 rhd_22, int n2) {
        rdn_1 rdn_12 = rdn_1.break;
        rjy_1 rjy_12 = (rjy_1)this.throws.get(n2);
        if (rjy_12 != null && rjy_12.break()) {
            int n3;
            rdn_1 rdn_13 = rjy_12.class();
            rdn_12 = rdn_13.implements();
            rxq_1 rxq_12 = is.finally(rdn_12);
            if (n2 == 0) {
                if (!this.class(rdn_13, 9, 45, true)) {
                    return rdn_1.break;
                }
                rjy_12.class(rdn_13, rdn_12);
            } else if (n2 >= 1 && n2 < 5 ? !this.class(rdn_13, 9, 45, false) : (n2 >= 5 && n2 < 9 ? !this.class(rdn_13, 9, 45, false) : (rxq_12.class() == rxn_2.ARMOR && !((rjy_1)this.throws.get(8 - rxq_12.break())).break() ? !this.class(rdn_13, n3 = 8 - rxq_12.break(), n3 + 1, false) : (rxq_12 == rxq_1.OFFHAND && !((rjy_1)this.throws.get(45)).break() ? !this.class(rdn_13, 45, 46, false) : (n2 >= 9 && n2 < 36 ? !this.class(rdn_13, 36, 45, false) : (n2 >= 36 && n2 < 45 ? !this.class(rdn_13, 9, 36, false) : !this.class(rdn_13, 9, 45, false))))))) {
                return rdn_1.break;
            }
            if (rdn_13.class()) {
                rjy_12.break(rdn_1.break);
            } else {
                rjy_12.byte();
            }
            if (rdn_13.char() == rdn_12.char()) {
                return rdn_1.break;
            }
            rdn_1 rdn_14 = rjy_12.class(rhd_22, rdn_13);
            if (n2 == 0) {
                rhd_22.class(rdn_14, false);
            }
        }
        return rdn_12;
    }

    @Override
    public void class() {
        this.volatile.public();
        this.native.public();
    }

    @Override
    public boolean class(rdn_1 rdn_12, rjy_1 rjy_12) {
        return rjy_12.byte != this.volatile && super.class(rdn_12, rjy_12);
    }

    @Override
    public void class(rwr_2 rwr_22) {
        this.native.class(rwr_22);
    }

    @Override
    public boolean class(rkw_2<? super rxk_1> rkw_22) {
        return rkw_22.class(this.native, (rYB)this.final.throws[7]);
    }

    @Override
    public void class(rxu_1 rxu_12) {
        rja_1.class(this.case, (rYB)this.final.throws[7], this.final, this.native, this.volatile);
    }

    @Override
    public boolean class(rhd_2 rhd_22) {
        return true;
    }

    @Override
    public int break() {
        return 0;
    }

    @Override
    public void break(rhd_2 rhd_22) {
        super.break(rhd_22);
        this.volatile.public();
        if (!((rYB)rhd_22.throws[7]).continue) {
            this.class(rhd_22, (rYB)rhd_22.throws[7], this.native);
        }
    }

    @Override
    public int throws() {
        return 5;
    }

    public rxk_1 case() {
        return this.native;
    }

    @Override
    public rke_2 implements() {
        return rke_2.CRAFTING;
    }

    @Override
    public int protected() {
        return this.native.byte();
    }
}

