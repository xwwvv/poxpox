/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.HU;
import protected.Hx;
import protected.aR;
import protected.an;
import protected.fZ;
import protected.ml_1;
import protected.ok_2;
import protected.qe_0;
import protected.rqo_0;
import protected.tf_1;
import protected.tp_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.TH
 */
public abstract class th_2<T extends an, M extends tp_0<T>>
extends tf_1<T, M> {
    public th_2(qe_0<T, M> qe_02) {
        super(qe_02);
    }

    protected abstract rqo_0 class();

    protected abstract float class(float var1);

    @Override
    public void class(ml_1 ml_12, Hx hx, int n2, T t2, float f2, float f3, float f4, float f5, float f6, float f7) {
        if (((aR)t2).class()) {
            float f8 = (float)((Integer)((an)t2).throws[41]).intValue() + f4;
            tp_0<T> tp_02 = this.break();
            tp_02.class(t2, f2, f3, f4);
            ((tp_0)this.byte()).class(tp_02);
            ok_2 ok_22 = hx.getBuffer(HU.class(this.class(), this.class(f8), f8 * 0.01f));
            tp_02.class(t2, f2, f3, f5, f6, f7);
            tp_02.class(ml_12, ok_22, n2, fZ.class, 0.5f, 0.5f, 0.5f, 1.0f);
        }
    }

    protected abstract tp_0<T> break();
}

