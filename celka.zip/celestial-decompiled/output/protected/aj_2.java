/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
package protected;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.atomic.AtomicInteger;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import protected.rya_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.AJ
 */
public class aj_2
extends Thread {
    private static final AtomicInteger class = new AtomicInteger(0);
    private static final Logger break = LogManager.getLogger();
    private final String byte;
    private final DatagramSocket protected;
    private boolean throws = true;
    private final String case;

    public aj_2(String string, String string2) throws IOException {
        super("LanServerPinger #" + aj_2.class.incrementAndGet());
        this.byte = string;
        this.case = string2;
        this.setDaemon(true);
        this.setUncaughtExceptionHandler(new rya_1(break));
        this.protected = new DatagramSocket();
    }

    @Override
    public void run() {
        String string = aj_2.class(this.byte, this.case);
        byte[] byArray = string.getBytes(StandardCharsets.UTF_8);
        while (!this.isInterrupted() && this.throws) {
            try {
                InetAddress inetAddress = InetAddress.getByName("224.0.2.60");
                DatagramPacket datagramPacket = new DatagramPacket(byArray, byArray.length, inetAddress, 4445);
                this.protected.send(datagramPacket);
            }
            catch (IOException iOException) {
                break.warn("LanServerPinger: {}", (Object)iOException.getMessage());
                break;
            }
            try {
                aj_2.sleep(1500L);
            }
            catch (InterruptedException interruptedException) {}
        }
    }

    @Override
    public void interrupt() {
        super.interrupt();
        this.throws = false;
    }

    public static String class(String string, String string2) {
        return "[MOTD]" + string + "[/MOTD][AD]" + string2 + "[/AD]";
    }

    public static String class(String string) {
        int n2 = string.indexOf("[MOTD]");
        if (n2 < 0) {
            return "missing no";
        }
        int n3 = string.indexOf("[/MOTD]", n2 + "[MOTD]".length());
        return n3 < n2 ? "missing no" : string.substring(n2 + "[MOTD]".length(), n3);
    }

    public static String break(String string) {
        int n2 = string.indexOf("[/MOTD]");
        if (n2 < 0) {
            return null;
        }
        int n3 = string.indexOf("[/MOTD]", n2 + "[/MOTD]".length());
        if (n3 >= 0) {
            return null;
        }
        int n4 = string.indexOf("[AD]", n2 + "[/MOTD]".length());
        if (n4 < 0) {
            return null;
        }
        int n5 = string.indexOf("[/AD]", n4 + "[AD]".length());
        return n5 < n4 ? null : string.substring(n4 + "[AD]".length(), n5);
    }
}

