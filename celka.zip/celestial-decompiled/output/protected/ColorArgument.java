/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.brigadier.StringReader
 *  com.mojang.brigadier.arguments.ArgumentType
 *  com.mojang.brigadier.context.CommandContext
 *  com.mojang.brigadier.exceptions.CommandSyntaxException
 *  com.mojang.brigadier.exceptions.DynamicCommandExceptionType
 *  com.mojang.brigadier.suggestion.Suggestions
 *  com.mojang.brigadier.suggestion.SuggestionsBuilder
 */
package protected;

import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.DynamicCommandExceptionType;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import java.util.Arrays;
import java.util.Collection;
import java.util.concurrent.CompletableFuture;
import protected.gR;
import protected.gy_0;
import protected.rgF;
import protected.rgn;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.RW
 */
public class rw_0
implements ArgumentType<rgF> {
    private static final Collection<String> break = Arrays.asList("red", "green");
    public static final DynamicCommandExceptionType class = new DynamicCommandExceptionType(object -> new rgn("argument.color.invalid", object));

    private rw_0() {
    }

    public static rw_0 class() {
        return new rw_0();
    }

    public rgF class(StringReader stringReader) throws CommandSyntaxException {
        String string = stringReader.readUnquotedString();
        rgF rgF2 = rgF.break(string);
        if (rgF2 != null && !rgF2.break()) {
            return rgF2;
        }
        throw rw_0.class.create((Object)string);
    }

    public static rgF class(CommandContext<gy_0> commandContext, String string) {
        return (rgF)((Object)commandContext.getArgument(string, rgF.class));
    }

    public /* synthetic */ Object parse(StringReader stringReader) throws CommandSyntaxException {
        return this.class(stringReader);
    }

    public Collection<String> getExamples() {
        return break;
    }

    public <S> CompletableFuture<Suggestions> listSuggestions(CommandContext<S> commandContext, SuggestionsBuilder suggestionsBuilder) {
        return gR.break(rgF.class(true, false), suggestionsBuilder);
    }
}

