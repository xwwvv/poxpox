/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.commons.io.FilenameUtils
 */
package protected;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import org.apache.commons.io.FilenameUtils;
import protected.case;
import protected.class;
import protected.e_0;
import protected.k_0;
import protected.ps_1;
import protected.rja;
import protected.ru_1;
import protected.s_0;
import protected.static;
import protected.try;
import protected.x;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.sO
 */
public class so_0
extends try {
    private static String[] throws;
    private static boolean[] case;
    private static short[] catch;
    private static byte[] private;
    public static Object[] break;

    public so_0(case case_) {
        String[] stringArray = new String[case[0]];
        stringArray[so_0.case[1]] = throws[0];
        super(case_, stringArray);
    }

    static {
        so_0.ntfClinit();
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0x18D84DBB;
    }

    @Override
    public void class(String string, static static_) throws x {
        ru_1 ru_12;
        File file = ((File)static_.break((e_0)e_0.staticFieldsa68f70fa3b203574ab28df4fae9f18d2[catch[0]], (File)break[catch[1]])).getAbsoluteFile();
        if (FilenameUtils.getExtension((String)file.getAbsolutePath()).isEmpty()) {
            file = new File(file.getAbsolutePath() + "." + (String)protected.class.instanceof().PZ.class[catch[2]]);
        }
        ru_1 ru_13 = ((ps_1)this.class[catch[3]]).volatile();
        if (static_.final()) {
            static_.class(private[0]);
            ru_12 = (ru_1)static_.break((s_0)s_0.staticFields2b61d3be194f3208a61ab56674f124f7[catch[4]], ru_13);
        } else {
            static_.class(case[2]);
            ru_12 = ru_13;
        }
        boolean bl2 = ((case)this.class[catch[5]]).r().class(file.getName(), file, (rja)ru_12);
        if (!bl2) {
            throw new k_0(throws[1]);
        }
        Object[] objectArray = new Object[case[3]];
        objectArray[so_0.case[4]] = ru_12;
        this.case(String.format(throws[2], objectArray));
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0xC442576FE0D96475L;
    }

    public static String break(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{117, -68, -5, -96, -69, -47, 58, 126}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    @Override
    public Stream<String> break(String string, static static_) throws x {
        if (static_.case()) {
            return e_0.class(static_, (File)break[catch[6]]);
        }
        if (static_.break(private[1])) {
            static_.throws();
            return static_.class((s_0)s_0.staticFields2b61d3be194f3208a61ab56674f124f7[catch[7]]);
        }
        return Stream.empty();
    }

    private static void throws() {
        Object[] objectArray = new Object[]{new File("C:\\Celestial\\Beta 1.16.5\\schematics")};
        break = objectArray;
    }

    private static /* synthetic */ void ntfClinit() {
        so_0.extends();
        so_0.native();
        so_0.finally();
        so_0.protected();
        so_0.throws();
    }

    private static void finally() {
        short[] sArray = new short[8];
        sArray[3] = 1;
        catch = sArray;
    }

    @Override
    public List<String> catch() {
        String[] stringArray = new String[private[2]];
        stringArray[so_0.case[5]] = throws[4];
        stringArray[so_0.case[6]] = throws[5];
        stringArray[so_0.private[3]] = throws[6];
        stringArray[so_0.private[4]] = throws[7];
        stringArray[so_0.private[5]] = throws[8];
        return Arrays.asList(stringArray);
    }

    private static void extends() {
        boolean[] blArray = new boolean[10];
        blArray[0] = true;
        blArray[3] = true;
        blArray[6] = true;
        blArray[7] = true;
        blArray[9] = true;
        case = blArray;
    }

    @Override
    public boolean case() {
        return case[7];
    }

    @Override
    public String implements() {
        return throws[3];
    }

    private static void protected() {
        private = new byte[]{3, 2, 5, 2, 3, 4, 24};
    }

    private static void native() {
        throws = new String[]{new String("build"), new String("\u041d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u0437\u0430\u0433\u0440\u0443\u0437\u0438\u0442\u044c \u0441\u0445\u0435\u043c\u0443. \u0423\u0431\u0435\u0434\u0438\u0442\u0435\u0441\u044c, \u0447\u0442\u043e \u0432\u044b \u0438\u0441\u043f\u043e\u043b\u044c\u0437\u0443\u0435\u0442\u0435 \u043f\u043e\u043b\u043d\u043e\u0435 \u0438\u043c\u044f \u0444\u0430\u0439\u043b\u0430, \u0432\u043a\u043b\u044e\u0447\u0430\u044f \u0440\u0430\u0441\u0448\u0438\u0440\u0435\u043d\u0438\u0435 (\u043d\u0430\u043f\u0440\u0438\u043c\u0435\u0440, blah.schematic)"), new String("\u0423\u0441\u043f\u0435\u0448\u043d\u043e \u0437\u0430\u0433\u0440\u0443\u0436\u0435\u043d\u0430 \u0441\u0445\u0435\u043c\u0430 \u0434\u043b\u044f \u0437\u0434\u0430\u043d\u0438\u044f\n\u041f\u0440\u043e\u0438\u0441\u0445\u043e\u0436\u0434\u0435\u043d\u0438\u0435: %s"), new String("\u041f\u043e\u0441\u0442\u0440\u043e\u0439\u0442\u0435 \u0441\u0445\u0435\u043c\u0443"), new String("\u041f\u043e\u0441\u0442\u0440\u043e\u0435\u043d\u0438\u0435 \u0441\u0445\u0435\u043c\u044b \u0438\u0437 \u0444\u0430\u0439\u043b\u0430"), new String(""), new String("\u0418\u0441\u043f\u043e\u043b\u044c\u0437\u043e\u0432\u0430\u043d\u0438\u0435:"), new String("> build <\u0438\u043c\u044f \u0444\u0430\u0439\u043b\u0430> - \u0417\u0430\u0433\u0440\u0443\u0436\u0430\u0435\u0442 \u0438 \u0441\u0442\u0440\u043e\u0438\u0442 '<\u0438\u043c\u044f \u0444\u0430\u0439\u043b\u0430>.schematic'"), new String("> build <\u0438\u043c\u044f \u0444\u0430\u0439\u043b\u0430> <x> <y> <z> - \u0412\u044b\u0431\u043e\u0440\u043e\u0447\u043d\u0430\u044f \u043f\u043e\u0437\u0438\u0446\u0438\u044f"), new String("schematics")};
    }
}

