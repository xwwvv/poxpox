/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.Gson
 *  com.google.gson.JsonArray
 *  com.google.gson.JsonElement
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
package protected;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import protected.rqo_0;
import protected.rqs_1;
import protected.rqz_2;
import protected.rzf_2;
import protected.rzk_2;
import protected.rzz_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.rWl
 */
public class rwl_1 {
    private static final Logger class = LogManager.getLogger();
    private final rqo_0 break;
    private final rzz_1 byte;
    private final Gson protected = rzf_2.class().create();

    public rwl_1(rqo_0 rqo_02, rzz_1 rzz_12) {
        this.break = rqo_02;
        this.byte = rzz_12;
    }

    public final rqz_2[] class(JsonArray jsonArray, String string, rzk_2 rzk_22) {
        rqz_2[] rqz_2Array = (rqz_2[])this.protected.fromJson((JsonElement)jsonArray, rqz_2[].class);
        rqs_1 rqs_12 = new rqs_1(rzk_22, this.byte::class, rqo_02 -> null);
        for (rqz_2 rqz_22 : rqz_2Array) {
            rqz_22.class(rqs_12);
            rqs_12.class().forEach((string2, string3) -> rwl_1.class.warn("Found validation problem in advancement trigger {}/{}: {}", (Object)string, string2, string3));
        }
        return rqz_2Array;
    }

    public rqo_0 class() {
        return this.break;
    }
}

