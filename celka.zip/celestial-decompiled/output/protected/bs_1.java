/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.bs_2;
import protected.px_2;
import protected.rrtj_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.BS
 */
public class bs_1
implements rrtj_1 {
    private static short[] break;
    public Object[] class;
    private static byte[] byte;

    private void byte() {
        if (this.class == null) {
            Object[] objectArray = this.class = new Object[byte[0]];
        }
    }

    public bs_1(px_2 px_22, boolean bl2) {
        this.byte();
        px_2 px_23 = px_22;
        this.class[bs_1.break[0]] = px_23;
        bs_2 bs_22 = bs_2.class(bl2);
        this.class[bs_1.break[1]] = bs_22;
    }

    static {
        bs_1.ntfClinit();
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0xF419271F;
    }

    public static String class(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{-85, -85, 85, 59, -118, -84, 56, -74}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    private static void class() {
        short[] sArray = new short[2];
        sArray[1] = 1;
        break = sArray;
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0x1189308119147681L;
    }

    private static void break() {
        byte = new byte[]{2};
    }

    private static /* synthetic */ void ntfClinit() {
        bs_1.class();
        bs_1.break();
    }
}

