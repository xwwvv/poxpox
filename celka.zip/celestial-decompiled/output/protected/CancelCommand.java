/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.case;
import protected.sn_0;
import protected.static;
import protected.try;
import protected.x;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.sv
 */
public class sv_0
extends try {
    private static short[] throws;
    public Object[] break;
    private static byte[] case;
    private static boolean[] catch;
    private static String[] private;

    public sv_0(sn_0 sn_02, case case_, String[] stringArray, boolean ... blArray) {
        super(case_, stringArray);
        this.extends();
        boolean[] blArray2 = blArray;
        this.break[sv_0.throws[0]] = blArray2;
    }

    static {
        sv_0.ntfClinit();
    }

    @Override
    public void class(String string, static static_) throws x {
        this.extends();
        static_.class(catch[0]);
        if (((boolean[])this.break[throws[1]])[catch[1]]) {
            ((boolean[])this.break[sv_0.throws[2]])[sv_0.catch[2]] = catch[3];
        }
        ((case)this.class[throws[3]]).this().break();
        this.case(private[0]);
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0x45EA1BE5;
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0xFEB6C39CB3A2EAD5L;
    }

    public static String break(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{49, 99, 119, 53, -105, 61, 113, 7}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    @Override
    public Stream<String> break(String string, static static_) {
        return Stream.empty();
    }

    private static void throws() {
        boolean[] blArray = new boolean[8];
        blArray[5] = true;
        blArray[6] = true;
        blArray[7] = true;
        catch = blArray;
    }

    private static /* synthetic */ void ntfClinit() {
        sv_0.throws();
        sv_0.protected();
        sv_0.finally();
        sv_0.native();
    }

    private static void finally() {
        throws = new short[4];
    }

    @Override
    public List<String> catch() {
        String[] stringArray = new String[case[0]];
        stringArray[sv_0.catch[4]] = private[2];
        stringArray[sv_0.catch[5]] = private[3];
        stringArray[sv_0.case[1]] = private[4];
        stringArray[sv_0.case[2]] = private[5];
        return Arrays.asList(stringArray);
    }

    private void extends() {
        if (this.break == null) {
            Object[] objectArray = this.break = new Object[catch[7]];
        }
    }

    @Override
    public boolean case() {
        return catch[6];
    }

    @Override
    public String implements() {
        return private[1];
    }

    private static void protected() {
        private = new String[]{new String("\u041e\u0442\u043c\u0435\u043d\u044f\u0435\u043c \u0432\u0441\u0435 \u043f\u0440\u043e\u0446\u0435\u0441\u0441\u044b \u0431\u0430\u0440\u0438\u0442\u043e\u043d\u0430"), new String("\u041e\u0442\u043c\u0435\u043d\u044f\u0435\u0442 \u0432\u0441\u0435 \u0430\u043a\u0442\u0438\u0432\u043d\u044b\u0435 \u043f\u0440\u043e\u0446\u0435\u0441\u0441\u044b \u0431\u0430\u0440\u0438\u0442\u043e\u043d\u0430"), new String("\u041a\u043e\u043c\u0430\u043d\u0434\u0430 \"cancel\" \u043e\u0442\u043c\u0435\u043d\u044f\u0435\u0442 \u0432\u0441\u0435 \u0430\u043a\u0442\u0438\u0432\u043d\u044b\u0435 \u043f\u0440\u043e\u0446\u0435\u0441\u0441\u044b \u0431\u0430\u0440\u0438\u0442\u043e\u043d\u0430"), new String(""), new String("\u0418\u0441\u043f\u043e\u043b\u044c\u0437\u043e\u0432\u0430\u043d\u0438\u0435:"), new String("> cancel")};
    }

    private static void native() {
        case = new byte[]{4, 2, 3};
    }
}

