/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 *  com.google.common.collect.Queues
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
package protected;

import com.google.common.collect.Lists;
import com.google.common.collect.Queues;
import java.util.ArrayList;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import protected.HU;
import protected.KY;
import protected.hv_0;
import protected.jm;
import protected.lD;
import protected.qy_1;
import protected.rYB;
import protected.rjU;
import protected.rrxa_0;
import protected.rrxr_0;
import protected.rth_2;
import protected.ym_2;
import protected.yn_2;
import protected.yq_2;
import protected.yx_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.yz
 */
public class yz_1 {
    private static final Logger byte = LogManager.getLogger();
    private final PriorityQueue<yn_2> protected = Queues.newPriorityQueue();
    private final Queue<hv_0> throws;
    private final Queue<Runnable> case = Queues.newConcurrentLinkedQueue();
    private volatile int catch;
    private volatile int private;
    final hv_0 implements;
    private final rth_2<Runnable> finally;
    private final Executor extends;
    rYB native;
    final yx_1 volatile;
    private rjU final = rjU.class;
    private final int package;
    private final List<hv_0> int = new ArrayList<hv_0>();
    public static final HU[] class = HU.public().toArray(new HU[0]);
    static final boolean new = rrxr_0.rb.byte();
    static final boolean continue = rrxr_0.Pt.byte();
    static final boolean super = rrxr_0.Pt.byte();
    static final boolean this = rrxr_0.rj.byte();
    public static int break;

    public boolean byte() {
        Runnable runnable;
        boolean bl2 = false;
        while ((runnable = this.case.poll()) != null) {
            runnable.run();
            bl2 = true;
        }
        return bl2;
    }

    public boolean byte(yq_2 yq_22) {
        if (this.throws.isEmpty()) {
            return false;
        }
        yq_22.class(this);
        return true;
    }

    public yz_1(rYB rYB2, yx_1 yx_12, Executor executor, boolean bl2, hv_0 hv_02) {
        this(rYB2, yx_12, executor, bl2, hv_02, -1);
    }

    public yz_1(rYB rYB2, yx_1 yx_12, Executor executor, boolean bl2, hv_0 hv_02, int n2) {
        this.native = rYB2;
        this.volatile = yx_12;
        int n3 = Math.max(1, (int)((double)Runtime.getRuntime().maxMemory() * 0.3) / (HU.public().stream().mapToInt(HU::goto).sum() * 4) - 1);
        int n4 = Runtime.getRuntime().availableProcessors();
        int n5 = bl2 ? n4 : Math.min(n4, 4);
        int n6 = Math.max(1, Math.min(n5, n3));
        if (n2 > 0) {
            n6 = n2;
        }
        this.implements = hv_02;
        ArrayList arrayList = Lists.newArrayListWithExpectedSize((int)n6);
        try {
            for (int k = 0; k < n6; ++k) {
                arrayList.add(new hv_0());
            }
        }
        catch (OutOfMemoryError outOfMemoryError) {
            byte.warn("Allocated only {}/{} buffers", (Object)arrayList.size(), (Object)n6);
            int n7 = Math.min(arrayList.size() * 2 / 3, arrayList.size() - 1);
            for (int k = 0; k < n7; ++k) {
                arrayList.remove(arrayList.size() - 1);
            }
            System.gc();
        }
        this.throws = Queues.newConcurrentLinkedQueue((Iterable)arrayList);
        this.package = this.private = this.throws.size();
        this.extends = executor;
        this.finally = rth_2.class(executor, "Chunk Renderer");
        this.finally.class(this::implements);
    }

    public void class(yn_2 yn_22) {
        this.finally.class(() -> {
            this.protected.offer(yn_22);
            this.catch = this.protected.size();
            this.implements();
        });
    }

    public CompletableFuture<Void> class(lD lD2, jm jm2) {
        return CompletableFuture.runAsync(() -> {}, this.case::add).thenCompose(void_ -> this.break(lD2, jm2));
    }

    public void class(rYB rYB2) {
        this.native = rYB2;
    }

    public void class(rjU rjU2) {
        this.final = rjU2;
    }

    public String class() {
        return String.format("pC: %03d, pU: %02d, aB: %02d", this.catch, this.case.size(), this.private);
    }

    public void class(yq_2 yq_22) {
        yq_22.extends();
    }

    public boolean break(yq_2 yq_22) {
        this.class(yq_22);
        return true;
    }

    private CompletableFuture<Void> break(lD lD2, jm jm2) {
        return jm2.break(lD2);
    }

    public rjU break() {
        return this.final;
    }

    public boolean throws() {
        return this.catch == 0 && this.case.isEmpty();
    }

    private void finally() {
        while (!this.protected.isEmpty()) {
            yn_2 yn_22 = this.protected.poll();
            if (yn_22 == null) continue;
            yn_22.class();
        }
        this.catch = 0;
    }

    public void catch() {
        long l2 = System.currentTimeMillis();
        if (this.int.size() <= 0) {
            while (this.int.size() != this.package) {
                this.byte();
                hv_0 hv_02 = this.throws.poll();
                if (hv_02 != null) {
                    this.int.add(hv_02);
                }
                if (System.currentTimeMillis() <= l2 + 1000L) continue;
                break;
            }
        }
    }

    public void case() {
        this.finally();
        this.finally.close();
        this.throws.clear();
    }

    private void implements() {
        yn_2 yn_22;
        if (!this.throws.isEmpty() && (yn_22 = this.protected.poll()) != null) {
            hv_0 hv_02 = this.throws.poll();
            if (hv_02 == null) {
                this.protected.add(yn_22);
                return;
            }
            this.catch = this.protected.size();
            this.private = this.throws.size();
            ((CompletableFuture)CompletableFuture.runAsync(() -> {}, this.extends).thenCompose(void_ -> yn_22.class(hv_02))).whenComplete((ym_22, throwable) -> {
                if (throwable != null) {
                    KY kY = KY.class(throwable, "Batching chunks");
                    qy_1.instanceof().break(qy_1.instanceof().class(kY));
                } else {
                    this.finally.class(() -> {
                        if (ym_22 == ym_2.SUCCESSFUL) {
                            hv_02.class();
                        } else {
                            hv_02.break();
                        }
                        this.throws.add(hv_02);
                        this.private = this.throws.size();
                        this.implements();
                    });
                }
            });
        }
    }

    public boolean protected(yq_2 yq_22) {
        return !this.throws.isEmpty() && yq_22.class(rrxa_0.protected, this);
    }

    public void protected() {
        this.finally();
    }

    public void private() {
        this.throws.addAll(this.int);
        this.int.clear();
    }
}

