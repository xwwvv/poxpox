/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.jq_1;
import protected.rRq;
import protected.rfH;
import protected.rpr_0;
import protected.xc_0;
import protected.xd_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.Wd
 */
public class wd_2
extends xd_0 {
    @Override
    public boolean byte(xc_0 xc_02) {
        return true;
    }

    public wd_2(jq_1 jq_12) {
        super(jq_12);
    }

    @Override
    public int class(xc_0 xc_02, rRq rRq2, rfH rfH2, rpr_0 rpr_02) {
        return 15;
    }
}

