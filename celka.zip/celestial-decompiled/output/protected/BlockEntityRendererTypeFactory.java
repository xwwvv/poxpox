/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonNull
 *  com.google.gson.JsonObject
 *  com.mojang.serialization.DynamicOps
 *  com.mojang.serialization.JsonOps
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
package protected;

import com.google.gson.JsonElement;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;
import com.mojang.serialization.DynamicOps;
import com.mojang.serialization.JsonOps;
import java.util.Optional;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import protected.ho_2;
import protected.rYB;
import protected.rfH;
import protected.rpY;
import protected.rqm_0;
import protected.rqo_0;
import protected.rrEm;
import protected.rrrZ;
import protected.rvl_0;
import protected.ryg_0;
import protected.xm_1;
import protected.xn;
import protected.xq_2;
import protected.xs_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.XN
 */
public class xn_2 {
    private static final Logger break = LogManager.getLogger();
    public static final xn_2 class = new xn_2(xm_1.throws, xm_1.throws, xm_1.throws, null, null, null, null, xq_2.class, ho_2.class, xs_2.class);
    private final xm_1 byte;
    private final xm_1 protected;
    private final xm_1 throws;
    private final rqm_0<ryg_0> case;
    private final rrrZ<?> catch;
    private final rqm_0<rYB> private;
    private final Boolean implements;
    private final xq_2 finally;
    private final ho_2 extends;
    private final xs_2 native;

    public xn_2(xm_1 xm_12, xm_1 xm_13, xm_1 xm_14, rqm_0<ryg_0> rqm_02, rrrZ<?> rrrZ2, rqm_0<rYB> rqm_03, Boolean bl2, xq_2 xq_22, ho_2 ho_22, xs_2 xs_22) {
        this.byte = xm_12;
        this.protected = xm_13;
        this.throws = xm_14;
        this.case = rqm_02;
        this.catch = rrrZ2;
        this.private = rqm_03;
        this.implements = bl2;
        this.finally = xq_22;
        this.extends = ho_22;
        this.native = xs_22;
    }

    public boolean class(rrEm rrEm2, float f2, float f3, float f4) {
        if (!this.byte.break(f2)) {
            return false;
        }
        if (!this.protected.break(f3)) {
            return false;
        }
        if (!this.throws.break(f4)) {
            return false;
        }
        if (this.private != null && this.private != rrEm2.E()) {
            return false;
        }
        rfH rfH2 = new rfH(f2, f3, f4);
        boolean bl2 = rrEm2.synchronized(rfH2);
        Optional<rqm_0<ryg_0>> optional = rrEm2.new().break(rvl_0.n).byte(rrEm2.implements(rfH2));
        if (!optional.isPresent()) {
            return false;
        }
        if (this.case == null || bl2 && this.case == optional.get()) {
            if (this.catch == null || bl2 && rrEm2.protected().class(rfH2, true, this.catch).throws()) {
                if (this.implements == null || bl2 && this.implements == xn.class(rrEm2, rfH2)) {
                    if (!this.finally.class(rrEm2, rfH2)) {
                        return false;
                    }
                    if (!this.extends.class(rrEm2, rfH2)) {
                        return false;
                    }
                    return this.native.class(rrEm2, rfH2);
                }
                return false;
            }
            return false;
        }
        return false;
    }

    public static xn_2 class(JsonElement jsonElement) {
        if (jsonElement != null && !jsonElement.isJsonNull()) {
            rqo_0 rqo_03;
            JsonObject jsonObject = rpY.private(jsonElement, "location");
            JsonObject jsonObject2 = rpY.class(jsonObject, "position", new JsonObject());
            xm_1 xm_12 = xm_1.class(jsonObject2.get("x"));
            xm_1 xm_13 = xm_1.class(jsonObject2.get("y"));
            xm_1 xm_14 = xm_1.class(jsonObject2.get("z"));
            rqm_0 rqm_02 = jsonObject.has("dimension") ? rqo_0.class.parse((DynamicOps)JsonOps.INSTANCE, (Object)jsonObject.get("dimension")).resultOrPartial(arg_0 -> ((Logger)break).error(arg_0)).map(rqo_02 -> rqm_0.class(rvl_0.static, rqo_02)).orElse(null) : null;
            rrrZ rrrZ2 = jsonObject.has("feature") ? (rrrZ)rrrZ.class.get((Object)rpY.case(jsonObject, "feature")) : null;
            rqm_0<ryg_0> rqm_03 = null;
            if (jsonObject.has("biome")) {
                rqo_03 = new rqo_0(rpY.case(jsonObject, "biome"));
                rqm_03 = rqm_0.class(rvl_0.n, rqo_03);
            }
            rqo_03 = jsonObject.has("smokey") ? Boolean.valueOf(jsonObject.get("smokey").getAsBoolean()) : null;
            xq_2 xq_22 = xq_2.class(jsonObject.get("light"));
            ho_2 ho_22 = ho_2.class(jsonObject.get("block"));
            xs_2 xs_22 = xs_2.class(jsonObject.get("fluid"));
            return new xn_2(xm_12, xm_13, xm_14, rqm_03, rrrZ2, rqm_02, (Boolean)((Object)rqo_03), xq_22, ho_22, xs_22);
        }
        return xn_2.class;
    }

    public JsonElement class() {
        if (this == xn_2.class) {
            return JsonNull.INSTANCE;
        }
        JsonObject jsonObject = new JsonObject();
        if (!(this.byte.byte() && this.protected.byte() && this.throws.byte())) {
            JsonObject jsonObject2 = new JsonObject();
            jsonObject2.add("x", this.byte.protected());
            jsonObject2.add("y", this.protected.protected());
            jsonObject2.add("z", this.throws.protected());
            jsonObject.add("position", (JsonElement)jsonObject2);
        }
        if (this.private != null) {
            rYB.break.encodeStart((DynamicOps)JsonOps.INSTANCE, this.private).resultOrPartial(arg_0 -> ((Logger)break).error(arg_0)).ifPresent(jsonElement -> jsonObject.add("dimension", jsonElement));
        }
        if (this.catch != null) {
            jsonObject.addProperty("feature", this.catch.catch());
        }
        if (this.case != null) {
            jsonObject.addProperty("biome", this.case.class().toString());
        }
        if (this.implements != null) {
            jsonObject.addProperty("smokey", this.implements);
        }
        jsonObject.add("light", this.finally.class());
        jsonObject.add("block", this.extends.class());
        jsonObject.add("fluid", this.native.class());
        return jsonObject;
    }

    public static xn_2 class(rrrZ<?> rrrZ2) {
        return new xn_2(xm_1.throws, xm_1.throws, xm_1.throws, null, rrrZ2, null, null, xq_2.class, ho_2.class, xs_2.class);
    }

    public boolean class(rrEm rrEm2, double d, double d2, double d3) {
        return this.class(rrEm2, (float)d, (float)d2, (float)d3);
    }

    public static xn_2 class(rqm_0<ryg_0> rqm_02) {
        return new xn_2(xm_1.throws, xm_1.throws, xm_1.throws, rqm_02, null, null, null, xq_2.class, ho_2.class, xs_2.class);
    }

    public static xn_2 break(rqm_0<rYB> rqm_02) {
        return new xn_2(xm_1.throws, xm_1.throws, xm_1.throws, null, null, rqm_02, null, xq_2.class, ho_2.class, xs_2.class);
    }
}

