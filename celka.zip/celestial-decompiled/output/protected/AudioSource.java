/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 *  org.lwjgl.openal.AL10
 */
package protected;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.concurrent.atomic.AtomicBoolean;
import javax.sound.sampled.AudioFormat;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.lwjgl.openal.AL10;
import protected.np_2;
import protected.nr_2;
import protected.nz_2;
import protected.rjU;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.NK
 */
public class nk_1 {
    private static final Logger class = LogManager.getLogger();
    private final int break;
    private final AtomicBoolean byte = new AtomicBoolean(true);
    private int protected = 16384;
    private nz_2 throws;

    public void byte(float f2) {
        AL10.alSourcei((int)this.break, (int)53248, (int)53251);
        AL10.alSourcef((int)this.break, (int)4131, (float)f2);
        AL10.alSourcef((int)this.break, (int)4129, (float)1.0f);
        AL10.alSourcef((int)this.break, (int)4128, (float)0.0f);
    }

    public void byte() {
        AL10.alSourcePlay((int)this.break);
    }

    private nk_1(int n2) {
        this.break = n2;
    }

    public void class(np_2 np_22) {
        np_22.class().ifPresent(n2 -> AL10.alSourcei((int)this.break, (int)4105, (int)n2));
    }

    static nk_1 class() {
        int[] nArray = new int[1];
        AL10.alGenSources((int[])nArray);
        return nr_2.class("Allocate new source") ? null : new nk_1(nArray[0]);
    }

    public void class(boolean bl2) {
        AL10.alSourcei((int)this.break, (int)4103, (int)(bl2 ? 1 : 0));
    }

    public void class(nz_2 nz_22) {
        this.throws = nz_22;
        AudioFormat audioFormat = nz_22.class();
        this.protected = nk_1.class(audioFormat, 1);
        this.class(4);
    }

    private static int class(AudioFormat audioFormat, int n2) {
        return (int)((float)(n2 * audioFormat.getSampleSizeInBits()) / 8.0f * (float)audioFormat.getChannels() * audioFormat.getSampleRate());
    }

    private void class(int n3) {
        if (this.throws != null) {
            try {
                for (int k = 0; k < n3; ++k) {
                    ByteBuffer byteBuffer = this.throws.class(this.protected);
                    if (byteBuffer == null) continue;
                    new np_2(byteBuffer, this.throws.class()).byte().ifPresent(n2 -> AL10.alSourceQueueBuffers((int)this.break, (int[])new int[]{n2}));
                }
            }
            catch (IOException iOException) {
                nk_1.class.error("Failed to read from audio stream", (Throwable)iOException);
            }
        }
    }

    public void class(float f2) {
        AL10.alSourcef((int)this.break, (int)4099, (float)f2);
    }

    public void class(rjU rjU2) {
        AL10.alSourcefv((int)this.break, (int)4100, (float[])new float[]{(float)rjU2.break, (float)rjU2.byte, (float)rjU2.protected});
    }

    public void break(float f2) {
        AL10.alSourcef((int)this.break, (int)4106, (float)f2);
    }

    public void break() {
        if (this.byte.compareAndSet(true, false)) {
            AL10.alSourceStop((int)this.break);
            nr_2.class("Stop");
            if (this.throws != null) {
                try {
                    this.throws.close();
                }
                catch (IOException iOException) {
                    nk_1.class.error("Failed to close audio stream", (Throwable)iOException);
                }
                this.extends();
                this.throws = null;
            }
            AL10.alDeleteSources((int[])new int[]{this.break});
            nr_2.class("Cleanup");
        }
    }

    public void break(boolean bl2) {
        AL10.alSourcei((int)this.break, (int)514, (int)(bl2 ? 1 : 0));
    }

    public void throws() {
        if (this.finally() == 4115) {
            AL10.alSourcePlay((int)this.break);
        }
    }

    private int finally() {
        return !this.byte.get() ? 4116 : AL10.alGetSourcei((int)this.break, (int)4112);
    }

    public boolean catch() {
        return this.finally() == 4116;
    }

    private int extends() {
        int n2 = AL10.alGetSourcei((int)this.break, (int)4118);
        if (n2 > 0) {
            int[] nArray = new int[n2];
            AL10.alSourceUnqueueBuffers((int)this.break, (int[])nArray);
            nr_2.class("Unqueue buffers");
            AL10.alDeleteBuffers((int[])nArray);
            nr_2.class("Remove processed buffers");
        }
        return n2;
    }

    public void case() {
        if (this.byte.get()) {
            AL10.alSourceStop((int)this.break);
            nr_2.class("Stop");
        }
    }

    public void implements() {
        if (this.throws != null) {
            int n2 = this.extends();
            this.class(n2);
        }
    }

    public void protected() {
        if (this.finally() == 4114) {
            AL10.alSourcePause((int)this.break);
        }
    }

    public void private() {
        AL10.alSourcei((int)this.break, (int)53248, (int)0);
    }
}

