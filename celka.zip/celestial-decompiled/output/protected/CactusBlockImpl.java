/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.util.Random;
import protected.an;
import protected.jq_1;
import protected.qp_2;
import protected.rCL;
import protected.rCZ;
import protected.rCm;
import protected.rRR;
import protected.rRg;
import protected.rRq;
import protected.rYB;
import protected.rct_0;
import protected.rfH;
import protected.rjC;
import protected.rjm;
import protected.rlg_0;
import protected.rlt_2;
import protected.rpb;
import protected.rpr_0;
import protected.rrEm;
import protected.rye_1;
import protected.xc_0;
import protected.xd_0;
import protected.xu_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.xL
 */
public class xl_0
extends xd_0 {
    public static final rCm volatile = rct_0.k;
    protected static final rjC final = xd_0.class(1.0, 0.0, 1.0, 15.0, 15.0, 15.0);
    protected static final rjC package = xd_0.class(1.0, 0.0, 1.0, 15.0, 16.0, 15.0);

    protected xl_0(jq_1 jq_12) {
        super(jq_12);
        this.extends((xc_0)((xc_0)this.abstract.break()).class(volatile, 0));
    }

    @Override
    public boolean class(xc_0 xc_02, rRR rRR2, rfH rfH2) {
        for (rpr_0 rpr_02 : rpb.HORIZONTAL) {
            xc_0 xc_03 = rRR2.byte(rfH2.break(rpr_02));
            qp_2 qp_22 = xc_03.byte();
            if (!qp_22.break() && !rRR2.break(rfH2.break(rpr_02)).class(rlg_0.byte)) continue;
            return false;
        }
        xc_0 xc_04 = rRR2.byte(rfH2.break());
        return (xc_04.class(xu_0.Pw) || xc_04.class(xu_0.throw) || xc_04.class(xu_0.interface)) && !rRR2.byte(rfH2.final()).byte().class();
    }

    @Override
    public void class(xc_0 xc_02, rYB rYB2, rfH rfH2, an an2) {
        an2.break(rye_1.finally, 1.0f);
    }

    @Override
    protected void class(rCL<xd_0, xc_0> rCL2) {
        rCL2.class(new rCZ[]{volatile});
    }

    @Override
    public boolean class(xc_0 xc_02, rRq rRq2, rfH rfH2, rlt_2 rlt_22) {
        return false;
    }

    @Override
    public xc_0 class(xc_0 xc_02, rpr_0 rpr_02, xc_0 xc_03, rRg rRg2, rfH rfH2, rfH rfH3) {
        if (!xc_02.class(rRg2, rfH2)) {
            rRg2.finally().class(rfH2, this, 1);
        }
        return super.class(xc_02, rpr_02, xc_03, rRg2, rfH2, rfH3);
    }

    @Override
    public void class(xc_0 xc_02, rrEm rrEm2, rfH rfH2, Random random) {
        rfH rfH3 = rfH2.final();
        if (rrEm2.finally(rfH3)) {
            int n2 = 1;
            while (rrEm2.byte(rfH2.catch(n2)).class(this)) {
                ++n2;
            }
            if (n2 < 3) {
                int n3 = xc_02.byte(volatile);
                if (n3 == 15) {
                    rrEm2.break(rfH3, this.continue());
                    xc_0 xc_03 = (xc_0)xc_02.class(volatile, 0);
                    rrEm2.class(rfH2, xc_03, 4);
                    xc_03.class(rrEm2, rfH3, this, rfH2, false);
                } else {
                    rrEm2.class(rfH2, (xc_0)xc_02.class(volatile, n3 + 1), 4);
                }
            }
        }
    }

    @Override
    public rjC class(xc_0 xc_02, rRq rRq2, rfH rfH2, rjm rjm2) {
        return package;
    }

    @Override
    public void break(xc_0 xc_02, rrEm rrEm2, rfH rfH2, Random random) {
        if (!xc_02.class((rRR)rrEm2, rfH2)) {
            rrEm2.break(rfH2, true);
        }
    }

    @Override
    public rjC break(xc_0 xc_02, rRq rRq2, rfH rfH2, rjm rjm2) {
        return final;
    }
}

