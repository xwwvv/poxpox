/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.fn_0;
import protected.uj_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.ul
 */
class ul_1
implements uj_2 {
    private final int class;
    private final int break;
    private final int byte;
    private final int protected;
    private final fn_0 throws;

    @Override
    public float byte() {
        return 2.0f;
    }

    ul_1(int n2, int n3, int n4, int n5, fn_0 fn_02) {
        this.class = n4;
        this.break = n5;
        this.byte = n2;
        this.protected = n3;
        this.throws = fn_02;
    }

    @Override
    public void class(int n2, int n3) {
        this.throws.class(0, n2, n3, this.byte, this.protected, this.class, this.break, false, false);
    }

    @Override
    public int class() {
        return this.class;
    }

    @Override
    public int break() {
        return this.break;
    }

    @Override
    public float catch() {
        return 0.5f;
    }

    @Override
    public float case() {
        return 0.5f;
    }

    @Override
    public boolean protected() {
        return this.throws.byte().class() > 1;
    }

    @Override
    public float getAdvance() {
        return this.class / 2 + 1;
    }
}

