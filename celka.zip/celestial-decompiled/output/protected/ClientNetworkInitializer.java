/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  io.netty.channel.Channel
 *  io.netty.channel.ChannelException
 *  io.netty.channel.ChannelHandler
 *  io.netty.channel.ChannelInitializer
 *  io.netty.channel.ChannelOption
 */
package protected;

import io.netty.channel.Channel;
import io.netty.channel.ChannelException;
import io.netty.channel.ChannelHandler;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelOption;
import protected.aa_2;
import protected.ad_2;
import protected.ak_2;
import protected.av_2;

/*
 * Renamed from protected.AL
 * Illegal identifiers - consider using --renameillegalidents true
 */
class al_1
extends ChannelInitializer<Channel> {
    final /* synthetic */ ad_2 class;
    final /* synthetic */ ak_2 break;

    al_1(av_2 av_22, ad_2 ad_22, ak_2 ak_22) {
        this.class = ad_22;
        this.break = ak_22;
    }

    protected void initChannel(Channel channel) throws Exception {
        try {
            channel.config().setOption(ChannelOption.TCP_NODELAY, (Object)true);
        }
        catch (ChannelException channelException) {
            // empty catch block
        }
        channel.pipeline().addLast(new ChannelHandler[]{new aa_2(this)});
    }
}

