/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.io.IOException;
import java.io.InputStream;
import protected.nz_2;

/*
 * Renamed from protected.Nl
 */
@FunctionalInterface
public interface nl_1 {
    public nz_2 create(InputStream var1) throws IOException;
}

