/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.bn_2;
import protected.bp_2;
import protected.bq_2;
import protected.bt_1;
import protected.bt_2;
import protected.bw_2;
import protected.class;
import protected.pv_2;
import protected.rfv_1;
import protected.rja;
import protected.rrfp;
import protected.rrfq;
import protected.rrje;
import protected.rrlo_2;
import protected.rrlu_2;
import protected.rrqx_1;
import protected.sh_2;
import protected.sx_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.SO
 */
public class so_2
extends pv_2 {
    private static boolean[] byte;
    private static short[] protected;
    public Object[] break;

    private static void byte() {
        byte = new boolean[]{true};
    }

    private void byte(String string) {
        this.class();
        bt_1 bt_12 = ((bw_2)this.break[protected[13]]).class(string);
        if (bt_12 == null || !bt_12.case()) {
            return;
        }
        ((rrqx_1)rrqx_1.staticFields09f1f28026cd378cb9df490a64ac8f2a[protected[14]]).finally().class(bp_2.class((bq_2)((Object)bq_2.staticFieldsc48d9c2a6a943f1684eec8a5f13e9034[protected[15]]), bt_12, (bt_2)((Object)bt_2.staticFields10e8ecd1ac80321e9230ae9a938c7436[protected[16]])));
    }

    public so_2(class clazz) {
        super(clazz);
        this.class();
        sx_1 sx_12 = new sx_1();
        this.break[so_2.protected[0]] = sx_12;
    }

    static {
        so_2.ntfClinit();
    }

    @Override
    public void class(rrlu_2 rrlu_22) {
        Object object = rrlu_22.class();
        if (object instanceof rfv_1) {
            rfv_1 rfv_12 = (rfv_1)object;
            if ((rrfq)((Object)rrfp.class[protected[1]]) != (rrfq)((Object)rrfq.staticFields8f8c034c8eef39ccbbc33e665d937d16[protected[2]])) {
                return;
            }
            object = rfv_12.protected();
            if (object == null) {
                return;
            }
            String string = object.byte();
            switch (((int[])sh_2.class[protected[3]])[rfv_12.byte().ordinal()]) {
                case 1: {
                    this.protected(string);
                    break;
                }
                case 2: {
                    this.byte(string);
                }
            }
        }
    }

    @Override
    public void class(rrlo_2 rrlo_22) {
        if (rrlo_22.class() != null || (rrfq)((Object)rrfp.class[protected[4]]) != (rrfq)((Object)rrfq.staticFields8f8c034c8eef39ccbbc33e665d937d16[protected[5]])) {
            return;
        }
        this.protected(rrlo_22.protected());
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0xBB7A2380;
    }

    private void class() {
        if (this.break == null) {
            Object[] objectArray = this.break = new Object[byte[0]];
        }
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0x91EA9752905BA696L;
    }

    public static String break(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{85, -62, -83, -92, -45, -74, -110, 6}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    private static void break() {
        short[] sArray = new short[17];
        sArray[1] = 1;
        sArray[4] = 1;
        sArray[16] = 1;
        protected = sArray;
    }

    private static /* synthetic */ void ntfClinit() {
        so_2.byte();
        so_2.break();
    }

    private void protected(String string) {
        this.class();
        bt_1 bt_12 = ((bw_2)this.break[protected[6]]).class(string);
        if (bt_12 == null) {
            return;
        }
        rja rja2 = null;
        if (bt_12 instanceof bn_2) {
            bn_2 bn_22 = (bn_2)bt_12;
            try {
                rja2 = bn_22.break(string);
            }
            catch (Exception exception) {
                exception.printStackTrace();
                return;
            }
            if (rja2 == null) {
                return;
            }
            bn_22.class(rja2);
        }
        bt_12.throws(string);
        if (rja2 != null) {
            boolean bl2 = ((rrje)((Object)rrje.staticFields67a5399629443d9d93e54c2de6d74063[protected[7]])).class(rja2);
            bt_12.protected(((rrje)((Object)rrje.staticFields67a5399629443d9d93e54c2de6d74063[protected[8]])).class(bt_12.throws(), bl2));
            if (((rrje)((Object)rrje.staticFields67a5399629443d9d93e54c2de6d74063[protected[9]])).protected(bt_12.throws()) && bl2) {
                return;
            }
        }
        ((rrqx_1)rrqx_1.staticFields09f1f28026cd378cb9df490a64ac8f2a[protected[10]]).finally().class(bp_2.class((bq_2)((Object)bq_2.staticFieldsc48d9c2a6a943f1684eec8a5f13e9034[protected[11]]), bt_12, (bt_2)((Object)bt_2.staticFields10e8ecd1ac80321e9230ae9a938c7436[protected[12]])));
    }
}

