/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.lwjgl.openal.AL10
 */
package protected;

import org.lwjgl.openal.AL10;
import protected.rjU;
import protected.rje;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.NZ
 */
public class nz_1 {
    private float class = 1.0f;
    private rjU break = rjU.class;

    public void byte() {
        this.class(rjU.class);
        this.class(rje.throws, rje.protected);
    }

    public void class(rje rje2, rje rje3) {
        AL10.alListenerfv((int)4111, (float[])new float[]{rje2.class(), rje2.break(), rje2.byte(), rje3.class(), rje3.break(), rje3.byte()});
    }

    public void class(float f2) {
        AL10.alListenerf((int)4106, (float)f2);
        this.class = f2;
    }

    public void class(rjU rjU2) {
        this.break = rjU2;
        AL10.alListener3f((int)4100, (float)((float)rjU2.break), (float)((float)rjU2.byte), (float)((float)rjU2.protected));
    }

    public rjU class() {
        return this.break;
    }

    public float break() {
        return this.class;
    }
}

