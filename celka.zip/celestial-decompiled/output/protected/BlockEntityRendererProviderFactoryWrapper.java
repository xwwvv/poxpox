/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonObject
 */
package protected;

import com.google.gson.JsonObject;
import protected.hl_1;
import protected.ho_1;
import protected.hz_1;
import protected.rhn_2;
import protected.rjU;
import protected.rwh_1;
import protected.xf_2;
import protected.xw_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.Xz
 */
public class xz_2
extends hz_1 {
    private final hl_1 class;
    private final xf_2 break;

    public xz_2(ho_1 ho_12, hl_1 hl_12, xf_2 xf_22) {
        super(xw_2.class, ho_12);
        this.class = hl_12;
        this.break = xf_22;
    }

    @Override
    public JsonObject class(rwh_1 rwh_12) {
        JsonObject jsonObject = super.class(rwh_12);
        jsonObject.add("distance", this.class.class());
        jsonObject.add("duration", this.break.protected());
        return jsonObject;
    }

    public boolean class(rhn_2 rhn_22, rjU rjU2, int n2) {
        if (!this.class.class(rjU2.break, rjU2.byte, rjU2.protected, rhn_22.rx(), rhn_22.re(), rhn_22.BO())) {
            return false;
        }
        return this.break.byte(n2);
    }

    public static xz_2 class(hl_1 hl_12) {
        return new xz_2(ho_1.class, hl_12, xf_2.throws);
    }
}

