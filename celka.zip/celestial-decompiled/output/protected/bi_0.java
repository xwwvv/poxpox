/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.annotation.Nullable
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import javax.annotation.Nullable;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.bw;
import protected.rRq;
import protected.rfH;
import protected.rxe_2;
import protected.ryo_2;
import protected.xc_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.bI
 */
public class bi_0
implements rRq {
    private static short[] break;
    private static boolean[] byte;
    public Object[] class;

    @Override
    public xc_0 byte(rfH rfH2) {
        return ((bw)this.class[break[1]]).class(rfH2.b_(), rfH2.c_(), rfH2.d_());
    }

    private static void byte() {
        byte = new boolean[]{true};
    }

    public bi_0(bw bw2) {
        this.break();
        bw bw3 = bw2;
        this.class[bi_0.break[0]] = bw3;
    }

    static {
        bi_0.ntfClinit();
    }

    private static void class() {
        break = new short[2];
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0x8DC237B47011B5D7L;
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0xAC81378D;
    }

    public static String class(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{-42, 53, 29, -108, -45, 72, -17, 22}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    @Override
    @Nullable
    public ryo_2 class(rfH rfH2) {
        return null;
    }

    private void break() {
        if (this.class == null) {
            Object[] objectArray = this.class = new Object[byte[0]];
        }
    }

    @Override
    public rxe_2 break(rfH rfH2) {
        return this.byte(rfH2).volatile();
    }

    private static /* synthetic */ void ntfClinit() {
        bi_0.byte();
        bi_0.class();
    }
}

