/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.rma_0;
import protected.rmf_0;
import protected.rml_0;
import protected.rmn;
import protected.rmv_0;
import protected.rub_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.AH
 */
public interface ah_1
extends rub_2 {
    public void class(rmv_0 var1);

    public void class(rml_0 var1);

    public void class(rmf_0 var1);

    public void class(rmn var1);

    public void class(rma_0 var1);
}

