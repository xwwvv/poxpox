/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.datafixers.schemas.Schema
 *  com.mojang.datafixers.types.templates.TypeTemplate
 */
package protected;

import com.mojang.datafixers.schemas.Schema;
import com.mojang.datafixers.types.templates.TypeTemplate;
import java.util.Map;
import java.util.function.Supplier;
import protected.rTA;

/*
 * Renamed from protected.rfP
 */
public class rfp_0
extends rTA {
    public rfp_0(int n2, Schema schema) {
        super(n2, schema);
    }

    public Map<String, Supplier<TypeTemplate>> registerBlockEntities(Schema schema) {
        Map map = super.registerBlockEntities(schema);
        map.remove("minecraft:flower_pot");
        map.remove("minecraft:noteblock");
        return map;
    }
}

