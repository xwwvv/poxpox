/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.rdn_1;
import protected.rkf_1;
import protected.rkg_2;
import protected.rkj_2;
import protected.rkw_2;
import protected.rqo_0;
import protected.rqs;
import protected.rxu_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.rWx
 */
public abstract class rwx_1
implements rkw_2<rxu_1> {
    protected final rkg_2 class;
    protected final rdn_1 break;
    private final rkj_2<?> throws;
    private final rkf_1<?> case;
    protected final rqo_0 byte;
    protected final String protected;

    @Override
    public rdn_1 byte() {
        return this.break;
    }

    public rwx_1(rkj_2<?> rkj_22, rkf_1<?> rkf_12, rqo_0 rqo_02, String string, rkg_2 rkg_22, rdn_1 rdn_12) {
        this.throws = rkj_22;
        this.case = rkf_12;
        this.byte = rqo_02;
        this.protected = string;
        this.class = rkg_22;
        this.break = rdn_12;
    }

    @Override
    public rdn_1 class(rxu_1 rxu_12) {
        return this.break.implements();
    }

    @Override
    public rqs<rkg_2> class() {
        rqs<rkg_2> rqs2 = rqs.class();
        rqs2.add(this.class);
        return rqs2;
    }

    @Override
    public boolean class(int n2, int n3) {
        return true;
    }

    @Override
    public rkj_2<?> catch() {
        return this.throws;
    }

    @Override
    public rqo_0 case() {
        return this.byte;
    }

    @Override
    public String protected() {
        return this.protected;
    }

    @Override
    public rkf_1<?> W_() {
        return this.case;
    }
}

