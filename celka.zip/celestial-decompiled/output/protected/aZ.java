/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 *  com.google.common.collect.Maps
 *  com.mojang.brigadier.StringReader
 *  com.mojang.brigadier.exceptions.CommandSyntaxException
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
package protected;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import protected.ai_0;
import protected.an;
import protected.ap;
import protected.iM;
import protected.ib_0;
import protected.qs_1;
import protected.rYB;
import protected.rab_2;
import protected.ras_1;
import protected.rcd_2;
import protected.rcy_2;
import protected.rfU;
import protected.rfj_2;
import protected.rli_1;
import protected.rlq_2;
import protected.rlx_1;
import protected.rly_1;
import protected.rme_0;
import protected.rrEm;
import protected.rus_2;
import protected.rut_2;
import protected.ruw_2;
import protected.rvl_0;
import protected.yc_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class aZ
extends an {
    private static final Logger class = LogManager.getLogger();
    private static final rut_2<Float> break = rme_0.class(aZ.class, ruw_2.byte);
    private static final rut_2<Integer> protected = rme_0.class(aZ.class, ruw_2.break);
    private static final rut_2<Boolean> catch = rme_0.class(aZ.class, ruw_2.implements);
    private static final rut_2<rlx_1> private = rme_0.class(aZ.class, ruw_2.finally);
    private rli_1 implements = ras_1.class;
    private final List<rly_1> finally = Lists.newArrayList();
    private final Map<an, Integer> extends = Maps.newHashMap();
    private int native = 600;
    private int volatile = 20;
    private int final = 20;
    private boolean package;
    private int int;
    private float new;
    private float continue;
    private ib_0 super;
    private UUID this;

    public void byte(int n2) {
        this.volatile = n2;
    }

    public void byte(float f2) {
        if (!((rYB)this.throws[7]).continue) {
            this.BQ().break(break, Float.valueOf(f2));
        }
    }

    public aZ(ai_0<? extends aZ> ai_02, rYB rYB2) {
        super(ai_02, rYB2);
        Boolean bl2 = true;
        this.throws[38] = bl2;
        this.byte(3.0f);
    }

    public aZ(rYB rYB2, double d, double d2, double d3) {
        this((ai_0<? extends aZ>)ai_0.class, rYB2);
        this.new(d, d2, d3);
    }

    @Override
    public void this() {
        block23: {
            boolean bl2;
            float f2;
            boolean bl3;
            block21: {
                rlx_1 rlx_12;
                block22: {
                    super.this();
                    bl3 = this.catch();
                    f2 = this.protected();
                    if (!((rYB)this.throws[7]).continue) break block21;
                    rlx_12 = this.case();
                    if (!bl3) break block22;
                    if (!((Random)this.throws[40]).nextBoolean()) break block23;
                    for (int k = 0; k < 2; ++k) {
                        float f3 = ((Random)this.throws[40]).nextFloat() * ((float)Math.PI * 2);
                        float f4 = rfU.byte(((Random)this.throws[40]).nextFloat()) * 0.2f;
                        float f5 = rfU.break(f3) * f4;
                        float f10 = rfU.class(f3) * f4;
                        if (rlx_12.protected() == rlq_2.else) {
                            int f11 = ((Random)this.throws[40]).nextBoolean() ? 0xFFFFFF : this.throws();
                            int n7 = f11 >> 16 & 0xFF;
                            int n8 = f11 >> 8 & 0xFF;
                            int n9 = f11 & 0xFF;
                            ((rYB)this.throws[7]).break(rlx_12, this.rx() + (double)f5, this.re(), this.BO() + (double)f10, (double)((float)n7 / 255.0f), (double)((float)n8 / 255.0f), (float)n9 / 255.0f);
                            continue;
                        }
                        ((rYB)this.throws[7]).break(rlx_12, this.rx() + (double)f5, this.re(), this.BO() + (double)f10, 0.0, 0.0, 0.0);
                    }
                    break block23;
                }
                float f7 = (float)Math.PI * f2 * f2;
                int n6 = 0;
                while ((float)n6 < f7) {
                    float f8 = ((Random)this.throws[40]).nextFloat() * ((float)Math.PI * 2);
                    float f9 = rfU.byte(((Random)this.throws[40]).nextFloat()) * f2;
                    float ib_02 = rfU.break(f8) * f9;
                    float d2 = rfU.class(f8) * f9;
                    if (rlx_12.protected() == rlq_2.else) {
                        int n2 = this.throws();
                        int d = n2 >> 16 & 0xFF;
                        int n3 = n2 >> 8 & 0xFF;
                        int d3 = n2 & 0xFF;
                        ((rYB)this.throws[7]).break(rlx_12, this.rx() + (double)ib_02, this.re(), this.BO() + (double)d2, (double)((float)d / 255.0f), (double)((float)n3 / 255.0f), (float)d3 / 255.0f);
                    } else {
                        ((rYB)this.throws[7]).break(rlx_12, this.rx() + (double)ib_02, this.re(), this.BO() + (double)d2, (0.5 - ((Random)this.throws[40]).nextDouble()) * 0.15, (double)0.01f, (0.5 - ((Random)this.throws[40]).nextDouble()) * 0.15);
                    }
                    ++n6;
                }
                break block23;
            }
            if ((Integer)this.throws[41] >= this.volatile + this.native) {
                this.PD();
                return;
            }
            boolean bl4 = bl2 = (Integer)this.throws[41] < this.volatile;
            if (bl3 != bl2) {
                this.class(bl2);
            }
            if (bl2) {
                return;
            }
            if (this.continue != 0.0f) {
                if ((f2 += this.continue) < 0.5f) {
                    this.PD();
                    return;
                }
                this.byte(f2);
            }
            if ((Integer)this.throws[41] % 5 == 0) {
                Object object;
                Iterator<Map.Entry<an, Integer>> iterator = this.extends.entrySet().iterator();
                while (iterator.hasNext()) {
                    object = iterator.next();
                    if ((Integer)this.throws[41] < (Integer)object.getValue()) continue;
                    iterator.remove();
                }
                object = Lists.newArrayList();
                for (rly_1 object2 : this.implements.class()) {
                    object.add(new rly_1(object2.class(), object2.break() / 4, object2.byte(), object2.protected(), object2.throws()));
                }
                object.addAll(this.finally);
                if (object.isEmpty()) {
                    this.extends.clear();
                } else {
                    List<ib_0> list = ((rYB)this.throws[7]).class(ib_0.class, this.rN());
                    if (!list.isEmpty()) {
                        for (ib_0 ib_02 : list) {
                            double d;
                            double d2;
                            double d3;
                            if (this.extends.containsKey(ib_02) || !ib_02.SL() || !((d3 = (d2 = ib_02.rx() - this.rx()) * d2 + (d = ib_02.BO() - this.BO()) * d) <= (double)(f2 * f2))) continue;
                            this.extends.put(ib_02, (Integer)this.throws[41] + this.final);
                            Iterator iterator2 = object.iterator();
                            while (iterator2.hasNext()) {
                                rly_1 rly_12 = (rly_1)iterator2.next();
                                if (rly_12.class().class()) {
                                    rly_12.class().class(this, this.implements(), ib_02, rly_12.byte(), 0.5);
                                    continue;
                                }
                                ib_02.break(new rly_1(rly_12));
                            }
                            if (this.new != 0.0f) {
                                if ((f2 += this.new) < 0.5f) {
                                    this.PD();
                                    return;
                                }
                                this.byte(f2);
                            }
                            if (this.int == 0) continue;
                            this.native += this.int;
                            if (this.native > 0) continue;
                            this.PD();
                            return;
                        }
                    }
                }
            }
        }
    }

    protected void class(boolean bl2) {
        this.BQ().break(catch, bl2);
    }

    public void class(rlx_1 rlx_12) {
        this.BQ().break(private, rlx_12);
    }

    public void class(int n2) {
        this.package = true;
        this.BQ().break(protected, n2);
    }

    @Override
    protected void class(rcd_2 rcd_22) {
        rcd_22.break("Age", (Integer)this.throws[41]);
        rcd_22.break("Duration", this.native);
        rcd_22.break("WaitTime", this.volatile);
        rcd_22.break("ReapplicationDelay", this.final);
        rcd_22.break("DurationOnUse", this.int);
        rcd_22.class("RadiusOnUse", this.new);
        rcd_22.class("RadiusPerTick", this.continue);
        rcd_22.class("Radius", this.protected());
        rcd_22.class("Particle", this.case().byte());
        if (this.this != null) {
            rcd_22.class("Owner", this.this);
        }
        if (this.package) {
            rcd_22.break("Color", this.throws());
        }
        if (this.implements != ras_1.class && this.implements != null) {
            rcd_22.class("Potion", rvl_0.double.break(this.implements).toString());
        }
        if (!this.finally.isEmpty()) {
            rcy_2 rcy_22 = new rcy_2();
            for (rly_1 rly_12 : this.finally) {
                rcy_22.add(rly_12.class(new rcd_2()));
            }
            rcd_22.class("Effects", rcy_22);
        }
    }

    public void class(ib_0 ib_02) {
        this.super = ib_02;
        this.this = ib_02 == null ? null : ib_02.ro();
    }

    @Override
    public void class(rut_2<?> rut_22) {
        if (break.equals(rut_22)) {
            this.q_();
        }
        super.class(rut_22);
    }

    public void class(rly_1 rly_12) {
        this.finally.add(rly_12);
        if (!this.package) {
            this.final();
        }
    }

    public void class(rli_1 rli_12) {
        this.implements = rli_12;
        if (!this.package) {
            this.final();
        }
    }

    public void break(int n2) {
        this.native = n2;
    }

    @Override
    protected void break(rcd_2 rcd_22) {
        Integer n2 = rcd_22.private("Age");
        this.throws[41] = n2;
        this.native = rcd_22.private("Duration");
        this.volatile = rcd_22.private("WaitTime");
        this.final = rcd_22.private("ReapplicationDelay");
        this.int = rcd_22.private("DurationOnUse");
        this.new = rcd_22.finally("RadiusOnUse");
        this.continue = rcd_22.finally("RadiusPerTick");
        this.byte(rcd_22.finally("Radius"));
        if (rcd_22.break("Owner")) {
            this.this = rcd_22.class("Owner");
        }
        if (rcd_22.byte("Particle", 8)) {
            try {
                this.class(yc_0.break(new StringReader(rcd_22.native("Particle"))));
            }
            catch (CommandSyntaxException commandSyntaxException) {
                aZ.class.warn("Couldn't load custom particle {}", (Object)rcd_22.native("Particle"), (Object)commandSyntaxException);
            }
        }
        if (rcd_22.byte("Color", 99)) {
            this.class(rcd_22.private("Color"));
        }
        if (rcd_22.byte("Potion", 8)) {
            this.class(rab_2.byte(rcd_22));
        }
        if (rcd_22.byte("Effects", 9)) {
            rcy_2 rcy_22 = rcd_22.protected("Effects", 10);
            this.finally.clear();
            for (int k = 0; k < rcy_22.size(); ++k) {
                rly_1 rly_12 = rly_1.break(rcy_22.class(k));
                if (rly_12 == null) continue;
                this.class(rly_12);
            }
        }
    }

    public int throws() {
        return this.BQ().class(protected);
    }

    public boolean catch() {
        return this.BQ().class(catch);
    }

    public void catch(float f2) {
        this.continue = f2;
    }

    public rlx_1 case() {
        return this.BQ().class(private);
    }

    public ib_0 implements() {
        an an2;
        if (this.super == null && this.this != null && (rYB)this.throws[7] instanceof rrEm && (an2 = ((rrEm)((rYB)this.throws[7])).break(this.this)) instanceof ib_0) {
            this.super = (ib_0)an2;
        }
        return this.super;
    }

    public float protected() {
        return this.BQ().class(break).floatValue();
    }

    public void protected(float f2) {
        this.new = f2;
    }

    public int private() {
        return this.native;
    }

    private void final() {
        if (this.implements == ras_1.class && this.finally.isEmpty()) {
            this.BQ().break(protected, 0);
        } else {
            this.BQ().break(protected, rab_2.class(rab_2.class(this.implements, this.finally)));
        }
    }

    @Override
    public ap a_(iM iM2) {
        return ap.break(this.protected() * 2.0f, 0.5f);
    }

    @Override
    protected void m_() {
        this.BQ().class(protected, 0);
        this.BQ().class(break, Float.valueOf(0.5f));
        this.BQ().class(catch, false);
        this.BQ().class(private, rlq_2.else);
    }

    @Override
    public void q_() {
        double d = this.rx();
        double d2 = this.re();
        double d3 = this.BO();
        super.q_();
        this.new(d, d2, d3);
    }

    @Override
    public rus_2<?> p_() {
        return new rfj_2(this);
    }

    @Override
    public qs_1 r_() {
        return qs_1.IGNORE;
    }
}

