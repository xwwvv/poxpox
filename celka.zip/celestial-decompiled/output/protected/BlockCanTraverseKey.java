/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.rpr_0;
import protected.xc_0;

/*
 * Renamed from protected.xz
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class xz_0 {
    private final xc_0 class;
    private final xc_0 break;
    private final rpr_0 byte;

    public xz_0(xc_0 xc_02, xc_0 xc_03, rpr_0 rpr_02) {
        this.class = xc_02;
        this.break = xc_03;
        this.byte = rpr_02;
    }

    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof xz_0)) {
            return false;
        }
        xz_0 xz_02 = (xz_0)object;
        return this.class == xz_02.class && this.break == xz_02.break && this.byte == xz_02.byte;
    }

    public int hashCode() {
        int n2 = this.class.hashCode();
        n2 = 31 * n2 + this.break.hashCode();
        return 31 * n2 + this.byte.hashCode();
    }
}

