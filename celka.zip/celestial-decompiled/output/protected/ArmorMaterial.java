/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.util.function.Supplier;
import protected.rdb_2;
import protected.rdy_2;
import protected.rkg_2;
import protected.rpo;
import protected.rqa_0;
import protected.rqn;
import protected.rxq_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.rxE
 */
public final class rxe_0
extends Enum<rxe_0>
implements rdb_2 {
    public static final /* enum */ rxe_0 LEATHER = new rxe_0("leather", 5, new int[]{1, 2, 3, 1}, 15, rqn.boolean, 0.0f, 0.0f, () -> rkg_2.class(rdy_2.ha));
    public static final /* enum */ rxe_0 CHAIN = new rxe_0("chainmail", 15, new int[]{1, 4, 5, 2}, 12, rqn.static, 0.0f, 0.0f, () -> rkg_2.class(rdy_2.Ox));
    public static final /* enum */ rxe_0 IRON = new rxe_0("iron", 15, new int[]{2, 5, 6, 2}, 9, rqn.strictfp, 0.0f, 0.0f, () -> rkg_2.class(rdy_2.Ox));
    public static final /* enum */ rxe_0 GOLD = new rxe_0("gold", 7, new int[]{1, 3, 5, 2}, 25, rqn.const, 0.0f, 0.0f, () -> rkg_2.class(rdy_2.Od));
    public static final /* enum */ rxe_0 DIAMOND = new rxe_0("diamond", 33, new int[]{3, 6, 8, 3}, 10, rqn.import, 2.0f, 0.0f, () -> rkg_2.class(rdy_2.OJ));
    public static final /* enum */ rxe_0 TURTLE = new rxe_0("turtle", 25, new int[]{2, 5, 6, 2}, 9, rqn.for, 0.0f, 0.0f, () -> rkg_2.class(rdy_2.OE));
    public static final /* enum */ rxe_0 NETHERITE = new rxe_0("netherite", 37, new int[]{3, 6, 8, 3}, 15, rqn.transient, 3.0f, 0.1f, () -> rkg_2.class(rdy_2.Ok));
    private static final int[] MAX_DAMAGE_ARRAY;
    private final String name;
    private final int maxDamageFactor;
    private final int[] damageReductionAmountArray;
    private final int enchantability;
    private final rqa_0 soundEvent;
    private final float toughness;
    private final float knockbackResistance;
    private final rpo<rkg_2> repairMaterial;
    private static final /* synthetic */ rxe_0[] $VALUES;

    @Override
    public rkg_2 byte() {
        return this.repairMaterial.class();
    }

    private rxe_0(String string2, int n3, int[] nArray, int n4, rqa_0 rqa_02, float f2, float f3, Supplier<rkg_2> supplier) {
        this.name = string2;
        this.maxDamageFactor = n3;
        this.damageReductionAmountArray = nArray;
        this.enchantability = n4;
        this.soundEvent = rqa_02;
        this.toughness = f2;
        this.knockbackResistance = f3;
        this.repairMaterial = new rpo<rkg_2>(supplier);
    }

    static {
        $VALUES = rxe_0.final();
        MAX_DAMAGE_ARRAY = new int[]{13, 15, 16, 11};
    }

    public static rxe_0[] values() {
        return (rxe_0[])$VALUES.clone();
    }

    public static rxe_0 valueOf(String string) {
        return Enum.valueOf(rxe_0.class, string);
    }

    @Override
    public int class(rxq_1 rxq_12) {
        return MAX_DAMAGE_ARRAY[rxq_12.break()] * this.maxDamageFactor;
    }

    @Override
    public int class() {
        return this.enchantability;
    }

    @Override
    public int break(rxq_1 rxq_12) {
        return this.damageReductionAmountArray[rxq_12.break()];
    }

    @Override
    public rqa_0 break() {
        return this.soundEvent;
    }

    @Override
    public float throws() {
        return this.toughness;
    }

    @Override
    public float case() {
        return this.knockbackResistance;
    }

    @Override
    public String protected() {
        return this.name;
    }

    private static /* synthetic */ rxe_0[] final() {
        return new rxe_0[]{LEATHER, CHAIN, IRON, GOLD, DIAMOND, TURTLE, NETHERITE};
    }
}

