/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  it.unimi.dsi.fastutil.objects.Object2IntMap
 *  it.unimi.dsi.fastutil.objects.Object2IntOpenHashMap
 */
package protected;

import it.unimi.dsi.fastutil.objects.Object2IntMap;
import it.unimi.dsi.fastutil.objects.Object2IntOpenHashMap;
import protected.ml_1;
import protected.rfU;
import protected.rgn_0;
import protected.ron_0;
import protected.row;
import protected.rqR;
import protected.vm_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.vo
 */
public class vo_1
extends vm_1 {
    private final row class;
    private long throws = -1L;
    private static final Object2IntMap<ron_0> case = (Object2IntMap)rqR.class(new Object2IntOpenHashMap(), object2IntOpenHashMap -> {
        object2IntOpenHashMap.defaultReturnValue(0);
        object2IntOpenHashMap.put((Object)ron_0.class, 0x545454);
        object2IntOpenHashMap.put((Object)ron_0.break, 0x999999);
        object2IntOpenHashMap.put((Object)ron_0.byte, 6250897);
        object2IntOpenHashMap.put((Object)ron_0.protected, 8434258);
        object2IntOpenHashMap.put((Object)ron_0.throws, 0xD1D1D1);
        object2IntOpenHashMap.put((Object)ron_0.case, 7497737);
        object2IntOpenHashMap.put((Object)ron_0.catch, 7169628);
        object2IntOpenHashMap.put((Object)ron_0.private, 3159410);
        object2IntOpenHashMap.put((Object)ron_0.implements, 2213376);
        object2IntOpenHashMap.put((Object)ron_0.finally, 0xCCCCCC);
        object2IntOpenHashMap.put((Object)ron_0.extends, 15884384);
        object2IntOpenHashMap.put((Object)ron_0.native, 0xEEEEEE);
        object2IntOpenHashMap.put((Object)ron_0.volatile, 0xFFFFFF);
    });

    public vo_1(row row2) {
        super(rgn_0.byte);
        this.class = row2;
    }

    @Override
    public void class(ml_1 ml_12, int n2, int n3, float f2) {
        this.class(ml_12);
        String string = rfU.class(this.class.throws(), 0, 100) + "%";
        long l2 = rqR.break();
        if (l2 - this.throws > 2000L) {
            this.throws = l2;
        }
        int n4 = this.package / 2;
        int n5 = this.int / 2;
        int n6 = 30;
        vo_1.class(ml_12, this.class, n4, n5 + 30, 2, 0);
        vo_1.class(ml_12, this.super, string, n4, n5 - 4 - 30, 0xFFFFFF);
    }

    public static void class(ml_1 ml_12, row row2, int n2, int n3, int n4, int n5) {
        int n6 = n4 + n5;
        int n7 = row2.byte();
        int n8 = n7 * n6 - n5;
        int n9 = row2.protected();
        int n10 = n9 * n6 - n5;
        int n11 = n2 - n10 / 2;
        int n12 = n3 - n10 / 2;
        int n13 = n8 / 2 + 1;
        int n14 = -16772609;
        if (n5 != 0) {
            vo_1.class(ml_12, n2 - n13, n3 - n13, n2 - n13 + 1, n3 + n13, -16772609);
            vo_1.class(ml_12, n2 + n13 - 1, n3 - n13, n2 + n13, n3 + n13, -16772609);
            vo_1.class(ml_12, n2 - n13, n3 - n13, n2 + n13, n3 - n13 + 1, -16772609);
            vo_1.class(ml_12, n2 - n13, n3 + n13 - 1, n2 + n13, n3 + n13, -16772609);
        }
        for (int k = 0; k < n9; ++k) {
            for (int i2 = 0; i2 < n9; ++i2) {
                ron_0 ron_02 = row2.class(k, i2);
                int n15 = n11 + k * n6;
                int n16 = n12 + i2 * n6;
                vo_1.class(ml_12, n15, n16, n15 + n4, n16 + n4, case.getInt((Object)ron_02) | 0xFF000000);
            }
        }
    }

    @Override
    public boolean E_() {
        return false;
    }

    @Override
    public void w_() {
        super.w_();
    }
}

