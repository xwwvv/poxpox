/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.io.Closeable;
import java.io.IOException;
import java.nio.ByteBuffer;
import javax.sound.sampled.AudioFormat;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.Nz
 */
public interface nz_2
extends Closeable {
    public AudioFormat class();

    public ByteBuffer class(int var1) throws IOException;
}

