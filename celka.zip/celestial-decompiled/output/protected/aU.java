/*
 * Decompiled with CFR 0.152.
 */
package protected;

public interface aU {
}

