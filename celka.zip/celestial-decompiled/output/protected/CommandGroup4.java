/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.SV
 */
public class sv_1 {
    private static byte[] break;
    private static boolean[] byte;
    public static Object[] class;

    private static void byte() {
        Object[] objectArray = new Object[]{new int[]{1, 2, 3, 4}};
        sv_1.class = objectArray;
    }

    static {
        sv_1.ntfClinit();
    }

    private static void class() {
        break = new byte[]{2, 2, 3, 3, 4};
    }

    public static String class(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{-59, 67, 23, -107, 45, 27, 51, -36}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0xC3FED53C88F61F35L;
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0xBAEC69A8;
    }

    private static void break() {
        boolean[] blArray = new boolean[9];
        blArray[3] = true;
        blArray[5] = true;
        blArray[8] = true;
        byte = blArray;
    }

    private static /* synthetic */ void ntfClinit() {
        sv_1.break();
        sv_1.class();
        sv_1.byte();
    }
}

