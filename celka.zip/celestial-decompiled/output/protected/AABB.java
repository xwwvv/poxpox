/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.commons.lang3.tuple.Pair
 */
package protected;

import java.util.Optional;
import org.apache.commons.lang3.tuple.Pair;
import protected.rfH;
import protected.rfU;
import protected.rff;
import protected.rfi;
import protected.rjU;
import protected.rpb_0;
import protected.rpr_0;
import protected.rrtr_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class rfl
implements rrtr_1 {
    public final double class;
    public final double break;
    public final double byte;
    public final double protected;
    public final double throws;
    public final double case;

    public double byte(rfl rfl2, double d) {
        if (rfl2.protected > this.class && rfl2.class < this.protected && rfl2.throws > this.break && rfl2.break < this.throws) {
            double d2;
            if (d > 0.0 && rfl2.case <= this.byte) {
                double d3 = this.byte - rfl2.case;
                if (d3 < d) {
                    d = d3;
                }
            } else if (d < 0.0 && rfl2.byte >= this.case && (d2 = this.case - rfl2.byte) > d) {
                d = d2;
            }
            return d;
        }
        return d;
    }

    public Optional<Pair<rpr_0, rjU>> byte(rjU rjU2, rjU rjU3) {
        double[] dArray = new double[]{1.0};
        double d = rjU3.break - rjU2.break;
        double d2 = rjU3.byte - rjU2.byte;
        double d3 = rjU3.protected - rjU2.protected;
        rpr_0 rpr_02 = rfl.class(this, rjU2, dArray, null, d, d2, d3);
        if (rpr_02 == null) {
            return Optional.empty();
        }
        double d4 = dArray[0];
        return Optional.of(Pair.of((Object)rpr_02, (Object)rjU2.break(d4 * d, d4 * d2, d4 * d3)));
    }

    public rfl byte(double d, double d2, double d3) {
        double d4 = this.class - d;
        double d5 = this.break - d2;
        double d6 = this.byte - d3;
        double d7 = this.protected + d;
        double d8 = this.throws + d2;
        double d9 = this.case + d3;
        return new rfl(d4, d5, d6, d7, d8, d9);
    }

    public double byte() {
        return this.throws - this.break;
    }

    public boolean byte(rfl rfl2) {
        return this.class(rfl2.class, rfl2.break, rfl2.byte, rfl2.protected, rfl2.throws, rfl2.case);
    }

    public rfl byte(rjU rjU2) {
        return this.byte(rjU2.break, rjU2.byte, rjU2.protected);
    }

    public rfl(double d, double d2, double d3, double d4, double d5, double d6) {
        this.class = Math.min(d, d4);
        this.break = Math.min(d2, d5);
        this.byte = Math.min(d3, d6);
        this.protected = Math.max(d, d4);
        this.throws = Math.max(d2, d5);
        this.case = Math.max(d3, d6);
    }

    public rfl(rfH rfH2, rfH rfH3) {
        this(rfH2.b_(), rfH2.c_(), rfH2.d_(), rfH3.b_(), rfH3.c_(), rfH3.d_());
    }

    public rfl(rfH rfH2) {
        this(rfH2.b_(), rfH2.c_(), rfH2.d_(), rfH2.b_() + 1, rfH2.c_() + 1, rfH2.d_() + 1);
    }

    public rfl(rjU rjU2, rjU rjU3) {
        this(rjU2.break, rjU2.byte, rjU2.protected, rjU3.break, rjU3.byte, rjU3.protected);
    }

    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof rfl)) {
            return false;
        }
        rfl rfl2 = (rfl)object;
        if (Double.compare(rfl2.class, this.class) != 0) {
            return false;
        }
        if (Double.compare(rfl2.break, this.break) != 0) {
            return false;
        }
        if (Double.compare(rfl2.byte, this.byte) != 0) {
            return false;
        }
        if (Double.compare(rfl2.protected, this.protected) != 0) {
            return false;
        }
        if (Double.compare(rfl2.throws, this.throws) != 0) {
            return false;
        }
        return Double.compare(rfl2.case, this.case) == 0;
    }

    public String toString() {
        return "AABB[" + this.class + ", " + this.break + ", " + this.byte + "] -> [" + this.protected + ", " + this.throws + ", " + this.case + "]";
    }

    public int hashCode() {
        long l2 = Double.doubleToLongBits(this.class);
        int n2 = (int)(l2 ^ l2 >>> 32);
        l2 = Double.doubleToLongBits(this.break);
        n2 = 31 * n2 + (int)(l2 ^ l2 >>> 32);
        l2 = Double.doubleToLongBits(this.byte);
        n2 = 31 * n2 + (int)(l2 ^ l2 >>> 32);
        l2 = Double.doubleToLongBits(this.protected);
        n2 = 31 * n2 + (int)(l2 ^ l2 >>> 32);
        l2 = Double.doubleToLongBits(this.throws);
        n2 = 31 * n2 + (int)(l2 ^ l2 >>> 32);
        l2 = Double.doubleToLongBits(this.case);
        return 31 * n2 + (int)(l2 ^ l2 >>> 32);
    }

    private static rpr_0 class(double[] dArray, rpr_0 rpr_02, double d, double d2, double d3, double d4, double d5, double d6, double d7, double d8, rpr_0 rpr_03, double d9, double d10, double d11) {
        double d12 = (d4 - d9) / d;
        double d13 = d10 + d12 * d2;
        double d14 = d11 + d12 * d3;
        if (0.0 < d12 && d12 < dArray[0] && d5 - 1.0E-7 < d13 && d13 < d6 + 1.0E-7 && d7 - 1.0E-7 < d14 && d14 < d8 + 1.0E-7) {
            dArray[0] = d12;
            return rpr_03;
        }
        return rpr_02;
    }

    public boolean class(double d, double d2, double d3, double d4, double d5, double d6) {
        return this.class < d4 && this.protected > d && this.break < d5 && this.throws > d2 && this.byte < d6 && this.case > d3;
    }

    public double class(rfl rfl2, double d) {
        if (rfl2.throws > this.break && rfl2.break < this.throws && rfl2.case > this.byte && rfl2.byte < this.case) {
            double d2;
            if (d > 0.0 && rfl2.protected <= this.class) {
                double d3 = this.class - rfl2.protected;
                if (d3 < d) {
                    d = d3;
                }
            } else if (d < 0.0 && rfl2.class >= this.protected && (d2 = this.protected - rfl2.class) > d) {
                d = d2;
            }
            return d;
        }
        return d;
    }

    public static rpr_0 class(rfl rfl2, rjU rjU2, double[] dArray, rpr_0 rpr_02, double d, double d2, double d3) {
        if (d > 1.0E-7) {
            rpr_02 = rfl.class(dArray, rpr_02, d, d2, d3, rfl2.class, rfl2.break, rfl2.throws, rfl2.byte, rfl2.case, rpr_0.WEST, rjU2.break, rjU2.byte, rjU2.protected);
        } else if (d < -1.0E-7) {
            rpr_02 = rfl.class(dArray, rpr_02, d, d2, d3, rfl2.protected, rfl2.break, rfl2.throws, rfl2.byte, rfl2.case, rpr_0.EAST, rjU2.break, rjU2.byte, rjU2.protected);
        }
        if (d2 > 1.0E-7) {
            rpr_02 = rfl.class(dArray, rpr_02, d2, d3, d, rfl2.break, rfl2.byte, rfl2.case, rfl2.class, rfl2.protected, rpr_0.DOWN, rjU2.byte, rjU2.protected, rjU2.break);
        } else if (d2 < -1.0E-7) {
            rpr_02 = rfl.class(dArray, rpr_02, d2, d3, d, rfl2.throws, rfl2.byte, rfl2.case, rfl2.class, rfl2.protected, rpr_0.UP, rjU2.byte, rjU2.protected, rjU2.break);
        }
        if (d3 > 1.0E-7) {
            rpr_02 = rfl.class(dArray, rpr_02, d3, d, d2, rfl2.byte, rfl2.class, rfl2.protected, rfl2.break, rfl2.throws, rpr_0.NORTH, rjU2.protected, rjU2.break, rjU2.byte);
        } else if (d3 < -1.0E-7) {
            rpr_02 = rfl.class(dArray, rpr_02, d3, d, d2, rfl2.case, rfl2.class, rfl2.protected, rfl2.break, rfl2.throws, rpr_0.SOUTH, rjU2.protected, rjU2.break, rjU2.byte);
        }
        return rpr_02;
    }

    public double class() {
        double d = this.break();
        double d2 = this.byte();
        double d3 = this.protected();
        return (d + d2 + d3) / 3.0;
    }

    public boolean class(rjU rjU2, rjU rjU3) {
        return this.class(Math.min(rjU2.break, rjU3.break), Math.min(rjU2.byte, rjU3.byte), Math.min(rjU2.protected, rjU3.protected), Math.max(rjU2.break, rjU3.break), Math.max(rjU2.byte, rjU3.byte), Math.max(rjU2.protected, rjU3.protected));
    }

    public static rff class(Iterable<rfl> iterable, rjU rjU2, rjU rjU3, rfH rfH2) {
        double[] dArray = new double[]{1.0};
        rpr_0 rpr_02 = null;
        double d = rjU3.break - rjU2.break;
        double d2 = rjU3.byte - rjU2.byte;
        double d3 = rjU3.protected - rjU2.protected;
        for (rfl rfl2 : iterable) {
            rpr_02 = rfl.class(rfl2.class(rfH2), rjU2, dArray, rpr_02, d, d2, d3);
        }
        if (rpr_02 == null) {
            return null;
        }
        double d4 = dArray[0];
        return new rff(rjU2.break(d4 * d, d4 * d2, d4 * d3), rpr_02, rfH2, false);
    }

    public rfl class(double d) {
        return this.byte(d, d, d);
    }

    public static rfl class(rfi rfi2) {
        return new rfl(rfi2.class, rfi2.break, rfi2.byte, rfi2.protected + 1, rfi2.throws + 1, rfi2.case + 1);
    }

    public rfl class(double d, double d2, double d3) {
        double d4 = this.class;
        double d5 = this.break;
        double d6 = this.byte;
        double d7 = this.protected;
        double d8 = this.throws;
        double d9 = this.case;
        if (d < 0.0) {
            d4 -= d;
        } else if (d > 0.0) {
            d7 -= d;
        }
        if (d2 < 0.0) {
            d5 -= d2;
        } else if (d2 > 0.0) {
            d8 -= d2;
        }
        if (d3 < 0.0) {
            d6 -= d3;
        } else if (d3 > 0.0) {
            d9 -= d3;
        }
        return new rfl(d4, d5, d6, d7, d8, d9);
    }

    public double class(rpb_0 rpb_02) {
        return rpb_02.class(this.class, this.break, this.byte);
    }

    public static rfl class(rjU rjU2) {
        return new rfl(rjU2.break, rjU2.byte, rjU2.protected, rjU2.break + 1.0, rjU2.byte + 1.0, rjU2.protected + 1.0);
    }

    public rfl class(rfH rfH2) {
        return new rfl(this.class + (double)rfH2.b_(), this.break + (double)rfH2.c_(), this.byte + (double)rfH2.d_(), this.protected + (double)rfH2.b_(), this.throws + (double)rfH2.c_(), this.case + (double)rfH2.d_());
    }

    public rfl class(rfl rfl2) {
        double d = Math.max(this.class, rfl2.class);
        double d2 = Math.max(this.break, rfl2.break);
        double d3 = Math.max(this.byte, rfl2.byte);
        double d4 = Math.min(this.protected, rfl2.protected);
        double d5 = Math.min(this.throws, rfl2.throws);
        double d6 = Math.min(this.case, rfl2.case);
        return new rfl(d, d2, d3, d4, d5, d6);
    }

    public double break(rfl rfl2, double d) {
        if (rfl2.protected > this.class && rfl2.class < this.protected && rfl2.case > this.byte && rfl2.byte < this.case) {
            double d2;
            if (d > 0.0 && rfl2.throws <= this.break) {
                double d3 = this.break - rfl2.throws;
                if (d3 < d) {
                    d = d3;
                }
            } else if (d < 0.0 && rfl2.break >= this.throws && (d2 = this.throws - rfl2.break) > d) {
                d = d2;
            }
            return d;
        }
        return d;
    }

    public rfl break(double d) {
        return this.class(-d);
    }

    public double break(rpb_0 rpb_02) {
        return rpb_02.class(this.protected, this.throws, this.case);
    }

    public Optional<rjU> break(rjU rjU2, rjU rjU3) {
        double[] dArray = new double[]{1.0};
        double d = rjU3.break - rjU2.break;
        double d2 = rjU3.byte - rjU2.byte;
        double d3 = rjU3.protected - rjU2.protected;
        rpr_0 rpr_02 = rfl.class(this, rjU2, dArray, null, d, d2, d3);
        if (rpr_02 == null) {
            return Optional.empty();
        }
        double d4 = dArray[0];
        return Optional.of(rjU2.break(d4 * d, d4 * d2, d4 * d3));
    }

    public rfl break(rjU rjU2) {
        return this.break(rjU2.break, rjU2.byte, rjU2.protected);
    }

    public boolean break(rfH rfH2) {
        return this.throws(rfH2.b_(), rfH2.c_(), rfH2.d_());
    }

    public rfl break(rfl rfl2) {
        double d = Math.min(this.class, rfl2.class);
        double d2 = Math.min(this.break, rfl2.break);
        double d3 = Math.min(this.byte, rfl2.byte);
        double d4 = Math.max(this.protected, rfl2.protected);
        double d5 = Math.max(this.throws, rfl2.throws);
        double d6 = Math.max(this.case, rfl2.case);
        return new rfl(d, d2, d3, d4, d5, d6);
    }

    public double break() {
        return this.protected - this.class;
    }

    public rfl break(double d, double d2, double d3) {
        double d4 = this.class;
        double d5 = this.break;
        double d6 = this.byte;
        double d7 = this.protected;
        double d8 = this.throws;
        double d9 = this.case;
        if (d < 0.0) {
            d4 += d;
        } else if (d > 0.0) {
            d7 += d;
        }
        if (d2 < 0.0) {
            d5 += d2;
        } else if (d2 > 0.0) {
            d8 += d2;
        }
        if (d3 < 0.0) {
            d6 += d3;
        } else if (d3 > 0.0) {
            d9 += d3;
        }
        return new rfl(d4, d5, d6, d7, d8, d9);
    }

    public boolean throws() {
        return Double.isNaN(this.class) || Double.isNaN(this.break) || Double.isNaN(this.byte) || Double.isNaN(this.protected) || Double.isNaN(this.throws) || Double.isNaN(this.case);
    }

    public boolean throws(double d, double d2, double d3) {
        return d >= this.class && d < this.protected && d2 >= this.break && d2 < this.throws && d3 >= this.byte && d3 < this.case;
    }

    public rfl throws(rjU rjU2) {
        return this.protected(-rjU2.break, -rjU2.byte, -rjU2.protected);
    }

    public rfl finally(rjU rjU2) {
        return this.private(rjU2.break, rjU2.byte, rjU2.protected);
    }

    public static rfl catch(double d, double d2, double d3) {
        return new rfl(-d / 2.0, -d2 / 2.0, -d3 / 2.0, d / 2.0, d2 / 2.0, d3 / 2.0);
    }

    public rfl catch(rjU rjU2) {
        return this.byte(-rjU2.break, -rjU2.byte, -rjU2.protected);
    }

    public rjU case() {
        return new rjU(rfU.protected(0.5, this.class, this.protected), rfU.protected(0.5, this.break, this.throws), rfU.protected(0.5, this.byte, this.case));
    }

    public boolean case(rjU rjU2) {
        return this.throws(rjU2.break, rjU2.byte, rjU2.protected);
    }

    public rfl case(double d, double d2, double d3) {
        return this.byte(-d, -d2, -d3);
    }

    public rjU implements(rjU rjU2) {
        float f2 = (float)rfU.class(rjU2.break, this.class, this.protected);
        float f3 = (float)rfU.class(rjU2.byte, this.break, this.throws);
        float f4 = (float)rfU.class(rjU2.protected, this.byte, this.case);
        return new rjU(f2, f3, f4);
    }

    public double protected() {
        return this.case - this.byte;
    }

    public rfl protected(rjU rjU2) {
        return this.protected(rjU2.break, rjU2.byte, rjU2.protected);
    }

    public boolean protected(rfl rfl2) {
        return this.class < rfl2.protected && this.protected > rfl2.class && this.byte < rfl2.case && this.case > rfl2.byte;
    }

    public rfl protected(double d, double d2, double d3) {
        return new rfl(this.class + d, this.break + d2, this.byte + d3, this.protected + d, this.throws + d2, this.case + d3);
    }

    public rfl private(double d, double d2, double d3) {
        return new rfl(d, d2, d3, d + this.break(), d2 + this.byte(), d3 + this.protected());
    }

    public rjU private(rjU rjU2) {
        int n2 = (int)rfU.class(rjU2.break, this.class, this.protected);
        int n3 = (int)rfU.class(rjU2.byte, this.break, this.throws);
        int n4 = (int)rfU.class(rjU2.protected, this.byte, this.case);
        return new rjU(n2, n3, n4);
    }

    @Override
    public rjU rr() {
        return this.case();
    }
}

