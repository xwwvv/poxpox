/*
 * Decompiled with CFR 0.152.
 */
package protected;

import com.mojang.blaze3d.systems.RenderSystem;
import protected.Hx;
import protected.an;
import protected.hh_0;
import protected.ju_0;
import protected.lD;
import protected.ml_1;
import protected.qy_1;
import protected.rrbb;
import protected.rrdZ;
import protected.yb_1;
import protected.yd_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.yg
 */
public class yg_2
implements yd_2 {
    private final qy_1 class;

    public yg_2(qy_1 qy_12) {
        this.class = qy_12;
    }

    @Override
    public void class(ml_1 ml_12, Hx hx, double d, double d2, double d3) {
        if (!rrdZ.new) {
            int n2;
            if (rrbb.rs()) {
                rrdZ.Z();
            }
            RenderSystem.enableDepthTest();
            RenderSystem.shadeModel(7425);
            RenderSystem.enableAlphaTest();
            RenderSystem.defaultAlphaFunc();
            an an2 = ((hh_0)this.class.class[16]).finally().catch();
            yb_1 yb_12 = yb_1.class();
            lD lD2 = yb_12.byte();
            double d4 = 0.0 - d2;
            double d5 = 256.0 - d2;
            RenderSystem.disableTexture();
            RenderSystem.disableBlend();
            double d6 = (double)((Integer)an2.throws[51] << 4) - d;
            double d7 = (double)((Integer)an2.throws[53] << 4) - d3;
            RenderSystem.lineWidth(1.0f);
            lD2.class(3, ju_0.this);
            for (n2 = -16; n2 <= 32; n2 += 16) {
                for (int k = -16; k <= 32; k += 16) {
                    lD2.class(d6 + (double)n2, d4, d7 + (double)k).class(1.0f, 0.0f, 0.0f, 0.0f).class();
                    lD2.class(d6 + (double)n2, d4, d7 + (double)k).class(1.0f, 0.0f, 0.0f, 0.5f).class();
                    lD2.class(d6 + (double)n2, d5, d7 + (double)k).class(1.0f, 0.0f, 0.0f, 0.5f).class();
                    lD2.class(d6 + (double)n2, d5, d7 + (double)k).class(1.0f, 0.0f, 0.0f, 0.0f).class();
                }
            }
            for (n2 = 2; n2 < 16; n2 += 2) {
                lD2.class(d6 + (double)n2, d4, d7).class(1.0f, 1.0f, 0.0f, 0.0f).class();
                lD2.class(d6 + (double)n2, d4, d7).class(1.0f, 1.0f, 0.0f, 1.0f).class();
                lD2.class(d6 + (double)n2, d5, d7).class(1.0f, 1.0f, 0.0f, 1.0f).class();
                lD2.class(d6 + (double)n2, d5, d7).class(1.0f, 1.0f, 0.0f, 0.0f).class();
                lD2.class(d6 + (double)n2, d4, d7 + 16.0).class(1.0f, 1.0f, 0.0f, 0.0f).class();
                lD2.class(d6 + (double)n2, d4, d7 + 16.0).class(1.0f, 1.0f, 0.0f, 1.0f).class();
                lD2.class(d6 + (double)n2, d5, d7 + 16.0).class(1.0f, 1.0f, 0.0f, 1.0f).class();
                lD2.class(d6 + (double)n2, d5, d7 + 16.0).class(1.0f, 1.0f, 0.0f, 0.0f).class();
            }
            for (n2 = 2; n2 < 16; n2 += 2) {
                lD2.class(d6, d4, d7 + (double)n2).class(1.0f, 1.0f, 0.0f, 0.0f).class();
                lD2.class(d6, d4, d7 + (double)n2).class(1.0f, 1.0f, 0.0f, 1.0f).class();
                lD2.class(d6, d5, d7 + (double)n2).class(1.0f, 1.0f, 0.0f, 1.0f).class();
                lD2.class(d6, d5, d7 + (double)n2).class(1.0f, 1.0f, 0.0f, 0.0f).class();
                lD2.class(d6 + 16.0, d4, d7 + (double)n2).class(1.0f, 1.0f, 0.0f, 0.0f).class();
                lD2.class(d6 + 16.0, d4, d7 + (double)n2).class(1.0f, 1.0f, 0.0f, 1.0f).class();
                lD2.class(d6 + 16.0, d5, d7 + (double)n2).class(1.0f, 1.0f, 0.0f, 1.0f).class();
                lD2.class(d6 + 16.0, d5, d7 + (double)n2).class(1.0f, 1.0f, 0.0f, 0.0f).class();
            }
            for (n2 = 0; n2 <= 256; n2 += 2) {
                double d8 = (double)n2 - d2;
                lD2.class(d6, d8, d7).class(1.0f, 1.0f, 0.0f, 0.0f).class();
                lD2.class(d6, d8, d7).class(1.0f, 1.0f, 0.0f, 1.0f).class();
                lD2.class(d6, d8, d7 + 16.0).class(1.0f, 1.0f, 0.0f, 1.0f).class();
                lD2.class(d6 + 16.0, d8, d7 + 16.0).class(1.0f, 1.0f, 0.0f, 1.0f).class();
                lD2.class(d6 + 16.0, d8, d7).class(1.0f, 1.0f, 0.0f, 1.0f).class();
                lD2.class(d6, d8, d7).class(1.0f, 1.0f, 0.0f, 1.0f).class();
                lD2.class(d6, d8, d7).class(1.0f, 1.0f, 0.0f, 0.0f).class();
            }
            yb_12.break();
            RenderSystem.lineWidth(2.0f);
            lD2.class(3, ju_0.this);
            for (n2 = 0; n2 <= 16; n2 += 16) {
                for (int k = 0; k <= 16; k += 16) {
                    lD2.class(d6 + (double)n2, d4, d7 + (double)k).class(0.25f, 0.25f, 1.0f, 0.0f).class();
                    lD2.class(d6 + (double)n2, d4, d7 + (double)k).class(0.25f, 0.25f, 1.0f, 1.0f).class();
                    lD2.class(d6 + (double)n2, d5, d7 + (double)k).class(0.25f, 0.25f, 1.0f, 1.0f).class();
                    lD2.class(d6 + (double)n2, d5, d7 + (double)k).class(0.25f, 0.25f, 1.0f, 0.0f).class();
                }
            }
            for (n2 = 0; n2 <= 256; n2 += 16) {
                double d9 = (double)n2 - d2;
                lD2.class(d6, d9, d7).class(0.25f, 0.25f, 1.0f, 0.0f).class();
                lD2.class(d6, d9, d7).class(0.25f, 0.25f, 1.0f, 1.0f).class();
                lD2.class(d6, d9, d7 + 16.0).class(0.25f, 0.25f, 1.0f, 1.0f).class();
                lD2.class(d6 + 16.0, d9, d7 + 16.0).class(0.25f, 0.25f, 1.0f, 1.0f).class();
                lD2.class(d6 + 16.0, d9, d7).class(0.25f, 0.25f, 1.0f, 1.0f).class();
                lD2.class(d6, d9, d7).class(0.25f, 0.25f, 1.0f, 1.0f).class();
                lD2.class(d6, d9, d7).class(0.25f, 0.25f, 1.0f, 0.0f).class();
            }
            yb_12.break();
            RenderSystem.lineWidth(1.0f);
            RenderSystem.enableBlend();
            RenderSystem.enableTexture();
            RenderSystem.shadeModel(7424);
            if (rrbb.rs()) {
                rrdZ.v();
            }
        }
    }
}

