/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.annotation.ParametersAreNonnullByDefault
 */
package protected;

import javax.annotation.ParametersAreNonnullByDefault;
import protected.ou_2;

/*
 * Renamed from protected.AC
 */
@ParametersAreNonnullByDefault
@ou_2
interface ac_2 {
}

