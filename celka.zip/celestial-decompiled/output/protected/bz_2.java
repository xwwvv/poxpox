/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.bq_1;
import protected.bw_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.Bz
 */
public class bz_2 {
    private static short[] break;
    public Object[] class;
    private static byte[] byte;

    private static void byte() {
        short[] sArray = new short[2];
        sArray[1] = 1;
        break = sArray;
    }

    public bz_2(bq_1 bq_12, bw_1 bw_12) {
        this.break();
        bq_1 bq_13 = bq_12;
        this.class[bz_2.break[0]] = bq_13;
        bw_1 bw_13 = bw_12;
        this.class[bz_2.break[1]] = bw_13;
    }

    static {
        bz_2.ntfClinit();
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0x5ACBDCFE;
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0x2C9E7F35C0DF2B0L;
    }

    public static String class(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{-36, -8, 56, -108, -97, 80, -40, -66}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    private static void class() {
        byte = new byte[]{2};
    }

    private void break() {
        if (this.class == null) {
            Object[] objectArray = this.class = new Object[byte[0]];
        }
    }

    private static /* synthetic */ void ntfClinit() {
        bz_2.byte();
        bz_2.class();
    }
}

