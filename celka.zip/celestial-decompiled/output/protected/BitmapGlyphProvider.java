/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  it.unimi.dsi.fastutil.ints.Int2ObjectMap
 *  it.unimi.dsi.fastutil.ints.IntSet
 *  it.unimi.dsi.fastutil.ints.IntSets
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
package protected;

import it.unimi.dsi.fastutil.ints.Int2ObjectMap;
import it.unimi.dsi.fastutil.ints.IntSet;
import it.unimi.dsi.fastutil.ints.IntSets;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import protected.fn_0;
import protected.uc_2;
import protected.uj_2;
import protected.uv_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.um
 */
public class um_1
implements uc_2 {
    static final Logger class = LogManager.getLogger();
    private final fn_0 break;
    private final Int2ObjectMap<uv_2> byte;
    boolean protected = false;
    float throws = -1.0f;

    public float byte() {
        return this.throws;
    }

    um_1(fn_0 fn_02, Int2ObjectMap<uv_2> int2ObjectMap) {
        this.break = fn_02;
        this.byte = int2ObjectMap;
    }

    @Override
    public IntSet class() {
        return IntSets.unmodifiable((IntSet)this.byte.keySet());
    }

    @Override
    public uj_2 class(int n2) {
        return (uj_2)this.byte.get(n2);
    }

    @Override
    public void close() {
        this.break.close();
    }

    public boolean break() {
        return this.protected;
    }
}

