/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.qp_2;
import protected.rls;
import protected.rpH;
import protected.rqa_0;
import protected.rqn;
import protected.xc_0;
import protected.xu_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.rCV
 */
public final class rcv_0
extends Enum<rcv_0>
implements rpH {
    public static final /* enum */ rcv_0 HARP = new rcv_0("harp", rqn.MA);
    public static final /* enum */ rcv_0 BASEDRUM = new rcv_0("basedrum", rqn.Mu);
    public static final /* enum */ rcv_0 SNARE = new rcv_0("snare", rqn.Ml);
    public static final /* enum */ rcv_0 HAT = new rcv_0("hat", rqn.Mn);
    public static final /* enum */ rcv_0 BASS = new rcv_0("bass", rqn.Mm);
    public static final /* enum */ rcv_0 FLUTE = new rcv_0("flute", rqn.MF);
    public static final /* enum */ rcv_0 BELL = new rcv_0("bell", rqn.MZ);
    public static final /* enum */ rcv_0 GUITAR = new rcv_0("guitar", rqn.ML);
    public static final /* enum */ rcv_0 CHIME = new rcv_0("chime", rqn.Mv);
    public static final /* enum */ rcv_0 XYLOPHONE = new rcv_0("xylophone", rqn.MH);
    public static final /* enum */ rcv_0 IRON_XYLOPHONE = new rcv_0("iron_xylophone", rqn.My);
    public static final /* enum */ rcv_0 COW_BELL = new rcv_0("cow_bell", rqn.Mp);
    public static final /* enum */ rcv_0 DIDGERIDOO = new rcv_0("didgeridoo", rqn.Mq);
    public static final /* enum */ rcv_0 BIT = new rcv_0("bit", rqn.MT);
    public static final /* enum */ rcv_0 BANJO = new rcv_0("banjo", rqn.Mt);
    public static final /* enum */ rcv_0 PLING = new rcv_0("pling", rqn.MC);
    private final String name;
    private final rqa_0 sound;
    private static final /* synthetic */ rcv_0[] $VALUES;

    private static /* synthetic */ rcv_0[] byte() {
        return new rcv_0[]{HARP, BASEDRUM, SNARE, HAT, BASS, FLUTE, BELL, GUITAR, CHIME, XYLOPHONE, IRON_XYLOPHONE, COW_BELL, DIDGERIDOO, BIT, BANJO, PLING};
    }

    private rcv_0(String string2, rqa_0 rqa_02) {
        this.name = string2;
        this.sound = rqa_02;
    }

    static {
        $VALUES = rcv_0.byte();
    }

    public static rcv_0[] values() {
        return (rcv_0[])$VALUES.clone();
    }

    public static rcv_0 valueOf(String string) {
        return Enum.valueOf(rcv_0.class, string);
    }

    @Override
    public String class() {
        return this.name;
    }

    public static rcv_0 class(xc_0 xc_02) {
        if (xc_02.class(xu_0.PI)) {
            return FLUTE;
        }
        if (xc_02.class(xu_0.rt)) {
            return BELL;
        }
        if (xc_02.class(rls.break)) {
            return GUITAR;
        }
        if (xc_02.class(xu_0.Ei)) {
            return CHIME;
        }
        if (xc_02.class(xu_0.bY)) {
            return XYLOPHONE;
        }
        if (xc_02.class(xu_0.rw)) {
            return IRON_XYLOPHONE;
        }
        if (xc_02.class(xu_0.PY)) {
            return COW_BELL;
        }
        if (xc_02.class(xu_0.Pg)) {
            return DIDGERIDOO;
        }
        if (xc_02.class(xu_0.SN)) {
            return BIT;
        }
        if (xc_02.class(xu_0.Ey)) {
            return BANJO;
        }
        if (xc_02.class(xu_0.Pa)) {
            return PLING;
        }
        qp_2 qp_22 = xc_02.byte();
        if (qp_22 == qp_2.void) {
            return BASEDRUM;
        }
        if (qp_22 == qp_2.synchronized) {
            return SNARE;
        }
        if (qp_22 == qp_2.abstract) {
            return HAT;
        }
        return qp_22 != qp_2.goto && qp_22 != qp_2.while ? HARP : BASS;
    }

    public rqa_0 break() {
        return this.sound;
    }
}

