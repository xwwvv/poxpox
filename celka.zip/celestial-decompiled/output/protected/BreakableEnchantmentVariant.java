/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.eC;
import protected.ef_0;
import protected.ev_0;
import protected.rxq_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class as
extends ev_0 {
    public as(ef_0 ef_02, rxq_1 ... rxq_1Array) {
        super(ef_02, eC.BREAKABLE, rxq_1Array);
    }

    @Override
    public int class() {
        return 1;
    }

    @Override
    public int class(int n2) {
        return n2 * 25;
    }

    @Override
    public boolean break() {
        return true;
    }

    @Override
    public int break(int n2) {
        return this.class(n2) + 50;
    }
}

