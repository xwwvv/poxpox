/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Stream;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.extends;
import protected.f_0;
import protected.pd_2;
import protected.rqo_0;
import protected.throws;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.v
 */
public class v_0 {
    private static boolean[] break;
    public Object[] class;
    private static short[] byte;

    public v_0 byte() {
        return this.break(((List)throws.break().Pj[byte[16]]).stream().filter(extends_ -> !pd_2.throws(extends_) ? break[0] : break[1]).map(extends::protected).sorted(String.CASE_INSENSITIVE_ORDER));
    }

    public static String byte(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{-44, -22, -84, -91, -85, -39, 27, 56}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    public v_0(List<String> list) {
        Stream stream;
        this.implements();
        this.class[v_0.byte[1]] = stream = list.stream();
    }

    public v_0() {
        Stream stream;
        this.implements();
        this.class[v_0.byte[2]] = stream = Stream.empty();
    }

    public v_0(String[] stringArray) {
        Stream<String> stream;
        this.implements();
        this.class[v_0.byte[0]] = stream = Stream.of(stringArray);
    }

    static {
        v_0.ntfClinit();
    }

    public v_0 class(Stream<String> stream) {
        Stream<String> stream2;
        this.class[v_0.byte[6]] = stream2 = Stream.concat(stream, (Stream)this.class[byte[5]]);
        return this;
    }

    public v_0 class(Predicate<String> predicate) {
        Stream<String> stream;
        this.class[v_0.byte[10]] = stream = ((Stream)this.class[byte[9]]).filter(predicate);
        return this;
    }

    public v_0 class(Class<? extends Enum<?>> clazz) {
        return this.class(Stream.of(clazz.getEnumConstants()).map(Enum::name).map(String::toLowerCase));
    }

    public v_0 class(String ... stringArray) {
        return this.class(Stream.of(stringArray));
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0xC7E92B65EBAA0961L;
    }

    public v_0 class(Function<String, String> function) {
        Stream<String> stream;
        this.class[v_0.byte[8]] = stream = ((Stream)this.class[byte[7]]).map(function);
        return this;
    }

    public v_0 class(f_0 f_02) {
        return this.break(f_02.class().byte().flatMap(interface_ -> interface_.break().stream()).distinct());
    }

    public v_0 class(String string) {
        return this.class((String string2) -> string2.toLowerCase(Locale.US).startsWith(string.toLowerCase(Locale.US)));
    }

    public String[] class() {
        return (String[])((Stream)this.class[byte[14]]).toArray(String[]::new);
    }

    public v_0 class(Comparator<String> comparator) {
        Stream<String> stream;
        this.class[v_0.byte[12]] = stream = ((Stream)this.class[byte[11]]).sorted(comparator);
        return this;
    }

    public v_0 break(String ... stringArray) {
        return this.break(Stream.of(stringArray));
    }

    public v_0 break(String string) {
        rqo_0 rqo_02 = rqo_0.break(string);
        if (rqo_02 == null) {
            Stream stream;
            this.class[v_0.byte[13]] = stream = Stream.empty();
            return this;
        }
        return this.class(rqo_02.toString());
    }

    private static int break(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0xD3794ED;
    }

    public v_0 break() {
        return this.class(String.CASE_INSENSITIVE_ORDER);
    }

    public v_0 break(Class<? extends Enum<?>> clazz) {
        return this.break(Stream.of(clazz.getEnumConstants()).map(Enum::name).map(String::toLowerCase));
    }

    public v_0 break(Stream<String> stream) {
        Stream<String> stream2;
        this.class[v_0.byte[4]] = stream2 = Stream.concat((Stream)this.class[byte[3]], stream);
        return this;
    }

    public v_0 throws() {
        return this.break(throws.break().class(Boolean.class).stream().map(extends::protected).sorted(String.CASE_INSENSITIVE_ORDER));
    }

    private static /* synthetic */ void ntfClinit() {
        v_0.private();
        v_0.catch();
    }

    private static void catch() {
        short[] sArray = new short[17];
        sArray[16] = 1;
        byte = sArray;
    }

    public v_0 case() {
        return this.break(pd_2.class(throws.break()).stream().map(extends::protected).sorted(String.CASE_INSENSITIVE_ORDER));
    }

    private void implements() {
        if (this.class == null) {
            Object[] objectArray = this.class = new Object[break[2]];
        }
    }

    public Stream<String> protected() {
        return (Stream)this.class[byte[15]];
    }

    private static void private() {
        boolean[] blArray = new boolean[3];
        blArray[0] = true;
        blArray[2] = true;
        break = blArray;
    }
}

