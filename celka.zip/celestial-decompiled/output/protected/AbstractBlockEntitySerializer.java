/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Iterables
 *  com.google.common.collect.Lists
 *  it.unimi.dsi.fastutil.objects.Object2IntMap
 *  it.unimi.dsi.fastutil.objects.Object2IntOpenHashMap
 *  org.apache.logging.log4j.LogManager
 */
package protected;

import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import it.unimi.dsi.fastutil.objects.Object2IntMap;
import it.unimi.dsi.fastutil.objects.Object2IntOpenHashMap;
import java.util.List;
import java.util.function.Supplier;
import org.apache.logging.log4j.LogManager;
import protected.rqR;
import protected.rub_2;
import protected.rus_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.ruF
 */
class ruf_1<T extends rub_2> {
    private final Object2IntMap<Class<? extends rus_2<T>>> class = (Object2IntMap)rqR.class(new Object2IntOpenHashMap(), object2IntOpenHashMap -> object2IntOpenHashMap.defaultReturnValue(-1));
    private final List<Supplier<? extends rus_2<T>>> break = Lists.newArrayList();

    ruf_1() {
    }

    public rus_2<?> class(int n2) {
        Supplier<rus_2<T>> supplier = this.break.get(n2);
        return supplier != null ? supplier.get() : null;
    }

    public Iterable<Class<? extends rus_2<?>>> class() {
        return Iterables.unmodifiableIterable((Iterable)this.class.keySet());
    }

    public Integer class(Class<?> clazz) {
        int n2 = this.class.getInt(clazz);
        return n2 == -1 ? null : Integer.valueOf(n2);
    }

    public <P extends rus_2<T>> ruf_1<T> class(Class<P> clazz, Supplier<P> supplier) {
        int n2 = this.break.size();
        int n3 = this.class.put(clazz, n2);
        if (n3 != -1) {
            String string = "Packet " + clazz + " is already registered to ID " + n3;
            LogManager.getLogger().fatal(string);
            throw new IllegalArgumentException(string);
        }
        this.break.add(supplier);
        return this;
    }
}

