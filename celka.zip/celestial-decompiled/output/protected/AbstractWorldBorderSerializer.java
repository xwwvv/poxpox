/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.serialization.Codec
 */
package protected;

import com.mojang.serialization.Codec;
import protected.rdq_0;
import protected.reb;
import protected.reb_0;
import protected.rvl_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.rUh
 */
public class ruh_0<P extends rdq_0> {
    public static final ruh_0<reb> class = ruh_0.class("two_layers_feature_size", reb.byte);
    public static final ruh_0<reb_0> break = ruh_0.class("three_layers_feature_size", reb_0.byte);
    private final Codec<P> byte;

    private ruh_0(Codec<P> codec) {
        this.byte = codec;
    }

    private static <P extends rdq_0> ruh_0<P> class(String string, Codec<P> codec) {
        return rvl_0.class(rvl_0.rs, string, new ruh_0<P>(codec));
    }

    public Codec<P> class() {
        return this.byte;
    }
}

