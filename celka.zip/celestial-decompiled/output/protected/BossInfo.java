/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.util.UUID;
import protected.rRb;
import protected.rfU;
import protected.rfv_1;
import protected.rgP;
import protected.rqR;
import protected.rrg_0;
import protected.rrm_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.cd
 */
public class cd_1
extends rrg_0 {
    protected float class;
    protected long break;

    public cd_1(rfv_1 rfv_12) {
        super(rfv_12.break(), rfv_12.protected(), rfv_12.case(), rfv_12.catch());
        this.class = rfv_12.throws();
        this.protected = rfv_12.throws();
        this.break = rqR.break();
        this.class(rfv_12.private());
        this.break(rfv_12.implements());
        this.byte(rfv_12.finally());
    }

    public cd_1(UUID uUID, rgP rgP2, rRb rRb2, rrm_0 rrm_02, float f2, boolean bl2, boolean bl3, boolean bl4) {
        super(uUID, rgP2, rRb2, rrm_02);
        this.class = f2;
        this.protected = f2;
        this.break = rqR.break();
        this.class(bl2);
        this.break(bl3);
        this.byte(bl4);
    }

    @Override
    public float class() {
        long l2 = rqR.break() - this.break;
        float f2 = rfU.class((float)l2 / 100.0f, 0.0f, 1.0f);
        return rfU.catch(f2, this.protected, this.class);
    }

    public void class(rfv_1 rfv_12) {
        switch (rfv_12.byte()) {
            case UPDATE_NAME: {
                this.class(rfv_12.protected());
                break;
            }
            case UPDATE_PCT: {
                this.class(rfv_12.throws());
                break;
            }
            case UPDATE_STYLE: {
                this.class(rfv_12.case());
                this.class(rfv_12.catch());
                break;
            }
            case UPDATE_PROPERTIES: {
                this.class(rfv_12.private());
                this.break(rfv_12.implements());
            }
        }
    }

    @Override
    public void class(float f2) {
        this.protected = this.class();
        this.class = f2;
        this.break = rqR.break();
    }
}

