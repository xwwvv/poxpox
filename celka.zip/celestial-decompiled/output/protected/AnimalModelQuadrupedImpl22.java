/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.iq_1;
import protected.rmk_1;
import protected.wk_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.wX
 */
public class wx_0<T extends rmk_1>
extends wk_0<T> {
    public wx_0() {
        super(12, 0.0f, true, 16.0f, 4.0f, 2.25f, 2.0f, 24);
        this.return = 128;
        this.public = 64;
        this.class = new iq_1(this, 0, 0);
        this.class.class(-3.5f, -3.0f, -3.0f, 7.0f, 7.0f, 7.0f, 0.0f);
        this.class.class(0.0f, 10.0f, -16.0f);
        this.class.class(0, 44).class(-2.5f, 1.0f, -6.0f, 5.0f, 3.0f, 3.0f, 0.0f);
        this.class.class(26, 0).class(-4.5f, -4.0f, -1.0f, 2.0f, 2.0f, 1.0f, 0.0f);
        iq_1 iq_12 = this.class.class(26, 0);
        iq_12.implements = true;
        iq_12.class(2.5f, -4.0f, -1.0f, 2.0f, 2.0f, 1.0f, 0.0f);
        this.break = new iq_1(this);
        this.break.class(0, 19).class(-5.0f, -13.0f, -7.0f, 14.0f, 14.0f, 11.0f, 0.0f);
        this.break.class(39, 0).class(-4.0f, -25.0f, -7.0f, 12.0f, 12.0f, 10.0f, 0.0f);
        this.break.class(-2.0f, 9.0f, 12.0f);
        int n2 = 10;
        this.byte = new iq_1(this, 50, 22);
        this.byte.class(-2.0f, 0.0f, -2.0f, 4.0f, 10.0f, 8.0f, 0.0f);
        this.byte.class(-3.5f, 14.0f, 6.0f);
        this.protected = new iq_1(this, 50, 22);
        this.protected.class(-2.0f, 0.0f, -2.0f, 4.0f, 10.0f, 8.0f, 0.0f);
        this.protected.class(3.5f, 14.0f, 6.0f);
        this.throws = new iq_1(this, 50, 40);
        this.throws.class(-2.0f, 0.0f, -2.0f, 4.0f, 10.0f, 6.0f, 0.0f);
        this.throws.class(-2.5f, 14.0f, -7.0f);
        this.case = new iq_1(this, 50, 40);
        this.case.class(-2.0f, 0.0f, -2.0f, 4.0f, 10.0f, 6.0f, 0.0f);
        this.case.class(2.5f, 14.0f, -7.0f);
        this.byte.byte -= 1.0f;
        this.protected.byte += 1.0f;
        this.byte.throws += 0.0f;
        this.protected.throws += 0.0f;
        this.throws.byte -= 1.0f;
        this.case.byte += 1.0f;
        this.throws.throws -= 1.0f;
        this.case.throws -= 1.0f;
    }

    @Override
    public void class(T t2, float f2, float f3, float f4, float f5, float f6) {
        super.class(t2, f2, f3, f4, f5, f6);
        float f7 = f4 - (float)((Integer)((rmk_1)t2).throws[41]).intValue();
        float f8 = ((rmk_1)t2).throw(f7);
        f8 *= f8;
        float f9 = 1.0f - f8;
        this.break.case = 1.5707964f - f8 * (float)Math.PI * 0.35f;
        this.break.protected = 9.0f * f9 + 11.0f * f8;
        this.throws.protected = 14.0f * f9 - 6.0f * f8;
        this.throws.throws = -8.0f * f9 - 4.0f * f8;
        this.throws.case -= f8 * (float)Math.PI * 0.45f;
        this.case.protected = this.throws.protected;
        this.case.throws = this.throws.throws;
        this.case.case -= f8 * (float)Math.PI * 0.45f;
        if (this.int) {
            this.class.protected = 10.0f * f9 - 9.0f * f8;
            this.class.throws = -16.0f * f9 - 7.0f * f8;
        } else {
            this.class.protected = 10.0f * f9 - 14.0f * f8;
            this.class.throws = -16.0f * f9 - 3.0f * f8;
        }
        this.class.case += f8 * (float)Math.PI * 0.15f;
    }
}

