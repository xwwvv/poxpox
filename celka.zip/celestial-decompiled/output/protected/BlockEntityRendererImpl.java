/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Maps
 */
package protected;

import com.google.common.collect.Maps;
import java.util.Map;
import protected.ai_0;
import protected.ea_0;
import protected.ey_0;
import protected.jq_1;
import protected.rYB;
import protected.rdn_1;
import protected.rfH;
import protected.rgz_1;
import protected.rrEm;
import protected.rru_0;
import protected.rrw_0;
import protected.xc_0;
import protected.xd_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.WT
 */
public class wt_2
extends xd_0 {
    private final xd_0 volatile;
    private static final Map<xd_0, xd_0> final = Maps.newIdentityHashMap();

    public wt_2(xd_0 xd_02, jq_1 jq_12) {
        super(jq_12);
        this.volatile = xd_02;
        final.put(xd_02, this);
    }

    public static xc_0 class(xd_0 xd_02) {
        return final.get(xd_02).continue();
    }

    @Override
    public void class(xc_0 xc_02, rrEm rrEm2, rfH rfH2, rdn_1 rdn_12) {
        super.class(xc_02, rrEm2, rfH2, rdn_12);
        if (rrEm2.B().break(rru_0.case) && ea_0.class(ey_0.else, rdn_12) == 0) {
            this.class(rrEm2, rfH2);
        }
    }

    @Override
    public void class(rYB rYB2, rfH rfH2, rrw_0 rrw_02) {
        if (rYB2 instanceof rrEm) {
            this.class((rrEm)rYB2, rfH2);
        }
    }

    private void class(rrEm rrEm2, rfH rfH2) {
        rgz_1 rgz_12 = ai_0.L.class(rrEm2);
        rgz_12.class((double)rfH2.b_() + 0.5, (double)rfH2.c_(), (double)rfH2.d_() + 0.5, 0.0f, 0.0f);
        rrEm2.a_(rgz_12);
        rgz_12.float();
    }

    public xd_0 break() {
        return this.volatile;
    }

    public static boolean private(xc_0 xc_02) {
        return final.containsKey(xc_02.break());
    }
}

