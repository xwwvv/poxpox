/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.Hx;
import protected.TG;
import protected.ml_1;
import protected.qe_0;
import protected.rgd_1;
import protected.tk_0;
import protected.tt_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
class Tb
extends tt_2<rgd_1, tk_0<rgd_1>> {
    Tb(TG tG, qe_0 qe_02) {
        super(qe_02);
    }

    @Override
    public void class(ml_1 ml_12, Hx hx, int n2, rgd_1 rgd_12, float f2, float f3, float f4, float f5, float f6, float f7) {
        if (rgd_12.v()) {
            super.class(ml_12, hx, n2, rgd_12, f2, f3, f4, f5, f6, f7);
        }
    }
}

