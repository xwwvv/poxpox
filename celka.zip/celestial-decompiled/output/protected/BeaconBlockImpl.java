/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.db_2;
import protected.ib_0;
import protected.jq_1;
import protected.ko_2;
import protected.rRq;
import protected.rYB;
import protected.rdn_1;
import protected.rfH;
import protected.rff;
import protected.rhd_2;
import protected.rho_0;
import protected.rlb_0;
import protected.rpm;
import protected.rxl_0;
import protected.ryo_2;
import protected.ryz_1;
import protected.xc_0;
import protected.xn_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.xG
 */
public class xg_0
extends db_2
implements ko_2 {
    public xg_0(jq_1 jq_12) {
        super(jq_12);
    }

    @Override
    public ryz_1 class(xc_0 xc_02, rYB rYB2, rfH rfH2, rhd_2 rhd_22, rpm rpm2, rff rff2) {
        if (rYB2.continue) {
            return ryz_1.SUCCESS;
        }
        ryo_2 ryo_22 = rYB2.class(rfH2);
        if (ryo_22 instanceof rho_0) {
            rhd_22.class((rho_0)ryo_22);
            rhd_22.break(rlb_0.G);
        }
        return ryz_1.CONSUME;
    }

    @Override
    public xn_0 class(xc_0 xc_02) {
        return xn_0.MODEL;
    }

    @Override
    public void class(rYB rYB2, rfH rfH2, xc_0 xc_02, ib_0 ib_02, rdn_1 rdn_12) {
        ryo_2 ryo_22;
        if (rdn_12.this() && (ryo_22 = rYB2.class(rfH2)) instanceof rho_0) {
            ((rho_0)ryo_22).class(rdn_12.continue());
        }
    }

    @Override
    public ryo_2 class(rRq rRq2) {
        return new rho_0();
    }

    @Override
    public rxl_0 break() {
        return rxl_0.WHITE;
    }
}

