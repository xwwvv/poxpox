/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.class;
import protected.pv_2;
import protected.rfU;
import protected.rfp_1;
import protected.rql;
import protected.y_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.BF
 */
public class bf_1
extends pv_2 {
    private static byte[] byte;
    private static short[] protected;
    private static String[] throws;
    private static long[] case;
    private static float[] catch;
    private static boolean[] private;
    public Object[] break;

    public String byte() {
        this.throws();
        return (String)this.break[protected[21]];
    }

    public bf_1(class clazz) {
        super(clazz);
        this.throws();
        float[] fArray = new float[byte[0]];
        this.break[bf_1.protected[0]] = fArray;
        Long l2 = case[0];
        this.break[bf_1.protected[1]] = l2;
        String string = throws[0];
        this.break[bf_1.protected[2]] = string;
        Float f2 = Float.valueOf(catch[0]);
        this.break[bf_1.protected[3]] = f2;
    }

    static {
        bf_1.ntfClinit();
    }

    @Override
    public void class(y_0 y_02) {
        this.throws();
        if (y_02.protected() instanceof rfp_1) {
            if ((Long)this.break[protected[4]] != case[1]) {
                float f2 = (float)(System.currentTimeMillis() - (Long)this.break[protected[5]]) / catch[1];
                ((float[])this.break[bf_1.protected[6]])[((Integer)this.break[bf_1.protected[7]]).intValue() % ((float[])this.break[bf_1.protected[8]]).length] = rfU.class(catch[2] / f2, catch[3], catch[4]);
                bf_1 bf_12 = this;
                Integer n2 = (Integer)bf_12.break[protected[9]] + private[0];
                bf_12.break[bf_1.protected[10]] = n2;
            }
            Long l2 = System.currentTimeMillis();
            this.break[bf_1.protected[11]] = l2;
            Float f3 = Float.valueOf(this.protected());
            this.break[bf_1.protected[12]] = f3;
            if (((Float)this.break[protected[13]]).floatValue() <= catch[5] || Float.isNaN(((Float)this.break[protected[14]]).floatValue())) {
                String string = throws[1];
                this.break[bf_1.protected[15]] = string;
            } else {
                String string = rql.class(((Float)this.break[protected[16]]).floatValue());
                this.break[bf_1.protected[17]] = string;
            }
        }
    }

    public float class() {
        this.throws();
        return catch[12] / ((Float)this.break[protected[19]]).floatValue();
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0xBBC2B7F5133E1EEFL;
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0x4258BE3C;
    }

    public float break() {
        this.throws();
        return ((Float)this.break[protected[20]]).floatValue();
    }

    public static String break(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{93, -95, -100, 80, -106, 81, 102, -7}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    private void throws() {
        if (this.break == null) {
            Object[] objectArray = this.break = new Object[byte[1]];
            objectArray[bf_1.private[2]] = case[2];
            objectArray[bf_1.byte[2]] = private[3];
            objectArray[bf_1.byte[3]] = Float.valueOf(catch[13]);
        }
    }

    private static /* synthetic */ void ntfClinit() {
        bf_1.extends();
        bf_1.private();
        bf_1.case();
        bf_1.implements();
        bf_1.catch();
        bf_1.finally();
    }

    private static void finally() {
        byte = new byte[]{20, 5, 2, 4};
    }

    private static void catch() {
        float[] fArray = new float[14];
        fArray[0] = 20.0f;
        fArray[1] = 1000.0f;
        fArray[2] = 20.0f;
        fArray[4] = 20.0f;
        fArray[9] = 1.0f;
        fArray[11] = 20.0f;
        fArray[12] = 20.0f;
        catch = fArray;
    }

    private static void extends() {
        boolean[] blArray = new boolean[4];
        blArray[0] = true;
        blArray[2] = true;
        private = blArray;
    }

    private static void case() {
        long[] lArray = new long[3];
        lArray[0] = -1L;
        lArray[1] = -1L;
        case = lArray;
    }

    private static void implements() {
        short[] sArray = new short[22];
        sArray[1] = 1;
        sArray[2] = 3;
        sArray[3] = 4;
        sArray[4] = 1;
        sArray[5] = 1;
        sArray[7] = 2;
        sArray[9] = 2;
        sArray[10] = 2;
        sArray[11] = 1;
        sArray[12] = 4;
        sArray[13] = 4;
        sArray[14] = 4;
        sArray[15] = 3;
        sArray[16] = 4;
        sArray[17] = 3;
        sArray[19] = 4;
        sArray[20] = 4;
        sArray[21] = 3;
        protected = sArray;
    }

    private float protected() {
        this.throws();
        float f2 = catch[6];
        float f3 = catch[7];
        float[] fArray = (float[])this.break[protected[18]];
        int n2 = fArray.length;
        for (int k = private[1]; k < n2; ++k) {
            float f4 = fArray[k];
            if (!(f4 > catch[8])) continue;
            f3 += f4;
            f2 += catch[9];
        }
        return rfU.class(f3 / f2, catch[10], catch[11]);
    }

    private static void private() {
        throws = new String[]{new String("20.0"), new String("0.0")};
    }
}

