/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.util.Random;
import protected.ib_0;
import protected.jq_1;
import protected.ke_2;
import protected.rRR;
import protected.rRq;
import protected.rYB;
import protected.rYr;
import protected.rcn_0;
import protected.rct_0;
import protected.rdn_1;
import protected.rfH;
import protected.rjC;
import protected.rjm;
import protected.rpr_0;
import protected.rrEm;
import protected.rxx;
import protected.ryo_2;
import protected.wu_2;
import protected.xc_0;
import protected.xd_0;
import protected.xu_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.Wk
 */
public abstract class wk_2
extends ke_2 {
    protected static final rjC final = xd_0.class(0.0, 0.0, 0.0, 16.0, 2.0, 16.0);
    public static final rcn_0 package = rct_0.return;

    protected void byte(rYB rYB2, rfH rfH2, xc_0 xc_02) {
        boolean bl2;
        boolean bl3;
        if (!this.class((rRR)rYB2, rfH2, xc_02) && (bl3 = xc_02.byte(package).booleanValue()) != (bl2 = this.class(rYB2, rfH2, xc_02)) && !rYB2.finally().break(rfH2, this)) {
            rYr rYr2 = rYr.HIGH;
            if (this.byte((rRq)rYB2, rfH2, xc_02)) {
                rYr2 = rYr.EXTREMELY_HIGH;
            } else if (bl3) {
                rYr2 = rYr.VERY_HIGH;
            }
            rYB2.finally().class(rfH2, this, this.private(xc_02), rYr2);
        }
    }

    public boolean byte(rRq rRq2, rfH rfH2, xc_0 xc_02) {
        rpr_0 rpr_02 = xc_02.byte(p).case();
        xc_0 xc_03 = rRq2.byte(rfH2.break(rpr_02));
        return wk_2.volatile(xc_03) && xc_03.byte(p) != rpr_02;
    }

    @Override
    public boolean byte(xc_0 xc_02) {
        return true;
    }

    protected wk_2(jq_1 jq_12) {
        super(jq_12);
    }

    @Override
    public boolean class(xc_0 xc_02, rRR rRR2, rfH rfH2) {
        return wk_2.byte(rRR2, rfH2.break());
    }

    @Override
    public xc_0 class(rxx rxx2) {
        return (xc_0)this.continue().class(p, rxx2.case().case());
    }

    @Override
    public void class(rYB rYB2, rfH rfH2, xc_0 xc_02, ib_0 ib_02, rdn_1 rdn_12) {
        if (this.class(rYB2, rfH2, xc_02)) {
            rYB2.finally().class(rfH2, this, 1);
        }
    }

    @Override
    public void class(xc_0 xc_02, rYB rYB2, rfH rfH2, xc_0 xc_03, boolean bl2) {
        this.protected(rYB2, rfH2, xc_02);
    }

    @Override
    public rjC class(xc_0 xc_02, rRq rRq2, rfH rfH2, rjm rjm2) {
        return final;
    }

    public boolean class(rRR rRR2, rfH rfH2, xc_0 xc_02) {
        return false;
    }

    @Override
    public void class(xc_0 xc_02, rYB rYB2, rfH rfH2, xd_0 xd_02, rfH rfH3, boolean bl2) {
        if (xc_02.class((rRR)rYB2, rfH2)) {
            this.byte(rYB2, rfH2, xc_02);
        } else {
            ryo_2 ryo_22 = this.protected() ? rYB2.class(rfH2) : null;
            wk_2.class(xc_02, rYB2, rfH2, ryo_22);
            rYB2.class(rfH2, false);
            for (rpr_0 rpr_02 : rpr_0.values()) {
                rYB2.break(rfH2.break(rpr_02), this);
            }
        }
    }

    protected boolean class(rYB rYB2, rfH rfH2, xc_0 xc_02) {
        return this.break(rYB2, rfH2, xc_02) > 0;
    }

    @Override
    public int class(xc_0 xc_02, rRq rRq2, rfH rfH2, rpr_0 rpr_02) {
        if (!xc_02.byte(package).booleanValue()) {
            return 0;
        }
        return xc_02.byte(p) == rpr_02 ? this.break(rRq2, rfH2, xc_02) : 0;
    }

    @Override
    public void break(xc_0 xc_02, rYB rYB2, rfH rfH2, xc_0 xc_03, boolean bl2) {
        if (!bl2 && !xc_02.class(xc_03.break())) {
            super.break(xc_02, rYB2, rfH2, xc_03, bl2);
            this.protected(rYB2, rfH2, xc_02);
        }
    }

    protected int break(rRR rRR2, rfH rfH2, rpr_0 rpr_02) {
        xc_0 xc_02 = rRR2.byte(rfH2);
        if (this.implements(xc_02)) {
            if (xc_02.class(xu_0.sn)) {
                return 15;
            }
            return xc_02.class(xu_0.ra) ? xc_02.byte(wu_2.new).intValue() : rRR2.class(rfH2, rpr_02);
        }
        return 0;
    }

    protected int break(rRq rRq2, rfH rfH2, xc_0 xc_02) {
        return 15;
    }

    protected int break(rRR rRR2, rfH rfH2, xc_0 xc_02) {
        rpr_0 rpr_02 = xc_02.byte(p);
        rpr_0 rpr_03 = rpr_02.catch();
        rpr_0 rpr_04 = rpr_02.private();
        return Math.max(this.break(rRR2, rfH2.break(rpr_03), rpr_03), this.break(rRR2, rfH2.break(rpr_04), rpr_04));
    }

    protected int break(rYB rYB2, rfH rfH2, xc_0 xc_02) {
        rpr_0 rpr_02 = xc_02.byte(p);
        rfH rfH3 = rfH2.break(rpr_02);
        int n2 = rYB2.byte(rfH3, rpr_02);
        if (n2 >= 15) {
            return n2;
        }
        xc_0 xc_03 = rYB2.byte(rfH3);
        return Math.max(n2, xc_03.class(xu_0.ra) ? xc_03.byte(wu_2.new) : 0);
    }

    @Override
    public void break(xc_0 xc_02, rrEm rrEm2, rfH rfH2, Random random) {
        if (!this.class((rRR)rrEm2, rfH2, xc_02)) {
            boolean bl2 = xc_02.byte(package);
            boolean bl3 = this.class((rYB)rrEm2, rfH2, xc_02);
            if (bl2 && !bl3) {
                rrEm2.class(rfH2, (xc_0)xc_02.class(package, false), 2);
            } else if (!bl2) {
                rrEm2.class(rfH2, (xc_0)xc_02.class(package, true), 2);
                if (!bl3) {
                    rrEm2.synchronized().class(rfH2, this, this.private(xc_02), rYr.VERY_HIGH);
                }
            }
        }
    }

    @Override
    public int break(xc_0 xc_02, rRq rRq2, rfH rfH2, rpr_0 rpr_02) {
        return xc_02.break(rRq2, rfH2, rpr_02);
    }

    protected boolean implements(xc_0 xc_02) {
        return xc_02.implements();
    }

    protected void protected(rYB rYB2, rfH rfH2, xc_0 xc_02) {
        rpr_0 rpr_02 = xc_02.byte(p);
        rfH rfH3 = rfH2.break(rpr_02.case());
        rYB2.class(rfH3, (xd_0)this, rfH2);
        rYB2.class(rfH3, (xd_0)this, rpr_02);
    }

    protected abstract int private(xc_0 var1);

    public static boolean volatile(xc_0 xc_02) {
        return xc_02.break() instanceof wk_2;
    }
}

