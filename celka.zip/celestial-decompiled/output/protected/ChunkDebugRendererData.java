/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableMap
 *  com.google.common.collect.ImmutableMap$Builder
 */
package protected;

import com.google.common.collect.ImmutableMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import protected.ao_2;
import protected.gm;
import protected.rYB;
import protected.rfj;
import protected.rng;
import protected.roj_0;
import protected.rqm_0;
import protected.rrEm;
import protected.rren_0;
import protected.yr_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.yY
 */
final class yy_1 {
    final Map<rfj, String> class;
    final CompletableFuture<Map<rfj, String>> break;

    yy_1(yr_2 yr_22, rng rng2, double d, double d2) {
        gm gm2 = (gm)yr_22.class.class[56];
        rqm_0<rYB> rqm_02 = gm2.E();
        int n2 = (int)d >> 4;
        int n3 = (int)d2 >> 4;
        ImmutableMap.Builder builder = ImmutableMap.builder();
        ao_2 ao_22 = gm2.native();
        for (int k = n2 - 12; k <= n2 + 12; ++k) {
            for (int i2 = n3 - 12; i2 <= n3 + 12; ++i2) {
                rfj rfj2 = new rfj(k, i2);
                Object object = "";
                roj_0 roj_02 = ao_22.class(k, i2, false);
                object = (String)object + "Client: ";
                if (roj_02 == null) {
                    object = (String)object + "0n/a\n";
                } else {
                    object = (String)object + (roj_02.catch() ? " E" : "");
                    object = (String)object + "\n";
                }
                builder.put((Object)rfj2, object);
            }
        }
        this.class = builder.build();
        this.break = rng2.class(() -> {
            rrEm rrEm2 = rng2.class(rqm_02);
            if (rrEm2 == null) {
                return ImmutableMap.of();
            }
            ImmutableMap.Builder builder = ImmutableMap.builder();
            rren_0 rren_02 = rrEm2.else();
            for (int k = n2 - 12; k <= n2 + 12; ++k) {
                for (int i2 = n3 - 12; i2 <= n3 + 12; ++i2) {
                    rfj rfj2 = new rfj(k, i2);
                    builder.put((Object)rfj2, (Object)("Server: " + rren_02.break(rfj2)));
                }
            }
            return builder.build();
        });
    }
}

