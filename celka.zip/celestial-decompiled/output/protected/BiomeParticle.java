/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.datafixers.kinds.App
 *  com.mojang.datafixers.kinds.Applicative
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.codecs.RecordCodecBuilder
 */
package protected;

import com.mojang.datafixers.kinds.App;
import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import protected.rqa_0;
import protected.rqn;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class rYj {
    public static final Codec<rYj> class = RecordCodecBuilder.create(instance -> instance.group((App)rqa_0.class.fieldOf("sound").forGetter(rYj2 -> rYj2.byte), (App)Codec.INT.fieldOf("tick_delay").forGetter(rYj2 -> rYj2.protected), (App)Codec.INT.fieldOf("block_search_extent").forGetter(rYj2 -> rYj2.throws), (App)Codec.DOUBLE.fieldOf("offset").forGetter(rYj2 -> rYj2.case)).apply((Applicative)instance, rYj::new));
    public static final rYj break = new rYj(rqn.class, 6000, 8, 2.0);
    private rqa_0 byte;
    private int protected;
    private int throws;
    private double case;

    public int byte() {
        return this.throws;
    }

    public rYj(rqa_0 rqa_02, int n2, int n3, double d) {
        this.byte = rqa_02;
        this.protected = n2;
        this.throws = n3;
        this.case = d;
    }

    public rqa_0 class() {
        return this.byte;
    }

    public int break() {
        return this.protected;
    }

    public double protected() {
        return this.case;
    }
}

