/*
 * Decompiled with CFR 0.152.
 */
package protected;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.NN
 */
public final class nn_2
extends Enum<nn_2> {
    public static final /* enum */ nn_2 NONE = new nn_2();
    public static final /* enum */ nn_2 LINEAR = new nn_2();
    private static final /* synthetic */ nn_2[] $VALUES;

    static {
        $VALUES = nn_2.class();
    }

    public static nn_2[] values() {
        return (nn_2[])$VALUES.clone();
    }

    public static nn_2 valueOf(String string) {
        return Enum.valueOf(nn_2.class, string);
    }

    private static /* synthetic */ nn_2[] class() {
        return new nn_2[]{NONE, LINEAR};
    }
}

