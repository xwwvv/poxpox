/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Maps
 */
package protected;

import com.google.common.collect.Maps;
import com.mojang.blaze3d.systems.RenderSystem;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;
import protected.cd_1;
import protected.ch_2;
import protected.cm_1;
import protected.ml_1;
import protected.qy_1;
import protected.rfl_2;
import protected.rfv_1;
import protected.rgP;
import protected.rqo_0;
import protected.rrbb;
import protected.rrbn_0;
import protected.rrg_0;
import protected.rrm_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.uj
 */
public class uj_1
extends ch_2 {
    private static final rqo_0 class = new rqo_0("textures/gui/bars.png");
    private final qy_1 throws;
    private final Map<UUID, cd_1> case = Maps.newLinkedHashMap();

    public uj_1(qy_1 qy_12) {
        this.throws = qy_12;
    }

    public boolean class(String ... stringArray) {
        Iterator<cd_1> iterator;
        if (!this.case.isEmpty() && (iterator = this.case.values().iterator()).hasNext()) {
            rrg_0 rrg_02 = iterator.next();
            String string = rrg_02.implements().byte().toLowerCase();
            boolean bl2 = true;
            for (String string2 : stringArray) {
                if (string.contains(string2.toLowerCase())) continue;
                bl2 = false;
                break;
            }
            return bl2;
        }
        return false;
    }

    public void class(ml_1 ml_12) {
        if (!this.case.isEmpty()) {
            int n2 = this.throws.else().super();
            int n3 = 12;
            for (cd_1 cd_12 : this.case.values()) {
                int n4 = n2 / 2 - 91;
                RenderSystem.color4f(1.0f, 1.0f, 1.0f, 1.0f);
                int n5 = 19;
                this.throws.A().class(uj_1.class);
                this.class(ml_12, n4, n3, cd_12);
                rgP rgP2 = cd_12.implements();
                int n6 = ((cm_1)this.throws.class[15]).class(rgP2);
                int n7 = n2 / 2 - n6 / 2;
                int n8 = n3 - 9;
                int n9 = 0xFFFFFF;
                if (rrbb.K()) {
                    n9 = rrbn_0.break(n9);
                }
                ((cm_1)this.throws.class[15]).break(ml_12, rgP2, (float)n7, (float)n8, n9);
                if ((n3 += n5) < this.throws.else().this() / 3) continue;
                break;
            }
        }
    }

    public boolean class(String string) {
        if (!this.case.isEmpty()) {
            string = string.toLowerCase();
            for (rrg_0 rrg_02 : this.case.values()) {
                String string2 = rrg_02.implements().byte().toLowerCase();
                if (!string2.contains(string)) continue;
                return true;
            }
        }
        return false;
    }

    private void class(ml_1 ml_12, int n2, int n3, rrg_0 rrg_02) {
        int n4;
        this.break(ml_12, n2, n3, 0, rrg_02.finally().ordinal() * 5 * 2, 182, 5);
        if (rrg_02.extends() != rrm_0.PROGRESS) {
            this.break(ml_12, n2, n3, 0, 80 + (rrg_02.extends().ordinal() - 1) * 5 * 2, 182, 5);
        }
        if ((n4 = (int)(rrg_02.class() * 183.0f)) > 0) {
            this.break(ml_12, n2, n3, 0, rrg_02.finally().ordinal() * 5 * 2 + 5, n4, 5);
            if (rrg_02.extends() != rrm_0.PROGRESS) {
                this.break(ml_12, n2, n3, 0, 80 + (rrg_02.extends().ordinal() - 1) * 5 * 2 + 5, n4, 5);
            }
        }
    }

    public void class(rfv_1 rfv_12) {
        if (rfv_12.byte() == rfl_2.ADD) {
            this.case.put(rfv_12.break(), new cd_1(rfv_12));
        } else if (rfv_12.byte() == rfl_2.REMOVE) {
            this.case.remove(rfv_12.break());
        } else {
            this.case.get(rfv_12.break()).class(rfv_12);
        }
    }

    public void class() {
        this.case.clear();
    }

    public boolean break(String ... stringArray) {
        if (!this.case.isEmpty()) {
            for (rrg_0 rrg_02 : this.case.values()) {
                String string = rrg_02.implements().byte().toLowerCase();
                for (String string2 : stringArray) {
                    if (!string.contains(string2.toLowerCase())) continue;
                    return true;
                }
            }
        }
        return false;
    }

    public boolean throws() {
        if (!this.case.isEmpty()) {
            for (rrg_0 rrg_02 : this.case.values()) {
                if (!rrg_02.native()) continue;
                return true;
            }
        }
        return false;
    }

    public Map<UUID, cd_1> catch() {
        return this.case;
    }

    public boolean case() {
        if (!this.case.isEmpty()) {
            for (rrg_0 rrg_02 : this.case.values()) {
                if (!rrg_02.final()) continue;
                return true;
            }
        }
        return false;
    }

    public boolean protected() {
        if (!this.case.isEmpty()) {
            for (rrg_0 rrg_02 : this.case.values()) {
                if (!rrg_02.volatile()) continue;
                return true;
            }
        }
        return false;
    }
}

