/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.regex.Pattern;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.bl_2;
import protected.bn_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.BK
 */
public class bk_2
extends bn_2 {
    private static String[] byte;
    private static short[] protected;

    public bk_2() {
        super(byte[0], (Pattern[])bl_2.class[protected[0]]);
    }

    static {
        bk_2.ntfClinit();
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0x383C225D578763EFL;
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0x2AB0C2C9;
    }

    private static /* synthetic */ void ntfClinit() {
        bk_2.catch();
        bk_2.private();
    }

    private static void catch() {
        byte = new String[]{new String("\u0413\u043e\u0440\u044f\u0449\u0438\u0439 \u0447\u0435\u0440\u0435\u043f")};
    }

    public static String catch(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{103, 63, -36, -35, 101, 91, 98, 4}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    private static void private() {
        protected = new short[]{22};
    }
}

