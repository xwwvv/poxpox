/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.Sn
 */
public class sn_1 {
    private static boolean[] break;
    public static Object[] class;
    private static byte[] byte;

    private static void byte() {
        Object[] objectArray = new Object[1];
        int[] nArray = new int[10];
        nArray[0] = 1;
        nArray[2] = 2;
        nArray[4] = 3;
        nArray[6] = 4;
        objectArray[0] = nArray;
        sn_1.class = objectArray;
    }

    static {
        sn_1.ntfClinit();
    }

    public static String class(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{-46, 28, -64, -23, 41, -81, -85, 94}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0x96C7703D00DF81B6L;
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0x8C7F61E3;
    }

    private static void class() {
        boolean[] blArray = new boolean[8];
        blArray[3] = true;
        blArray[7] = true;
        break = blArray;
    }

    private static void break() {
        byte = new byte[]{2, 2, 4, 3, 6, 4};
    }

    private static /* synthetic */ void ntfClinit() {
        sn_1.class();
        sn_1.break();
        sn_1.byte();
    }
}

