/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.rYt;
import protected.rYx;
import protected.ryg_0;
import protected.ryh_0;
import protected.ryj_0;
import protected.ryv_0;
import protected.ryw_0;
import protected.ryx_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.rYO
 */
public class ryo_0 {
    private ryj_0 class;
    private ryh_0 break;
    private Float byte;
    private Float protected;
    private Float throws;
    private rYx case = rYx.NONE;
    private Float catch;
    private ryw_0 private;
    private rYt implements;
    private ryv_0 finally;

    public ryo_0 byte(float f2) {
        this.throws = Float.valueOf(f2);
        return this;
    }

    public String toString() {
        return "BiomeBuilder{\nprecipitation=" + this.class + ",\nbiomeCategory=" + this.break + ",\ndepth=" + this.byte + ",\nscale=" + this.protected + ",\ntemperature=" + this.throws + ",\ntemperatureModifier=" + this.case + ",\ndownfall=" + this.catch + ",\nspecialEffects=" + this.private + ",\nmobSpawnSettings=" + this.implements + ",\ngenerationSettings=" + this.finally + ",\n}";
    }

    public ryo_0 class(ryw_0 ryw_02) {
        this.private = ryw_02;
        return this;
    }

    public ryo_0 class(rYt rYt2) {
        this.implements = rYt2;
        return this;
    }

    public ryo_0 class(ryv_0 ryv_02) {
        this.finally = ryv_02;
        return this;
    }

    public ryo_0 class(rYx rYx2) {
        this.case = rYx2;
        return this;
    }

    public ryg_0 class() {
        if (this.class != null && this.break != null && this.byte != null && this.protected != null && this.throws != null && this.catch != null && this.private != null && this.implements != null && this.finally != null) {
            return new ryg_0(new ryx_0(this.class, this.throws.floatValue(), this.case, this.catch.floatValue()), this.break, this.byte.floatValue(), this.protected.floatValue(), this.private, this.finally, this.implements);
        }
        throw new IllegalStateException("You are missing parameters to build a proper biome\n" + this);
    }

    public ryo_0 class(ryj_0 ryj_02) {
        this.class = ryj_02;
        return this;
    }

    public ryo_0 class(ryh_0 ryh_02) {
        this.break = ryh_02;
        return this;
    }

    public ryo_0 class(float f2) {
        this.byte = Float.valueOf(f2);
        return this;
    }

    public ryo_0 break(float f2) {
        this.protected = Float.valueOf(f2);
        return this;
    }

    public ryo_0 protected(float f2) {
        this.catch = Float.valueOf(f2);
        return this;
    }
}

