/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.sk
 */
public class sk_0 {
    private static byte[] break;
    private static boolean[] byte;
    public static Object[] class;

    private static void byte() {
        boolean[] blArray = new boolean[10];
        blArray[3] = true;
        blArray[5] = true;
        blArray[9] = true;
        byte = blArray;
    }

    static {
        sk_0.ntfClinit();
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0x2E824B95F4E54EEFL;
    }

    public static String class(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{74, 6, -114, -40, 6, 2, -94, -100}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0x13DEC71D;
    }

    private static void class() {
        break = new byte[]{2, 2, 3, 3, 4, 4, 5};
    }

    private static void break() {
        Object[] objectArray = new Object[]{new int[]{1, 2, 3, 4, 5}};
        sk_0.class = objectArray;
    }

    private static /* synthetic */ void ntfClinit() {
        sk_0.byte();
        sk_0.class();
        sk_0.break();
    }
}

