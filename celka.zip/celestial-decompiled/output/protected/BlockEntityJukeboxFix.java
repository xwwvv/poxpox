/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.datafixers.DSL
 *  com.mojang.datafixers.OpticFinder
 *  com.mojang.datafixers.Typed
 *  com.mojang.datafixers.schemas.Schema
 *  com.mojang.datafixers.types.Type
 *  com.mojang.datafixers.util.Pair
 *  com.mojang.serialization.Dynamic
 */
package protected;

import com.mojang.datafixers.DSL;
import com.mojang.datafixers.OpticFinder;
import com.mojang.datafixers.Typed;
import com.mojang.datafixers.schemas.Schema;
import com.mojang.datafixers.types.Type;
import com.mojang.datafixers.util.Pair;
import com.mojang.serialization.Dynamic;
import protected.rTC;
import protected.rtK;
import protected.rti;
import protected.rww_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class rws
extends rww_0 {
    public rws(Schema schema, boolean bl2) {
        super(schema, bl2, "BlockEntityJukeboxFix", rTC.extends, "minecraft:jukebox");
    }

    @Override
    protected Typed<?> class(Typed<?> typed) {
        Type type = this.getInputSchema().getChoiceType(rTC.extends, "minecraft:jukebox");
        Type type2 = type.findFieldType("RecordItem");
        OpticFinder opticFinder = DSL.fieldFinder((String)"RecordItem", (Type)type2);
        Dynamic dynamic = (Dynamic)typed.get(DSL.remainderFinder());
        int n2 = dynamic.get("Record").asInt(0);
        if (n2 > 0) {
            dynamic.remove("Record");
            String string = rti.class(rtK.class(n2), 0);
            if (string != null) {
                Dynamic dynamic2 = dynamic.emptyMap();
                dynamic2 = dynamic2.set("id", dynamic2.createString(string));
                dynamic2 = dynamic2.set("Count", dynamic2.createByte((byte)1));
                return typed.set(opticFinder, (Typed)((Pair)type2.readTyped(dynamic2).result().orElseThrow(() -> new IllegalStateException("Could not create record item stack."))).getFirst()).set(DSL.remainderFinder(), (Object)dynamic);
            }
        }
        return typed;
    }
}

