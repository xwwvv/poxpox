/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 *  org.apache.logging.log4j.util.Supplier
 */
package protected;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.util.Supplier;
import protected.Ko;
import protected.ao;
import protected.rYB;
import protected.rcd_2;
import protected.rfH;
import protected.rfy_2;
import protected.rpa;
import protected.rqd_0;
import protected.rqo_0;
import protected.rvl_0;
import protected.ryw_2;
import protected.xc_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.ryO
 */
public abstract class ryo_2
implements ao {
    private static final Logger class = LogManager.getLogger();
    private final ryw_2<?> break;
    protected rYB extends;
    protected rfH native = rfH.protected;
    protected boolean volatile;
    private xc_0 byte;
    private boolean protected;

    public rfH char() {
        return this.native;
    }

    public void byte(rfH rfH2) {
        this.native = rfH2.int();
    }

    public void int() {
        this.volatile = false;
    }

    public boolean long() {
        return this.volatile;
    }

    public void float() {
        this.byte = null;
    }

    public ryo_2(ryw_2<?> ryw_22) {
        this.break = ryw_22;
    }

    public boolean interface() {
        return this.extends != null;
    }

    public void class(xc_0 xc_02, rcd_2 rcd_22) {
        this.native = new rfH(rcd_22.private("x"), rcd_22.private("y"), rcd_22.private("z"));
    }

    public void class(Ko ko) {
        ko.class("Name", () -> rvl_0.r.break(this.void()) + " // " + this.getClass().getCanonicalName());
        if (this.extends != null) {
            Ko.class(ko, this.native, this.abstract());
            Ko.class(ko, this.native, this.extends.byte(this.native));
        }
    }

    public rcd_2 class(rcd_2 rcd_22) {
        return this.break(rcd_22);
    }

    public ryw_2<?> void() {
        return this.break;
    }

    public static ryo_2 break(xc_0 xc_02, rcd_2 rcd_22) {
        String string = rcd_22.native("id");
        return rvl_0.r.break(new rqo_0(string)).map(ryw_22 -> {
            try {
                return ryw_22.class();
            }
            catch (Throwable throwable) {
                ryo_2.class.error("Failed to create block entity {}", (Object)string, (Object)throwable);
                return null;
            }
        }).map(ryo_22 -> {
            try {
                ryo_22.class(xc_02, rcd_22);
                return ryo_22;
            }
            catch (Throwable throwable) {
                ryo_2.class.error("Failed to load data for block entity {}", (Object)string, (Object)throwable);
                return null;
            }
        }).orElseGet(() -> {
            ryo_2.class.warn("Skipping BlockEntity with id {}", (Object)string);
            return null;
        });
    }

    private rcd_2 break(rcd_2 rcd_22) {
        rqo_0 rqo_02 = ryw_2.class(this.void());
        if (rqo_02 == null) {
            throw new RuntimeException(this.getClass() + " is missing a mapping! This is a bug!");
        }
        rcd_22.class("id", rqo_02.toString());
        rcd_22.break("x", this.native.b_());
        rcd_22.break("y", this.native.c_());
        rcd_22.break("z", this.native.d_());
        return rcd_22;
    }

    public void break(rpa rpa2) {
    }

    public void break() {
        if (this.extends != null) {
            this.byte = this.extends.byte(this.native);
            this.extends.break(this.native, this);
            if (!this.byte.catch()) {
                this.extends.byte(this.native, this.byte.break());
            }
        }
    }

    public void break(rqd_0 rqd_02) {
    }

    public void break(rYB rYB2, rfH rfH2) {
        this.extends = rYB2;
        this.native = rfH2.int();
    }

    public double implements() {
        return 64.0;
    }

    public rYB while() {
        return this.extends;
    }

    public void static() {
        if (!this.protected) {
            this.protected = true;
            ryo_2.class.warn("Block entity invalid: {} @ {}", new Supplier[]{() -> rvl_0.r.break(this.void()), this::char});
        }
    }

    public xc_0 abstract() {
        if (this.byte == null) {
            this.byte = this.extends.byte(this.native);
        }
        return this.byte;
    }

    public void aa_() {
        this.volatile = true;
    }

    public boolean ac_() {
        return false;
    }

    public boolean a_(int n2, int n3) {
        return false;
    }

    public rfy_2 Y_() {
        return null;
    }

    public rcd_2 Z_() {
        return this.break(new rcd_2());
    }
}

