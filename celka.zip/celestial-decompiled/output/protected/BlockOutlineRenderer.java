/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Maps
 */
package protected;

import com.google.common.collect.Maps;
import com.mojang.blaze3d.systems.RenderSystem;
import java.util.Map;
import protected.Hx;
import protected.mk_1;
import protected.ml_1;
import protected.op_2;
import protected.rfH;
import protected.rqR;
import protected.yd_2;
import protected.yi_1;
import protected.yk_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.ya
 */
public class ya_1
implements yd_2 {
    private final Map<rfH, yi_1> class = Maps.newHashMap();

    @Override
    public void class(ml_1 ml_12, Hx hx, double d, double d2, double d3) {
        long l2 = rqR.break();
        this.class.entrySet().removeIf(entry -> l2 > ((yi_1)entry.getValue()).byte);
        this.class.forEach(this::class);
    }

    private void class(rfH rfH2, yi_1 yi_12) {
        RenderSystem.pushMatrix();
        RenderSystem.enableBlend();
        RenderSystem.blendFuncSeparate(op_2.SRC_ALPHA, mk_1.ONE_MINUS_SRC_ALPHA, op_2.ONE, mk_1.ZERO);
        RenderSystem.color4f(0.0f, 1.0f, 0.0f, 0.75f);
        RenderSystem.disableTexture();
        yk_2.class(rfH2, 0.02f, yi_12.class(), yi_12.break(), yi_12.byte(), yi_12.protected());
        if (!yi_12.break.isEmpty()) {
            double d = (double)rfH2.b_() + 0.5;
            double d2 = (double)rfH2.c_() + 1.2;
            double d3 = (double)rfH2.d_() + 0.5;
            yk_2.class(yi_12.break, d, d2, d3, -1, 0.01f, true, 0.0f, true);
        }
        RenderSystem.enableTexture();
        RenderSystem.disableBlend();
        RenderSystem.popMatrix();
    }

    @Override
    public void class() {
        this.class.clear();
    }

    public void class(rfH rfH2, int n2, String string, int n3) {
        this.class.put(rfH2, new yi_1(n2, string, rqR.break() + (long)n3));
    }
}

