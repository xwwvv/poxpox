/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 */
package protected;

import com.google.common.collect.Lists;
import java.util.List;
import protected.ht_2;
import protected.rcd_2;
import protected.rdb_1;
import protected.rlb;
import protected.rli_1;
import protected.rpl_0;
import protected.xc_1;
import protected.xf_2;
import protected.xh_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.XX
 */
public class xx_2 {
    private final List<ht_2> class = Lists.newArrayList();
    private final List<ht_2> break = Lists.newArrayList();
    private rdb_1 byte;
    private rlb<rdb_1> protected;
    private xf_2 throws = xf_2.throws;
    private xf_2 case = xf_2.throws;
    private rli_1 catch;
    private xc_1 private = xc_1.class;

    private xx_2() {
    }

    public xx_2 class(rlb<rdb_1> rlb2) {
        this.protected = rlb2;
        return this;
    }

    public xx_2 class(rcd_2 rcd_22) {
        this.private = new xc_1(rcd_22);
        return this;
    }

    public xx_2 class(ht_2 ht_22) {
        this.class.add(ht_22);
        return this;
    }

    public xx_2 class(rpl_0 rpl_02) {
        this.byte = rpl_02.case();
        return this;
    }

    public static xx_2 class() {
        return new xx_2();
    }

    public xh_2 break() {
        return new xh_2(this.protected, this.byte, this.throws, this.case, this.class.toArray(ht_2.break), this.break.toArray(ht_2.break), this.catch, this.private);
    }
}

