/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.rpr_0;

/*
 * Renamed from protected.yA
 * Illegal identifiers - consider using --renameillegalidents true
 */
class ya_2 {
    static final /* synthetic */ int[] class;

    static {
        ya_2.class = new int[rpr_0.values().length];
        try {
            ya_2.class[rpr_0.DOWN.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            ya_2.class[rpr_0.UP.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            ya_2.class[rpr_0.NORTH.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            ya_2.class[rpr_0.SOUTH.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            ya_2.class[rpr_0.WEST.ordinal()] = 5;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            ya_2.class[rpr_0.EAST.ordinal()] = 6;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}

