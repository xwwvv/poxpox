/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.lwjgl.opengl.GL11
 */
package protected;

import com.mojang.blaze3d.systems.RenderSystem;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import org.lwjgl.opengl.GL11;
import protected.Y;
import protected.bb_0;
import protected.be_0;
import protected.bm_0;
import protected.bs_0;
import protected.class;
import protected.dv_2;
import protected.jI;
import protected.ji_1;
import protected.ji_2;
import protected.ju_0;
import protected.jv_1;
import protected.ml_1;
import protected.ps_1;
import protected.q;
import protected.qy_1;
import protected.rVi;
import protected.rYB;
import protected.rZR;
import protected.rfH;
import protected.rfl;
import protected.rgF;
import protected.rgn_0;
import protected.rjC;
import protected.rrfD;
import protected.rrik_0;
import protected.rrjc_0;
import protected.rrlu_2;
import protected.rrze_1;
import protected.rus_2;
import protected.rvc_1;
import protected.ryo_2;
import protected.t_0;
import protected.wp_1;
import protected.xc_0;
import protected.xd_0;
import protected.xs;
import protected.yt_1;
import protected.yx_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class bS
extends bb_0
implements rrze_1 {
    public Object[] class;
    private static boolean[] break;
    private static String[] protected;
    private static short[] throws;
    private static float[] case;
    private static byte[] catch;

    public bS(class clazz, bm_0 bm_02) {
        super(clazz, bm_02);
        HashMap hashMap;
        HashMap hashMap2;
        ConcurrentHashMap concurrentHashMap;
        this.implements();
        this.class[bS.throws[0]] = concurrentHashMap = new ConcurrentHashMap();
        this.class[bS.throws[1]] = hashMap2 = new HashMap();
        this.class[bS.throws[2]] = hashMap = new HashMap();
        bs_0 bs_02 = (rfH2, xc_02) -> {
            this.implements();
            xd_0 xd_02 = xc_02.break();
            if (xd_02 instanceof ji_2) {
                return ((rrik_0)((Map)this.class[throws[21]]).get((Object)((be_0)((Object)((Object)be_0.staticFields41d67a8911663c568d38045d1ac26747[throws[22]]))))).class();
            }
            if (xd_02 instanceof wp_1) {
                return ((rrik_0)((Map)this.class[throws[23]]).get((Object)((be_0)((Object)((Object)be_0.staticFields41d67a8911663c568d38045d1ac26747[throws[24]]))))).class();
            }
            if (xd_02 instanceof ji_1) {
                return ((rrik_0)((Map)this.class[throws[25]]).get((Object)((be_0)((Object)((Object)be_0.staticFields41d67a8911663c568d38045d1ac26747[throws[26]]))))).class();
            }
            if (xd_02 instanceof dv_2) {
                return ((rrik_0)((Map)this.class[throws[27]]).get((Object)((be_0)((Object)((Object)be_0.staticFields41d67a8911663c568d38045d1ac26747[throws[28]]))))).class();
            }
            if (xd_02 instanceof xs) {
                return ((rrik_0)((Map)this.class[throws[29]]).get((Object)((be_0)((Object)((Object)be_0.staticFields41d67a8911663c568d38045d1ac26747[throws[30]]))))).class();
            }
            if (xd_02 instanceof jv_1) {
                return ((rrik_0)((Map)this.class[throws[31]]).get((Object)((be_0)((Object)((Object)be_0.staticFields41d67a8911663c568d38045d1ac26747[throws[32]]))))).class();
            }
            return break[7];
        };
        this.class[bS.throws[3]] = bs_02;
    }

    static {
        bS.ntfClinit();
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0x2524713ED8F40DB8L;
    }

    @Override
    public void class(q q2) {
        this.implements();
        if (q2.class() == (Y)((Object)Y.staticFields22c81230f53b33f2a682b4198db24cc4[throws[9]])) {
            if (((Map)this.class[throws[10]]).isEmpty()) {
                return;
            }
            ps_1 ps_12 = this.byte().throw();
            rYB rYB2 = ps_12.case();
            ((Map)this.class[throws[11]]).entrySet().removeIf(entry -> {
                this.implements();
                rfH rfH2 = (rfH)entry.getKey();
                xd_0 xd_02 = (xd_0)entry.getValue();
                if (rYB2.byte(rfH2).break() == xd_02) {
                    ((Map)this.class[throws[18]]).put(rfH2, xd_02);
                    return break[4];
                }
                if (((Map)this.class[throws[19]]).containsKey(rfH2)) {
                    ((Map)this.class[throws[20]]).remove(rfH2);
                    return break[5];
                }
                return break[6];
            });
        }
    }

    public static String class(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{123, 83, 25, -35, 113, 69, 51, 117}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    @Override
    public void class(rrlu_2 rrlu_22) {
        rus_2<?> rus_22 = rrlu_22.class();
        if (rus_22 instanceof rvc_1) {
            rvc_1 rvc_12 = (rvc_1)rus_22;
            rvc_12.class((rfH rfH2, xc_0 xc_02) -> this.break((rfH)rfH2, (xc_0)xc_02));
        } else if (rus_22 instanceof rZR) {
            rZR rZR2 = (rZR)rus_22;
            this.break(rZR2.byte(), rZR2.break());
        }
    }

    public void class(Map<be_0, rrik_0> map) {
        this.implements();
        ((Map)this.class[throws[14]]).clear();
        ((Map)this.class[throws[15]]).putAll(map);
    }

    @Override
    public void class() {
        this.implements();
        super.class();
        ((Map)this.class[throws[12]]).clear();
        ((Map)this.class[throws[13]]).clear();
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0x4DB7F02;
    }

    @Override
    public void class(t_0 t_02) {
        this.implements();
        if (((Map)this.class[throws[4]]).isEmpty()) {
            return;
        }
        ps_1 ps_12 = this.byte().throw();
        qy_1 qy_12 = ps_12.throws();
        yt_1 yt_12 = ((yx_1)qy_12.class[throws[5]]).static();
        rYB rYB2 = ps_12.case();
        ml_1 ml_12 = t_02.byte();
        float f2 = t_02.break();
        ml_12.class();
        GL11.glEnable((int)throws[6]);
        RenderSystem.defaultBlendFunc();
        RenderSystem.enableBlend();
        RenderSystem.lineWidth(case[0]);
        RenderSystem.disableTexture();
        RenderSystem.disableDepthTest();
        RenderSystem.depthMask(break[0]);
        strictfp.class(break[1], ju_0.this);
        double d = void.case();
        double d2 = void.catch();
        double d3 = void.private();
        for (Map.Entry entry : ((Map)this.class[throws[7]]).entrySet()) {
            rfl rfl2;
            rfH rfH2 = (rfH)entry.getKey();
            xd_0 xd_02 = (xd_0)entry.getValue();
            double d4 = rfH2.b_();
            double d5 = rfH2.c_();
            double d6 = rfH2.d_();
            ryo_2 ryo_22 = rYB2.class(rfH2);
            if (ryo_22 != null) {
                xc_0 xc_02 = ryo_22.abstract();
                rjC rjC2 = rrjc_0.class(ryo_22, rfH2, xc_02, f2);
                if (rjC2 == null) continue;
                rfl2 = rjC2.class().protected(d4, d5, d6);
            } else {
                rfl2 = rrjc_0.class(xd_02.continue(), rfH2).protected(d4, d5, d6);
            }
            if (!yt_12.class(rfl2)) continue;
            rrfD.class(ml_12, rfl2.protected(-d, -d2, -d3), (int)catch[0]);
        }
        default.break();
        RenderSystem.enableTexture();
        RenderSystem.enableDepthTest();
        RenderSystem.depthMask(break[2]);
        RenderSystem.disableBlend();
        GL11.glDisable((int)throws[8]);
        ml_12.break();
    }

    private void break(rfH rfH2, xc_0 xc_02) {
        this.implements();
        if (xc_02.catch()) {
            return;
        }
        xd_0 xd_02 = xc_02.break();
        if (((bs_0)this.class[throws[16]]).test(rfH2, xc_02) && ((Map)this.class[throws[17]]).putIfAbsent(rfH2.int(), xd_02) == null) {
            rVi rVi2 = new rgn_0(protected[0]).class(rgF.GRAY).break(protected[1]).class(new rgn_0(jI.class(protected[2], xd_02.volatile(), new Object[break[3]])).class(rgF.RED)).break(protected[3]);
            this.class(rVi2);
        }
    }

    private static void throws() {
        short[] sArray = new short[33];
        sArray[1] = 1;
        sArray[2] = 2;
        sArray[3] = 3;
        sArray[5] = 8;
        sArray[6] = 2848;
        sArray[8] = 2848;
        sArray[13] = 1;
        sArray[14] = 2;
        sArray[15] = 2;
        sArray[16] = 3;
        sArray[18] = 1;
        sArray[19] = 1;
        sArray[20] = 1;
        sArray[21] = 2;
        sArray[23] = 2;
        sArray[24] = 1;
        sArray[25] = 2;
        sArray[26] = 2;
        sArray[27] = 2;
        sArray[28] = 3;
        sArray[29] = 2;
        sArray[30] = 4;
        sArray[31] = 2;
        sArray[32] = 5;
        throws = sArray;
    }

    private static /* synthetic */ void ntfClinit() {
        bS.private();
        bS.finally();
        bS.throws();
        bS.case();
        bS.catch();
    }

    private static void finally() {
        protected = new String[]{new String(""), new String("\u041d\u0430\u0439\u0434\u0435\u043d \u0431\u043b\u043e\u043a '"), new String("ru_ru"), new String("'")};
    }

    private static void catch() {
        catch = new byte[]{-1, 4};
    }

    private static void case() {
        case = new float[]{1.5f};
    }

    private void implements() {
        if (this.class == null) {
            Object[] objectArray = this.class = new Object[catch[1]];
        }
    }

    private static void private() {
        boolean[] blArray = new boolean[8];
        blArray[1] = true;
        blArray[2] = true;
        blArray[5] = true;
        break = blArray;
    }
}

