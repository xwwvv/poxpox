/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonObject
 */
package protected;

import com.google.gson.JsonObject;
import protected.hc_1;
import protected.hk_1;
import protected.hn_1;
import protected.ho_1;
import protected.hz_1;
import protected.oo_1;
import protected.rhn_2;
import protected.rqo_0;
import protected.rwh_1;
import protected.rye_1;
import protected.rzr_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.Xk
 */
public class xk_2
extends hz_1 {
    private final ho_1 class;
    private final hn_1 break;

    public xk_2(rqo_0 rqo_02, ho_1 ho_12, ho_1 ho_13, hn_1 hn_12) {
        super(rqo_02, ho_12);
        this.class = ho_13;
        this.break = hn_12;
    }

    public static xk_2 class(hk_1 hk_12, hc_1 hc_12) {
        return new xk_2(oo_1.break.class, ho_1.class, ho_1.class(hk_12.break()), hc_12.break());
    }

    public boolean class(rhn_2 rhn_22, rzr_2 rzr_22, rye_1 rye_12) {
        return !this.break.class(rhn_22, rye_12) ? false : this.class.class(rzr_22);
    }

    @Override
    public JsonObject class(rwh_1 rwh_12) {
        JsonObject jsonObject = super.class(rwh_12);
        jsonObject.add("entity", this.class.class(rwh_12));
        jsonObject.add("killing_blow", this.break.class());
        return jsonObject;
    }

    public static xk_2 class(hk_1 hk_12) {
        return new xk_2(oo_1.break.class, ho_1.class, ho_1.class(hk_12.break()), hn_1.class);
    }

    public static xk_2 break() {
        return new xk_2(oo_1.break.class, ho_1.class, ho_1.class, hn_1.class);
    }

    public static xk_2 protected() {
        return new xk_2(oo_1.byte.class, ho_1.class, ho_1.class, hn_1.class);
    }
}

