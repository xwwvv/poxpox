/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.D;
import protected.V;
import protected.bY;
import protected.j;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class bo
implements D {
    private static boolean[] break;
    private static short[] byte;
    public Object[] class;

    private static void byte() {
        break = new boolean[]{true};
    }

    public bo(bY bY2) {
        this.class();
        bY bY3 = bY2;
        this.class[bo.byte[0]] = bY3;
    }

    static {
        bo.ntfClinit();
    }

    private void class() {
        if (this.class == null) {
            Object[] objectArray = this.class = new Object[break[0]];
        }
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0x30EB7433;
    }

    @Override
    public void class(j j2) {
        if (j2.class() == (V)((Object)V.staticFields30e1cd8580ce39faa61be3646b7cc079[byte[1]])) {
            ((bY)this.class[byte[2]]).volatile();
        }
    }

    public static String class(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{-123, 10, -52, -113, 54, -43, 115, -78}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0x4762C6B6893C9DC3L;
    }

    private static void break() {
        byte = new short[3];
    }

    private static /* synthetic */ void ntfClinit() {
        bo.byte();
        bo.break();
    }
}

