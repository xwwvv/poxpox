/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.util.Random;
import protected.aU;
import protected.aa_0;
import protected.ai_0;
import protected.am;
import protected.iO;
import protected.rRf;
import protected.rYB;
import protected.rcd_2;
import protected.rlq_2;
import protected.rme_0;
import protected.rrEm;
import protected.rrh_0;
import protected.rut_2;
import protected.ruw_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.au
 */
public abstract class au_0
extends aa_0 {
    private static final rut_2<Boolean> super = rme_0.class(au_0.class, ruw_2.implements);
    protected int class;
    protected int break;
    protected int protected;

    protected au_0(ai_0<? extends au_0> ai_02, rYB rYB2) {
        super((ai_0<? extends aa_0>)ai_02, rYB2);
    }

    public void class(int n2, boolean bl2) {
        int n3 = this.O_();
        if ((n3 += n2 * 20) > 0) {
            n3 = 0;
        }
        int n4 = n3 - n3;
        this.e_(n3);
        if (bl2) {
            this.break += n4;
            if (this.protected == 0) {
                this.protected = 40;
            }
        }
        if (this.O_() == 0) {
            this.e_(this.break);
        }
    }

    @Override
    public aU class(rRf rRf2, rrh_0 rrh_02, iO iO2, aU aU2, rcd_2 rcd_22) {
        am am2;
        if (aU2 == null) {
            aU2 = new am(true);
        }
        if ((am2 = (am)aU2).byte() && am2.class() > 0 && ((Random)this.throws[40]).nextFloat() <= am2.protected()) {
            this.e_(-24000);
        }
        am2.break();
        return super.class(rRf2, rrh_02, iO2, aU2, rcd_22);
    }

    @Override
    public void class(rcd_2 rcd_22) {
        super.class(rcd_22);
        rcd_22.break("Age", this.O_());
        rcd_22.break("ForcedAge", this.break);
    }

    @Override
    public void class(rut_2<?> rut_22) {
        if (super.equals(rut_22)) {
            this.q_();
        }
        super.class(rut_22);
    }

    @Override
    public void class(boolean bl2) {
        this.e_(bl2 ? -24000 : 0);
    }

    public abstract au_0 class(rrEm var1, au_0 var2);

    @Override
    public void default() {
        super.default();
        if (((rYB)this.throws[7]).continue) {
            if (this.protected > 0) {
                if (this.protected % 4 == 0) {
                    ((rYB)this.throws[7]).class(rlq_2.char, this.break(1.0), this.Ph() + 0.5, this.protected(1.0), 0.0, 0.0, 0.0);
                }
                --this.protected;
            }
        } else if (this.BM()) {
            int n2 = this.O_();
            if (n2 < 0) {
                this.e_(++n2);
            } else if (n2 > 0) {
                this.e_(--n2);
            }
        }
    }

    @Override
    public void break(rcd_2 rcd_22) {
        super.break(rcd_22);
        this.e_(rcd_22.private("Age"));
        this.break = rcd_22.private("ForcedAge");
    }

    public int O_() {
        if (((rYB)this.throws[7]).continue) {
            return ((rme_0)this.throws[49]).class(super) != false ? -1 : 1;
        }
        return this.class;
    }

    protected void P_() {
    }

    public boolean N_() {
        return false;
    }

    @Override
    protected void m_() {
        super.m_();
        ((rme_0)this.throws[49]).class(super, false);
    }

    @Override
    public boolean n_() {
        return this.O_() < 0;
    }

    public void e_(int n2) {
        int n3 = this.class;
        this.class = n2;
        if (n3 < 0 && n2 >= 0 || n3 >= 0 && n2 < 0) {
            ((rme_0)this.throws[49]).break(super, n2 < 0);
            this.P_();
        }
    }

    public void d_(int n2) {
        this.class(n2, false);
    }
}

