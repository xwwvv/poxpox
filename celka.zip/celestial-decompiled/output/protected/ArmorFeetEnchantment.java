/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.eC;
import protected.ef_0;
import protected.ev_0;
import protected.rxq_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.ak
 */
public class ak_0
extends ev_0 {
    public ak_0(ef_0 ef_02, rxq_1 ... rxq_1Array) {
        super(ef_02, eC.ARMOR_FEET, rxq_1Array);
    }

    @Override
    public int class() {
        return 3;
    }

    @Override
    public int class(int n2) {
        return n2 * 10;
    }

    @Override
    public boolean break() {
        return true;
    }

    @Override
    public int break(int n2) {
        return this.class(n2) + 15;
    }

    @Override
    public boolean implements() {
        return false;
    }

    @Override
    public boolean private() {
        return false;
    }
}

