/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import javax.sound.sampled.AudioFormat;
import protected.nh_1;
import protected.nl_1;
import protected.nz_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.NC
 */
public class nc_1
implements nz_2 {
    private final nl_1 class;
    private nz_2 break;
    private final BufferedInputStream byte;

    public nc_1(nl_1 nl_12, InputStream inputStream) throws IOException {
        this.class = nl_12;
        this.byte = new BufferedInputStream(inputStream);
        this.byte.mark(Integer.MAX_VALUE);
        this.break = nl_12.create(new nh_1(this.byte));
    }

    @Override
    public ByteBuffer class(int n2) throws IOException {
        ByteBuffer byteBuffer = this.break.class(n2);
        if (!byteBuffer.hasRemaining()) {
            this.break.close();
            this.byte.reset();
            this.break = this.class.create(new nh_1(this.byte));
            byteBuffer = this.break.class(n2);
        }
        return byteBuffer;
    }

    @Override
    public AudioFormat class() {
        return this.break.class();
    }

    @Override
    public void close() throws IOException {
        this.break.close();
        this.byte.close();
    }
}

