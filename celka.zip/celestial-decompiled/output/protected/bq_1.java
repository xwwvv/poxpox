/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.an;
import protected.bn_1;
import protected.rdn_1;
import protected.rjU;
import protected.rqR;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.BQ
 */
public class bq_1 {
    private static byte[] break;
    private static short[] byte;
    private static long[] protected;
    public Object[] class;

    public an byte() {
        return (an)this.class[byte[5]];
    }

    public bq_1(an an2, rjU rjU2, rdn_1 rdn_12, List<bn_1> list) {
        List<bn_1> list2;
        this.case();
        an an3 = an2;
        this.class[bq_1.byte[0]] = an3;
        rjU rjU3 = rjU2;
        this.class[bq_1.byte[1]] = rjU3;
        rdn_1 rdn_13 = rdn_12;
        this.class[bq_1.byte[2]] = rdn_13;
        this.class[bq_1.byte[3]] = list2 = list;
        Long l2 = rqR.break();
        this.class[bq_1.byte[4]] = l2;
    }

    static {
        bq_1.ntfClinit();
    }

    public static String class(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{-18, -20, 67, 77, 27, 113, -74, 124}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0xA97C014A359A559EL;
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0x3E1F3396;
    }

    public long class() {
        return (Long)this.class[byte[9]];
    }

    public rjU break() {
        return (rjU)this.class[byte[7]];
    }

    public rdn_1 throws() {
        return (rdn_1)this.class[byte[6]];
    }

    private static /* synthetic */ void ntfClinit() {
        bq_1.catch();
        bq_1.implements();
        bq_1.private();
    }

    private static void catch() {
        protected = new long[1];
    }

    private void case() {
        if (this.class == null) {
            Object[] objectArray = this.class = new Object[break[0]];
            objectArray[bq_1.break[1]] = protected[0];
        }
    }

    private static void implements() {
        short[] sArray = new short[10];
        sArray[1] = 2;
        sArray[2] = 1;
        sArray[3] = 3;
        sArray[4] = 4;
        sArray[6] = 1;
        sArray[7] = 2;
        sArray[8] = 3;
        sArray[9] = 4;
        byte = sArray;
    }

    public List<bn_1> protected() {
        return (List)this.class[byte[8]];
    }

    private static void private() {
        break = new byte[]{5, 4};
    }
}

