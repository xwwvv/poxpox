/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.HU;
import protected.ff;
import protected.fo;
import protected.fu_0;
import protected.ral_2;
import protected.rqo_0;
import protected.ud_2;
import protected.uh_2;
import protected.uj_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.uO
 */
public class uo_2
extends ff {
    private final rqo_0 class;
    private final HU break;
    private final HU byte;
    private final boolean protected;
    private final uh_2 throws;

    public uo_2(rqo_0 rqo_02, boolean bl2) {
        this.class = rqo_02;
        this.protected = bl2;
        this.throws = new uh_2(0, 0, 256, 256);
        fo.class(bl2 ? fu_0.RGBA : fu_0.INTENSITY, this.new(), 256, 256);
        this.break = HU.int(rqo_02);
        this.byte = HU.new(rqo_02);
    }

    public ud_2 class(uj_2 uj_22) {
        if (uj_22.protected() != this.protected) {
            return null;
        }
        uh_2 uh_22 = this.throws.class(uj_22);
        if (uh_22 != null) {
            this.super();
            uj_22.class(uh_22.class, uh_22.break);
            float f2 = 256.0f;
            float f3 = 256.0f;
            float f4 = 0.01f;
            return new ud_2(this.break, this.byte, ((float)uh_22.class + 0.01f) / 256.0f, ((float)uh_22.class - 0.01f + (float)uj_22.class()) / 256.0f, ((float)uh_22.break + 0.01f) / 256.0f, ((float)uh_22.break - 0.01f + (float)uj_22.break()) / 256.0f, uj_22.private(), uj_22.implements(), uj_22.finally(), uj_22.extends());
        }
        return null;
    }

    public rqo_0 class() {
        return this.class;
    }

    @Override
    public void close() {
        this.continue();
    }

    @Override
    public void a_(ral_2 ral_22) {
    }
}

