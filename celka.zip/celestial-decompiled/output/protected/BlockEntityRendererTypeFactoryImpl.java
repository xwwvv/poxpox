/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonNull
 *  com.google.gson.JsonObject
 *  com.google.gson.JsonSyntaxException
 */
package protected;

import com.google.gson.JsonElement;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import protected.js_1;
import protected.rfH;
import protected.rlZ;
import protected.rlb;
import protected.rpY;
import protected.rqo_0;
import protected.rrEm;
import protected.rvl_0;
import protected.rxe_2;
import protected.rxs_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.XS
 */
public class xs_2 {
    public static final xs_2 class = new xs_2(null, null, js_1.class);
    private final rlb<rxs_1> break;
    private final rxs_1 byte;
    private final js_1 protected;

    public xs_2(rlb<rxs_1> rlb2, rxs_1 rxs_12, js_1 js_12) {
        this.break = rlb2;
        this.byte = rxs_12;
        this.protected = js_12;
    }

    public boolean class(rrEm rrEm2, rfH rfH2) {
        if (this == xs_2.class) {
            return true;
        }
        if (!rrEm2.synchronized(rfH2)) {
            return false;
        }
        rxe_2 rxe_22 = rrEm2.break(rfH2);
        rxs_1 rxs_12 = rxe_22.class();
        if (this.break != null && !this.break.class(rxs_12)) {
            return false;
        }
        if (this.byte != null && rxs_12 != this.byte) {
            return false;
        }
        return this.protected.class(rxe_22);
    }

    public JsonElement class() {
        if (this == xs_2.class) {
            return JsonNull.INSTANCE;
        }
        JsonObject jsonObject = new JsonObject();
        if (this.byte != null) {
            jsonObject.addProperty("fluid", rvl_0.default.break(this.byte).toString());
        }
        if (this.break != null) {
            jsonObject.addProperty("tag", rlZ.class().byte().break(this.break).toString());
        }
        jsonObject.add("state", this.protected.class());
        return jsonObject;
    }

    public static xs_2 class(JsonElement jsonElement) {
        if (jsonElement != null && !jsonElement.isJsonNull()) {
            Object object;
            rlb<rxs_1> rlb2;
            JsonObject jsonObject = rpY.private(jsonElement, "fluid");
            rxs_1 rxs_12 = null;
            if (jsonObject.has("fluid")) {
                rlb2 = new rqo_0(rpY.case(jsonObject, "fluid"));
                rxs_12 = rvl_0.default.class((rqo_0)((Object)rlb2));
            }
            rlb2 = null;
            if (jsonObject.has("tag")) {
                object = new rqo_0(rpY.case(jsonObject, "tag"));
                rlb2 = rlZ.class().byte().class((rqo_0)object);
                if (rlb2 == null) {
                    throw new JsonSyntaxException("Unknown fluid tag '" + (rqo_0)object + "'");
                }
            }
            object = js_1.class(jsonObject.get("state"));
            return new xs_2(rlb2, rxs_12, (js_1)object);
        }
        return xs_2.class;
    }
}

