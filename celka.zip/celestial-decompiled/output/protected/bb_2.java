/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.ps_1;
import protected.px_2;
import protected.rk_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.BB
 */
public class bb_2
extends rk_1 {
    private static short[] break;

    @Override
    public px_2 byte() {
        return ((ps_1)this.class[break[0]]).protected();
    }

    public bb_2(ps_1 ps_12) {
        super(ps_12);
    }

    static {
        bb_2.protected();
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0xDDCB847ED958112BL;
    }

    public static String break(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{-58, -35, -22, 89, -98, -40, -108, -95}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    private static int break(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0xA8E14C7A;
    }

    private static void protected() {
        break = new short[1];
    }
}

