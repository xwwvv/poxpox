/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.HU;
import protected.Hx;
import protected.cg_2;
import protected.fZ;
import protected.ml_1;
import protected.ok_2;
import protected.qe_0;
import protected.rdn_1;
import protected.rdy_2;
import protected.rfU;
import protected.rhq_2;
import protected.rje;
import protected.rrbb;
import protected.rxq_1;
import protected.tf_1;
import protected.wh_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.Tm
 */
public class tm_2
extends tf_1<cg_2, wh_0<cg_2>> {
    public tm_2(qe_0<cg_2, wh_0<cg_2>> qe_02) {
        super(qe_02);
    }

    @Override
    public void class(ml_1 ml_12, Hx hx, int n2, cg_2 cg_22, float f2, float f3, float f4, float f5, float f6, float f7) {
        rdn_1 rdn_12;
        if (cg_22.super() && !cg_22.Pp() && cg_22.class(rhq_2.CAPE) && cg_22.case() != null && (rdn_12 = cg_22.class(rxq_1.CHEST)).break() != rdy_2.kc) {
            ml_12.class();
            ml_12.class(0.0, 0.0, 0.125);
            double d = rfU.protected((double)f4, (Double)cg_22.implements[10], (Double)cg_22.implements[13]) - rfU.protected((double)f4, (Double)cg_22.throws[8], cg_22.rx());
            double d2 = rfU.protected((double)f4, (Double)cg_22.implements[11], (Double)cg_22.implements[14]) - rfU.protected((double)f4, (Double)cg_22.throws[9], cg_22.re());
            double d3 = rfU.protected((double)f4, (Double)cg_22.implements[12], (Double)cg_22.implements[15]) - rfU.protected((double)f4, (Double)cg_22.throws[10], cg_22.BO());
            float f8 = ((Float)cg_22.private[24]).floatValue() + (((Float)cg_22.private[23]).floatValue() - ((Float)cg_22.private[24]).floatValue()) * f4;
            double d4 = rfU.class(f8 * ((float)Math.PI / 180));
            double d5 = -rfU.break(f8 * ((float)Math.PI / 180));
            float f9 = (float)d2 * 10.0f;
            f9 = rfU.class(f9, -6.0f, 32.0f);
            float f10 = (float)(d * d4 + d3 * d5) * 100.0f;
            f10 = rfU.class(f10, 0.0f, 150.0f);
            float f11 = (float)(d * d5 - d3 * d4) * 100.0f;
            f11 = rfU.class(f11, -20.0f, 20.0f);
            if (f10 < 0.0f) {
                f10 = 0.0f;
            }
            if (f10 > 165.0f) {
                f10 = 165.0f;
            }
            if (f9 < -5.0f) {
                f9 = -5.0f;
            }
            float f12 = rfU.catch(f4, ((Float)cg_22.implements[7]).floatValue(), ((Float)cg_22.implements[8]).floatValue());
            f9 += rfU.class(rfU.catch(f4, ((Float)cg_22.throws[28]).floatValue(), ((Float)cg_22.throws[29]).floatValue()) * 6.0f) * 32.0f * f12;
            if (cg_22.x()) {
                f9 += 25.0f;
            }
            float f13 = rrbb.rV() * 20.0f;
            f13 = rrbb.class(f13, 0.02f, 1.0f);
            Float f14 = Float.valueOf(rfU.catch(f13, ((Float)cg_22.class[11]).floatValue(), 6.0f + f10 / 2.0f + f9));
            cg_22.class[11] = f14;
            Float f15 = Float.valueOf(rfU.catch(f13, ((Float)cg_22.class[13]).floatValue(), f11 / 2.0f));
            cg_22.class[13] = f15;
            Float f16 = Float.valueOf(rfU.catch(f13, ((Float)cg_22.class[12]).floatValue(), 180.0f - f11 / 2.0f));
            cg_22.class[12] = f16;
            ml_12.class(rje.break.byte(((Float)cg_22.class[11]).floatValue()));
            ml_12.class(rje.case.byte(((Float)cg_22.class[13]).floatValue()));
            ml_12.class(rje.protected.byte(((Float)cg_22.class[12]).floatValue()));
            ok_2 ok_22 = hx.getBuffer(HU.break(cg_22.case()));
            ((wh_0)this.byte()).break(ml_12, ok_22, n2, fZ.class);
            ml_12.break();
        }
    }
}

