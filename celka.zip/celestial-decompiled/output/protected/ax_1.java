/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.datafixers.util.Pair
 *  com.viaversion.viaversion.api.protocol.version.ProtocolVersion
 *  it.unimi.dsi.fastutil.objects.Object2ObjectLinkedOpenHashMap
 */
package protected;

import com.mojang.datafixers.util.Pair;
import com.viaversion.viaversion.api.protocol.version.ProtocolVersion;
import it.unimi.dsi.fastutil.objects.Object2ObjectLinkedOpenHashMap;
import protected.VR;
import protected.Y;
import protected.an;
import protected.aq_1;
import protected.break;
import protected.cb_1;
import protected.gm;
import protected.ib_0;
import protected.kw_2;
import protected.np_1;
import protected.qy_1;
import protected.rRg;
import protected.rRl;
import protected.rYB;
import protected.rZb;
import protected.rZq;
import protected.rZs;
import protected.rZx;
import protected.rdh_1;
import protected.rdn_1;
import protected.rdy_2;
import protected.rfH;
import protected.rff;
import protected.rfo;
import protected.rhd_2;
import protected.rhx_1;
import protected.rhz_2;
import protected.rjU;
import protected.rjr_2;
import protected.rkw_2;
import protected.rlp_0;
import protected.rmK;
import protected.rmR;
import protected.rme;
import protected.rmt;
import protected.rod_2;
import protected.rpm;
import protected.rpr_0;
import protected.rql_0;
import protected.rrAC;
import protected.rrAR;
import protected.rrAg;
import protected.rrai_0;
import protected.rrak_0;
import protected.rrff_1;
import protected.rrfj_1;
import protected.rrfp;
import protected.rrfq;
import protected.rrja_0;
import protected.rrjc_0;
import protected.rrle_1;
import protected.rrlp_1;
import protected.rrlq_1;
import protected.rrlt_2;
import protected.rrqx_1;
import protected.rrtr_1;
import protected.rxa_2;
import protected.rxe_2;
import protected.rxm;
import protected.rym_1;
import protected.ryz_1;
import protected.rzd_0;
import protected.rze_0;
import protected.rzm_0;
import protected.rzx_0;
import protected.xK;
import protected.xc_0;
import protected.xd_0;
import protected.zr_2;
import protected.zx_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.Ax
 */
public class ax_1 {
    private final qy_1 catch;
    private final aq_1 private;
    private rfH implements = new rfH(-1, -1, -1);
    private rdn_1 finally = rdn_1.break;
    public float class;
    private float extends;
    private int native;
    private boolean volatile;
    private rRl final = rRl.SURVIVAL;
    private rRl package = rRl.NOT_SET;
    private final Object2ObjectLinkedOpenHashMap<Pair<rfH, rzm_0>, rjU> int = new Object2ObjectLinkedOpenHashMap();
    public int break;
    public long byte;
    public long protected;
    public long throws;
    public long case;

    private void byte(rhd_2 rhd_22, an an2, boolean bl2) {
        this.new();
        if (rrja_0.protected().throws().protected(ProtocolVersion.v1_8)) {
            if (bl2) {
                rhd_22.class(rpm.MAIN_HAND);
            }
            this.private.class(new rZq(an2, rhd_22.h()));
        } else {
            this.private.class(new rZq(an2, rhd_22.h()));
            if (bl2) {
                rhd_22.class(rpm.MAIN_HAND);
            }
        }
        if (this.final != rRl.SPECTATOR) {
            rhd_22.throw(an2);
            rhd_22.sg();
        }
    }

    public float byte() {
        return this.final.throws() ? 5.0f : 4.5f;
    }

    public void byte(rhd_2 rhd_22) {
        this.new();
        this.private.class(new rZb(rzm_0.RELEASE_USE_ITEM, rfH.protected, rpr_0.DOWN));
        rhd_22.SC();
    }

    public void byte(int n2) {
        this.native = n2;
    }

    public void int() {
        if (!((cb_1)this.catch.class[57]).native()) {
            this.new();
            ((aq_1)((cb_1)this.catch.class[57]).break[0]).class(new rZb(rzm_0.SWAP_ITEM_WITH_OFFHAND, rfH.protected, rpr_0.DOWN));
        }
    }

    public ax_1(qy_1 qy_12, aq_1 aq_12) {
        this.catch = qy_12;
        this.private = aq_12;
        rme.class = 0;
    }

    public void class(int n2, rkw_2<?> rkw_22, boolean bl2) {
        this.private.class(new rze_0(n2, rkw_22, bl2));
    }

    public void class(int n2, int n3) {
        this.private.class(new rmK(n2, n3));
    }

    public void class(rdn_1 rdn_12, int n2) {
        if (this.final.throws()) {
            this.private.class(new rmR(n2, rdn_12));
        }
    }

    public void class(rdn_1 rdn_12) {
        if (this.final.throws() && !rdn_12.class()) {
            this.private.class(new rmR(-1, rdn_12));
        }
    }

    public ryz_1 class(rhd_2 rhd_22, an an2, rpm rpm2) {
        this.new();
        if (an2 instanceof ib_0) {
            ib_0 ib_02 = (ib_0)an2;
            if (((rrqx_1)rrqx_1.staticFields09f1f28026cd378cb9df490a64ac8f2a[0]).finally().class(rrle_1.class(ib_02, rpm2)).byte()) {
                return ryz_1.PASS;
            }
        }
        this.private.class(new rZq(an2, rpm2, rhd_22.h()));
        return this.final == rRl.SPECTATOR ? ryz_1.PASS : rhd_22.class(an2, rpm2);
    }

    public ryz_1 class(rhd_2 rhd_22, an an2, rfo rfo2, rpm rpm2) {
        rrtr_1 rrtr_12;
        this.new();
        if (an2 instanceof ib_0) {
            rrtr_12 = (ib_0)an2;
            if (((rrqx_1)rrqx_1.staticFields09f1f28026cd378cb9df490a64ac8f2a[0]).finally().class(rrle_1.class(rrtr_12, rpm2)).byte()) {
                return ryz_1.PASS;
            }
        }
        rrtr_12 = rfo2.case().class(an2.rx(), an2.re(), an2.BO());
        this.private.class(new rZq(an2, rpm2, (rjU)rrtr_12, rhd_22.h()));
        return this.final == rRl.SPECTATOR ? ryz_1.PASS : an2.class(rhd_22, (rjU)rrtr_12, rpm2);
    }

    public void class(int n2, int n3, int n4, rxa_2 rxa_22, boolean bl2) {
        if (rrak_0.break(n2, n3, n4, rxa_22).byte()) {
            return;
        }
        short s2 = ((rjr_2)((cb_1)this.catch.class[57]).implements[4]).class((rhz_2)((cb_1)this.catch.class[57]).implements[1]);
        rdn_1 rdn_12 = ((rjr_2)((cb_1)this.catch.class[57]).implements[4]).class(n3, n4, rxa_22, (cb_1)this.catch.class[57]);
        rdn_1 rdn_13 = bl2 && rxa_22.class() ? new rdn_1(rdy_2.class) : rdn_12;
        this.private.class(new rmt(n2, n3, n4, rxa_22, rdn_13, s2));
        rrAg.break(n2, n3, n4, s2, rxa_22, rdn_12);
    }

    public void class(int n2, int n3, int n4, rxa_2 rxa_22) {
        this.class(n2, n3, n4, rxa_22, new rdn_1(rdy_2.class));
    }

    public void class(gm gm2, rfH rfH2, xc_0 xc_02, rzm_0 rzm_02, boolean bl2) {
        rjU rjU2 = (rjU)this.int.remove((Object)Pair.of((Object)rfH2, (Object)((Object)rzm_02)));
        xc_0 xc_03 = gm2.byte(rfH2);
        if ((rjU2 == null || !bl2 || rzm_02 != rzm_0.START_DESTROY_BLOCK && xc_03 != xc_02) && xc_03 != xc_02) {
            gm2.class(rfH2, xc_02);
            cb_1 cb_12 = (cb_1)this.catch.class[57];
            if (rjU2 != null && gm2 == (rYB)cb_12.throws[7] && cb_12.class(rfH2, xc_02)) {
                cb_12.package(rjU2.break, rjU2.byte, rjU2.protected);
            }
        }
        while (this.int.size() >= 50) {
            this.int.removeFirst();
        }
    }

    public void class(boolean bl2) {
        this.volatile = bl2;
    }

    public void class(rhd_2 rhd_22) {
        this.final.class((rhx_1)rhd_22.implements[18]);
    }

    public void class(int n2, int n3, int n4, rxa_2 rxa_22, rdn_1 rdn_12) {
        short s2 = ((rjr_2)((cb_1)this.catch.class[57]).implements[4]).class((rhz_2)((cb_1)this.catch.class[57]).implements[1]);
        this.private.class(new rmt(n2, n3, n4, rxa_22, rdn_12, s2));
    }

    private void class(rzm_0 rzm_02, rfH rfH2, rpr_0 rpr_02) {
        cb_1 cb_12 = (cb_1)this.catch.class[57];
        this.int.put((Object)Pair.of((Object)rfH2, (Object)((Object)rzm_02)), (Object)cb_12.Ps());
        this.private.class(new rZb(rzm_02, rfH2, rpr_02));
    }

    public void class(int n2) {
        this.private.class(new rZs(n2));
        this.protected = System.currentTimeMillis();
    }

    public void class(rRl rRl2) {
        this.package = rRl2;
    }

    public cb_1 class(gm gm2, rlp_0 rlp_02, VR vR) {
        return this.class(gm2, rlp_02, vR, false, false);
    }

    public ryz_1 class(rpm rpm2) {
        boolean bl2;
        if (this.final == rRl.SPECTATOR) {
            return ryz_1.PASS;
        }
        cb_1 cb_12 = (cb_1)this.catch.class[57];
        this.new();
        rdn_1 rdn_12 = cb_12.protected(rpm2);
        boolean bl3 = cb_12.sK().class(rdn_12.break());
        boolean bl4 = bl2 = (rrfq)((Object)rrfp.class[1]) == (rrfq)((Object)rrfq.staticFields8f8c034c8eef39ccbbc33e665d937d16[2]) && rdn_12.break() == rdy_2.kU;
        if (bl3 && bl2 && rxm.protected(rdn_12)) {
            return ryz_1.PASS;
        }
        if (rrja_0.protected().throws().byte(ProtocolVersion.v1_17_1)) {
            this.private.class(new rzx_0(cb_12.rx(), cb_12.re(), cb_12.BO(), ((Float)cb_12.throws[15]).floatValue(), ((Float)cb_12.throws[16]).floatValue(), cb_12.BL()));
        }
        this.private.class(new rzd_0(rpm2));
        if (bl3 && !bl2) {
            return ryz_1.PASS;
        }
        rym_1<rdn_1> rym_12 = rdn_12.class((rYB)((gm)this.catch.class[56]), (rhd_2)cb_12, rpm2);
        rdn_1 rdn_13 = rym_12.break();
        if (rdn_13 != rdn_12) {
            cb_12.class(rpm2, rdn_13);
        }
        return rym_12.class();
    }

    public ryz_1 class(cb_1 cb_12, gm gm2, rpm rpm2, rff rff2) {
        Object object;
        boolean bl2;
        rfH rfH2 = rff2.class();
        this.new();
        if (!((gm)this.catch.class[56]).instanceof().class(rfH2)) {
            return ryz_1.FAIL;
        }
        rdn_1 rdn_12 = cb_12.protected(rpm2);
        xd_0 xd_02 = rrjc_0.protected(rfH2);
        if (((rrqx_1)rrqx_1.staticFields09f1f28026cd378cb9df490a64ac8f2a[0]).finally().class(rrAR.class(rdn_12, rff2, xd_02, rpm2)).byte()) {
            return ryz_1.PASS;
        }
        if (this.final == rRl.SPECTATOR) {
            this.private.class(new rZx(rpm2, rff2));
            return ryz_1.SUCCESS;
        }
        boolean bl3 = !cb_12.ss().class() || !cb_12.Sn().class();
        boolean bl4 = bl2 = cb_12.sN() && bl3;
        if (!bl2) {
            object = gm2.byte(rfH2).class((rYB)gm2, cb_12, rpm2, rff2);
            if (cb_12.sK().class(rdn_12.break())) {
                return ryz_1.PASS;
            }
            if (object.class()) {
                this.private.class(new rZx(rpm2, rff2));
                return object;
            }
        }
        this.private.class(new rZx(rpm2, rff2));
        if (!rdn_12.class() && !cb_12.sK().class(rdn_12.break())) {
            ryz_1 ryz_12;
            object = new rdh_1(cb_12, rpm2, rff2);
            if (this.final.throws()) {
                int n2 = rdn_12.char();
                ryz_12 = rdn_12.class((rdh_1)object);
                rdn_12.throws(n2);
            } else {
                ryz_12 = rdn_12.class((rdh_1)object);
            }
            ((rrqx_1)rrqx_1.staticFields09f1f28026cd378cb9df490a64ac8f2a[0]).finally().class(rrai_0.class(rdn_12, rfH2, xd_02, ryz_12));
            return ryz_12;
        }
        return ryz_1.PASS;
    }

    public boolean class(rfH rfH2, rpr_0 rpr_02, boolean bl2) {
        rrlp_1 rrlp_12 = rrlp_1.class((rrlq_1)((Object)rrlq_1.staticFields2d4389a28d3a3bcfbac26ede38e74314[0]), rfH2, rpr_02, ((rhz_2)((cb_1)this.catch.class[57]).implements[1]).class.get(((rhz_2)((cb_1)this.catch.class[57]).implements[1]).protected), 5);
        if (rrlp_12.byte()) {
            return false;
        }
        if (((cb_1)this.catch.class[57]).class((gm)this.catch.class[56], rfH2, this.final)) {
            return false;
        }
        if (!((gm)this.catch.class[56]).instanceof().class(rfH2)) {
            return false;
        }
        if (this.final.throws()) {
            this.class(rzm_0.START_DESTROY_BLOCK, rfH2, rpr_02);
            this.class(rfH2, bl2);
            this.native = rrlp_12.break();
        } else if (!this.volatile || !this.class(rfH2)) {
            boolean bl3;
            if (this.volatile) {
                this.class(rzm_0.ABORT_DESTROY_BLOCK, this.implements, rpr_02);
            }
            xc_0 xc_02 = ((gm)this.catch.class[56]).byte(rfH2);
            this.class(rzm_0.START_DESTROY_BLOCK, rfH2, rpr_02);
            boolean bl4 = bl3 = !xc_02.catch();
            if (bl3 && this.class == 0.0f) {
                xc_02.class((rYB)((gm)this.catch.class[56]), rfH2, (cb_1)this.catch.class[57]);
            }
            if (bl3 && xc_02.class((cb_1)this.catch.class[57], (rYB)((cb_1)this.catch.class[57]).throws[7], rfH2) >= 1.0f) {
                this.class(rfH2, bl2);
                rrlp_1.class((rrlq_1)((Object)rrlq_1.staticFields2d4389a28d3a3bcfbac26ede38e74314[2]), rfH2, rpr_02, ((rhz_2)((cb_1)this.catch.class[57]).implements[1]).class.get(((rhz_2)((cb_1)this.catch.class[57]).implements[1]).protected), 5);
            } else {
                this.volatile = true;
                this.implements = rfH2;
                this.finally = ((cb_1)this.catch.class[57]).ss();
                this.class = 0.0f;
                this.extends = 0.0f;
                ((gm)this.catch.class[56]).class(((cb_1)this.catch.class[57]).V(), this.implements, (int)(this.class * 10.0f) - 1);
            }
        }
        return true;
    }

    private boolean class(rfH rfH2) {
        boolean bl2;
        rdn_1 rdn_12 = ((cb_1)this.catch.class[57]).ss();
        boolean bl3 = bl2 = this.finally.class() && rdn_12.class();
        if (!this.finally.class() && !rdn_12.class()) {
            bl2 = rdn_12.break() == this.finally.break() && rdn_1.class(rdn_12, this.finally) && (rdn_12.throws() || rdn_12.catch() == this.finally.catch());
        }
        return rfH2.equals(this.implements) && bl2;
    }

    public boolean class(rfH rfH2, boolean bl2) {
        boolean bl3;
        if (((cb_1)this.catch.class[57]).class((gm)this.catch.class[56], rfH2, this.final)) {
            return false;
        }
        gm gm2 = (gm)this.catch.class[56];
        xc_0 xc_02 = gm2.byte(rfH2);
        if (!((cb_1)this.catch.class[57]).ss().break().class(xc_02, (rYB)gm2, rfH2, (cb_1)this.catch.class[57])) {
            return false;
        }
        xd_0 xd_02 = xc_02.break();
        if ((xd_02 instanceof xK || xd_02 instanceof zx_1 || xd_02 instanceof kw_2) && !((cb_1)this.catch.class[57]).sU()) {
            return false;
        }
        if (xc_02.catch()) {
            return false;
        }
        xd_02.class((rYB)gm2, rfH2, xc_02, (rhd_2)((cb_1)this.catch.class[57]));
        rxe_2 rxe_22 = gm2.break(rfH2);
        boolean bl4 = bl3 = bl2 && ((rYB)gm2).class(rfH2, rxe_22.catch(), 11);
        if (bl3) {
            xd_02.class((rRg)gm2, rfH2, xc_02);
        }
        return false;
    }

    public void class(rhd_2 rhd_22, an an2, boolean bl2) {
        rrfj_1 rrfj_12 = ((rrqx_1)rrqx_1.staticFields09f1f28026cd378cb9df490a64ac8f2a[0]).finally().class(rrfj_1.class(an2));
        ((break)protected.break.staticFieldsf9703d96375232b196815afd59d1eb48[0]).class(rrfj_12);
        if (rrfj_12.byte()) {
            return;
        }
        this.byte(rhd_22, an2, bl2);
        rrff_1 rrff_12 = rrff_1.class(an2);
        ((rrqx_1)rrqx_1.staticFields09f1f28026cd378cb9df490a64ac8f2a[0]).finally().class(rrff_12);
        ((break)protected.break.staticFieldsf9703d96375232b196815afd59d1eb48[0]).class(rrff_12);
    }

    public boolean class() {
        return this.final.case();
    }

    public cb_1 class(gm gm2, rlp_0 rlp_02, VR vR, boolean bl2, boolean bl3) {
        return new cb_1(this.catch, gm2, this.private, rlp_02, vR, bl2, bl3);
    }

    public boolean break(rfH rfH2, rpr_0 rpr_02, boolean bl2) {
        rrlp_1 rrlp_12 = rrlp_1.class((rrlq_1)((Object)rrlq_1.staticFields2d4389a28d3a3bcfbac26ede38e74314[1]), rfH2, rpr_02, ((rhz_2)((cb_1)this.catch.class[57]).implements[1]).class.get(((rhz_2)((cb_1)this.catch.class[57]).implements[1]).protected), 5);
        if (rrlp_12.byte()) {
            return false;
        }
        this.new();
        if (this.native > 0) {
            --this.native;
            return true;
        }
        if (this.final.throws() && ((gm)this.catch.class[56]).instanceof().class(rfH2)) {
            this.native = rrlp_12.break();
            this.class(rzm_0.START_DESTROY_BLOCK, rfH2, rpr_02);
            this.class(rfH2, bl2);
            rrlp_1.class((rrlq_1)((Object)rrlq_1.staticFields2d4389a28d3a3bcfbac26ede38e74314[2]), rfH2, rpr_02, ((rhz_2)((cb_1)this.catch.class[57]).implements[1]).class.get(((rhz_2)((cb_1)this.catch.class[57]).implements[1]).protected), 5);
            return true;
        }
        if (this.class(rfH2)) {
            Object object;
            xc_0 xc_02 = ((gm)this.catch.class[56]).byte(rfH2);
            if (xc_02.catch()) {
                this.volatile = false;
                return false;
            }
            this.class += xc_02.class((cb_1)this.catch.class[57], (rYB)((cb_1)this.catch.class[57]).throws[7], rfH2);
            if (this.extends % 4.0f == 0.0f) {
                object = xc_02.package();
                this.catch.c().class(new np_1(((zr_2)object).case(), rql_0.BLOCKS, (((zr_2)object).class() + 1.0f) / 8.0f, ((zr_2)object).break() * 0.5f, rfH2));
            }
            this.extends += 1.0f;
            object = ((rrqx_1)rrqx_1.staticFields09f1f28026cd378cb9df490a64ac8f2a[0]).finally().class(rrlt_2.class(1.0f));
            if (this.class >= ((rrlt_2)object).class()) {
                rrlp_1.class((rrlq_1)((Object)rrlq_1.staticFields2d4389a28d3a3bcfbac26ede38e74314[2]), rfH2, rpr_02, ((rhz_2)((cb_1)this.catch.class[57]).implements[1]).class.get(((rhz_2)((cb_1)this.catch.class[57]).implements[1]).protected), rrlp_12.break());
                this.volatile = false;
                this.class(rzm_0.STOP_DESTROY_BLOCK, rfH2, rpr_02);
                this.class(rfH2, bl2);
                this.class = 0.0f;
                this.extends = 0.0f;
                this.native = rrlp_12.break();
            }
            ((gm)this.catch.class[56]).class(((cb_1)this.catch.class[57]).V(), this.implements, (int)(this.class * 10.0f) - 1);
            return true;
        }
        return this.class(rfH2, rpr_02, bl2);
    }

    public void break(int n2) {
        this.private.break(new rZs(n2));
    }

    public void break(rhd_2 rhd_22, an an2, boolean bl2) {
        this.byte(rhd_22, an2, bl2);
    }

    public ryz_1 break(cb_1 cb_12, gm gm2, rpm rpm2, rff rff2) {
        Object object;
        boolean bl2;
        rfH rfH2 = rff2.class();
        this.new();
        if (!((gm)this.catch.class[56]).instanceof().class(rfH2)) {
            return ryz_1.FAIL;
        }
        rdn_1 rdn_12 = cb_12.protected(rpm2);
        if (this.final == rRl.SPECTATOR) {
            this.private.class(new rZx(rpm2, rff2));
            return ryz_1.SUCCESS;
        }
        boolean bl3 = !cb_12.ss().class() || !cb_12.Sn().class();
        boolean bl4 = bl2 = cb_12.sN() && bl3;
        if (!bl2) {
            object = gm2.byte(rfH2).class((rYB)gm2, cb_12, rpm2, rff2);
            if (cb_12.sK().class(rdn_12.break())) {
                return ryz_1.PASS;
            }
            if (object.class()) {
                this.private.class(new rZx(rpm2, rff2));
                return object;
            }
        }
        this.private.class(new rZx(rpm2, rff2));
        if (!rdn_12.class() && !cb_12.sK().class(rdn_12.break())) {
            ryz_1 ryz_12;
            object = new rdh_1(cb_12, rpm2, rff2);
            if (this.final.throws()) {
                int n2 = rdn_12.char();
                ryz_12 = rdn_12.class((rdh_1)object);
                rdn_12.throws(n2);
            } else {
                ryz_12 = rdn_12.class((rdh_1)object);
            }
            return ryz_12;
        }
        return ryz_1.PASS;
    }

    public void break(rRl rRl2) {
        if (rRl2 != this.final) {
            this.package = this.final;
        }
        this.final = rRl2;
        this.final.class((rhx_1)((cb_1)this.catch.class[57]).implements[18]);
    }

    public void break(rhd_2 rhd_22) {
        this.new();
        rpm rpm2 = ((cb_1)this.catch.class[57]).P();
        rdn_1 rdn_12 = ((cb_1)this.catch.class[57]).sX();
        if (rhd_22 == (cb_1)this.catch.class[57] && ((rrqx_1)rrqx_1.staticFields09f1f28026cd378cb9df490a64ac8f2a[0]).finally().class(rrAC.class((Y)((Object)Y.staticFields22c81230f53b33f2a682b4198db24cc4[0]), rdn_12, rpm2)).byte()) {
            return;
        }
        this.private.class(new rZb(rzm_0.RELEASE_USE_ITEM, rfH.protected, rpr_0.DOWN));
        rhd_22.SC();
        if (rhd_22 == (cb_1)this.catch.class[57]) {
            ((rrqx_1)rrqx_1.staticFields09f1f28026cd378cb9df490a64ac8f2a[0]).finally().class(rrAC.class((Y)((Object)Y.staticFields22c81230f53b33f2a682b4198db24cc4[1]), rdn_12, rpm2));
        }
    }

    public void break() {
        if (this.volatile) {
            this.class(rzm_0.ABORT_DESTROY_BLOCK, this.implements, rpr_0.DOWN);
            this.class = 0.0f;
            ((gm)this.catch.class[56]).class(((cb_1)this.catch.class[57]).V(), this.implements, -1);
            ((cb_1)this.catch.class[57]).sg();
            this.volatile = false;
        }
    }

    public void break(int n2, int n3, int n4, rxa_2 rxa_22, boolean bl2) {
        short s2 = ((rjr_2)((cb_1)this.catch.class[57]).implements[4]).class((rhz_2)((cb_1)this.catch.class[57]).implements[1]);
        rdn_1 rdn_12 = ((rjr_2)((cb_1)this.catch.class[57]).implements[4]).class(n3, n4, rxa_22, (cb_1)this.catch.class[57]);
        rdn_1 rdn_13 = bl2 && rxa_22.class() ? new rdn_1(rdy_2.class) : rdn_12;
        this.private.class(new rmt(n2, n3, n4, rxa_22, rdn_13, s2));
    }

    public boolean throws() {
        return this.final.case();
    }

    public boolean finally() {
        return this.final == rRl.SPECTATOR;
    }

    public boolean catch() {
        return this.final.throws();
    }

    public rRl extends() {
        return this.package;
    }

    public boolean case() {
        return !this.final.throws();
    }

    public boolean implements() {
        return ((cb_1)this.catch.class[57]).Pm() && ((cb_1)this.catch.class[57]).ra() instanceof rod_2;
    }

    private void new() {
        int n2 = ((rhz_2)((cb_1)this.catch.class[57]).implements[1]).protected;
        if (n2 != this.break && rme.class != n2) {
            this.break = n2;
            this.private.class(new rme(this.break));
            this.protected = System.currentTimeMillis();
        }
    }

    public void package() {
        this.new();
    }

    public void protected() {
        this.new();
        if (this.private.class().case()) {
            this.private.class().class();
        } else {
            this.private.class().native();
        }
    }

    public boolean private() {
        return this.final.throws();
    }

    public rfH final() {
        return this.implements;
    }

    public boolean volatile() {
        return this.volatile;
    }

    public rRl native() {
        return this.final;
    }
}

