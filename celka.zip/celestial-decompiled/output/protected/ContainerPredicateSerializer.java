/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonArray
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonObject
 *  it.unimi.dsi.fastutil.objects.ObjectArrayList
 */
package protected;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import protected.ho_1;
import protected.ht_2;
import protected.hz_1;
import protected.rdn_1;
import protected.rhz_2;
import protected.rpl_0;
import protected.rwh_1;
import protected.xc_1;
import protected.xf_2;
import protected.xg_2;
import protected.xh_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.Xb
 */
public class xb_1
extends hz_1 {
    private final xf_2 class;
    private final xf_2 break;
    private final xf_2 byte;
    private final xh_2[] protected;

    public xb_1(ho_1 ho_12, xf_2 xf_22, xf_2 xf_23, xf_2 xf_24, xh_2[] xh_2Array) {
        super(xg_2.class, ho_12);
        this.class = xf_22;
        this.break = xf_23;
        this.byte = xf_24;
        this.protected = xh_2Array;
    }

    @Override
    public JsonObject class(rwh_1 rwh_12) {
        JsonObject jsonObject;
        JsonObject jsonObject2 = super.class(rwh_12);
        if (!(this.class.byte() && this.break.byte() && this.byte.byte())) {
            jsonObject = new JsonObject();
            jsonObject.add("occupied", this.class.protected());
            jsonObject.add("full", this.break.protected());
            jsonObject.add("empty", this.byte.protected());
            jsonObject2.add("slots", (JsonElement)jsonObject);
        }
        if (this.protected.length > 0) {
            jsonObject = new JsonArray();
            for (xh_2 xh_22 : this.protected) {
                jsonObject.add(xh_22.class());
            }
            jsonObject2.add("items", (JsonElement)jsonObject);
        }
        return jsonObject2;
    }

    public boolean class(rhz_2 rhz_22, rdn_1 rdn_12, int n2, int n3, int n4) {
        if (!this.break.byte(n2)) {
            return false;
        }
        if (!this.byte.byte(n3)) {
            return false;
        }
        if (!this.class.byte(n4)) {
            return false;
        }
        int n5 = this.protected.length;
        if (n5 == 0) {
            return true;
        }
        if (n5 != 1) {
            ObjectArrayList objectArrayList = new ObjectArrayList((Object[])this.protected);
            int n6 = rhz_22.else();
            for (int k = 0; k < n6; ++k) {
                if (objectArrayList.isEmpty()) {
                    return true;
                }
                rdn_1 rdn_13 = rhz_22.extends(k);
                if (rdn_13.class()) continue;
                objectArrayList.removeIf(xh_22 -> xh_22.class(rdn_13));
            }
            return objectArrayList.isEmpty();
        }
        return !rdn_12.class() && this.protected[0].class(rdn_12);
    }

    public static xb_1 class(rpl_0 ... rpl_0Array) {
        xh_2[] xh_2Array = new xh_2[rpl_0Array.length];
        for (int k = 0; k < rpl_0Array.length; ++k) {
            xh_2Array[k] = new xh_2(null, rpl_0Array[k].case(), xf_2.throws, xf_2.throws, ht_2.break, ht_2.break, null, xc_1.class);
        }
        return xb_1.class(xh_2Array);
    }

    public static xb_1 class(xh_2 ... xh_2Array) {
        return new xb_1(ho_1.class, xf_2.throws, xf_2.throws, xf_2.throws, xh_2Array);
    }
}

