/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.rjU;

/*
 * Renamed from protected.WP
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class wp_2 {
    public final rjU class;
    public final rjU break;
    public final float byte;
    public final float protected;

    public wp_2(rjU rjU2, rjU rjU3, float f2, float f3) {
        this.class = rjU2;
        this.break = rjU3;
        this.byte = f2;
        this.protected = f3;
    }
}

