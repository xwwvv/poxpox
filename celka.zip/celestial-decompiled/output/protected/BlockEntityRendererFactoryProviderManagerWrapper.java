/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.primitives.Doubles
 */
package protected;

import com.google.common.primitives.Doubles;
import java.util.Collections;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.atomic.AtomicBoolean;
import protected.gm;
import protected.hv_0;
import protected.qy_1;
import protected.rfH;
import protected.rfj;
import protected.rrGp;
import protected.rrGq;
import protected.rrgy_0;
import protected.ym_2;
import protected.yq_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.yN
 */
abstract class yn_2
implements Comparable<yn_2> {
    protected final double class;
    protected final AtomicBoolean break = new AtomicBoolean(false);
    protected Map<rfH, rrGq> byte;

    public yn_2(yq_2 yq_22, rfj rfj2, double d) {
        this.class = d;
        this.byte = rfj2 == null ? Collections.emptyMap() : rrgy_0.class((gm)qy_1.instanceof().class[56], rfj2);
    }

    @Override
    public /* synthetic */ int compareTo(Object object) {
        return this.class((yn_2)object);
    }

    public int class(yn_2 yn_22) {
        return Doubles.compare((double)this.class, (double)yn_22.class);
    }

    public rrGq class(rfH rfH2) {
        return this.byte.getOrDefault(rfH2, rrGp.class);
    }

    public abstract CompletableFuture<ym_2> class(hv_0 var1);

    public abstract void class();
}

