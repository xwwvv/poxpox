/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  it.unimi.dsi.fastutil.longs.Long2DoubleOpenHashMap
 */
package protected;

import it.unimi.dsi.fastutil.longs.Long2DoubleOpenHashMap;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.a;
import protected.be;
import protected.ez_1;
import protected.pp_2;
import protected.ps_1;
import protected.ru_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class bi {
    private static short[] break;
    private static double[] byte;
    private static boolean[] protected;
    public Object[] class;

    private static void byte() {
        byte = new double[]{1.0, 1.0};
    }

    public bi(ps_1 ps_12, a a2, ez_1 ez_12) {
        this(a2, ez_12);
        for (be be2 : be.class(ps_12)) {
            be2.class((Long2DoubleOpenHashMap)this.class[break[0]]);
        }
        pp_2.a_.byte("Favoring size: " + ((Long2DoubleOpenHashMap)this.class[break[1]]).size());
    }

    public bi(a a2, ez_1 ez_12) {
        this.protected();
        Long2DoubleOpenHashMap long2DoubleOpenHashMap = new Long2DoubleOpenHashMap();
        this.class[bi.break[2]] = long2DoubleOpenHashMap;
        ((Long2DoubleOpenHashMap)this.class[break[3]]).defaultReturnValue(byte[0]);
        double d = (Double)ez_12.break[break[4]];
        if (d != byte[1] && a2 != null) {
            a2.break().forEach(ru_12 -> ((Long2DoubleOpenHashMap)this.class[break[7]]).put(ru_1.class(ru_12), d));
        }
    }

    static {
        bi.ntfClinit();
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0x4F2E7156;
    }

    public static String class(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{32, 22, -103, 62, 106, 124, -105, 91}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    public double class(long l2) {
        return ((Long2DoubleOpenHashMap)this.class[break[6]]).get(l2);
    }

    public boolean class() {
        return ((Long2DoubleOpenHashMap)this.class[break[5]]).isEmpty();
    }

    private static void break() {
        short[] sArray = new short[8];
        sArray[4] = 25;
        break = sArray;
    }

    private static long break(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0x8E7962178F97496L;
    }

    private static void throws() {
        protected = new boolean[]{true};
    }

    private static /* synthetic */ void ntfClinit() {
        bi.throws();
        bi.break();
        bi.byte();
    }

    private void protected() {
        if (this.class == null) {
            Object[] objectArray = this.class = new Object[protected[0]];
        }
    }
}

