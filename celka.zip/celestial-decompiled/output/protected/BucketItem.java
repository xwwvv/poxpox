/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.util.List;
import protected.VD;
import protected.ai_0;
import protected.an;
import protected.iO;
import protected.rRg;
import protected.rYB;
import protected.rcd_2;
import protected.rdn_1;
import protected.rdo_2;
import protected.rfH;
import protected.rgF;
import protected.rgP;
import protected.rgn;
import protected.rhd_2;
import protected.rog_2;
import protected.rop_2;
import protected.rql_0;
import protected.rqn;
import protected.rrEm;
import protected.rxn_0;
import protected.rxs_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class rxR
extends rxn_0 {
    private final ai_0<?> class;

    public rxR(ai_0<?> ai_02, rxs_1 rxs_12, rdo_2 rdo_22) {
        super(rxs_12, rdo_22);
        this.class = ai_02;
    }

    @Override
    public void class(rdn_1 rdn_12, rYB rYB2, List<rgP> list, VD vD) {
        rcd_2 rcd_22;
        if (this.class == ai_0.Y && (rcd_22 = rdn_12.package()) != null && rcd_22.byte("BucketVariantTag", 3)) {
            int n2 = rcd_22.private("BucketVariantTag");
            rgF[] rgFArray = new rgF[]{rgF.ITALIC, rgF.GRAY};
            String string = "color.minecraft." + rog_2.this(n2);
            String string2 = "color.minecraft." + rog_2.else(n2);
            for (int k = 0; k < rog_2.class.length; ++k) {
                if (n2 != rog_2.class[k]) continue;
                list.add(new rgn(rog_2.break(k)).class(rgFArray));
                return;
            }
            list.add(new rgn(rog_2.synchronized(n2)).class(rgFArray));
            rgn rgn2 = new rgn(string);
            if (!string.equals(string2)) {
                rgn2.break(", ").class(new rgn(string2));
            }
            rgn2.class(rgFArray);
            list.add(rgn2);
        }
    }

    private void class(rrEm rrEm2, rdn_1 rdn_12, rfH rfH2) {
        an an2 = this.class.class(rrEm2, rdn_12, null, rfH2, iO.BUCKET, true, false);
        if (an2 != null) {
            ((rop_2)an2).this(true);
        }
    }

    @Override
    protected void class(rhd_2 rhd_22, rRg rRg2, rfH rfH2) {
        rRg2.class(rhd_22, rfH2, rqn.rW, rql_0.NEUTRAL, 1.0f, 1.0f);
    }

    @Override
    public void class(rYB rYB2, rdn_1 rdn_12, rfH rfH2) {
        if (rYB2 instanceof rrEm) {
            this.class((rrEm)rYB2, rdn_12, rfH2);
        }
    }
}

