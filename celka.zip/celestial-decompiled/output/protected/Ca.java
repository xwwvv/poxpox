/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.CH;
import protected.Ce;
import protected.ch_0;
import protected.cx_0;
import protected.gm;
import protected.rlo_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class Ca
implements cx_0<rlo_2> {
    private final ch_0 class;

    public Ca(ch_0 ch_02) {
        this.class = ch_02;
    }

    @Override
    public CH class(rlo_2 rlo_22, gm gm2, double d, double d2, double d3, double d4, double d5, double d6) {
        Ce ce = new Ce(gm2, d, d2, d3, d4, d5, d6, this.class);
        ce.throws(1.0f);
        return ce;
    }
}

