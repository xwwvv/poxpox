/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.ll_2;
import protected.lp_1;
import protected.qf_2;
import protected.rgP;
import protected.vj_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
class Vx
extends lp_1 {
    final /* synthetic */ vj_0 class;

    Vx(vj_0 vj_02, int n2, int n3, int n4, int n5, qf_2 qf_22, rgP rgP2, ll_2 ll_22) {
        this.class = vj_02;
        super(n2, n3, n4, n5, qf_22, rgP2, ll_22);
    }

    @Override
    public float public() {
        return this.class.protected();
    }
}

