/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.net.Authenticator;
import java.net.PasswordAuthentication;

/*
 * Renamed from protected.AS
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class as_2
extends Authenticator {
    final /* synthetic */ String class;
    final /* synthetic */ String break;

    public as_2(String string, String string2) {
        this.class = string;
        this.break = string2;
    }

    @Override
    protected PasswordAuthentication getPasswordAuthentication() {
        return new PasswordAuthentication(this.class, this.break.toCharArray());
    }
}

