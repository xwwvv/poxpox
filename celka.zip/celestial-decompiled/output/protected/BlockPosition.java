/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.rfH;

/*
 * Renamed from protected.WN
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class wn_2 {
    final rfH class;
    final long break;

    public wn_2(rfH rfH2, long l2) {
        this.class = rfH2;
        this.break = l2;
    }
}

