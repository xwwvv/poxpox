/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.io.DataOutput;
import java.io.IOException;
import protected.rcc_2;
import protected.rcv_2;
import protected.rcz_1;
import protected.rgP;
import protected.rgn_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.rcN
 */
public class rcn_2
implements rcz_1 {
    public static final rcv_2<rcn_2> class = new rcc_2();
    public static final rcn_2 break = new rcn_2();

    @Override
    public /* synthetic */ rcz_1 byte() {
        return this.protected();
    }

    private rcn_2() {
    }

    @Override
    public String toString() {
        return "END";
    }

    @Override
    public void class(DataOutput dataOutput) throws IOException {
    }

    @Override
    public rgP class(String string, int n2) {
        return rgn_0.byte;
    }

    @Override
    public byte class() {
        return 0;
    }

    public rcv_2<rcn_2> break() {
        return rcn_2.class;
    }

    public rcn_2 protected() {
        return this;
    }
}

