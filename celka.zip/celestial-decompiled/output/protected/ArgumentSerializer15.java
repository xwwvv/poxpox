/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.rcr_0;
import protected.rff_1;
import protected.rfw_1;
import protected.roS;
import protected.roe_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.rCP
 */
class rcp_0
implements roS {
    final /* synthetic */ rcr_0 class;

    @Override
    public void byte(roe_0 roe_02, double d) {
    }

    rcp_0(rcr_0 rcr_02) {
        this.class = rcr_02;
    }

    @Override
    public void class(roe_0 roe_02, int n2) {
        this.class.class(new rfw_1(roe_02, rff_1.SET_WARNING_TIME));
    }

    @Override
    public void class(roe_0 roe_02, double d) {
        this.class.class(new rfw_1(roe_02, rff_1.SET_SIZE));
    }

    @Override
    public void class(roe_0 roe_02, double d, double d2) {
        this.class.class(new rfw_1(roe_02, rff_1.SET_CENTER));
    }

    @Override
    public void class(roe_0 roe_02, double d, double d2, long l2) {
        this.class.class(new rfw_1(roe_02, rff_1.LERP_SIZE));
    }

    @Override
    public void break(roe_0 roe_02, int n2) {
        this.class.class(new rfw_1(roe_02, rff_1.SET_WARNING_BLOCKS));
    }

    @Override
    public void break(roe_0 roe_02, double d) {
    }
}

