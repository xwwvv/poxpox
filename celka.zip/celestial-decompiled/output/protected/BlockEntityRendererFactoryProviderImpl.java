/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonObject
 */
package protected;

import com.google.gson.JsonObject;
import protected.ho_1;
import protected.hz_1;
import protected.rdn_1;
import protected.rwh_1;
import protected.rzr_2;
import protected.xh_2;
import protected.xq_1;
import protected.xx_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.XT
 */
public class xt_2
extends hz_1 {
    private final xh_2 class;
    private final ho_1 break;

    public xt_2(ho_1 ho_12, xh_2 xh_22, ho_1 ho_13) {
        super(xq_1.class, ho_12);
        this.class = xh_22;
        this.break = ho_13;
    }

    @Override
    public JsonObject class(rwh_1 rwh_12) {
        JsonObject jsonObject = super.class(rwh_12);
        jsonObject.add("item", this.class.class());
        jsonObject.add("entity", this.break.class(rwh_12));
        return jsonObject;
    }

    public boolean class(rdn_1 rdn_12, rzr_2 rzr_22) {
        return !this.class.class(rdn_12) ? false : this.break.class(rzr_22);
    }

    public static xt_2 class(ho_1 ho_12, xx_2 xx_22, ho_1 ho_13) {
        return new xt_2(ho_12, xx_22.break(), ho_13);
    }
}

