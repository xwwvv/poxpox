# Obfuscated Class Name Analysis Results

## Summary
Analysis of decompiled Java files starting with 'r' that still have obfuscated names.
Focus on identifying original Minecraft/Brigadier class names from string constants,
references, method signatures, and inheritance patterns.

---

## HIGH CONFIDENCE IDENTIFICATIONS

### 1. RB.java → `BuiltInExceptions`
- **Evidence**: Implements `BuiltInExceptionProvider` interface. Contains all standard Brigadier exception types: `argument.double.low`, `argument.float.big`, `argument.integer.low`, `argument.long.big`, `parsing.quote.expected.start`, `command.unknown.command`, etc.
- **Confidence**: HIGH
- **Reasoning**: This is the standard Brigadier built-in exception provider class.

### 2. RC.java → `EntityArgument`
- **Evidence**: Parses entity selectors `@p`, `@a`, `@r`, `@s`, `@e`. Has fields for sorting (nearest/furthest/random), limiting, filtering by distance/angle/type. Returns `Rn` (EntitySelector). Error messages: `argument.entity.selector.unknown`, `argument.entity.selector.not_allowed`, `argument.entity.selector.missing`.
- **Confidence**: HIGH
- **Reasoning**: This is the standard Minecraft entity selector argument parser.

### 3. Rn.java → `EntitySelector`
- **Evidence**: Has fields for limit, sorting type, position offset function, bounding box, entity filter predicate. Methods: `break(gy_0)` returns list of entities, `protected(gy_0)` returns list of players. Uses `rrEm` (EntityIterable) and `rgv` (EntitySorter).
- **Confidence**: HIGH
- **Reasoning**: This is the parsed entity selector result class.

### 4. Rg.java → `RangeArgument` (FloatRange)
- **Evidence**: Implements `Rj<xf_2>`. Parses range values: "0..5", "0", "-5", "-100..", "..100". Returns `xf_2` (likely FloatRange).
- **Confidence**: HIGH
- **Reasoning**: Standard range argument parser for numeric values.

### 5. RV.java → `DoubleRangeArgument`
- **Evidence**: Implements `Rj<xm_1>`. Parses double ranges: "0..5.2", "0", "-5.4", "-100.76..", "..100". Returns `xm_1` (likely DoubleRange).
- **Confidence**: HIGH
- **Reasoning**: Standard double range argument parser.

### 6. RH.java → `FunctionArgument`
- **Evidence**: Implements `ArgumentType<Rq>`. Parses function references: "foo", "foo:bar", "#foo". Error messages: `arguments.function.tag.unknown`, `arguments.function.unknown`. Uses `rqo_0` (ResourceLocation) and `gt` (Function).
- **Confidence**: HIGH
- **Reasoning**: Standard Minecraft function argument parser.

### 7. RK.java → `ItemPredicateArgument`
- **Evidence**: Implements `ArgumentType<RD>`. Parses item references: "stick", "minecraft:stick", "#stick", "#stick{foo=bar}". Error message: `arguments.item.tag.unknown`. Uses `Ro` (ItemStackParser) and `rlb<rdb_1>` (TagCollection).
- **Confidence**: HIGH
- **Reasoning**: Standard item predicate argument parser.

### 8. Rl.java → `EntitySummonArgument` (EntityTypeArgument)
- **Evidence**: Implements `ArgumentType<rqo_0>`. Parses entity type references: "minecraft:pig", "cow". Error message: `entity.notFound`. Uses `rvl_0` (EntityType) and `ai_0` (EntityCategory).
- **Confidence**: HIGH
- **Reasoning**: Standard entity type argument parser.

### 9. Rm.java → `EntityAnchorArgument` (AnchorType)
- **Evidence**: Enum with values `FEET` and `EYES`. Has offset functions for position calculation. Method `class(gy_0)` returns position based on anchor type. Uses `rjU` (Vec3) and `an` (Entity).
- **Confidence**: HIGH
- **Reasoning**: Standard entity anchor argument (feet/eyes positioning).

### 10. RS.java → `AngleArgument`
- **Evidence**: Implements `ArgumentType<rs_0>`. Parses angle values: "0", "~", "~-5". Error message: `argument.angle.incomplete`. Returns `rs_0` (Angle).
- **Confidence**: HIGH
- **Reasoning**: Standard angle argument parser.

### 11. RT.java → `GameProfileArgument`
- **Evidence**: Implements `ArgumentType<rt_0>`. Parses player references: "Player", "0123", "dd12be42-52a9-4a91-a8a1-11c01849e498", "@e". Error message: `argument.player.unknown`. Uses `GameProfile` from authlib.
- **Confidence**: HIGH
- **Reasoning**: Standard game profile/player argument parser.

### 12. Rj.java → `RangeArgumentType` (interface)
- **Evidence**: Interface extending `ArgumentType<T>`. Has static factory methods for `Rg` (float range) and `RV` (double range).
- **Confidence**: HIGH
- **Reasoning**: Base interface for range-based argument types.

### 13. Rf.java → `Coordinates` (interface)
- **Evidence**: Interface with methods: `class(gy_0)` returns `rjU` (Vec3), `break(gy_0)` returns `rjK` (Rotation). Has `byte()` and `class()` boolean methods.
- **Confidence**: HIGH
- **Reasoning**: Interface for coordinate-based argument types.

### 14. Ra.java → `Vec3Argument`
- **Evidence**: Implements `Rf`. Has three double fields. Parses three doubles from StringReader. `class(gy_0)` does coordinate transformation using rotation matrices. Uses `rjU` (Vec3) and `rjK` (Rotation).
- **Confidence**: HIGH
- **Reasoning**: Standard Vec3 coordinate argument parser.

### 15. Ri.java → `Vec2Argument`
- **Evidence**: Implements `Rf`. Has three `yr_0` fields (optional doubles). Parses three values with optional flags. `class(gy_0)` returns `rjU` (Vec3). `break(gy_0)` returns `rjK` (Rotation).
- **Confidence**: HIGH
- **Reasoning**: Standard Vec2 coordinate argument parser (with optional z).

### 16. RD.java → `EntityArgument.IParser` (interface)
- **Evidence**: Interface with single method `create(CommandContext<gy_0>)` returning `Predicate<rdn_1>`.
- **Confidence**: HIGH
- **Reasoning**: Parser interface for entity-based predicates.

### 17. Rq.java → `FunctionInput` (interface)
- **Evidence**: Interface with methods: `class(CommandContext)` returns `Collection<gt>` (functions), `break(CommandContext)` returns `Pair<rqo_0, Either<gt, rlb<gt>>>`.
- **Confidence**: HIGH
- **Reasoning**: Interface for function input (single function or tag).

### 18. Rw.java → `EntitySelectorPlayer`
- **Evidence**: Implements `rt_0`. Wraps `Rn` (EntitySelector). Method `getNames(gy_0)` returns `Collection<GameProfile>`. Uses `rhn_2` (PlayerEntity).
- **Confidence**: HIGH
- **Reasoning**: Wrapper for entity selector that returns player profiles.

### 19. Ro.java → `ItemStackParser`
- **Evidence**: Parses item stack or item tag references. Has fields for item (`rdb_1`), NBT data (`rcd_2`), tag (`rqo_0`). Methods for parsing item IDs and tags.
- **Confidence**: HIGH
- **Reasoning**: Parser for item stack arguments.

### 20. Re.java → `EntityTagPredicate`
- **Evidence**: Implements `Predicate<rdn_1>`. Takes `rlb<rdb_1>` (TagCollection) and `rcd_2` (NBT). Tests if entity matches tag and NBT.
- **Confidence**: HIGH
- **Reasoning**: Predicate for entity tag matching.

### 21. RU.java → `EntityItemPredicate`
- **Evidence**: Implements `Predicate<rdn_1>`. Takes `rdb_1` (Item) and `rcd_2` (NBT). Tests if entity matches item and NBT.
- **Confidence**: HIGH
- **Reasoning**: Predicate for entity item matching.

---

## MEDIUM CONFIDENCE IDENTIFICATIONS

### 22. R.java → `StringDecryptor` / `EncryptionUtil`
- **Evidence**: Uses DES/CBC/PKCS5Padding encryption. Has `break(String)` method that decrypts strings. Implements interface `o`.
- **Confidence**: MEDIUM
- **Reasoning**: Likely a string decryption utility for obfuscated strings. Not a vanilla Minecraft class but a mod utility.

### 23. RP.java → `CodecRegistry` / `SerializationRegistry`
- **Evidence**: Generic class with serialization/deserialization. Has map of type serializers (`gK<C, ?>`). Methods for serializing/deserializing objects.
- **Confidence**: MEDIUM
- **Reasoning**: Likely a codec registry for custom serialization framework.

### 24. Rr.java → `TimerCallback` / `ScheduledTask`
- **Evidence**: Data class with `long` (time), `UnsignedLong` (id), `String` (name), `go<T>` (callback).
- **Confidence**: MEDIUM
- **Reasoning**: Likely a timer callback or scheduled task data holder.

---

## FILES WITH INSUFFICIENT EVIDENCE

The following files are too obfuscated or lack sufficient identifying information:

- `rrAa.java` through `rrAZ.java` - Inner classes or anonymous classes
- `rrAb.java` through `rrAZ.java` - Inner classes or anonymous classes
- `rCa.java`, `rCb.java`, `rCe.java` - Not found (case sensitivity issue)
- `rbC.java`, `rbD.java`, `rbH.java`, `rbK.java`, `rbR.java`, `rbU.java`, `rbV.java`, `rbX.java` - Not found (case sensitivity issue)

---

## KEY OBFUSCATED TYPE MAPPINGS (Inferred)

| Obfuscated | Likely Original | Evidence |
|------------|-----------------|----------|
| `rjU` | `Vec3` | 3D vector with break/byte/protected fields |
| `rjK` | `Rotation` | Rotation with protected/byte fields |
| `rqo_0` | `ResourceLocation` | Used for item/entity/function IDs |
| `rcd_2` | `CompoundNBT` | NBT data compound |
| `rdb_1` | `Item` | Item type reference |
| `rlb<T>` | `TagCollection<T>` | Tag collection |
| `rrEm` | `EntityIterable` | Entity iteration |
| `rgv` | `EntitySorter` | Entity sorting |
| `rhn_2` | `PlayerEntity` | Player entity |
| `rt_0` | `EntityArgumentResult` | Entity argument result |
| `rs_0` | `Angle` | Angle value |
| `xf_2` | `FloatRange` | Float range |
| `xm_1` | `DoubleRange` | Double range |
| `gy_0` | `CommandSource` | Command source |
| `an` | `Entity` | Base entity class |
| `ai_0` | `EntityCategory` | Entity category |
| `rvl_0` | `EntityType` | Entity type |
| `gt` | `Function` | Minecraft function |
| `go<T>` | `TimerCallback<T>` | Timer callback |
| `gK<C, T>` | `TypeSerializer<C, T>` | Type serializer |
| `rgn` | `TextComponent` | Text component |
| `rfl` | `BoundingBox` | Bounding box |
| `rVi` | `EntityList` | Entity list |

---

## SUMMARY

**Total files analyzed**: 24 obfuscated files
**High confidence identifications**: 21
**Medium confidence identifications**: 3
**Insufficient evidence**: Many `rr*` inner classes

The majority of identifiable classes are **Brigadier command argument types** and **entity-related classes** from Minecraft's command system. This is consistent with the `protected` package containing command-related utilities.
