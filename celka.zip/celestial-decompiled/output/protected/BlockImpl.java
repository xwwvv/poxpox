/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableMap
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.MapCodec
 */
package protected;

import com.google.common.collect.ImmutableMap;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import java.util.concurrent.atomic.AtomicInteger;
import protected.jc_1;
import protected.rCZ;
import protected.rRq;
import protected.rfH;
import protected.rqo_0;
import protected.rrGf;
import protected.rrbb;
import protected.rrwp_2;
import protected.rvl_0;
import protected.xd_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.xc
 */
public class xc_0
extends jc_1
implements rrGf {
    public static final Codec<xc_0> break = xc_0.class(rvl_0.strictfp, xd_0::continue).stable();
    private int throws = -1;
    private int case = -1;
    private rqo_0 catch;
    private int private = -1;
    private static final AtomicInteger implements = new AtomicInteger(0);

    @Override
    protected xc_0 int() {
        return this;
    }

    public xc_0(xd_0 xd_02, ImmutableMap<rCZ<?>, Comparable<?>> immutableMap, MapCodec<xc_0> mapCodec) {
        super(xd_02, immutableMap, mapCodec);
    }

    public rqo_0 this() {
        if (this.catch == null) {
            this.catch = rvl_0.strictfp.break(this.break());
        }
        return this.catch;
    }

    public int continue() {
        if (this.throws < 0) {
            this.throws = rvl_0.strictfp.class(this.break());
        }
        return this.throws;
    }

    public int continue(rRq rRq2, rfH rfH2) {
        return this.case();
    }

    public int else() {
        if (this.private < 0) {
            this.private = implements.incrementAndGet();
        }
        return this.private;
    }

    public boolean return() {
        return this.class != null && this.class.protected;
    }

    public int super() {
        if (this.case < 0) {
            this.case = rrwp_2.class(this);
            if (this.case < 0) {
                rrbb.protected("Metadata not found, block: " + this.this());
                this.case = 0;
            }
        }
        return this.case;
    }

    public boolean synchronized() {
        return this.class != null && this.class.class;
    }
}

