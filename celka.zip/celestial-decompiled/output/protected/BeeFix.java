/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.util.Objects;
import java.util.function.Consumer;
import protected.rwr_1;
import protected.rzr_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.rWV
 */
@FunctionalInterface
interface rwv_1 {
    public static final rwv_1 class = (rzr_22, consumer) -> false;
    public static final rwv_1 break = (rzr_22, consumer) -> true;

    public boolean expand(rzr_2 var1, Consumer<rwr_1> var2);

    default public rwv_1 class(rwv_1 rwv_12) {
        Objects.requireNonNull(rwv_12);
        return (rzr_22, consumer) -> this.expand(rzr_22, consumer) && rwv_12.expand(rzr_22, consumer);
    }

    default public rwv_1 break(rwv_1 rwv_12) {
        Objects.requireNonNull(rwv_12);
        return (rzr_22, consumer) -> this.expand(rzr_22, consumer) || rwv_12.expand(rzr_22, consumer);
    }
}

