/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.datafixers.DataFixer
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
package protected;

import com.mojang.datafixers.DataFixer;
import java.io.File;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import protected.rcd_2;
import protected.rco_1;
import protected.rcw_2;
import protected.rqu_0;
import protected.rtv_2;
import protected.vq_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.Vk
 */
public class vk_0 {
    private static final Logger class = LogManager.getLogger();
    private final File break;
    private final DataFixer byte;
    private final vq_0[] protected = new vq_0[9];
    private boolean throws;

    public vk_0(File file, DataFixer dataFixer) {
        this.break = new File(file, "hotbar.nbt");
        this.byte = dataFixer;
        for (int k = 0; k < 9; ++k) {
            this.protected[k] = new vq_0();
        }
    }

    public vq_0 class(int n2) {
        if (!this.throws) {
            this.break();
            this.throws = true;
        }
        return this.protected[n2];
    }

    public void class() {
        try {
            rcd_2 rcd_22 = new rcd_2();
            rcd_22.break("DataVersion", rqu_0.class().getWorldVersion());
            for (int k = 0; k < 9; ++k) {
                rcd_22.class(String.valueOf(k), this.class(k).class());
            }
            rcw_2.break(rcd_22, this.break);
        }
        catch (Exception exception) {
            vk_0.class.error("Failed to save creative mode options", (Throwable)exception);
        }
    }

    private void break() {
        try {
            rcd_2 rcd_22 = rcw_2.break(this.break);
            if (rcd_22 == null) {
                return;
            }
            if (!rcd_22.byte("DataVersion", 99)) {
                rcd_22.break("DataVersion", 1343);
            }
            rcd_22 = rco_1.class(this.byte, rtv_2.HOTBAR, rcd_22, rcd_22.private("DataVersion"));
            for (int k = 0; k < 9; ++k) {
                this.protected[k].class(rcd_22.protected(String.valueOf(k), 10));
            }
        }
        catch (Exception exception) {
            vk_0.class.error("Failed to load creative mode options", (Throwable)exception);
        }
    }
}

