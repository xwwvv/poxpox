/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.util.Random;
import java.util.Set;
import protected.ay_0;
import protected.ib_0;
import protected.il;
import protected.rrEm;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.rrr
 */
public abstract class rrr_2<E extends ib_0> {
    private static final Random class = new Random();
    private static final ay_0 break = new ay_0().class(16.0).break().protected();
    private static final ay_0 byte = new ay_0().class(16.0).break().protected().throws();
    private final int protected;
    private long throws;

    public rrr_2(int n2) {
        this.protected = n2;
        this.throws = rrr_2.class.nextInt(n2);
    }

    public rrr_2() {
        this(20);
    }

    protected abstract void class(rrEm var1, E var2);

    public abstract Set<il<?>> class();

    protected static boolean class(ib_0 ib_02, ib_0 ib_03) {
        return ib_02.SF().break(il.package, ib_03) ? byte.class(ib_02, ib_03) : break.class(ib_02, ib_03);
    }

    public final void break(rrEm rrEm2, E e2) {
        if (--this.throws <= 0L) {
            this.throws = this.protected;
            this.class(rrEm2, e2);
        }
    }
}

