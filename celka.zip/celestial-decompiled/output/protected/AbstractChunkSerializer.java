/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.serialization.Codec
 */
package protected;

import com.mojang.serialization.Codec;
import protected.rrsZ;
import protected.rrsc_0;
import protected.rrsf_0;
import protected.rrsl_0;
import protected.rrsn_0;
import protected.rrsu_0;
import protected.rrsv_0;
import protected.rvl_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.rrsA
 */
public class rrsa_0<P extends rrsn_0> {
    public static final rrsa_0<rrsl_0> class = rrsa_0.class("straight_trunk_placer", rrsl_0.throws);
    public static final rrsa_0<rrsZ> break = rrsa_0.class("forking_trunk_placer", rrsZ.throws);
    public static final rrsa_0<rrsv_0> byte = rrsa_0.class("giant_trunk_placer", rrsv_0.throws);
    public static final rrsa_0<rrsf_0> protected = rrsa_0.class("mega_jungle_trunk_placer", rrsf_0.case);
    public static final rrsa_0<rrsc_0> throws = rrsa_0.class("dark_oak_trunk_placer", rrsc_0.throws);
    public static final rrsa_0<rrsu_0> case = rrsa_0.class("fancy_trunk_placer", rrsu_0.throws);
    private final Codec<P> catch;

    private rrsa_0(Codec<P> codec) {
        this.catch = codec;
    }

    private static <P extends rrsn_0> rrsa_0<P> class(String string, Codec<P> codec) {
        return rvl_0.class(rvl_0.rB, string, new rrsa_0<P>(codec));
    }

    public Codec<P> class() {
        return this.catch;
    }
}

