/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableList
 *  com.google.common.collect.ImmutableList$Builder
 */
package protected;

import com.google.common.collect.ImmutableList;
import java.util.Arrays;
import protected.an;
import protected.iq_1;
import protected.rfU;
import protected.wn_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.wF
 */
public class wf_0<T extends an>
extends wn_0<T> {
    private final iq_1[] class;
    private final iq_1[] break;
    private final ImmutableList<iq_1> byte;
    private final float[] protected = new float[7];
    private static final int[][] throws = new int[][]{{3, 2, 2}, {4, 3, 2}, {6, 4, 3}, {3, 3, 3}, {2, 2, 3}, {2, 1, 2}, {1, 1, 2}};
    private static final int[][] case = new int[][]{{0, 0}, {0, 4}, {0, 9}, {0, 16}, {0, 22}, {11, 0}, {13, 4}};

    public wf_0() {
        this.class = new iq_1[7];
        float f2 = -3.5f;
        for (int k = 0; k < this.class.length; ++k) {
            this.class[k] = new iq_1(this, case[k][0], case[k][1]);
            this.class[k].class((float)throws[k][0] * -0.5f, 0.0f, (float)throws[k][2] * -0.5f, throws[k][0], throws[k][1], throws[k][2]);
            this.class[k].class(0.0f, 24 - throws[k][1], f2);
            this.protected[k] = f2;
            if (k >= this.class.length - 1) continue;
            f2 += (float)(throws[k][2] + throws[k + 1][2]) * 0.5f;
        }
        this.break = new iq_1[3];
        this.break[0] = new iq_1(this, 20, 0);
        this.break[0].class(-5.0f, 0.0f, (float)throws[2][2] * -0.5f, 10.0f, 8.0f, throws[2][2]);
        this.break[0].class(0.0f, 16.0f, this.protected[2]);
        this.break[1] = new iq_1(this, 20, 11);
        this.break[1].class(-3.0f, 0.0f, (float)throws[4][2] * -0.5f, 6.0f, 4.0f, throws[4][2]);
        this.break[1].class(0.0f, 20.0f, this.protected[4]);
        this.break[2] = new iq_1(this, 20, 18);
        this.break[2].class(-3.0f, 0.0f, (float)throws[4][2] * -0.5f, 6.0f, 5.0f, throws[1][2]);
        this.break[2].class(0.0f, 19.0f, this.protected[1]);
        ImmutableList.Builder builder = ImmutableList.builder();
        builder.addAll(Arrays.asList(this.class));
        builder.addAll(Arrays.asList(this.break));
        this.byte = builder.build();
    }

    @Override
    public /* synthetic */ Iterable class() {
        return this.break();
    }

    @Override
    public void class(T t2, float f2, float f3, float f4, float f5, float f6) {
        for (int k = 0; k < this.class.length; ++k) {
            this.class[k].catch = rfU.break(f4 * 0.9f + (float)k * 0.15f * (float)Math.PI) * (float)Math.PI * 0.05f * (float)(1 + Math.abs(k - 2));
            this.class[k].byte = rfU.class(f4 * 0.9f + (float)k * 0.15f * (float)Math.PI) * (float)Math.PI * 0.2f * (float)Math.abs(k - 2);
        }
        this.break[0].catch = this.class[2].catch;
        this.break[1].catch = this.class[4].catch;
        this.break[1].byte = this.class[4].byte;
        this.break[2].catch = this.class[1].catch;
        this.break[2].byte = this.class[1].byte;
    }

    public ImmutableList<iq_1> break() {
        return this.byte;
    }
}

