/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.V;
import protected.bD;
import protected.bt;
import protected.bt_0;
import protected.class;
import protected.j;
import protected.pm_2;
import protected.ps_1;
import protected.ps_2;
import protected.pv_2;
import protected.qw_1;
import protected.qy_1;
import protected.rqp_0;
import protected.rqr_0;
import protected.throws;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class bV
extends pv_2
implements ps_2 {
    private static boolean[] byte;
    private static byte[] protected;
    private static short[] throws;
    public Object[] break;

    private boolean byte() {
        pm_2[] pm_2Array = new pm_2[protected[0]];
        pm_2Array[bV.byte[3]] = (pm_2)((Object)pm_2.staticFieldsd2ae74894aa334618e73ed450cdbde1f[throws[22]]);
        pm_2Array[bV.byte[4]] = (pm_2)((Object)pm_2.staticFieldsd2ae74894aa334618e73ed450cdbde1f[throws[23]]);
        pm_2Array[bV.protected[1]] = (pm_2)((Object)pm_2.staticFieldsd2ae74894aa334618e73ed450cdbde1f[throws[24]]);
        pm_2Array[bV.protected[2]] = (pm_2)((Object)pm_2.staticFieldsd2ae74894aa334618e73ed450cdbde1f[throws[25]]);
        pm_2Array[bV.protected[3]] = (pm_2)((Object)pm_2.staticFieldsd2ae74894aa334618e73ed450cdbde1f[throws[26]]);
        pm_2[] pm_2Array2 = pm_2Array;
        int n2 = pm_2Array2.length;
        for (int k = byte[5]; k < n2; ++k) {
            pm_2 pm_22 = pm_2Array2[k];
            if (!this.class(pm_22)) continue;
            return byte[6];
        }
        return ((class)this.class[throws[27]]).while().catch() || (class)this.class[throws[28]] != protected.throws.class().break() ? byte[7] : byte[8];
    }

    public bV(class clazz) {
        super(clazz);
        HashMap hashMap;
        this.throws();
        this.break[bV.throws[0]] = hashMap = new HashMap();
        bt_0 bt_02 = new bt_0(clazz.throw());
        this.break[bV.throws[1]] = bt_02;
        bt bt2 = new bt(clazz.throw());
        this.break[bV.throws[2]] = bt2;
    }

    static {
        bV.ntfClinit();
    }

    @Override
    public void class() {
        this.throws();
        ((Map)this.break[throws[5]]).clear();
    }

    @Override
    public boolean class(pm_2 pm_22) {
        this.throws();
        return pm_22 == null ? byte[0] : ((Map)this.break[throws[3]]).getOrDefault((Object)pm_22, byte[1]);
    }

    @Override
    public void class(pm_2 pm_22, boolean bl2) {
        this.throws();
        ((Map)this.break[throws[4]]).put(pm_22, bl2);
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0xACC09B8E26ACCDB1L;
    }

    @Override
    public void class(j j2) {
        this.throws();
        if (j2.class() == (V)((Object)V.staticFields30e1cd8580ce39faa61be3646b7cc079[throws[6]])) {
            return;
        }
        if (this.class((pm_2)((Object)pm_2.staticFieldsd2ae74894aa334618e73ed450cdbde1f[throws[7]]))) {
            this.class((pm_2)((Object)pm_2.staticFieldsd2ae74894aa334618e73ed450cdbde1f[throws[8]]), byte[2]);
        }
        ((bt_0)this.break[throws[9]]).class(this.class((pm_2)((Object)pm_2.staticFieldsd2ae74894aa334618e73ed450cdbde1f[throws[10]])));
        ((bt)this.break[throws[11]]).class(this.class((pm_2)((Object)pm_2.staticFieldsd2ae74894aa334618e73ed450cdbde1f[throws[12]])));
        if (this.byte()) {
            if (((rqr_0)((ps_1)this.class[bV.throws[13]]).catch().break[throws[14]]).getClass() != bD.class) {
                bD bD2 = new bD(this);
                ((ps_1)this.class[bV.throws[15]]).catch().break[bV.throws[16]] = bD2;
            }
        } else if (((rqr_0)((ps_1)this.class[bV.throws[17]]).catch().break[throws[18]]).getClass() == bD.class) {
            rqp_0 rqp_02 = new rqp_0((qw_1)qy_1.instanceof().class[throws[20]]);
            ((ps_1)this.class[bV.throws[19]]).catch().break[bV.throws[21]] = rqp_02;
        }
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0x61A37D77;
    }

    public static String break(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{105, -64, 47, -29, -78, 112, 87, 88}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    public bt_0 break() {
        this.throws();
        return (bt_0)this.break[throws[29]];
    }

    private void throws() {
        if (this.break == null) {
            Object[] objectArray = this.break = new Object[protected[4]];
        }
    }

    private static /* synthetic */ void ntfClinit() {
        bV.catch();
        bV.case();
        bV.protected();
    }

    private static void catch() {
        boolean[] blArray = new boolean[9];
        blArray[4] = true;
        blArray[6] = true;
        blArray[7] = true;
        byte = blArray;
    }

    private static void case() {
        short[] sArray = new short[30];
        sArray[1] = 1;
        sArray[2] = 2;
        sArray[6] = 1;
        sArray[7] = 4;
        sArray[8] = 5;
        sArray[9] = 1;
        sArray[10] = 4;
        sArray[11] = 2;
        sArray[12] = 5;
        sArray[13] = 1;
        sArray[14] = 17;
        sArray[15] = 1;
        sArray[16] = 17;
        sArray[17] = 1;
        sArray[18] = 17;
        sArray[19] = 1;
        sArray[20] = 20;
        sArray[21] = 17;
        sArray[23] = 1;
        sArray[24] = 2;
        sArray[25] = 3;
        sArray[26] = 7;
        sArray[29] = 1;
        throws = sArray;
    }

    private static void protected() {
        protected = new byte[]{5, 2, 3, 4, 3};
    }
}

