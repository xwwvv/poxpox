/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.brigadier.ImmutableStringReader
 *  com.mojang.brigadier.Message
 *  com.mojang.brigadier.StringReader
 *  com.mojang.brigadier.arguments.ArgumentType
 *  com.mojang.brigadier.context.CommandContext
 *  com.mojang.brigadier.exceptions.CommandSyntaxException
 *  com.mojang.brigadier.exceptions.SimpleCommandExceptionType
 *  com.mojang.brigadier.suggestion.Suggestions
 *  com.mojang.brigadier.suggestion.SuggestionsBuilder
 */
package protected;

import com.mojang.brigadier.ImmutableStringReader;
import com.mojang.brigadier.Message;
import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.SimpleCommandExceptionType;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.concurrent.CompletableFuture;
import protected.Rf;
import protected.Ri;
import protected.gR;
import protected.gY;
import protected.gp;
import protected.gy_0;
import protected.rfH;
import protected.rfg;
import protected.rgn;
import protected.yr_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.Rz
 */
public class rz_0
implements ArgumentType<Rf> {
    private static final Collection<String> break = Arrays.asList("0 0", "~ ~", "~1 ~-2", "^ ^", "^-1 ^0");
    public static final SimpleCommandExceptionType class = new SimpleCommandExceptionType((Message)new rgn("argument.pos2d.incomplete"));

    public static rz_0 class() {
        return new rz_0();
    }

    public Rf class(StringReader stringReader) throws CommandSyntaxException {
        int n2 = stringReader.getCursor();
        if (!stringReader.canRead()) {
            throw rz_0.class.createWithContext((ImmutableStringReader)stringReader);
        }
        yr_0 yr_02 = yr_0.class(stringReader);
        if (stringReader.canRead() && stringReader.peek() == ' ') {
            stringReader.skip();
            yr_0 yr_03 = yr_0.class(stringReader);
            return new Ri(yr_02, new yr_0(true, 0.0), yr_03);
        }
        stringReader.setCursor(n2);
        throw rz_0.class.createWithContext((ImmutableStringReader)stringReader);
    }

    public static rfg class(CommandContext<gy_0> commandContext, String string) {
        rfH rfH2 = ((Rf)commandContext.getArgument(string, Rf.class)).byte((gy_0)commandContext.getSource());
        return new rfg(rfH2.b_(), rfH2.d_());
    }

    public /* synthetic */ Object parse(StringReader stringReader) throws CommandSyntaxException {
        return this.class(stringReader);
    }

    public Collection<String> getExamples() {
        return break;
    }

    public <S> CompletableFuture<Suggestions> listSuggestions(CommandContext<S> commandContext, SuggestionsBuilder suggestionsBuilder) {
        if (!(commandContext.getSource() instanceof gR)) {
            return Suggestions.empty();
        }
        String string = suggestionsBuilder.getRemaining();
        Collection<gY> collection = !string.isEmpty() && string.charAt(0) == '^' ? Collections.singleton(gY.class) : ((gR)commandContext.getSource()).case();
        return gR.break(string, collection, suggestionsBuilder, gp.class(this::class));
    }
}

