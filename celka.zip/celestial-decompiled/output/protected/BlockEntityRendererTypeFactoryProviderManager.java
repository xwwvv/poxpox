/*
 * Decompiled with CFR 0.152.
 */
package protected;

import com.mojang.blaze3d.systems.RenderSystem;
import java.util.Map;
import protected.Hx;
import protected.hh_0;
import protected.ml_1;
import protected.qy_1;
import protected.rfj;
import protected.rng;
import protected.rqR;
import protected.yd_2;
import protected.yk_2;
import protected.yy_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.yR
 */
public class yr_2
implements yd_2 {
    final qy_1 class;
    private double break = Double.MIN_VALUE;
    private final int byte;
    private yy_1 protected;

    public yr_2(qy_1 qy_12) {
        this.byte = 12;
        this.class = qy_12;
    }

    @Override
    public void class(ml_1 ml_12, Hx hx, double d, double d2, double d3) {
        Object object;
        double d4 = rqR.byte();
        if (d4 - this.break > 3.0E9) {
            this.break = d4;
            object = this.class.this();
            this.protected = object != null ? new yy_1(this, (rng)object, d, d3) : null;
        }
        if (this.protected != null) {
            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();
            RenderSystem.lineWidth(2.0f);
            RenderSystem.disableTexture();
            RenderSystem.depthMask(false);
            object = this.protected.break.getNow(null);
            double d5 = ((hh_0)this.class.class[16]).finally().break().byte * 0.85;
            for (Map.Entry<rfj, String> entry : this.protected.class.entrySet()) {
                rfj rfj2 = entry.getKey();
                Object object2 = entry.getValue();
                if (object != null) {
                    object2 = (String)object2 + (String)object.get(rfj2);
                }
                String[] stringArray = ((String)object2).split("\n");
                int n2 = 0;
                for (String string : stringArray) {
                    yk_2.class(string, (double)((rfj2.break << 4) + 8), d5 + (double)n2, (double)((rfj2.byte << 4) + 8), -1, 0.15f);
                    n2 -= 2;
                }
            }
            RenderSystem.depthMask(true);
            RenderSystem.enableTexture();
            RenderSystem.disableBlend();
        }
    }
}

