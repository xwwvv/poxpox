/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.class;
import protected.pp_2;
import protected.ps_1;
import protected.rz_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public abstract class bq
implements pp_2,
rz_2 {
    private static short[] break;
    private static boolean[] throws;
    private static byte[] catch;
    public Object[] case;

    public bq(class clazz) {
        this.finally();
        class clazz2 = clazz;
        this.case[bq.break[0]] = clazz2;
        ps_1 ps_12 = clazz.throw();
        this.case[bq.break[1]] = ps_12;
    }

    static {
        bq.ntfClinit();
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0x6E02813694F8A0A4L;
    }

    public static String break(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{122, 2, -58, 54, -48, -2, 7, 61}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    private static int break(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0xB3BB5DDE;
    }

    private static /* synthetic */ void ntfClinit() {
        bq.extends();
        bq.implements();
        bq.final();
    }

    private void finally() {
        if (this.case == null) {
            Object[] objectArray = this.case = new Object[catch[0]];
        }
    }

    @Override
    public boolean catch() {
        return throws[0];
    }

    private static void extends() {
        throws = new boolean[1];
    }

    private static void implements() {
        short[] sArray = new short[3];
        sArray[1] = 1;
        break = sArray;
    }

    @Override
    public void protected() {
        ((class)this.case[break[2]]).s().native();
    }

    private static void final() {
        catch = new byte[]{2};
    }
}

