/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Maps
 *  com.mojang.datafixers.DataFix
 *  com.mojang.datafixers.DataFixUtils
 *  com.mojang.datafixers.TypeRewriteRule
 *  com.mojang.datafixers.schemas.Schema
 *  com.mojang.datafixers.types.Type
 *  com.mojang.serialization.Dynamic
 *  it.unimi.dsi.fastutil.ints.Int2ObjectMap
 *  it.unimi.dsi.fastutil.ints.Int2ObjectMap$Entry
 *  it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
package protected;

import com.google.common.collect.Maps;
import com.mojang.datafixers.DataFix;
import com.mojang.datafixers.DataFixUtils;
import com.mojang.datafixers.TypeRewriteRule;
import com.mojang.datafixers.schemas.Schema;
import com.mojang.datafixers.types.Type;
import com.mojang.serialization.Dynamic;
import it.unimi.dsi.fastutil.ints.Int2ObjectMap;
import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
import java.util.BitSet;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import protected.rTC;
import protected.rpf;
import protected.rts_2;
import protected.rtw_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.rtO
 */
public class rto_1
extends DataFix {
    static final Logger class = LogManager.getLogger();
    static final BitSet break = new BitSet(256);
    static final BitSet byte = new BitSet(256);
    static final Dynamic<?> protected = rts_2.break("{Name:'minecraft:pumpkin'}");
    static final Dynamic<?> throws = rts_2.break("{Name:'minecraft:podzol',Properties:{snowy:'true'}}");
    static final Dynamic<?> case = rts_2.break("{Name:'minecraft:grass_block',Properties:{snowy:'true'}}");
    static final Dynamic<?> catch = rts_2.break("{Name:'minecraft:mycelium',Properties:{snowy:'true'}}");
    static final Dynamic<?> private = rts_2.break("{Name:'minecraft:sunflower',Properties:{half:'upper'}}");
    static final Dynamic<?> implements = rts_2.break("{Name:'minecraft:lilac',Properties:{half:'upper'}}");
    static final Dynamic<?> finally = rts_2.break("{Name:'minecraft:tall_grass',Properties:{half:'upper'}}");
    static final Dynamic<?> extends = rts_2.break("{Name:'minecraft:large_fern',Properties:{half:'upper'}}");
    static final Dynamic<?> native = rts_2.break("{Name:'minecraft:rose_bush',Properties:{half:'upper'}}");
    static final Dynamic<?> volatile = rts_2.break("{Name:'minecraft:peony',Properties:{half:'upper'}}");
    static final Map<String, Dynamic<?>> final = (Map)DataFixUtils.make((Object)Maps.newHashMap(), hashMap -> {
        hashMap.put("minecraft:air0", rts_2.break("{Name:'minecraft:flower_pot'}"));
        hashMap.put("minecraft:red_flower0", rts_2.break("{Name:'minecraft:potted_poppy'}"));
        hashMap.put("minecraft:red_flower1", rts_2.break("{Name:'minecraft:potted_blue_orchid'}"));
        hashMap.put("minecraft:red_flower2", rts_2.break("{Name:'minecraft:potted_allium'}"));
        hashMap.put("minecraft:red_flower3", rts_2.break("{Name:'minecraft:potted_azure_bluet'}"));
        hashMap.put("minecraft:red_flower4", rts_2.break("{Name:'minecraft:potted_red_tulip'}"));
        hashMap.put("minecraft:red_flower5", rts_2.break("{Name:'minecraft:potted_orange_tulip'}"));
        hashMap.put("minecraft:red_flower6", rts_2.break("{Name:'minecraft:potted_white_tulip'}"));
        hashMap.put("minecraft:red_flower7", rts_2.break("{Name:'minecraft:potted_pink_tulip'}"));
        hashMap.put("minecraft:red_flower8", rts_2.break("{Name:'minecraft:potted_oxeye_daisy'}"));
        hashMap.put("minecraft:yellow_flower0", rts_2.break("{Name:'minecraft:potted_dandelion'}"));
        hashMap.put("minecraft:sapling0", rts_2.break("{Name:'minecraft:potted_oak_sapling'}"));
        hashMap.put("minecraft:sapling1", rts_2.break("{Name:'minecraft:potted_spruce_sapling'}"));
        hashMap.put("minecraft:sapling2", rts_2.break("{Name:'minecraft:potted_birch_sapling'}"));
        hashMap.put("minecraft:sapling3", rts_2.break("{Name:'minecraft:potted_jungle_sapling'}"));
        hashMap.put("minecraft:sapling4", rts_2.break("{Name:'minecraft:potted_acacia_sapling'}"));
        hashMap.put("minecraft:sapling5", rts_2.break("{Name:'minecraft:potted_dark_oak_sapling'}"));
        hashMap.put("minecraft:red_mushroom0", rts_2.break("{Name:'minecraft:potted_red_mushroom'}"));
        hashMap.put("minecraft:brown_mushroom0", rts_2.break("{Name:'minecraft:potted_brown_mushroom'}"));
        hashMap.put("minecraft:deadbush0", rts_2.break("{Name:'minecraft:potted_dead_bush'}"));
        hashMap.put("minecraft:tallgrass2", rts_2.break("{Name:'minecraft:potted_fern'}"));
        hashMap.put("minecraft:cactus0", rts_2.break(2240));
    });
    static final Map<String, Dynamic<?>> package = (Map)DataFixUtils.make((Object)Maps.newHashMap(), hashMap -> {
        rto_1.class(hashMap, 0, "skeleton", "skull");
        rto_1.class(hashMap, 1, "wither_skeleton", "skull");
        rto_1.class(hashMap, 2, "zombie", "head");
        rto_1.class(hashMap, 3, "player", "head");
        rto_1.class(hashMap, 4, "creeper", "head");
        rto_1.class(hashMap, 5, "dragon", "head");
    });
    static final Map<String, Dynamic<?>> int = (Map)DataFixUtils.make((Object)Maps.newHashMap(), hashMap -> {
        rto_1.class(hashMap, "oak_door", 1024);
        rto_1.class(hashMap, "iron_door", 1136);
        rto_1.class(hashMap, "spruce_door", 3088);
        rto_1.class(hashMap, "birch_door", 3104);
        rto_1.class(hashMap, "jungle_door", 3120);
        rto_1.class(hashMap, "acacia_door", 3136);
        rto_1.class(hashMap, "dark_oak_door", 3152);
    });
    static final Map<String, Dynamic<?>> new = (Map)DataFixUtils.make((Object)Maps.newHashMap(), hashMap -> {
        for (int k = 0; k < 26; ++k) {
            hashMap.put("true" + k, rts_2.break("{Name:'minecraft:note_block',Properties:{powered:'true',note:'" + k + "'}}"));
            hashMap.put("false" + k, rts_2.break("{Name:'minecraft:note_block',Properties:{powered:'false',note:'" + k + "'}}"));
        }
    });
    private static final Int2ObjectMap<String> continue = (Int2ObjectMap)DataFixUtils.make((Object)new Int2ObjectOpenHashMap(), int2ObjectOpenHashMap -> {
        int2ObjectOpenHashMap.put(0, (Object)"white");
        int2ObjectOpenHashMap.put(1, (Object)"orange");
        int2ObjectOpenHashMap.put(2, (Object)"magenta");
        int2ObjectOpenHashMap.put(3, (Object)"light_blue");
        int2ObjectOpenHashMap.put(4, (Object)"yellow");
        int2ObjectOpenHashMap.put(5, (Object)"lime");
        int2ObjectOpenHashMap.put(6, (Object)"pink");
        int2ObjectOpenHashMap.put(7, (Object)"gray");
        int2ObjectOpenHashMap.put(8, (Object)"light_gray");
        int2ObjectOpenHashMap.put(9, (Object)"cyan");
        int2ObjectOpenHashMap.put(10, (Object)"purple");
        int2ObjectOpenHashMap.put(11, (Object)"blue");
        int2ObjectOpenHashMap.put(12, (Object)"brown");
        int2ObjectOpenHashMap.put(13, (Object)"green");
        int2ObjectOpenHashMap.put(14, (Object)"red");
        int2ObjectOpenHashMap.put(15, (Object)"black");
    });
    static final Map<String, Dynamic<?>> super = (Map)DataFixUtils.make((Object)Maps.newHashMap(), hashMap -> {
        for (Int2ObjectMap.Entry entry : continue.int2ObjectEntrySet()) {
            if (Objects.equals(entry.getValue(), "red")) continue;
            rto_1.class(hashMap, entry.getIntKey(), (String)entry.getValue());
        }
    });
    static final Map<String, Dynamic<?>> this = (Map)DataFixUtils.make((Object)Maps.newHashMap(), hashMap -> {
        for (Int2ObjectMap.Entry entry : continue.int2ObjectEntrySet()) {
            if (Objects.equals(entry.getValue(), "white")) continue;
            rto_1.break(hashMap, 15 - entry.getIntKey(), (String)entry.getValue());
        }
    });
    static final Dynamic<?> else = rts_2.break(0);

    public rto_1(Schema schema, boolean bl2) {
        super(schema, bl2);
    }

    static {
        byte.set(2);
        byte.set(3);
        byte.set(110);
        byte.set(140);
        byte.set(144);
        byte.set(25);
        byte.set(86);
        byte.set(26);
        byte.set(176);
        byte.set(177);
        byte.set(175);
        byte.set(64);
        byte.set(71);
        byte.set(193);
        byte.set(194);
        byte.set(195);
        byte.set(196);
        byte.set(197);
        break.set(54);
        break.set(146);
        break.set(25);
        break.set(26);
        break.set(51);
        break.set(53);
        break.set(67);
        break.set(108);
        break.set(109);
        break.set(114);
        break.set(128);
        break.set(134);
        break.set(135);
        break.set(136);
        break.set(156);
        break.set(163);
        break.set(164);
        break.set(180);
        break.set(203);
        break.set(55);
        break.set(85);
        break.set(113);
        break.set(188);
        break.set(189);
        break.set(190);
        break.set(191);
        break.set(192);
        break.set(93);
        break.set(94);
        break.set(101);
        break.set(102);
        break.set(160);
        break.set(106);
        break.set(107);
        break.set(183);
        break.set(184);
        break.set(185);
        break.set(186);
        break.set(187);
        break.set(132);
        break.set(139);
        break.set(199);
    }

    private static void class(Map<String, Dynamic<?>> map, String string, int n2) {
        map.put("minecraft:" + string + "eastlowerleftfalsefalse", rts_2.break("{Name:'minecraft:" + string + "',Properties:{facing:'east',half:'lower',hinge:'left',open:'false',powered:'false'}}"));
        map.put("minecraft:" + string + "eastlowerleftfalsetrue", rts_2.break("{Name:'minecraft:" + string + "',Properties:{facing:'east',half:'lower',hinge:'left',open:'false',powered:'true'}}"));
        map.put("minecraft:" + string + "eastlowerlefttruefalse", rts_2.break("{Name:'minecraft:" + string + "',Properties:{facing:'east',half:'lower',hinge:'left',open:'true',powered:'false'}}"));
        map.put("minecraft:" + string + "eastlowerlefttruetrue", rts_2.break("{Name:'minecraft:" + string + "',Properties:{facing:'east',half:'lower',hinge:'left',open:'true',powered:'true'}}"));
        map.put("minecraft:" + string + "eastlowerrightfalsefalse", rts_2.break(n2));
        map.put("minecraft:" + string + "eastlowerrightfalsetrue", rts_2.break("{Name:'minecraft:" + string + "',Properties:{facing:'east',half:'lower',hinge:'right',open:'false',powered:'true'}}"));
        map.put("minecraft:" + string + "eastlowerrighttruefalse", rts_2.break(n2 + 4));
        map.put("minecraft:" + string + "eastlowerrighttruetrue", rts_2.break("{Name:'minecraft:" + string + "',Properties:{facing:'east',half:'lower',hinge:'right',open:'true',powered:'true'}}"));
        map.put("minecraft:" + string + "eastupperleftfalsefalse", rts_2.break(n2 + 8));
        map.put("minecraft:" + string + "eastupperleftfalsetrue", rts_2.break(n2 + 10));
        map.put("minecraft:" + string + "eastupperlefttruefalse", rts_2.break("{Name:'minecraft:" + string + "',Properties:{facing:'east',half:'upper',hinge:'left',open:'true',powered:'false'}}"));
        map.put("minecraft:" + string + "eastupperlefttruetrue", rts_2.break("{Name:'minecraft:" + string + "',Properties:{facing:'east',half:'upper',hinge:'left',open:'true',powered:'true'}}"));
        map.put("minecraft:" + string + "eastupperrightfalsefalse", rts_2.break(n2 + 9));
        map.put("minecraft:" + string + "eastupperrightfalsetrue", rts_2.break(n2 + 11));
        map.put("minecraft:" + string + "eastupperrighttruefalse", rts_2.break("{Name:'minecraft:" + string + "',Properties:{facing:'east',half:'upper',hinge:'right',open:'true',powered:'false'}}"));
        map.put("minecraft:" + string + "eastupperrighttruetrue", rts_2.break("{Name:'minecraft:" + string + "',Properties:{facing:'east',half:'upper',hinge:'right',open:'true',powered:'true'}}"));
        map.put("minecraft:" + string + "northlowerleftfalsefalse", rts_2.break("{Name:'minecraft:" + string + "',Properties:{facing:'north',half:'lower',hinge:'left',open:'false',powered:'false'}}"));
        map.put("minecraft:" + string + "northlowerleftfalsetrue", rts_2.break("{Name:'minecraft:" + string + "',Properties:{facing:'north',half:'lower',hinge:'left',open:'false',powered:'true'}}"));
        map.put("minecraft:" + string + "northlowerlefttruefalse", rts_2.break("{Name:'minecraft:" + string + "',Properties:{facing:'north',half:'lower',hinge:'left',open:'true',powered:'false'}}"));
        map.put("minecraft:" + string + "northlowerlefttruetrue", rts_2.break("{Name:'minecraft:" + string + "',Properties:{facing:'north',half:'lower',hinge:'left',open:'true',powered:'true'}}"));
        map.put("minecraft:" + string + "northlowerrightfalsefalse", rts_2.break(n2 + 3));
        map.put("minecraft:" + string + "northlowerrightfalsetrue", rts_2.break("{Name:'minecraft:" + string + "',Properties:{facing:'north',half:'lower',hinge:'right',open:'false',powered:'true'}}"));
        map.put("minecraft:" + string + "northlowerrighttruefalse", rts_2.break(n2 + 7));
        map.put("minecraft:" + string + "northlowerrighttruetrue", rts_2.break("{Name:'minecraft:" + string + "',Properties:{facing:'north',half:'lower',hinge:'right',open:'true',powered:'true'}}"));
        map.put("minecraft:" + string + "northupperleftfalsefalse", rts_2.break("{Name:'minecraft:" + string + "',Properties:{facing:'north',half:'upper',hinge:'left',open:'false',powered:'false'}}"));
        map.put("minecraft:" + string + "northupperleftfalsetrue", rts_2.break("{Name:'minecraft:" + string + "',Properties:{facing:'north',half:'upper',hinge:'left',open:'false',powered:'true'}}"));
        map.put("minecraft:" + string + "northupperlefttruefalse", rts_2.break("{Name:'minecraft:" + string + "',Properties:{facing:'north',half:'upper',hinge:'left',open:'true',powered:'false'}}"));
        map.put("minecraft:" + string + "northupperlefttruetrue", rts_2.break("{Name:'minecraft:" + string + "',Properties:{facing:'north',half:'upper',hinge:'left',open:'true',powered:'true'}}"));
        map.put("minecraft:" + string + "northupperrightfalsefalse", rts_2.break("{Name:'minecraft:" + string + "',Properties:{facing:'north',half:'upper',hinge:'right',open:'false',powered:'false'}}"));
        map.put("minecraft:" + string + "northupperrightfalsetrue", rts_2.break("{Name:'minecraft:" + string + "',Properties:{facing:'north',half:'upper',hinge:'right',open:'false',powered:'true'}}"));
        map.put("minecraft:" + string + "northupperrighttruefalse", rts_2.break("{Name:'minecraft:" + string + "',Properties:{facing:'north',half:'upper',hinge:'right',open:'true',powered:'false'}}"));
        map.put("minecraft:" + string + "northupperrighttruetrue", rts_2.break("{Name:'minecraft:" + string + "',Properties:{facing:'north',half:'upper',hinge:'right',open:'true',powered:'true'}}"));
        map.put("minecraft:" + string + "southlowerleftfalsefalse", rts_2.break("{Name:'minecraft:" + string + "',Properties:{facing:'south',half:'lower',hinge:'left',open:'false',powered:'false'}}"));
        map.put("minecraft:" + string + "southlowerleftfalsetrue", rts_2.break("{Name:'minecraft:" + string + "',Properties:{facing:'south',half:'lower',hinge:'left',open:'false',powered:'true'}}"));
        map.put("minecraft:" + string + "southlowerlefttruefalse", rts_2.break("{Name:'minecraft:" + string + "',Properties:{facing:'south',half:'lower',hinge:'left',open:'true',powered:'false'}}"));
        map.put("minecraft:" + string + "southlowerlefttruetrue", rts_2.break("{Name:'minecraft:" + string + "',Properties:{facing:'south',half:'lower',hinge:'left',open:'true',powered:'true'}}"));
        map.put("minecraft:" + string + "southlowerrightfalsefalse", rts_2.break(n2 + 1));
        map.put("minecraft:" + string + "southlowerrightfalsetrue", rts_2.break("{Name:'minecraft:" + string + "',Properties:{facing:'south',half:'lower',hinge:'right',open:'false',powered:'true'}}"));
        map.put("minecraft:" + string + "southlowerrighttruefalse", rts_2.break(n2 + 5));
        map.put("minecraft:" + string + "southlowerrighttruetrue", rts_2.break("{Name:'minecraft:" + string + "',Properties:{facing:'south',half:'lower',hinge:'right',open:'true',powered:'true'}}"));
        map.put("minecraft:" + string + "southupperleftfalsefalse", rts_2.break("{Name:'minecraft:" + string + "',Properties:{facing:'south',half:'upper',hinge:'left',open:'false',powered:'false'}}"));
        map.put("minecraft:" + string + "southupperleftfalsetrue", rts_2.break("{Name:'minecraft:" + string + "',Properties:{facing:'south',half:'upper',hinge:'left',open:'false',powered:'true'}}"));
        map.put("minecraft:" + string + "southupperlefttruefalse", rts_2.break("{Name:'minecraft:" + string + "',Properties:{facing:'south',half:'upper',hinge:'left',open:'true',powered:'false'}}"));
        map.put("minecraft:" + string + "southupperlefttruetrue", rts_2.break("{Name:'minecraft:" + string + "',Properties:{facing:'south',half:'upper',hinge:'left',open:'true',powered:'true'}}"));
        map.put("minecraft:" + string + "southupperrightfalsefalse", rts_2.break("{Name:'minecraft:" + string + "',Properties:{facing:'south',half:'upper',hinge:'right',open:'false',powered:'false'}}"));
        map.put("minecraft:" + string + "southupperrightfalsetrue", rts_2.break("{Name:'minecraft:" + string + "',Properties:{facing:'south',half:'upper',hinge:'right',open:'false',powered:'true'}}"));
        map.put("minecraft:" + string + "southupperrighttruefalse", rts_2.break("{Name:'minecraft:" + string + "',Properties:{facing:'south',half:'upper',hinge:'right',open:'true',powered:'false'}}"));
        map.put("minecraft:" + string + "southupperrighttruetrue", rts_2.break("{Name:'minecraft:" + string + "',Properties:{facing:'south',half:'upper',hinge:'right',open:'true',powered:'true'}}"));
        map.put("minecraft:" + string + "westlowerleftfalsefalse", rts_2.break("{Name:'minecraft:" + string + "',Properties:{facing:'west',half:'lower',hinge:'left',open:'false',powered:'false'}}"));
        map.put("minecraft:" + string + "westlowerleftfalsetrue", rts_2.break("{Name:'minecraft:" + string + "',Properties:{facing:'west',half:'lower',hinge:'left',open:'false',powered:'true'}}"));
        map.put("minecraft:" + string + "westlowerlefttruefalse", rts_2.break("{Name:'minecraft:" + string + "',Properties:{facing:'west',half:'lower',hinge:'left',open:'true',powered:'false'}}"));
        map.put("minecraft:" + string + "westlowerlefttruetrue", rts_2.break("{Name:'minecraft:" + string + "',Properties:{facing:'west',half:'lower',hinge:'left',open:'true',powered:'true'}}"));
        map.put("minecraft:" + string + "westlowerrightfalsefalse", rts_2.break(n2 + 2));
        map.put("minecraft:" + string + "westlowerrightfalsetrue", rts_2.break("{Name:'minecraft:" + string + "',Properties:{facing:'west',half:'lower',hinge:'right',open:'false',powered:'true'}}"));
        map.put("minecraft:" + string + "westlowerrighttruefalse", rts_2.break(n2 + 6));
        map.put("minecraft:" + string + "westlowerrighttruetrue", rts_2.break("{Name:'minecraft:" + string + "',Properties:{facing:'west',half:'lower',hinge:'right',open:'true',powered:'true'}}"));
        map.put("minecraft:" + string + "westupperleftfalsefalse", rts_2.break("{Name:'minecraft:" + string + "',Properties:{facing:'west',half:'upper',hinge:'left',open:'false',powered:'false'}}"));
        map.put("minecraft:" + string + "westupperleftfalsetrue", rts_2.break("{Name:'minecraft:" + string + "',Properties:{facing:'west',half:'upper',hinge:'left',open:'false',powered:'true'}}"));
        map.put("minecraft:" + string + "westupperlefttruefalse", rts_2.break("{Name:'minecraft:" + string + "',Properties:{facing:'west',half:'upper',hinge:'left',open:'true',powered:'false'}}"));
        map.put("minecraft:" + string + "westupperlefttruetrue", rts_2.break("{Name:'minecraft:" + string + "',Properties:{facing:'west',half:'upper',hinge:'left',open:'true',powered:'true'}}"));
        map.put("minecraft:" + string + "westupperrightfalsefalse", rts_2.break("{Name:'minecraft:" + string + "',Properties:{facing:'west',half:'upper',hinge:'right',open:'false',powered:'false'}}"));
        map.put("minecraft:" + string + "westupperrightfalsetrue", rts_2.break("{Name:'minecraft:" + string + "',Properties:{facing:'west',half:'upper',hinge:'right',open:'false',powered:'true'}}"));
        map.put("minecraft:" + string + "westupperrighttruefalse", rts_2.break("{Name:'minecraft:" + string + "',Properties:{facing:'west',half:'upper',hinge:'right',open:'true',powered:'false'}}"));
        map.put("minecraft:" + string + "westupperrighttruetrue", rts_2.break("{Name:'minecraft:" + string + "',Properties:{facing:'west',half:'upper',hinge:'right',open:'true',powered:'true'}}"));
    }

    public static int class(boolean bl2, boolean bl3, boolean bl4, boolean bl5) {
        int n2 = 0;
        if (bl4) {
            n2 = bl3 ? (n2 |= 2) : (bl2 ? (n2 |= 0x80) : (n2 |= 1));
        } else if (bl5) {
            n2 = bl2 ? (n2 |= 0x20) : (bl3 ? (n2 |= 8) : (n2 |= 0x10));
        } else if (bl3) {
            n2 |= 4;
        } else if (bl2) {
            n2 |= 0x40;
        }
        return n2;
    }

    private static void class(Map<String, Dynamic<?>> map, int n2, String string, String string2) {
        map.put(n2 + "north", rts_2.break("{Name:'minecraft:" + string + "_wall_" + string2 + "',Properties:{facing:'north'}}"));
        map.put(n2 + "east", rts_2.break("{Name:'minecraft:" + string + "_wall_" + string2 + "',Properties:{facing:'east'}}"));
        map.put(n2 + "south", rts_2.break("{Name:'minecraft:" + string + "_wall_" + string2 + "',Properties:{facing:'south'}}"));
        map.put(n2 + "west", rts_2.break("{Name:'minecraft:" + string + "_wall_" + string2 + "',Properties:{facing:'west'}}"));
        for (int k = 0; k < 16; ++k) {
            map.put("" + n2 + k, rts_2.break("{Name:'minecraft:" + string + "_" + string2 + "',Properties:{rotation:'" + k + "'}}"));
        }
    }

    public static String class(Dynamic<?> dynamic) {
        return dynamic.get("Name").asString("");
    }

    public static String class(Dynamic<?> dynamic, String string) {
        return dynamic.get("Properties").get(string).asString("");
    }

    public static int class(rpf<Dynamic<?>> rpf2, Dynamic<?> dynamic) {
        int n2 = rpf2.class(dynamic);
        if (n2 == -1) {
            n2 = rpf2.break(dynamic);
        }
        return n2;
    }

    private static void class(Map<String, Dynamic<?>> map, int n2, String string) {
        map.put("southfalsefoot" + n2, rts_2.break("{Name:'minecraft:" + string + "_bed',Properties:{facing:'south',occupied:'false',part:'foot'}}"));
        map.put("westfalsefoot" + n2, rts_2.break("{Name:'minecraft:" + string + "_bed',Properties:{facing:'west',occupied:'false',part:'foot'}}"));
        map.put("northfalsefoot" + n2, rts_2.break("{Name:'minecraft:" + string + "_bed',Properties:{facing:'north',occupied:'false',part:'foot'}}"));
        map.put("eastfalsefoot" + n2, rts_2.break("{Name:'minecraft:" + string + "_bed',Properties:{facing:'east',occupied:'false',part:'foot'}}"));
        map.put("southfalsehead" + n2, rts_2.break("{Name:'minecraft:" + string + "_bed',Properties:{facing:'south',occupied:'false',part:'head'}}"));
        map.put("westfalsehead" + n2, rts_2.break("{Name:'minecraft:" + string + "_bed',Properties:{facing:'west',occupied:'false',part:'head'}}"));
        map.put("northfalsehead" + n2, rts_2.break("{Name:'minecraft:" + string + "_bed',Properties:{facing:'north',occupied:'false',part:'head'}}"));
        map.put("eastfalsehead" + n2, rts_2.break("{Name:'minecraft:" + string + "_bed',Properties:{facing:'east',occupied:'false',part:'head'}}"));
        map.put("southtruehead" + n2, rts_2.break("{Name:'minecraft:" + string + "_bed',Properties:{facing:'south',occupied:'true',part:'head'}}"));
        map.put("westtruehead" + n2, rts_2.break("{Name:'minecraft:" + string + "_bed',Properties:{facing:'west',occupied:'true',part:'head'}}"));
        map.put("northtruehead" + n2, rts_2.break("{Name:'minecraft:" + string + "_bed',Properties:{facing:'north',occupied:'true',part:'head'}}"));
        map.put("easttruehead" + n2, rts_2.break("{Name:'minecraft:" + string + "_bed',Properties:{facing:'east',occupied:'true',part:'head'}}"));
    }

    private static void break(Map<String, Dynamic<?>> map, int n2, String string) {
        for (int k = 0; k < 16; ++k) {
            map.put(k + "_" + n2, rts_2.break("{Name:'minecraft:" + string + "_banner',Properties:{rotation:'" + k + "'}}"));
        }
        map.put("north_" + n2, rts_2.break("{Name:'minecraft:" + string + "_wall_banner',Properties:{facing:'north'}}"));
        map.put("south_" + n2, rts_2.break("{Name:'minecraft:" + string + "_wall_banner',Properties:{facing:'south'}}"));
        map.put("west_" + n2, rts_2.break("{Name:'minecraft:" + string + "_wall_banner',Properties:{facing:'west'}}"));
        map.put("east_" + n2, rts_2.break("{Name:'minecraft:" + string + "_wall_banner',Properties:{facing:'east'}}"));
    }

    private Dynamic<?> break(Dynamic<?> dynamic) {
        Optional optional = dynamic.get("Level").result();
        return optional.isPresent() && ((Dynamic)optional.get()).get("Sections").asStreamOpt().result().isPresent() ? dynamic.set("Level", new rtw_0((Dynamic)optional.get()).class()) : dynamic;
    }

    public TypeRewriteRule makeRule() {
        Type type = this.getInputSchema().getType(rTC.byte);
        Type type2 = this.getOutputSchema().getType(rTC.byte);
        return this.writeFixAndRead("ChunkPalettedStorageFix", type, type2, this::break);
    }
}

