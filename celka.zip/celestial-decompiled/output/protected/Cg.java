/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.CH;
import protected.CV;
import protected.ch_0;
import protected.cx_0;
import protected.gm;
import protected.rlc_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class Cg
implements cx_0<rlc_2> {
    private final ch_0 class;

    public Cg(ch_0 ch_02) {
        this.class = ch_02;
    }

    @Override
    public CH class(rlc_2 rlc_22, gm gm2, double d, double d2, double d3, double d4, double d5, double d6) {
        return new CV(gm2, d, d2, d3, d4, d5, d6, rlc_22, this.class);
    }
}

