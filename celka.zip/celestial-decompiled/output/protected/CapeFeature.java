/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.rgP;
import protected.rgn;
import protected.rhd_2;
import protected.rhu_0;
import protected.rhz_2;
import protected.rjr_2;
import protected.rjz_1;
import protected.rxe_1;
import protected.rxu_1;
import protected.xi_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
class xf
implements rjz_1 {
    final /* synthetic */ rhu_0 class;
    final /* synthetic */ rhu_0 break;
    final /* synthetic */ rxu_1 byte;

    /*
     * Ignored method signature, as it can't be verified against descriptor
     */
    xf(xi_0 xi_02, rhu_0 rhu_02, rhu_0 rhu_03, rxu_1 rxu_12) {
        this.class = rhu_02;
        this.break = rhu_03;
        this.byte = rxu_12;
    }

    @Override
    public rgP L_() {
        if (this.class.Bk()) {
            return this.class.L_();
        }
        return this.break.Bk() ? this.break.L_() : new rgn("container.chestDouble");
    }

    @Override
    public rjr_2 createMenu(int n2, rhz_2 rhz_22, rhd_2 rhd_22) {
        if (this.class.throws(rhd_22) && this.break.throws(rhd_22)) {
            this.class.protected(rhz_22.throws);
            this.break.protected(rhz_22.throws);
            return rxe_1.break(n2, rhz_22, this.byte);
        }
        return null;
    }
}

