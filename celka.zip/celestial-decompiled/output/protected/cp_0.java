/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.CH;
import protected.ch_0;
import protected.cr_0;
import protected.cx_0;
import protected.cy_0;
import protected.gm;
import protected.qy_1;
import protected.rlo_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.CP
 */
public class cp_0
implements cx_0<rlo_2> {
    private final ch_0 class;

    public cp_0(ch_0 ch_02) {
        this.class = ch_02;
    }

    @Override
    public CH class(rlo_2 rlo_22, gm gm2, double d, double d2, double d3, double d4, double d5, double d6) {
        cr_0 cr_02 = new cr_0(gm2, d, d2, d3, d4, d5, d6, (cy_0)qy_1.instanceof().class[12], this.class);
        cr_02.throws(0.99f);
        return cr_02;
    }
}

