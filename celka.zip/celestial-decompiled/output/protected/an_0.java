/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.eC;
import protected.ef_0;
import protected.ev_0;
import protected.rxq_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.aN
 */
public class an_0
extends ev_0 {
    @Override
    public boolean byte() {
        return true;
    }

    public an_0(ef_0 ef_02, rxq_1 ... rxq_1Array) {
        super(ef_02, eC.VANISHABLE, rxq_1Array);
    }

    @Override
    public int class() {
        return 1;
    }

    @Override
    public int class(int n2) {
        return 25;
    }

    @Override
    public int break(int n2) {
        return 50;
    }

    @Override
    public boolean break() {
        return true;
    }
}

