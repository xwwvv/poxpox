/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.datafixers.DSL
 *  com.mojang.datafixers.schemas.Schema
 *  com.mojang.datafixers.types.templates.TypeTemplate
 */
package protected;

import com.mojang.datafixers.DSL;
import com.mojang.datafixers.schemas.Schema;
import com.mojang.datafixers.types.templates.TypeTemplate;
import java.util.Map;
import java.util.function.Supplier;
import protected.rTA;
import protected.rTC;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.rfd
 */
public class rfd_0
extends rTA {
    public rfd_0(int n2, Schema schema) {
        super(n2, schema);
    }

    protected static void class(Schema schema, Map<String, Supplier<TypeTemplate>> map, String string) {
        schema.register(map, string, () -> DSL.optionalFields((String)"Items", (TypeTemplate)DSL.list((TypeTemplate)rTC.native.in(schema))));
    }

    public Map<String, Supplier<TypeTemplate>> registerBlockEntities(Schema schema) {
        Map map = super.registerBlockEntities(schema);
        rfd_0.class(schema, map, "minecraft:barrel");
        rfd_0.class(schema, map, "minecraft:smoker");
        rfd_0.class(schema, map, "minecraft:blast_furnace");
        schema.register(map, "minecraft:lectern", string -> DSL.optionalFields((String)"Book", (TypeTemplate)rTC.native.in(schema)));
        schema.registerSimple(map, "minecraft:bell");
        return map;
    }
}

