/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableList
 */
package protected;

import com.google.common.collect.ImmutableList;
import protected.HU;
import protected.iq_1;
import protected.rfU;
import protected.rgz_2;
import protected.wn_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.wv
 */
public class wv_0<T extends rgz_2>
extends wn_0<T> {
    private final iq_1 class;
    private final iq_1 break = new iq_1(64, 64, 0, 0);
    private final iq_1 byte;

    public iq_1 byte() {
        return this.break;
    }

    public wv_0() {
        super(HU::throws);
        this.class = new iq_1(64, 64, 0, 28);
        this.byte = new iq_1(64, 64, 0, 52);
        this.break.class(-8.0f, -16.0f, -8.0f, 16.0f, 12.0f, 16.0f);
        this.break.class(0.0f, 24.0f, 0.0f);
        this.class.class(-8.0f, -8.0f, -8.0f, 16.0f, 8.0f, 16.0f);
        this.class.class(0.0f, 24.0f, 0.0f);
        this.byte.class(-3.0f, 0.0f, -3.0f, 6.0f, 6.0f, 6.0f);
        this.byte.class(0.0f, 12.0f, 0.0f);
    }

    @Override
    public Iterable<iq_1> class() {
        return ImmutableList.of((Object)this.class, (Object)this.break);
    }

    @Override
    public void class(T t2, float f2, float f3, float f4, float f5, float f6) {
        float f7 = f4 - (float)((Integer)((rgz_2)t2).throws[41]).intValue();
        float f8 = (0.5f + ((rgz_2)t2).throw(f7)) * (float)Math.PI;
        float f9 = -1.0f + rfU.class(f8);
        float f10 = 0.0f;
        if (f8 > (float)Math.PI) {
            f10 = rfU.class(f4 * 0.1f) * 0.7f;
        }
        this.break.class(0.0f, 16.0f + rfU.class(f8) * 8.0f + f10, 0.0f);
        this.break.catch = ((rgz_2)t2).throw(f7) > 0.3f ? f9 * f9 * f9 * f9 * (float)Math.PI * 0.125f : 0.0f;
        this.byte.case = f6 * ((float)Math.PI / 180);
        this.byte.catch = (((Float)((rgz_2)t2).private[25]).floatValue() - 180.0f - ((Float)((rgz_2)t2).private[23]).floatValue()) * ((float)Math.PI / 180);
    }

    public iq_1 break() {
        return this.class;
    }

    public iq_1 protected() {
        return this.byte;
    }
}

