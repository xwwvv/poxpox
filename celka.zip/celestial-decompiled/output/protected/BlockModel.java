/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.VD;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class VU
extends Enum<VU>
implements VD {
    public static final /* enum */ VU NORMAL = new VU(false);
    public static final /* enum */ VU ADVANCED = new VU(true);
    private final boolean isAdvanced;
    private static final /* synthetic */ VU[] $VALUES;

    private VU(boolean bl2) {
        this.isAdvanced = bl2;
    }

    static {
        $VALUES = VU.break();
    }

    public static VU[] values() {
        return (VU[])$VALUES.clone();
    }

    public static VU valueOf(String string) {
        return Enum.valueOf(VU.class, string);
    }

    @Override
    public boolean class() {
        return this.isAdvanced;
    }

    private static /* synthetic */ VU[] break() {
        return new VU[]{NORMAL, ADVANCED};
    }
}

