/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.n;
import protected.rfH;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.A
 */
public class a_0 {
    private static byte[] break;
    private static short[] byte;
    public Object[] class;

    private void byte() {
        if (this.class == null) {
            Object[] objectArray = this.class = new Object[break[0]];
        }
    }

    public a_0(rfH rfH2, n n2) {
        this.byte();
        rfH rfH3 = rfH2;
        this.class[a_0.byte[0]] = rfH3;
        n n3 = n2;
        this.class[a_0.byte[1]] = n3;
    }

    static {
        a_0.ntfClinit();
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0xA40300F3A56F1C7FL;
    }

    public n class() {
        return (n)((Object)this.class[byte[3]]);
    }

    public static String class(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{117, -119, 45, 30, -92, -88, -36, 0}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0x812DD1F3;
    }

    public rfH break() {
        return (rfH)this.class[byte[2]];
    }

    private static void throws() {
        break = new byte[]{2};
    }

    private static /* synthetic */ void ntfClinit() {
        a_0.protected();
        a_0.throws();
    }

    private static void protected() {
        short[] sArray = new short[4];
        sArray[1] = 1;
        sArray[3] = 1;
        byte = sArray;
    }
}

