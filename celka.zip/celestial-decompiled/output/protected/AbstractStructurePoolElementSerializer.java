/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.base.MoreObjects
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 *  protected.rnA$protected.rnn
 */
package protected;

import com.google.common.base.MoreObjects;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.OpenOption;
import java.nio.file.Path;
import java.util.Map;
import java.util.Objects;
import java.util.Properties;
import java.util.function.Function;
import java.util.function.IntFunction;
import java.util.function.UnaryOperator;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import protected.rVm;
import protected.rna_0;
import protected.rnn_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.rnA
 */
public abstract class rna_0<T extends rna_0<T>> {
    private static final Logger class = LogManager.getLogger();
    private final Properties break;

    private String byte(String string) {
        return (String)this.break.get(string);
    }

    public rna_0(Properties properties) {
        this.break = properties;
    }

    protected boolean class(String string, boolean bl2) {
        return this.class(string, Boolean::valueOf, bl2);
    }

    protected long class(String string, long l2) {
        return this.class(string, rna_0.class(Long::parseLong), l2);
    }

    protected int class(String string, UnaryOperator<Integer> unaryOperator, int n2) {
        return this.class(string, rna_0.class(Integer::parseInt), unaryOperator, Objects::toString, n2);
    }

    protected String class(String string) {
        return (String)this.class(string, Function.identity());
    }

    protected int class(String string, int n2) {
        return this.class(string, rna_0.class(Integer::parseInt), Integer.valueOf(n2));
    }

    public static Properties class(Path path) {
        Properties properties = new Properties();
        try (InputStream inputStream = Files.newInputStream(path, new OpenOption[0]);){
            properties.load(inputStream);
        }
        catch (IOException iOException) {
            rna_0.class.error("Failed to load properties from file: " + path);
        }
        return properties;
    }

    protected abstract T class(rVm var1, Properties var2);

    protected Properties class() {
        Properties properties = new Properties();
        properties.putAll((Map<?, ?>)this.break);
        return properties;
    }

    private static <V extends Number> Function<String, V> class(Function<String, V> function) {
        return string -> {
            try {
                return (Number)function.apply((String)string);
            }
            catch (NumberFormatException numberFormatException) {
                return null;
            }
        };
    }

    protected static <V> Function<String, V> class(IntFunction<V> intFunction, Function<String, V> function) {
        return string -> {
            try {
                return intFunction.apply(Integer.parseInt(string));
            }
            catch (NumberFormatException numberFormatException) {
                return function.apply((String)string);
            }
        };
    }

    protected <V> V class(String string, Function<String, V> function, Function<V, String> function2, V v) {
        String string2 = this.byte(string);
        Object object = MoreObjects.firstNonNull(string2 != null ? function.apply(string2) : null, v);
        this.break.put(string, function2.apply(object));
        return (V)object;
    }

    protected <V> V class(String string, Function<String, V> function) {
        String string2 = this.byte(string);
        if (string2 == null) {
            return null;
        }
        this.break.remove(string);
        return function.apply(string2);
    }

    protected String class(String string, String string2) {
        return this.class(string, Function.identity(), Function.identity(), string2);
    }

    protected <V> V class(String string, Function<String, V> function, V v) {
        return (V)this.class(string, function, Objects::toString, v);
    }

    protected <V> V class(String string2, Function<String, V> function, UnaryOperator<V> unaryOperator, Function<V, String> function2, V v) {
        return (V)this.class(string2, string -> {
            Object r = function.apply((String)string);
            return r != null ? unaryOperator.apply(r) : null;
        }, function2, v);
    }

    protected rnn<Integer> break(String string, int n2) {
        return this.break(string, rna_0.class(Integer::parseInt), n2);
    }

    public void break(Path path) {
        try (OutputStream outputStream = Files.newOutputStream(path, new OpenOption[0]);){
            this.break.store(outputStream, "Minecraft server properties");
        }
        catch (IOException iOException) {
            rna_0.class.error("Failed to store properties to file: " + path);
        }
    }

    protected <V> rnn<V> break(String string, Function<String, V> function, V v) {
        return this.break(string, function, Objects::toString, v);
    }

    protected <V> rnn<V> break(String string, Function<String, V> function, Function<V, String> function2, V v) {
        String string2 = this.byte(string);
        Object object = MoreObjects.firstNonNull(string2 != null ? function.apply(string2) : null, v);
        this.break.put(string, function2.apply(object));
        return new rnn_0(this, string, object, function2);
    }

    protected rnn<Boolean> break(String string, boolean bl2) {
        return this.break(string, Boolean::valueOf, bl2);
    }

    protected Boolean break(String string) {
        return this.class(string, Boolean::valueOf);
    }
}

