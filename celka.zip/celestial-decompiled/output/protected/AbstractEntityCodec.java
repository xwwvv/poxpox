/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.serialization.Codec
 */
package protected;

import com.mojang.serialization.Codec;
import protected.rrpd_1;
import protected.rrpe_1;
import protected.rrpf_1;
import protected.rrpg_1;
import protected.rrpi_2;
import protected.rrpj_1;
import protected.rrpk_1;
import protected.rrpr_1;
import protected.rrpu_1;
import protected.rrpv_1;
import protected.rvl_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.rrPo
 */
public class rrpo_1<P extends rrpr_1> {
    public static final rrpo_1<rrpf_1> class = rrpo_1.class("blob_foliage_placer", rrpf_1.class);
    public static final rrpo_1<rrpe_1> break = rrpo_1.class("spruce_foliage_placer", rrpe_1.class);
    public static final rrpo_1<rrpu_1> byte = rrpo_1.class("pine_foliage_placer", rrpu_1.class);
    public static final rrpo_1<rrpi_2> protected = rrpo_1.class("acacia_foliage_placer", rrpi_2.class);
    public static final rrpo_1<rrpj_1> throws = rrpo_1.class("bush_foliage_placer", rrpj_1.byte);
    public static final rrpo_1<rrpg_1> case = rrpo_1.class("fancy_foliage_placer", rrpg_1.byte);
    public static final rrpo_1<rrpk_1> catch = rrpo_1.class("jungle_foliage_placer", rrpk_1.class);
    public static final rrpo_1<rrpd_1> private = rrpo_1.class("mega_pine_foliage_placer", rrpd_1.class);
    public static final rrpo_1<rrpv_1> implements = rrpo_1.class("dark_oak_foliage_placer", rrpv_1.class);
    private final Codec<P> finally;

    private rrpo_1(Codec<P> codec) {
        this.finally = codec;
    }

    private static <P extends rrpr_1> rrpo_1<P> class(String string, Codec<P> codec) {
        return rvl_0.class(rvl_0.rP, string, new rrpo_1<P>(codec));
    }

    public Codec<P> class() {
        return this.finally;
    }
}

