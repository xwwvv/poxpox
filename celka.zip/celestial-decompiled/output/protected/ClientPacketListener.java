/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 *  com.google.common.collect.Maps
 *  com.google.common.collect.Multimap
 *  com.google.common.collect.Sets
 *  com.mojang.authlib.GameProfile
 *  com.mojang.brigadier.CommandDispatcher
 *  com.viaversion.viaversion.api.protocol.version.ProtocolVersion
 *  io.netty.buffer.Unpooled
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
package protected;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Multimap;
import com.google.common.collect.Sets;
import com.mojang.authlib.GameProfile;
import com.mojang.brigadier.CommandDispatcher;
import com.viaversion.viaversion.api.protocol.version.ProtocolVersion;
import io.netty.buffer.Unpooled;
import java.io.File;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import protected.VR;
import protected.Vo;
import protected.Zb;
import protected.Zs;
import protected.aZ;
import protected.ab_1;
import protected.ai_0;
import protected.ak_2;
import protected.an;
import protected.ao_2;
import protected.aq_2;
import protected.at_1;
import protected.aw_1;
import protected.ax_1;
import protected.ax_2;
import protected.az_2;
import protected.break;
import protected.cb_1;
import protected.cg_1;
import protected.cm_2;
import protected.cn_0;
import protected.cq_1;
import protected.ct_1;
import protected.cy_0;
import protected.cy_2;
import protected.ex;
import protected.fl_1;
import protected.fv_1;
import protected.gR;
import protected.gg_0;
import protected.gj_0;
import protected.gm;
import protected.gv_0;
import protected.hh_0;
import protected.ib_0;
import protected.ic_0;
import protected.ik_0;
import protected.is;
import protected.ix_0;
import protected.mb_0;
import protected.mg_0;
import protected.ml;
import protected.ms;
import protected.mt_0;
import protected.nb_1;
import protected.ne_2;
import protected.nf_2;
import protected.ng_2;
import protected.nk_2;
import protected.nn_2;
import protected.np_1;
import protected.nq_2;
import protected.ot_1;
import protected.pb;
import protected.pg_0;
import protected.ps_0;
import protected.px;
import protected.qn_1;
import protected.qw_1;
import protected.qy_1;
import protected.rCi;
import protected.rHU;
import protected.rHZ;
import protected.rHb;
import protected.rHj;
import protected.rHx;
import protected.rRl;
import protected.rRo;
import protected.rVm;
import protected.rYB;
import protected.rYZ;
import protected.rZD;
import protected.rZK;
import protected.rZR;
import protected.rZU;
import protected.rZV;
import protected.rZY;
import protected.rZa;
import protected.rZe;
import protected.rZf;
import protected.rZg;
import protected.rZj;
import protected.rZo;
import protected.raa_1;
import protected.rai_1;
import protected.raz_1;
import protected.rbf_0;
import protected.rcd_2;
import protected.rdf_1;
import protected.rdn_1;
import protected.rdx_1;
import protected.rdy_2;
import protected.rei_2;
import protected.rfH;
import protected.rfU;
import protected.rfa_2;
import protected.rfb_1;
import protected.rfb_2;
import protected.rfc_1;
import protected.rfc_2;
import protected.rfd_2;
import protected.rfe_2;
import protected.rfg_2;
import protected.rfh_1;
import protected.rfh_2;
import protected.rfi;
import protected.rfj;
import protected.rfj_1;
import protected.rfj_2;
import protected.rfk_2;
import protected.rfl_1;
import protected.rfm_1;
import protected.rfm_2;
import protected.rfn_1;
import protected.rfn_2;
import protected.rfo_2;
import protected.rfp_1;
import protected.rfp_2;
import protected.rfq_1;
import protected.rfq_2;
import protected.rfr_2;
import protected.rfs_1;
import protected.rfs_2;
import protected.rft_1;
import protected.rft_2;
import protected.rfu_2;
import protected.rfv_1;
import protected.rfw_1;
import protected.rfw_2;
import protected.rfx_1;
import protected.rfx_2;
import protected.rfy_2;
import protected.rfz_1;
import protected.rfz_2;
import protected.rgP;
import protected.rgn;
import protected.rgn_0;
import protected.rha_0;
import protected.rha_2;
import protected.rhc_0;
import protected.rhc_1;
import protected.rhd_1;
import protected.rhd_2;
import protected.rhf_2;
import protected.rhg_1;
import protected.rhh_1;
import protected.rhi_2;
import protected.rhj_0;
import protected.rhl_1;
import protected.rhm_1;
import protected.rhn_1;
import protected.rho_0;
import protected.rho_1;
import protected.rhp_1;
import protected.rhr_1;
import protected.rhu_1;
import protected.rhw_1;
import protected.rhx_1;
import protected.rhy_0;
import protected.rhy_1;
import protected.rhy_2;
import protected.rhz_2;
import protected.rjU;
import protected.rjh_0;
import protected.rjp_1;
import protected.rjq_2;
import protected.rjr_2;
import protected.rjt_1;
import protected.rkw_2;
import protected.rla_0;
import protected.rlc_1;
import protected.rlp_0;
import protected.rlq_0;
import protected.rlq_2;
import protected.rlr_1;
import protected.rly_1;
import protected.rmV;
import protected.rmf;
import protected.rmg;
import protected.rmg_0;
import protected.rmi_0;
import protected.rmy_0;
import protected.rnb_0;
import protected.rnh_0;
import protected.rnp_0;
import protected.rns_0;
import protected.rnx_0;
import protected.roH;
import protected.rod_2;
import protected.roj_0;
import protected.rpm;
import protected.rpr_0;
import protected.rql_0;
import protected.rqm_0;
import protected.rqn;
import protected.rqo_0;
import protected.rqp_0;
import protected.rrAH;
import protected.rrAl;
import protected.rrGb;
import protected.rrag_0;
import protected.rrfZ;
import protected.rrj_0;
import protected.rrja_0;
import protected.rrla_2;
import protected.rrlf_1;
import protected.rrll_2;
import protected.rrln_1;
import protected.rrln_2;
import protected.rrlq_2;
import protected.rrno_0;
import protected.rro_0;
import protected.rrqx_1;
import protected.rrse;
import protected.rrvl_0;
import protected.rrw_0;
import protected.rsX;
import protected.rsa_1;
import protected.rsb_0;
import protected.rsc_0;
import protected.rse_0;
import protected.rsg_0;
import protected.rsg_1;
import protected.rsi_1;
import protected.rsj_0;
import protected.rsk_0;
import protected.rsk_1;
import protected.rsm;
import protected.rsm_0;
import protected.rsm_1;
import protected.rsn_0;
import protected.rso_0;
import protected.rsp_0;
import protected.rsr_0;
import protected.rsu_0;
import protected.rsu_2;
import protected.rsv_0;
import protected.rsw_0;
import protected.rsy_1;
import protected.rud_1;
import protected.rus_2;
import protected.ruu_1;
import protected.ruz_1;
import protected.rva_1;
import protected.rva_2;
import protected.rvb_1;
import protected.rvc_1;
import protected.rvc_2;
import protected.rvd_1;
import protected.rve_1;
import protected.rve_2;
import protected.rvf_1;
import protected.rvf_2;
import protected.rvg_1;
import protected.rvg_2;
import protected.rvh_1;
import protected.rvh_2;
import protected.rvi_1;
import protected.rvi_2;
import protected.rvj_1;
import protected.rvj_2;
import protected.rvk_1;
import protected.rvl_0;
import protected.rvl_1;
import protected.rvl_2;
import protected.rvm_1;
import protected.rvm_2;
import protected.rvn_1;
import protected.rvn_2;
import protected.rvo_1;
import protected.rvo_2;
import protected.rvp_1;
import protected.rvp_2;
import protected.rvq_1;
import protected.rvq_2;
import protected.rvr_2;
import protected.rvs_1;
import protected.rvs_2;
import protected.rvt_1;
import protected.rvt_2;
import protected.rvu_1;
import protected.rvu_2;
import protected.rvv_1;
import protected.rvv_2;
import protected.rvw_1;
import protected.rvw_2;
import protected.rvx_2;
import protected.rvy_1;
import protected.rvy_2;
import protected.rvz_1;
import protected.rvz_2;
import protected.rwb_2;
import protected.rxa_1;
import protected.rxi_0;
import protected.rxq_1;
import protected.ryg_2;
import protected.ryo_2;
import protected.rys_1;
import protected.rys_2;
import protected.rzi_0;
import protected.rzn_0;
import protected.rzq_0;
import protected.rzr_0;
import protected.rzs_0;
import protected.rzx_0;
import protected.vg_1;
import protected.vg_2;
import protected.vm_1;
import protected.vu_2;
import protected.vz_2;
import protected.xc_0;
import protected.xd_0;
import protected.ye_2;
import protected.yf_1;
import protected.yj_2;
import protected.yk_2;
import protected.yx_1;
import protected.zg_0;
import protected.zs_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.Aq
 */
public class aq_1
implements at_1 {
    private static final Logger break = LogManager.getLogger();
    public static final rgP class = new rgn("disconnect.lost");
    private final rud_1 byte;
    private final GameProfile protected;
    private final vm_1 throws;
    private qy_1 case;
    private gm catch;
    private gv_0 private;
    private boolean implements;
    private final Map<UUID, aw_1> finally = Maps.newHashMap();
    private final ab_1 extends;
    private final ax_2 native;
    private rlq_0 volatile = rlq_0.class;
    private final gg_0 final = new gg_0(this);
    private int package = 3;
    private final Random int = new Random();
    private CommandDispatcher<gR> new = new CommandDispatcher();
    private final rwb_2 continue = new rwb_2();
    private final UUID super = UUID.randomUUID();
    private Set<rqm_0<rYB>> this;
    private rVm else = rVm.break();

    public void byte() {
        this.catch = null;
    }

    public aq_1(qy_1 qy_12, vm_1 vm_12, rud_1 rud_12, GameProfile gameProfile) {
        this.case = qy_12;
        this.throws = vm_12;
        this.byte = rud_12;
        this.protected = gameProfile;
        this.extends = new ab_1(qy_12);
        this.native = new ax_2(this, qy_12);
    }

    @Override
    public void class(rvv_2 rvv_22) {
        this.class(new rzr_0(rvv_22.break()));
    }

    @Override
    public void class(rvf_1 rvf_12) {
        ruz_1.class(rvf_12, this, this.case);
        cb_1 cb_12 = (cb_1)this.case.class[57];
        ((rhx_1)cb_12.implements[18]).break = rvf_12.byte();
        ((rhx_1)cb_12.implements[18]).protected = rvf_12.throws();
        ((rhx_1)cb_12.implements[18]).class = rvf_12.break();
        ((rhx_1)cb_12.implements[18]).byte = rvf_12.protected();
        ((rhx_1)cb_12.implements[18]).class(rvf_12.case());
        ((rhx_1)cb_12.implements[18]).break(rvf_12.catch());
    }

    @Override
    public void class(rvt_1 rvt_12) {
        ruz_1.class(rvt_12, this, this.case);
        ((gm)this.case.class[56]).class((cb_1)this.case.class[57], rvt_12.protected(), rvt_12.throws(), rvt_12.case(), rvt_12.break(), rvt_12.byte(), rvt_12.catch(), rvt_12.private());
    }

    @Override
    public void class(rfx_2 rfx_22) {
        ruz_1.class(rfx_22, this, this.case);
        an an2 = this.catch.break(rfx_22.protected());
        if (an2 != null) {
            ((gm)this.case.class[56]).class((rhd_2)((cb_1)this.case.class[57]), an2, rfx_22.break(), rfx_22.byte(), rfx_22.throws(), rfx_22.case());
        }
    }

    @Override
    public void class(rvg_1 rvg_12) {
        ruz_1.class(rvg_12, this, this.case);
        aw_1 aw_12 = null;
        for (rvo_1 rvo_12 : rvg_12.break()) {
            if (rvg_12.byte() == rvy_1.REMOVE_PLAYER) {
                this.case.volatile().case(rvo_12.class().getId());
                aw_12 = this.finally.remove(rvo_12.class().getId());
                continue;
            }
            aw_12 = this.finally.get(rvo_12.class().getId());
            if (rvg_12.byte() == rvy_1.ADD_PLAYER) {
                aw_12 = new aw_1(rvo_12);
                this.finally.put(aw_12.class().getId(), aw_12);
                this.case.volatile().class(aw_12);
            }
            if (aw_12 == null) continue;
            switch (rvg_12.byte()) {
                case ADD_PLAYER: {
                    aw_12.class(rvo_12.byte());
                    aw_12.class(rvo_12.break());
                    aw_12.class(rvo_12.protected());
                    break;
                }
                case UPDATE_GAME_MODE: {
                    aw_12.class(rvo_12.byte());
                    break;
                }
                case UPDATE_LATENCY: {
                    aw_12.class(rvo_12.break());
                    break;
                }
                case UPDATE_DISPLAY_NAME: {
                    aw_12.class(rvo_12.protected());
                }
            }
        }
        if (aw_12 != null) {
            ((rrqx_1)rrqx_1.staticFields09f1f28026cd378cb9df490a64ac8f2a[0]).finally().class(rrln_2.class(aw_12, rvg_12.byte()));
        }
    }

    @Override
    public void class(rfr_2 rfr_22) {
        ruz_1.class(rfr_22, this, this.case);
        an an2 = rfr_22.class(this.catch);
        if (an2 instanceof ib_0) {
            ((ib_0)an2).class(rfr_22.break());
        }
    }

    @Override
    public void class(rvv_1 rvv_12) {
        ((cq_1)this.case.class[19]).implements().break(rvv_12.break().getString().isEmpty() ? null : rvv_12.break());
        ((cq_1)this.case.class[19]).implements().class(rvv_12.byte().getString().isEmpty() ? null : rvv_12.byte());
    }

    public void class(rzn_0 rzn_02) {
        this.byte.class(new rzq_0(rzn_02));
    }

    @Override
    public void class(rfv_1 rfv_12) {
        ruz_1.class(rfv_12, this, this.case);
        ((cq_1)this.case.class[19]).extends().class(rfv_12);
    }

    @Override
    public void class(rvs_1 rvs_12) {
        ruz_1.class(rvs_12, this, this.case);
        if (((rrqx_1)rrqx_1.staticFields09f1f28026cd378cb9df490a64ac8f2a[0]).finally().class(rrln_1.class(rvs_12)).byte()) {
            return;
        }
        if (rvs_12.byte() == 0) {
            ((cb_1)this.case.class[57]).sK().break(rvs_12.break());
        } else {
            ((cb_1)this.case.class[57]).sK().class(rvs_12.break(), rvs_12.byte());
        }
        ((rrqx_1)rrqx_1.staticFields09f1f28026cd378cb9df490a64ac8f2a[0]).finally().class(rrla_2.class(rvs_12));
    }

    @Override
    public void class(rvn_1 rvn_12) {
        ruz_1.class(rvn_12, this, this.case);
        an an2 = ((cb_1)this.case.class[57]).PO();
        if (an2 != (cb_1)this.case.class[57] && an2.Po()) {
            an2.break(rvn_12.break(), rvn_12.byte(), rvn_12.protected(), rvn_12.throws(), rvn_12.case());
            this.byte.class(new rzs_0(an2));
        }
    }

    private void class(CompletableFuture<?> completableFuture) {
        ((CompletableFuture)completableFuture.thenRun(() -> this.class(rzn_0.SUCCESSFULLY_LOADED))).exceptionally(throwable -> {
            this.class(rzn_0.FAILED_DOWNLOAD);
            return null;
        });
    }

    @Override
    public void class(rfs_1 rfs_12) {
        String string = rfs_12.break();
        String string2 = rfs_12.byte();
        if (this.break(string)) {
            if (string.startsWith("level://")) {
                File file = new File((File)this.case.class[24], "saves");
                String string3 = URLDecoder.decode(string.substring("level://".length()), StandardCharsets.UTF_8);
                File file2 = new File(file, string3);
                if (file2.isFile()) {
                    this.class(rzn_0.ACCEPTED);
                    CompletableFuture<Void> completableFuture = this.case.Z().class(file2, raz_1.byte);
                    this.class(completableFuture);
                    return;
                }
                this.class(rzn_0.FAILED_DOWNLOAD);
            } else {
                ak_2 ak_22 = this.case.S();
                if (ak_22 != null && ak_22.break() == az_2.ENABLED) {
                    this.class(rzn_0.ACCEPTED);
                    this.class(this.case.Z().class(string, string2));
                } else if (ak_22 != null && ak_22.break() != az_2.PROMPT) {
                    this.class(rzn_0.DECLINED);
                } else {
                    this.case.execute(() -> this.case.break(new mt_0(bl2 -> {
                        this.case = qy_1.instanceof();
                        ak_2 ak_22 = this.case.S();
                        if (bl2) {
                            if (ak_22 != null) {
                                ak_22.class(az_2.ENABLED);
                            }
                            this.class(rzn_0.ACCEPTED);
                            this.class(this.case.Z().class(string, string2));
                        } else {
                            if (ak_22 != null) {
                                ak_22.class(az_2.DISABLED);
                            }
                            this.class(rzn_0.DECLINED);
                        }
                        aq_2.byte(ak_22);
                        this.case.break((vm_1)null);
                    }, new rgn("multiplayer.texturePrompt.line1"), new rgn("multiplayer.texturePrompt.line2"))));
                }
            }
        }
    }

    @Override
    public void class(rvi_2 rvi_22) {
        ruz_1.class(rvi_22, this, this.case);
        this.case.c().class(new np_1(rvi_22.break(), rvi_22.byte(), rvi_22.catch(), rvi_22.private(), false, 0, nn_2.LINEAR, rvi_22.protected(), rvi_22.throws(), rvi_22.case(), false));
    }

    @Override
    public void class(rvk_1 rvk_12) {
        ruz_1.class(rvk_12, this, this.case);
        rjU rjU2 = rvk_12.class(this.catch);
        if (rjU2 != null) {
            ((cb_1)this.case.class[57]).class(rvk_12.break(), rjU2);
        }
    }

    @Override
    public void class(rve_1 rve_12) {
        ruz_1.class(rve_12, this, this.case);
        if (!this.final.class(rve_12.break(), rve_12.byte())) {
            break.debug("Got unhandled response to tag query {}", (Object)rve_12.break());
        }
    }

    @Override
    public void class(rfw_2 rfw_22) {
        ruz_1.class(rfw_22, this, this.case);
        for (Map.Entry<rCi<?>, Integer> entry : rfw_22.break().entrySet()) {
            rCi<?> rCi2 = entry.getKey();
            int n2 = entry.getValue();
            ((cb_1)this.case.class[57]).abstract().class((cb_1)this.case.class[57], rCi2, n2);
        }
        if ((vm_1)this.case.class[73] instanceof cy_2) {
            ((cy_2)((Object)((vm_1)this.case.class[73]))).break();
        }
    }

    @Override
    public void class(rvt_2 rvt_22) {
        rlr_1 rlr_12;
        ruz_1.class(rvt_22, this, this.case);
        an an2 = this.catch.break(rvt_22.byte());
        if (an2 instanceof ib_0 && (rlr_12 = rlr_1.class(rvt_22.protected())) != null) {
            rly_1 rly_12 = new rly_1(rlr_12, rvt_22.case(), rvt_22.throws(), rvt_22.private(), rvt_22.catch(), rvt_22.implements());
            rly_12.class(rvt_22.break());
            ((ib_0)an2).byte(rly_12);
        }
    }

    @Override
    public void class(rfl_1 rfl_12) {
        ruz_1.class(rfl_12, this, this.case);
        this.continue.class(rfl_12.break());
        Vo<mg_0> vo = this.case.class(gj_0.byte);
        vo.class();
        VR vR = ((cb_1)this.case.class[57]).Z();
        vR.class(this.continue.break());
        vR.class().forEach(vo::class);
        vo.break();
    }

    @Override
    public void class(rfq_2 rfq_22) {
        ruz_1.class(rfq_22, this, this.case);
        this.native.class(rfq_22.break(), rfq_22.byte());
    }

    @Override
    public void class(rfz_2 rfz_22) {
        ruz_1.class(rfz_22, this, this.case);
        this.case.c().class(rfz_22.break(), rfz_22.byte());
    }

    @Override
    public void class(rfu_2 rfu_22) {
        ruz_1.class(rfu_22, this, this.case);
        rfm_1 rfm_12 = rfu_22.break();
        rgP rgP2 = null;
        rgP rgP3 = null;
        rgP rgP4 = rfu_22.byte() != null ? rfu_22.byte() : rgn_0.byte;
        switch (rfm_12) {
            case TITLE: {
                rgP2 = rgP4;
                break;
            }
            case SUBTITLE: {
                rgP3 = rgP4;
                break;
            }
            case ACTIONBAR: {
                if (!rgP4.getString().isEmpty()) {
                    ((cq_1)this.case.class[19]).class(rgP4, false, false);
                }
                return;
            }
            case RESET: {
                ((cq_1)this.case.class[19]).class(null, null, -1, -1, -1);
                ((cq_1)this.case.class[19]).class();
                return;
            }
        }
        ((cq_1)this.case.class[19]).class(rgP2, rgP3, rfu_22.protected(), rfu_22.throws(), rfu_22.case());
    }

    @Override
    public void class(rfw_1 rfw_12) {
        ruz_1.class(rfw_12, this, this.case);
        rfw_12.class(this.catch.instanceof());
    }

    @Override
    public void class(rZg rZg2) {
        ruz_1.class(rZg2, this, this.case);
        an an2 = rZg2.class(this.catch);
        if (an2 != null) {
            this.case.break(an2);
        }
    }

    @Override
    public void class(rfe_2 rfe_22) {
        ruz_1.class(rfe_22, this, this.case);
        this.private.class(rfe_22.byte());
        this.private.break(rfe_22.break());
    }

    @Override
    public void class(rZa rZa2) {
        an an2;
        ruz_1.class(rZa2, this, this.case);
        if (rZa2.class == rvr_2.ENTITY_DIED && (an2 = this.catch.break(rZa2.break)) == (cb_1)this.case.class[57]) {
            if (((cb_1)this.case.class[57]).d()) {
                ((break)protected.break.staticFieldsf9703d96375232b196815afd59d1eb48[0]).class();
                ((rrqx_1)rrqx_1.staticFields09f1f28026cd378cb9df490a64ac8f2a[0]).finally().class(rrag_0.class(an2.Ps()));
                this.case.break(new zs_0(rZa2.throws, this.catch.synchronized().implements()));
            } else {
                ((cb_1)this.case.class[57]).J();
            }
        }
    }

    @Override
    public void class(rfn_2 rfn_22) {
        ruz_1.class(rfn_22, this, this.case);
        rlq_0 rlq_02 = rfn_22.break();
        Multimap<rqo_0, rqo_0> multimap = rla_0.break(rlq_02);
        if (!multimap.isEmpty()) {
            break.warn("Incomplete server tags, disconnecting. Missing: {}", multimap);
            this.byte.class(new rgn("multiplayer.disconnect.missing_tags"));
        } else {
            this.volatile = rlq_02;
            if (!this.byte.protected()) {
                rlq_02.throws();
            }
            this.case.class(gj_0.break).break();
        }
    }

    public aw_1 class(UUID uUID) {
        return this.finally.get(uUID);
    }

    public aw_1 class(String string) {
        for (aw_1 aw_12 : this.finally.values()) {
            if (!aw_12.class().getName().equals(string)) continue;
            return aw_12;
        }
        return null;
    }

    @Override
    public rud_1 class() {
        return this.byte;
    }

    private void class(int n2, int n3, rrse rrse2, rRo rRo2, int n4, int n5, Iterator<byte[]> iterator, boolean bl2) {
        for (int k = 0; k < 18; ++k) {
            boolean bl3;
            int n6 = -1 + k;
            boolean bl4 = (n4 & 1 << k) != 0;
            boolean bl5 = bl3 = (n5 & 1 << k) != 0;
            if (!bl4 && !bl3) continue;
            rrse2.class(rRo2, rjh_0.class(n2, n6, n3), bl4 ? new roH((byte[])iterator.next().clone()) : new roH(), bl2);
            this.catch.break(n2, n6, n3);
        }
    }

    @Override
    public void class(rvj_1 rvj_12) {
        ruz_1.class(rvj_12, this, this.case);
        ((ax_1)this.case.class[55]).class(this.catch, rvj_12.byte(), rvj_12.break(), rvj_12.throws(), rvj_12.protected());
    }

    @Override
    public void class(rva_1 rva_12) {
        ruz_1.class(rva_12, this, this.case);
        VR vR = ((cb_1)this.case.class[57]).Z();
        vR.class(rva_12.protected());
        rvi_1 rvi_12 = rva_12.throws();
        switch (rvi_12) {
            case REMOVE: {
                for (rqo_0 rqo_02 : rva_12.break()) {
                    this.continue.class(rqo_02).ifPresent(vR::byte);
                }
                break;
            }
            case INIT: {
                for (rqo_0 rqo_03 : rva_12.break()) {
                    this.continue.class(rqo_03).ifPresent(vR::class);
                }
                for (rqo_0 rqo_03 : rva_12.byte()) {
                    this.continue.class(rqo_03).ifPresent(vR::case);
                }
                break;
            }
            case ADD: {
                for (rqo_0 rqo_04 : rva_12.break()) {
                    this.continue.class(rqo_04).ifPresent(rkw_22 -> {
                        vR.class((rkw_2<?>)rkw_22);
                        vR.case((rkw_2<?>)rkw_22);
                    });
                }
                break;
            }
        }
        vR.class().forEach(mg_02 -> mg_02.class(vR));
        if ((vm_1)this.case.class[73] instanceof mb_0) {
            ((mb_0)((Object)((vm_1)this.case.class[73]))).class();
        }
    }

    @Override
    public void class(rfh_1 rfh_12) {
        ruz_1.class(rfh_12, this, this.case);
        rns_0 rns_02 = this.catch.package();
        String string = rfh_12.byte();
        switch (rfh_12.throws()) {
            case CHANGE: {
                rnp_0 rnp_02 = rns_02.break(string);
                raa_1 raa_12 = rns_02.break(rfh_12.break(), rnp_02);
                raa_12.break(rfh_12.protected());
                break;
            }
            case REMOVE: {
                rns_02.byte(rfh_12.break(), rns_02.byte(string));
            }
        }
    }

    @Override
    public void class(rvm_2 rvm_22) {
        ruz_1.class(rvm_22, this, this.case);
        rns_0 rns_02 = this.catch.package();
        String string = rvm_22.byte();
        rnp_0 rnp_02 = string == null ? null : rns_02.break(string);
        rns_02.class(rvm_22.break(), rnp_02);
    }

    @Override
    public void class(rfc_2 rfc_22) {
        ruz_1.class(rfc_22, this, this.case);
        rns_0 rns_02 = this.catch.package();
        rnb_0 rnb_02 = rfc_22.throws() == 0 ? rns_02.case(rfc_22.break()) : rns_02.throws(rfc_22.break());
        if (rfc_22.throws() == 0 || rfc_22.throws() == 2) {
            Object object;
            rnb_02.class(rfc_22.byte());
            rnb_02.class(rfc_22.catch());
            rnb_02.class(rfc_22.case());
            rnx_0 rnx_02 = rnx_0.class(rfc_22.private());
            if (rnx_02 != null) {
                rnb_02.class(rnx_02);
            }
            if ((object = rnh_0.class(rfc_22.implements())) != null) {
                rnb_02.class((rnh_0)((Object)object));
            }
            rnb_02.break(rfc_22.finally());
            rnb_02.byte(rfc_22.extends());
        }
        if (rfc_22.throws() == 0 || rfc_22.throws() == 3) {
            for (Object object : rfc_22.protected()) {
                rns_02.class((String)object, rnb_02);
                ((rrqx_1)rrqx_1.staticFields09f1f28026cd378cb9df490a64ac8f2a[0]).finally().class(rrll_2.class(new aw_1(new GameProfile(UUID.randomUUID(), object)), rfc_22.finally()));
            }
        }
        if (rfc_22.throws() == 4) {
            for (Object object : rfc_22.protected()) {
                ((rrqx_1)rrqx_1.staticFields09f1f28026cd378cb9df490a64ac8f2a[0]).finally().class(rrll_2.class(new aw_1(new GameProfile(UUID.randomUUID(), object)), rfc_22.finally()));
                rns_02.break((String)object, rnb_02);
            }
        }
        if (rfc_22.throws() == 1) {
            rns_02.class(rnb_02);
        }
    }

    @Override
    public void class(rfd_2 rfd_22) {
        ruz_1.class(rfd_22, this, this.case);
        double d = rfd_22.byte();
        double d2 = rfd_22.protected();
        double d3 = rfd_22.throws();
        if (Double.isInfinite(d) || Double.isInfinite(d2) || Double.isInfinite(d3)) {
            rrfZ.class();
            return;
        }
        if (rfd_22.finally() == 0) {
            double d4 = rfd_22.implements() * rfd_22.case();
            double d5 = rfd_22.implements() * rfd_22.catch();
            double d6 = rfd_22.implements() * rfd_22.private();
            try {
                this.catch.class(rfd_22.extends(), rfd_22.break(), d, d2, d3, d4, d5, d6);
            }
            catch (Throwable throwable) {
                break.warn("Could not spawn particle effect {}", (Object)rfd_22.extends());
            }
        } else {
            for (int k = 0; k < rfd_22.finally(); ++k) {
                double d7 = this.int.nextGaussian() * (double)rfd_22.case();
                double d8 = this.int.nextGaussian() * (double)rfd_22.catch();
                double d9 = this.int.nextGaussian() * (double)rfd_22.private();
                double d10 = this.int.nextGaussian() * (double)rfd_22.implements();
                double d11 = this.int.nextGaussian() * (double)rfd_22.implements();
                double d12 = this.int.nextGaussian() * (double)rfd_22.implements();
                try {
                    this.catch.class(rfd_22.extends(), rfd_22.break(), d + d7, d2 + d8, d3 + d9, d10, d11, d12);
                    continue;
                }
                catch (Throwable throwable) {
                    break.warn("Could not spawn particle effect {}", (Object)rfd_22.extends());
                    return;
                }
            }
        }
    }

    @Override
    public void class(rfb_2 rfb_22) {
        ruz_1.class(rfb_22, this, this.case);
        rns_0 rns_02 = this.catch.package();
        String string = rfb_22.break();
        if (rfb_22.protected() == 0) {
            rns_02.class(string, rai_1.break, rfb_22.byte(), rfb_22.throws());
        } else if (rns_02.class(string)) {
            rnp_0 rnp_02 = rns_02.byte(string);
            if (rfb_22.protected() == 1) {
                rns_02.byte(rnp_02);
            } else if (rfb_22.protected() == 2) {
                rnp_02.class(rfb_22.throws());
                rnp_02.class(rfb_22.byte());
            }
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Override
    public void class(rve_2 rve_22) {
        ruz_1.class(rve_22, this, this.case);
        rqo_0 rqo_02 = rve_22.break();
        ruu_1 ruu_12 = null;
        try {
            ruu_12 = rve_22.byte();
            if (rve_2.class.equals(rqo_02)) {
                ((cb_1)this.case.class[57]).byte(ruu_12.throws(Short.MAX_VALUE));
            } else if (rve_2.break.equals(rqo_02)) {
                int n2 = ruu_12.readInt();
                float f2 = ruu_12.readFloat();
                rlc_1 rlc_12 = rlc_1.class(ruu_12);
                ((yk_2)this.case.class[17]).class.class(n2, rlc_12, f2);
            } else if (rve_2.byte.equals(rqo_02)) {
                long l2 = ruu_12.catch();
                rfH rfH2 = ruu_12.byte();
                ((ps_0)((yk_2)this.case.class[17]).case).class(l2, rfH2);
            } else if (rve_2.protected.equals(rqo_02)) {
                rfH rfH3 = ruu_12.byte();
                int n3 = ruu_12.readInt();
                ArrayList arrayList = Lists.newArrayList();
                ArrayList arrayList2 = Lists.newArrayList();
                for (int k = 0; k < n3; ++k) {
                    arrayList.add(ruu_12.byte());
                    arrayList2.add(Float.valueOf(ruu_12.readFloat()));
                }
                ((yk_2)this.case.class[17]).catch.class(rfH3, arrayList, arrayList2);
            } else if (rve_2.throws.equals(rqo_02)) {
                rrj_0 rrj_02 = this.else.class().class(ruu_12.volatile());
                rfi rfi2 = new rfi(ruu_12.readInt(), ruu_12.readInt(), ruu_12.readInt(), ruu_12.readInt(), ruu_12.readInt(), ruu_12.readInt());
                int n4 = ruu_12.readInt();
                ArrayList arrayList = Lists.newArrayList();
                ArrayList arrayList3 = Lists.newArrayList();
                for (int k = 0; k < n4; ++k) {
                    arrayList.add(new rfi(ruu_12.readInt(), ruu_12.readInt(), ruu_12.readInt(), ruu_12.readInt(), ruu_12.readInt(), ruu_12.readInt()));
                    arrayList3.add(ruu_12.readBoolean());
                }
                ((yk_2)this.case.class[17]).private.class(rfi2, arrayList, arrayList3, rrj_02);
            } else if (rve_2.case.equals(rqo_02)) {
                ((px)((yk_2)this.case.class[17]).finally).class(ruu_12.byte(), ruu_12.readFloat(), ruu_12.readFloat(), ruu_12.readFloat(), ruu_12.readFloat(), ruu_12.readFloat());
            } else if (rve_2.finally.equals(rqo_02)) {
                int n5;
                int n6 = ruu_12.readInt();
                for (n5 = 0; n5 < n6; ++n5) {
                    ((yk_2)this.case.class[17]).final.class(ruu_12.protected());
                }
                n5 = ruu_12.readInt();
                for (int k = 0; k < n5; ++k) {
                    ((yk_2)this.case.class[17]).final.break(ruu_12.protected());
                }
            } else if (rve_2.private.equals(rqo_02)) {
                rfH rfH4 = ruu_12.byte();
                String string = ruu_12.native();
                int n7 = ruu_12.readInt();
                pb pb2 = new pb(rfH4, string, n7);
                ((yk_2)this.case.class[17]).volatile.class(pb2);
            } else if (rve_2.implements.equals(rqo_02)) {
                rfH rfH5 = ruu_12.byte();
                ((yk_2)this.case.class[17]).volatile.class(rfH5);
            } else if (rve_2.catch.equals(rqo_02)) {
                rfH rfH6 = ruu_12.byte();
                int n8 = ruu_12.readInt();
                ((yk_2)this.case.class[17]).volatile.class(rfH6, n8);
            } else if (rve_2.extends.equals(rqo_02)) {
                rfH rfH7 = ruu_12.byte();
                int n9 = ruu_12.readInt();
                int n10 = ruu_12.readInt();
                ArrayList arrayList = Lists.newArrayList();
                for (int k = 0; k < n10; ++k) {
                    int n11 = ruu_12.readInt();
                    boolean bl2 = ruu_12.readBoolean();
                    String string = ruu_12.throws(255);
                    arrayList.add(new ye_2(rfH7, n11, string, bl2));
                }
                ((yk_2)this.case.class[17]).new.class(n9, arrayList);
            } else if (rve_2.new.equals(rqo_02)) {
                int n12 = ruu_12.readInt();
                ArrayList arrayList = Lists.newArrayList();
                for (int k = 0; k < n12; ++k) {
                    arrayList.add(ruu_12.byte());
                }
                ((yk_2)this.case.class[17]).int.class(arrayList);
            } else if (rve_2.native.equals(rqo_02)) {
                int n13;
                int n14;
                int n15;
                int n16;
                int n17;
                double d = ruu_12.readDouble();
                double d2 = ruu_12.readDouble();
                double d3 = ruu_12.readDouble();
                ex ex2 = new ex(d, d2, d3);
                UUID uUID = ruu_12.private();
                int n18 = ruu_12.readInt();
                String string = ruu_12.native();
                String string2 = ruu_12.native();
                int n19 = ruu_12.readInt();
                float f3 = ruu_12.readFloat();
                float f4 = ruu_12.readFloat();
                String string3 = ruu_12.native();
                boolean bl3 = ruu_12.readBoolean();
                rlc_1 rlc_13 = bl3 ? rlc_1.class(ruu_12) : null;
                boolean bl4 = ruu_12.readBoolean();
                pg_0 pg_02 = new pg_0(uUID, n18, string, string2, n19, f3, f4, ex2, string3, rlc_13, bl4);
                int n20 = ruu_12.readInt();
                for (n17 = 0; n17 < n20; ++n17) {
                    String string4 = ruu_12.native();
                    pg_02.native.add(string4);
                }
                n17 = ruu_12.readInt();
                for (n16 = 0; n16 < n17; ++n16) {
                    String string5 = ruu_12.native();
                    pg_02.volatile.add(string5);
                }
                n16 = ruu_12.readInt();
                for (n15 = 0; n15 < n16; ++n15) {
                    String string6 = ruu_12.native();
                    pg_02.final.add(string6);
                }
                n15 = ruu_12.readInt();
                for (n14 = 0; n14 < n15; ++n14) {
                    rfH rfH8 = ruu_12.byte();
                    pg_02.int.add(rfH8);
                }
                n14 = ruu_12.readInt();
                for (n13 = 0; n13 < n14; ++n13) {
                    rfH rfH9 = ruu_12.byte();
                    pg_02.new.add(rfH9);
                }
                n13 = ruu_12.readInt();
                for (int k = 0; k < n13; ++k) {
                    String string7 = ruu_12.native();
                    pg_02.package.add(string7);
                }
                ((yk_2)this.case.class[17]).volatile.class(pg_02);
            } else if (rve_2.volatile.equals(rqo_02)) {
                int n21;
                double d = ruu_12.readDouble();
                double d4 = ruu_12.readDouble();
                double d5 = ruu_12.readDouble();
                ex ex3 = new ex(d, d4, d5);
                UUID uUID = ruu_12.private();
                int n22 = ruu_12.readInt();
                boolean bl5 = ruu_12.readBoolean();
                rfH rfH10 = null;
                if (bl5) {
                    rfH10 = ruu_12.byte();
                }
                boolean bl6 = ruu_12.readBoolean();
                rfH rfH11 = null;
                if (bl6) {
                    rfH11 = ruu_12.byte();
                }
                int n23 = ruu_12.readInt();
                boolean bl7 = ruu_12.readBoolean();
                rlc_1 rlc_14 = null;
                if (bl7) {
                    rlc_14 = rlc_1.class(ruu_12);
                }
                yf_1 yf_12 = new yf_1(uUID, n22, ex3, rlc_14, rfH10, rfH11, n23);
                int n24 = ruu_12.readInt();
                for (n21 = 0; n21 < n24; ++n21) {
                    String string = ruu_12.native();
                    yf_12.private.add(string);
                }
                n21 = ruu_12.readInt();
                for (int k = 0; k < n21; ++k) {
                    rfH rfH12 = ruu_12.byte();
                    yf_12.implements.add(rfH12);
                }
                ((yk_2)this.case.class[17]).package.class(yf_12);
            } else if (rve_2.final.equals(rqo_02)) {
                rfH rfH13 = ruu_12.byte();
                String string = ruu_12.native();
                int n25 = ruu_12.readInt();
                int n26 = ruu_12.readInt();
                boolean bl8 = ruu_12.readBoolean();
                yj_2 yj_22 = new yj_2(rfH13, string, n25, n26, bl8, this.catch.r());
                ((yk_2)this.case.class[17]).package.class(yj_22);
            } else if (rve_2.int.equals(rqo_02)) {
                ((yk_2)this.case.class[17]).continue.class();
            } else if (rve_2.package.equals(rqo_02)) {
                rfH rfH14 = ruu_12.byte();
                int n27 = ruu_12.readInt();
                String string = ruu_12.native();
                int n28 = ruu_12.readInt();
                ((yk_2)this.case.class[17]).continue.class(rfH14, n27, string, n28);
            } else if (rqo_02.break().equals("custom_ping_packet") && rrja_0.protected().throws().byte(ProtocolVersion.v1_17_1)) {
                ruu_1 ruu_13 = new ruu_1(Unpooled.buffer());
                ruu_13.writeInt(rve_22.byte().readInt());
                this.byte.class(new rmy_0(rqo_02, ruu_13));
            } else {
                break.warn("Unknown custom packed identifier: {}", (Object)rqo_02);
            }
        }
        finally {
            if (ruu_12 != null) {
                ruu_12.release();
            }
        }
    }

    @Override
    public void class(rvl_1 rvl_12) {
        ruz_1.class(rvl_12, this, this.case);
        rdn_1 rdn_12 = ((cb_1)this.case.class[57]).protected(rvl_12.break());
        if (rdn_12.break() == rdy_2.dr) {
            this.case.break(new vz_2(new vu_2(rdn_12)));
        }
    }

    @Override
    public void class(rfa_2 rfa_22) {
        ruz_1.class(rfa_22, this, this.case);
        this.catch.native().break(rfa_22.break(), rfa_22.byte());
    }

    @Override
    public void class(rfq_1 rfq_12) {
        ruz_1.class(rfq_12, this, this.case);
        this.package = rfq_12.break();
        this.catch.native().class(rfq_12.break());
    }

    @Override
    public void class(rvl_2 rvl_22) {
        ruz_1.class(rvl_22, this, this.case);
        rjr_2 rjr_22 = (rjr_2)((cb_1)this.case.class[57]).implements[4];
        if (rvl_22.break() == rjr_22.case && rjr_22 instanceof rjp_1) {
            ((rjp_1)rjr_22).class(new rdf_1(rvl_22.byte().class()));
            ((rjp_1)rjr_22).throws(rvl_22.throws());
            ((rjp_1)rjr_22).case(rvl_22.protected());
            ((rjp_1)rjr_22).class(rvl_22.case());
            ((rjp_1)rjr_22).break(rvl_22.catch());
        }
    }

    @Override
    public void class(rfc_1 rfc_12) {
        ruz_1.class(rfc_12, this, this.case);
        int n2 = rfc_12.break();
        int n3 = rfc_12.byte();
        rrse rrse2 = this.catch.native().class();
        int n4 = rfc_12.protected();
        int n5 = rfc_12.throws();
        Iterator<byte[]> iterator = rfc_12.case().iterator();
        this.class(n2, n3, rrse2, rRo.SKY, n4, n5, iterator, rfc_12.finally());
        int n6 = rfc_12.catch();
        int n7 = rfc_12.private();
        Iterator<byte[]> iterator2 = rfc_12.implements().iterator();
        this.class(n2, n3, rrse2, rRo.BLOCK, n6, n7, iterator2, rfc_12.finally());
    }

    @Override
    public void class(rvq_1 rvq_12) {
        ruz_1.class(rvq_12, this, this.case);
        rjr_2 rjr_22 = (rjr_2)((cb_1)this.case.class[57]).implements[4];
        if (rjr_22.case == rvq_12.byte() && rjr_22.byte((cb_1)this.case.class[57])) {
            this.continue.class(rvq_12.break()).ifPresent(rkw_22 -> {
                if ((vm_1)this.case.class[73] instanceof mb_0) {
                    ms ms2 = ((mb_0)((Object)((vm_1)this.case.class[73]))).break();
                    ms2.class((rkw_2<?>)rkw_22, rjr_22.throws);
                }
            });
        }
    }

    @Override
    public void class(rvw_2 rvw_22) {
        ruz_1.class(rvw_22, this, this.case);
        an an2 = this.catch.break(rvw_22.break());
        if (an2 != null) {
            if (!(an2 instanceof ib_0)) {
                throw new IllegalStateException("Server tried to update attributes of a non-living entity (actually: " + an2 + ")");
            }
            ik_0 ik_02 = ((ib_0)an2).BT();
            for (rvz_2 rvz_22 : rvw_22.byte()) {
                ic_0 ic_02 = ik_02.class(rvz_22.class());
                if (ic_02 == null) {
                    break.warn("Entity {} does not have attribute {}", (Object)an2, (Object)rvl_0.O.break(rvz_22.class()));
                    continue;
                }
                ic_02.class(rvz_22.break());
                ic_02.throws();
                for (ix_0 ix_02 : rvz_22.byte()) {
                    ic_02.break(ix_02);
                }
            }
        }
    }

    @Override
    public void class(rvb_1 rvb_12) {
        this.byte.class(rvb_12.break());
    }

    @Override
    public void class(rgP rgP2, rgP rgP3) {
        this.case.transient();
        if (this.throws != null) {
            this.case.break(new zg_0(this.throws, rgP2, rgP3));
        } else {
            this.case.break(new zg_0(new vg_2(new rrvl_0()), rgP2, rgP3));
        }
    }

    public void class(rus_2<?> rus_22) {
        this.byte.class(rus_22);
    }

    @Override
    public void class(rvz_1 rvz_12) {
        gv_0 gv_02;
        ruz_1.class(rvz_12, this, this.case);
        ax_1 ax_12 = new ax_1(this.case, this);
        this.case.class[55] = ax_12;
        if (!this.byte.protected()) {
            rla_0.class();
        }
        ArrayList arrayList = Lists.newArrayList(rvz_12.catch());
        Collections.shuffle(arrayList);
        this.this = Sets.newLinkedHashSet((Iterable)arrayList);
        this.else = rvz_12.private();
        rqm_0<rYB> rqm_02 = rvz_12.finally();
        rrj_0 rrj_02 = rvz_12.implements();
        this.package = rvz_12.extends();
        boolean bl2 = rvz_12.final();
        boolean bl3 = rvz_12.package();
        this.private = gv_02 = new gv_0(rro_0.NORMAL, rvz_12.protected(), bl3);
        this.catch = new gm(this, gv_02, rqm_02, rrj_02, this.package, (yx_1)this.case.class[8], bl2, rvz_12.byte());
        this.case.class(this.catch);
        if ((cb_1)this.case.class[57] == null) {
            cb_1 cb_12 = ((ax_1)this.case.class[55]).class(this.catch, new rlp_0(), new VR());
            this.case.class[57] = cb_12;
            Float f2 = Float.valueOf(-180.0f);
            ((cb_1)this.case.class[57]).throws[15] = f2;
            if (this.case.this() != null) {
                this.case.this().class(((cb_1)this.case.class[57]).ro());
            }
        }
        ((yk_2)this.case.class[17]).class();
        ((cb_1)this.case.class[57]).Bc();
        int n2 = rvz_12.break();
        this.catch.class(n2, (cb_1)this.case.class[57]);
        rqp_0 rqp_02 = new rqp_0((qw_1)this.case.class[20]);
        ((cb_1)this.case.class[57]).break[17] = rqp_02;
        ((ax_1)this.case.class[55]).class((cb_1)this.case.class[57]);
        cb_1 cb_13 = (cb_1)this.case.class[57];
        this.case.class[62] = cb_13;
        this.case.break(new Zb());
        ((cb_1)this.case.class[57]).implements(n2);
        ((cb_1)this.case.class[57]).synchronized(rvz_12.native());
        ((cb_1)this.case.class[57]).throws(rvz_12.volatile());
        ((ax_1)this.case.class[55]).break(rvz_12.throws());
        ((ax_1)this.case.class[55]).class(rvz_12.case());
        ((qw_1)this.case.class[20]).byte();
        this.byte.class(new rmy_0(rmy_0.class, new ruu_1(Unpooled.buffer()).class(qn_1.class())));
        this.case.short().break();
    }

    @Override
    public void class(rZR rZR2) {
        ruz_1.class(rZR2, this, this.case);
        this.catch.class(rZR2.byte(), rZR2.break());
        ((break)protected.break.staticFieldsf9703d96375232b196815afd59d1eb48[0]).class(rZR2);
    }

    @Override
    public void class(rfz_1 rfz_12) {
        ((break)protected.break.staticFieldsf9703d96375232b196815afd59d1eb48[0]).class(rfz_12);
        ruz_1.class(rfz_12, this, this.case);
        int n2 = rfz_12.break();
        int n3 = rfz_12.byte();
        ao_2 ao_22 = this.catch.native();
        ao_22.class(n2, n3);
        rrse rrse2 = ao_22.class();
        for (int k = 0; k < 16; ++k) {
            this.catch.break(n2, k, n3);
            rrse2.class(rjh_0.class(n2, k, n3), true);
        }
        rrse2.class(new rfj(n2, n3), false);
        ((break)protected.break.staticFieldsf9703d96375232b196815afd59d1eb48[0]).break(rfz_12);
    }

    @Override
    public void class(rZD rZD2) {
        ruz_1.class(rZD2, this, this.case);
        int n2 = rZD2.byte();
        int n3 = rZD2.protected();
        rYZ rYZ2 = rZD2.implements() == null ? null : new rYZ(this.else.break(rvl_0.n), rZD2.implements());
        roj_0 roj_02 = this.catch.native().class(n2, n3, rYZ2, rZD2.break(), rZD2.catch(), rZD2.throws(), rZD2.case());
        if (roj_02 != null && rZD2.case()) {
            this.catch.break(roj_02);
        }
        for (int k = 0; k < 16; ++k) {
            this.catch.break(n2, k, n3);
        }
        for (rcd_2 rcd_22 : rZD2.private()) {
            rfH rfH2 = new rfH(rcd_22.private("x"), rcd_22.private("y"), rcd_22.private("z"));
            ryo_2 ryo_22 = this.catch.class(rfH2);
            ((rrqx_1)rrqx_1.staticFields09f1f28026cd378cb9df490a64ac8f2a[0]).finally().class(rrno_0.class(ryo_22, rfH2));
            if (ryo_22 == null) continue;
            ryo_22.class(this.catch.byte(rfH2), rcd_22);
        }
        ((break)protected.break.staticFieldsf9703d96375232b196815afd59d1eb48[0]).class(rZD2);
    }

    @Override
    public void class(rfh_2 rfh_22) {
        ruz_1.class(rfh_22, this, this.case);
        double d = rfh_22.throws();
        double d2 = rfh_22.case();
        double d3 = rfh_22.catch();
        float f2 = (float)(rfh_22.extends() * 360) / 256.0f;
        float f3 = (float)(rfh_22.native() * 360) / 256.0f;
        ib_0 ib_02 = (ib_0)ai_0.class(rfh_22.protected(), (rYB)((gm)this.case.class[56]));
        if (ib_02 != null) {
            ib_02.byte(d, d2, d3);
            Float f4 = Float.valueOf((float)(rfh_22.volatile() * 360) / 256.0f);
            ib_02.private[23] = f4;
            Float f5 = Float.valueOf((float)(rfh_22.volatile() * 360) / 256.0f);
            ib_02.private[25] = f5;
            if (ib_02 instanceof rsu_2) {
                rsm_1[] rsm_1Array = ((rsu_2)ib_02).implements();
                for (int k = 0; k < rsm_1Array.length; ++k) {
                    rsm_1Array[k].implements(k + rfh_22.break());
                }
            }
            ib_02.implements(rfh_22.break());
            ib_02.a_(rfh_22.byte());
            ib_02.break(d, d2, d3, f2, f3);
            ib_02.catch((float)rfh_22.private() / 8000.0f, (float)rfh_22.implements() / 8000.0f, (float)rfh_22.finally() / 8000.0f);
            this.catch.class(rfh_22.break(), (an)ib_02);
            if (ib_02 instanceof rbf_0) {
                boolean bl2 = ((rbf_0)ib_02).T_();
                nb_1 nb_12 = bl2 ? new ne_2((rbf_0)ib_02) : new ng_2((rbf_0)ib_02);
                this.case.c().class(nb_12);
            }
        }
    }

    @Override
    public void class(rfp_1 rfp_12) {
        ruz_1.class(rfp_12, this, this.case);
        ((gm)this.case.class[56]).class(rfp_12.break());
        ((gm)this.case.class[56]).break(rfp_12.byte());
    }

    @Override
    public void class(rfj_1 rfj_12) {
        ruz_1.class(rfj_12, this, this.case);
        ((gm)this.case.class[56]).break(rfj_12.break(), rfj_12.byte());
    }

    @Override
    public void class(rfb_1 rfb_12) {
        ruz_1.class(rfb_12, this, this.case);
        an an2 = this.catch.break(rfb_12.byte());
        if (an2 == null) {
            break.warn("Received passengers for unknown entity");
        } else {
            boolean bl2 = an2.else((cb_1)this.case.class[57]);
            an2.Bn();
            for (int n2 : rfb_12.break()) {
                an an3 = this.catch.break(n2);
                if (an3 == null) continue;
                an3.class(an2, true);
                if (an3 != (cb_1)this.case.class[57] || bl2) continue;
                ((cq_1)this.case.class[19]).class(new rgn("mount.onboard", ((qw_1)this.case.class[20]).k.native()), false, false);
            }
        }
    }

    @Override
    public void class(rZj rZj2) {
        ruz_1.class(rZj2, this, this.case);
        an an2 = this.catch.break(rZj2.break());
        if (an2 != null) {
            if (rZj2.byte() == 0) {
                ib_0 ib_02 = (ib_0)an2;
                ib_02.class(rpm.MAIN_HAND);
            } else if (rZj2.byte() == 3) {
                ib_0 ib_03 = (ib_0)an2;
                ib_03.class(rpm.OFF_HAND);
            } else if (rZj2.byte() == 1) {
                an2.rF();
            } else if (rZj2.byte() == 2) {
                rhd_2 rhd_22 = (rhd_2)an2;
                rhd_22.class(false, false);
            } else if (rZj2.byte() == 4) {
                ((cy_0)this.case.class[12]).class(an2, rlq_2.catch);
            } else if (rZj2.byte() == 5) {
                ((cy_0)this.case.class[12]).class(an2, rlq_2.continue);
            }
        }
    }

    @Override
    public void class(rZK rZK2) {
        ruz_1.class(rZK2, this, this.case);
        ((cq_1)this.case.class[19]).class(rZK2.protected(), rZK2.break(), rZK2.throws());
    }

    @Override
    public void class(rZe rZe2) {
        ruz_1.class(rZe2, this, this.case);
        an an2 = this.catch.break(rZe2.break());
        ib_0 ib_02 = (ib_0)this.catch.break(rZe2.byte());
        if (ib_02 == null) {
            ib_02 = (cb_1)this.case.class[57];
        }
        if (an2 != null) {
            if (an2 instanceof rsp_0) {
                this.catch.class(an2.rx(), an2.re(), an2.BO(), rqn.SB, rql_0.PLAYERS, 0.1f, (this.int.nextFloat() - this.int.nextFloat()) * 0.35f + 0.9f, false);
            } else {
                this.catch.class(an2.rx(), an2.re(), an2.BO(), rqn.ER, rql_0.PLAYERS, 0.2f, (this.int.nextFloat() - this.int.nextFloat()) * 1.4f + 2.0f, false);
            }
            ((cy_0)this.case.class[12]).class(new cn_0(this.case.case(), this.case.interface(), this.catch, an2, ib_02));
            if (an2 instanceof rse_0) {
                rse_0 rse_02 = (rse_0)an2;
                rdn_1 rdn_12 = rse_02.protected();
                rrlf_1.class(ib_02, rdn_12.implements());
                rdn_12.catch(rZe2.protected());
                if (rdn_12.class()) {
                    this.catch.class(rZe2.break());
                }
            } else {
                this.catch.class(rZe2.break());
            }
        }
    }

    @Override
    public void class(rvc_2 rvc_22) {
        ruz_1.class(rvc_22, this, this.case);
        an an2 = this.catch.break(rvc_22.break());
        if (an2 != null) {
            an2.extends((double)rvc_22.byte() / 8000.0, (double)rvc_22.protected() / 8000.0, (double)rvc_22.throws() / 8000.0);
        }
    }

    @Override
    public void class(rvx_2 rvx_22) {
        ruz_1.class(rvx_22, this, this.case);
        an an2 = this.catch.break(rvx_22.byte());
        List<rmg_0<?>> list = rvx_22.break();
        if (an2 != null && list != null) {
            an2.BQ().class(list);
            ((rrqx_1)rrqx_1.staticFields09f1f28026cd378cb9df490a64ac8f2a[0]).finally().class(rrlq_2.class(an2, list));
        }
    }

    @Override
    public void class(rfk_2 rfk_22) {
        ruz_1.class(rfk_22, this, this.case);
        UUID uUID = rfk_22.byte();
        if (uUID == null) {
            return;
        }
        aw_1 aw_12 = this.class(uUID);
        if (aw_12 == null) {
            return;
        }
        double d = rfk_22.protected();
        double d2 = rfk_22.throws();
        double d3 = rfk_22.case();
        float f2 = (float)(rfk_22.catch() * 360) / 256.0f;
        float f3 = (float)(rfk_22.private() * 360) / 256.0f;
        int n2 = rfk_22.break();
        cm_2 cm_22 = new cm_2((gm)this.case.class[56], aw_12.class());
        cm_22.implements(n2);
        cm_22.native(d, d2, d3);
        cm_22.byte(d, d2, d3);
        cm_22.break(d, d2, d3, f2, f3);
        this.catch.class(n2, cm_22);
    }

    @Override
    public void class(rvn_2 rvn_22) {
        ruz_1.class(rvn_22, this, this.case);
        an an2 = this.catch.break(rvn_22.break());
        if (an2 != null) {
            double d = rvn_22.byte();
            double d2 = rvn_22.protected();
            double d3 = rvn_22.throws();
            an2.byte(d, d2, d3);
            if (!an2.Po()) {
                float f2 = (float)(rvn_22.case() * 360) / 256.0f;
                float f3 = (float)(rvn_22.catch() * 360) / 256.0f;
                an2.class(d, d2, d3, f2, f3, 3, true);
                an2.int(rvn_22.private());
            }
        }
    }

    @Override
    public void class(rfx_1 rfx_12) {
        ruz_1.class(rfx_12, this, this.case);
        rso_0 rso_02 = new rso_0(this.catch, rfx_12.protected(), rfx_12.throws(), rfx_12.case());
        rso_02.implements(rfx_12.break());
        rso_02.a_(rfx_12.byte());
        this.catch.class(rfx_12.break(), (an)rso_02);
    }

    @Override
    public void class(rfo_2 rfo_22) {
        ruz_1.class(rfo_22, this, this.case);
        double d = rfo_22.byte();
        double d2 = rfo_22.protected();
        double d3 = rfo_22.throws();
        rsp_0 rsp_02 = new rsp_0(this.catch, d, d2, d3, rfo_22.case());
        rsp_02.byte(d, d2, d3);
        Float f2 = Float.valueOf(0.0f);
        rsp_02.throws[15] = f2;
        Float f3 = Float.valueOf(0.0f);
        rsp_02.throws[16] = f3;
        rsp_02.implements(rfo_22.break());
        this.catch.class(rfo_22.break(), (an)rsp_02);
    }

    @Override
    public void class(rfj_2 rfj_22) {
        an an2;
        ruz_1.class(rfj_22, this, this.case);
        double d = rfj_22.protected();
        double d2 = rfj_22.throws();
        double d3 = rfj_22.case();
        ai_0<?> ai_02 = rfj_22.native();
        if (ai_02 == ai_0.r) {
            an2 = new rsk_0(this.catch, d, d2, d3);
        } else if (ai_02 == ai_0.B) {
            an2 = new rsn_0(this.catch, d, d2, d3);
        } else if (ai_02 == ai_0.E) {
            an2 = new rsv_0(this.catch, d, d2, d3);
        } else if (ai_02 == ai_0.s) {
            an2 = new rsm(this.catch, d, d2, d3);
        } else if (ai_02 == ai_0.S) {
            an2 = new rsc_0(this.catch, d, d2, d3);
        } else if (ai_02 == ai_0.P) {
            an2 = new rsw_0(this.catch, d, d2, d3);
        } else if (ai_02 == ai_0.switch) {
            an2 = new rsu_0(this.catch, d, d2, d3);
        } else if (ai_02 == ai_0.rO) {
            var10_7 = this.catch.break(rfj_22.volatile());
            an2 = var10_7 instanceof rhd_2 ? new rhp_1(this.catch, (rhd_2)var10_7, d, d2, d3) : null;
        } else if (ai_02 == ai_0.byte) {
            an2 = new rhf_2(this.catch, d, d2, d3);
            var10_7 = this.catch.break(rfj_22.volatile());
            if (var10_7 != null) {
                ((rhm_1)an2).break(var10_7);
            }
        } else if (ai_02 == ai_0.p) {
            an2 = new rho_1(this.catch, d, d2, d3);
            var10_7 = this.catch.break(rfj_22.volatile());
            if (var10_7 != null) {
                ((rhm_1)an2).break(var10_7);
            }
        } else if (ai_02 == ai_0.g) {
            an2 = new rhd_1(this.catch, d, d2, d3);
            var10_7 = this.catch.break(rfj_22.volatile());
            if (var10_7 != null) {
                ((rhm_1)an2).break(var10_7);
            }
        } else {
            an2 = ai_02 == ai_0.y ? new rhy_1(this.catch, d, d2, d3) : (ai_02 == ai_0.for ? new rhw_1(this.catch, d, d2, d3, rfj_22.catch(), rfj_22.private(), rfj_22.implements()) : (ai_02 == ai_0.default ? new rsg_0(this.catch, new rfH(d, d2, d3), rpr_0.class(rfj_22.volatile())) : (ai_02 == ai_0.strictfp ? new rsm_0(this.catch, new rfH(d, d2, d3)) : (ai_02 == ai_0.f ? new rsi_1(this.catch, d, d2, d3) : (ai_02 == ai_0.while ? new rhl_1(this.catch, d, d2, d3) : (ai_02 == ai_0.instanceof ? new rhy_2(this.catch, d, d2, d3, rdn_1.break) : (ai_02 == ai_0.const ? new rhh_1(this.catch, d, d2, d3, rfj_22.catch(), rfj_22.private(), rfj_22.implements()) : (ai_02 == ai_0.int ? new rha_2(this.catch, d, d2, d3, rfj_22.catch(), rfj_22.private(), rfj_22.implements()) : (ai_02 == ai_0.l ? new rhr_1(this.catch, d, d2, d3, rfj_22.catch(), rfj_22.private(), rfj_22.implements()) : (ai_02 == ai_0.rP ? new rhu_1(this.catch, d, d2, d3, rfj_22.catch(), rfj_22.private(), rfj_22.implements()) : (ai_02 == ai_0.F ? new rhg_1(this.catch, d, d2, d3, rfj_22.catch(), rfj_22.private(), rfj_22.implements()) : (ai_02 == ai_0.I ? new rhn_1(this.catch, d, d2, d3) : (ai_02 == ai_0.public ? new rhc_1(this.catch, d, d2, d3, 0.0f, 0, null) : (ai_02 == ai_0.V ? new rhi_2(this.catch, d, d2, d3) : (ai_02 == ai_0.j ? new rsr_0(this.catch, d, d2, d3) : (ai_02 == ai_0.catch ? new rsk_1(this.catch, d, d2, d3) : (ai_02 == ai_0.Q ? new rsX(this.catch, d, d2, d3, null) : (ai_02 == ai_0.break ? new rsy_1(this.catch, d, d2, d3) : (ai_02 == ai_0.super ? new rsa_1(this.catch, d, d2, d3) : (ai_02 == ai_0.short ? new rse_0(this.catch, d, d2, d3) : (ai_02 == ai_0.try ? new rsb_0(this.catch, d, d2, d3, xd_0.class(rfj_22.volatile())) : (ai_02 == ai_0.class ? new aZ(this.catch, d, d2, d3) : (ai_02 == ai_0.boolean ? new rsg_1((ai_0<? extends rsg_1>)ai_0.boolean, (rYB)this.catch) : null)))))))))))))))))))))));
        }
        if (an2 != null) {
            int n2 = rfj_22.break();
            an2.byte(d, d2, d3);
            an2.private(d, d2, d3);
            Float f2 = Float.valueOf((float)(rfj_22.finally() * 360) / 256.0f);
            an2.throws[16] = f2;
            Float f3 = Float.valueOf((float)(rfj_22.extends() * 360) / 256.0f);
            an2.throws[15] = f3;
            an2.implements(n2);
            an2.a_(rfj_22.byte());
            this.catch.class(n2, an2);
            if (an2 instanceof rsj_0) {
                this.case.c().class((nq_2)new nf_2((rsj_0)an2));
            }
        }
    }

    @Override
    public void class(rvc_1 rvc_12) {
        ruz_1.class(rvc_12, this, this.case);
        int n2 = 0x13 | (rvc_12.break() ? 128 : 0);
        rvc_12.class((rfH rfH2, xc_0 xc_02) -> this.catch.class((rfH)rfH2, (xc_0)xc_02, n2));
        ((break)protected.break.staticFieldsf9703d96375232b196815afd59d1eb48[0]).class(rvc_12);
    }

    @Override
    public void class(rvd_1 rvd_12) {
        double d;
        double d2;
        double d3;
        double d4;
        double d5;
        double d6;
        ruz_1.class(rvd_12, this, this.case);
        double d7 = rvd_12.break();
        double d8 = rvd_12.byte();
        double d9 = rvd_12.protected();
        if (Double.isInfinite(d7) || Double.isInfinite(d8) || Double.isInfinite(d9)) {
            rrfZ.class();
            return;
        }
        cb_1 cb_12 = (cb_1)this.case.class[57];
        rjU rjU2 = cb_12.rv();
        boolean bl2 = rvd_12.private().contains((Object)rvu_1.X);
        boolean bl3 = rvd_12.private().contains((Object)rvu_1.Y);
        boolean bl4 = rvd_12.private().contains((Object)rvu_1.Z);
        rrAl rrAl2 = ((rrqx_1)rrqx_1.staticFields09f1f28026cd378cb9df490a64ac8f2a[0]).finally().class(rrAl.class(d7, d8, d9, cb_12.rx(), cb_12.re(), cb_12.BO(), rvd_12.catch(), false, false));
        ((break)protected.break.staticFieldsf9703d96375232b196815afd59d1eb48[0]).class(rrAl2);
        rrAl2.implements();
        if (rrAl2.byte()) {
            return;
        }
        double d10 = rrAl2.break();
        double d11 = rrAl2.extends();
        double d12 = rrAl2.catch();
        if (bl2) {
            d6 = rjU2.class();
            d5 = cb_12.rx() + d10;
            cb_1 cb_13 = cb_12;
            Double d13 = (Double)cb_13.throws[34] + d10;
            cb_13.throws[34] = d13;
        } else {
            d6 = 0.0;
            d5 = d10;
            Double d14 = d5;
            cb_12.throws[34] = d14;
        }
        if (bl3) {
            d4 = rjU2.break();
            d3 = cb_12.re() + d11;
            cb_1 cb_14 = cb_12;
            Double d15 = (Double)cb_14.throws[35] + d11;
            cb_14.throws[35] = d15;
        } else {
            d4 = 0.0;
            d3 = d11;
            Double d16 = d3;
            cb_12.throws[35] = d16;
        }
        if (bl4) {
            d2 = rjU2.byte();
            d = cb_12.BO() + d12;
            cb_1 cb_15 = cb_12;
            Double d17 = (Double)cb_15.throws[36] + d12;
            cb_15.throws[36] = d17;
        } else {
            d2 = 0.0;
            d = d12;
            Double d18 = d;
            cb_12.throws[36] = d18;
        }
        if ((Integer)cb_12.throws[41] > 0 && cb_12.ra() != null) {
            ((rhd_2)cb_12).const();
        }
        cb_12.volatile(d5, d3, d);
        Double d19 = d5;
        cb_12.throws[8] = d19;
        Double d20 = d3;
        cb_12.throws[9] = d20;
        Double d21 = d;
        cb_12.throws[10] = d21;
        cb_12.catch(d6, d4, d2);
        float f2 = rvd_12.throws();
        float f3 = rvd_12.case();
        if (rvd_12.private().contains((Object)rvu_1.X_ROT)) {
            f3 += ((Float)cb_12.throws[16]).floatValue();
        }
        if (rvd_12.private().contains((Object)rvu_1.Y_ROT)) {
            f2 += ((Float)cb_12.throws[15]).floatValue();
        }
        float f4 = f2;
        float f5 = f3;
        if (rrAl2.case()) {
            f4 = ((Float)cb_12.throws[15]).floatValue();
            f5 = ((Float)cb_12.throws[16]).floatValue();
        }
        rrAH rrAH2 = rrAH.class(((Float)cb_12.throws[15]).floatValue(), ((Float)cb_12.throws[16]).floatValue(), true);
        ((break)protected.break.staticFieldsf9703d96375232b196815afd59d1eb48[0]).class(rrAH2);
        if (!rrAl2.native()) {
            cb_12.class(d5, d3, d, f4, f5, rrAH2.break());
        }
        this.byte.class(new rmV(rrAl2.finally()));
        this.byte.class(new rzx_0(cb_12.rx(), cb_12.re(), cb_12.BO(), rrAH2.class(), rrAH2.byte(), false));
        if (!this.implements) {
            this.implements = true;
            this.case.break((vm_1)null);
        }
    }

    @Override
    public void class(rvg_2 rvg_22) {
        ruz_1.class(rvg_22, this, this.case);
        for (int k = 0; k < rvg_22.break().length; ++k) {
            int n2 = rvg_22.break()[k];
            this.catch.class(n2);
        }
    }

    @Override
    public void class(rvh_2 rvh_22) {
        ruz_1.class(rvh_22, this, this.case);
        an an2 = rvh_22.class(this.catch);
        if (an2 != null) {
            float f2 = (float)(rvh_22.break() * 360) / 256.0f;
            an2.class(f2, 3);
        }
    }

    @Override
    public void class(rvj_2 rvj_22) {
        ruz_1.class(rvj_22, this, this.case);
        an an2 = rvj_22.class(this.catch);
        if (an2 != null && !an2.Po()) {
            if (rvj_22.throws()) {
                rjU rjU2 = rvj_22.class(an2.rm());
                an2.catch(rjU2);
                float f2 = rvj_22.protected() ? (float)(rvj_22.break() * 360) / 256.0f : ((Float)an2.throws[15]).floatValue();
                float f3 = rvj_22.protected() ? (float)(rvj_22.byte() * 360) / 256.0f : ((Float)an2.throws[16]).floatValue();
                an2.class(rjU2.class(), rjU2.break(), rjU2.byte(), f2, f3, 3, false);
            } else if (rvj_22.protected()) {
                float f4 = (float)(rvj_22.break() * 360) / 256.0f;
                float f5 = (float)(rvj_22.byte() * 360) / 256.0f;
                an2.class(an2.rx(), an2.re(), an2.BO(), f4, f5, 3, false);
            }
            an2.int(rvj_22.case());
        }
    }

    @Override
    public void class(rvm_1 rvm_12) {
        ruz_1.class(rvm_12, this, this.case);
        if (rhz_2.break(rvm_12.break())) {
            ((rhz_2)((cb_1)this.case.class[57]).implements[1]).protected = rvm_12.break();
        }
    }

    @Override
    public void class(rvo_2 rvo_22) {
        ruz_1.class(rvo_22, this, this.case);
        an an2 = this.catch.break(rvo_22.break());
        if (an2 != null) {
            rvo_22.byte().forEach(pair -> an2.class((rxq_1)((Object)((Object)pair.getFirst())), (rdn_1)pair.getSecond()));
        }
    }

    @Override
    public void class(rZU rZU2) {
        ruz_1.class(rZU2, this, this.case);
        ((cb_1)this.case.class[57]).k();
    }

    @Override
    public void class(rZV rZV2) {
        ruz_1.class(rZV2, this, this.case);
        ((gm)this.case.class[56]).class(rZV2.break(), rZV2.throws(), rZV2.byte(), rZV2.protected());
    }

    @Override
    public void class(rZf rZf2) {
        ruz_1.class(rZf2, this, this.case);
        ((gm)this.case.class[56]).class(rZf2.break(), rZf2.byte(), rZf2.protected());
    }

    @Override
    public void class(rft_1 rft_12) {
        ruz_1.class(rft_12, this, this.case);
        cb_1 cb_12 = (cb_1)this.case.class[57];
        if ((rjr_2)cb_12.implements[4] != null && ((rjr_2)cb_12.implements[4]).case == rft_12.break()) {
            ((rjr_2)cb_12.implements[4]).class(rft_12.byte(), rft_12.protected());
        }
    }

    @Override
    public void class(rfy_2 rfy_22) {
        boolean bl2;
        ruz_1.class(rfy_22, this, this.case);
        rfH rfH2 = rfy_22.break();
        ryo_2 ryo_22 = ((gm)this.case.class[56]).class(rfH2);
        int n2 = rfy_22.byte();
        boolean bl3 = bl2 = n2 == 2 && ryo_22 instanceof rHZ;
        if (n2 == 1 && ryo_22 instanceof rHU || bl2 || n2 == 3 && ryo_22 instanceof rho_0 || n2 == 4 && ryo_22 instanceof rys_1 || n2 == 6 && ryo_22 instanceof rHb || n2 == 7 && ryo_22 instanceof ryg_2 || n2 == 8 && ryo_22 instanceof rhy_0 || n2 == 9 && ryo_22 instanceof rys_2 || n2 == 11 && ryo_22 instanceof rhj_0 || n2 == 5 && ryo_22 instanceof rha_0 || n2 == 12 && ryo_22 instanceof rHj || n2 == 13 && ryo_22 instanceof rhc_0 || n2 == 14 && ryo_22 instanceof rHx) {
            ryo_22.class(((gm)this.case.class[56]).byte(rfH2), rfy_22.protected());
        }
        if (bl2 && (vm_1)this.case.class[73] instanceof ml) {
            ((ml)((vm_1)this.case.class[73])).final();
        }
    }

    @Override
    public void class(rvy_2 rvy_22) {
        ruz_1.class(rvy_22, this, this.case);
        ryo_2 ryo_22 = this.catch.class(rvy_22.break());
        if (!(ryo_22 instanceof rys_2)) {
            ryo_22 = new rys_2();
            ryo_22.break(this.catch, rvy_22.break());
        }
        ((cb_1)this.case.class[57]).class((rys_2)ryo_22);
    }

    @Override
    public void class(rvp_2 rvp_22) {
        ruz_1.class(rvp_22, this, this.case);
        this.new = new CommandDispatcher(rvp_22.break());
    }

    @Override
    public void class(rfs_2 rfs_22) {
        ruz_1.class(rfs_22, this, this.case);
        rqo_0 rqo_02 = rfs_22.break();
        if (rqo_02 == null) {
            this.extends.class(null, false);
        } else {
            ot_1 ot_12 = this.extends.class().class(rqo_02);
            this.extends.class(ot_12, false);
        }
    }

    @Override
    public void class(rzi_0 rzi_02) {
        ruz_1.class(rzi_02, this, this.case);
        this.extends.class(rzi_02);
    }

    @Override
    public void class(rvw_1 rvw_12) {
        ruz_1.class(rvw_12, this, this.case);
        if (rvw_12.break()) {
            ((gm)this.case.class[56]).break(rvw_12.byte(), rvw_12.throws(), rvw_12.protected());
        } else {
            ((gm)this.case.class[56]).byte(rvw_12.byte(), rvw_12.throws(), rvw_12.protected());
        }
    }

    @Override
    public void class(rvf_2 rvf_22) {
        ruz_1.class(rvf_22, this, this.case);
        ct_1 ct_12 = ((hh_0)this.case.class[16]).catch();
        String string = rxi_0.class(rvf_22.break());
        rrGb rrGb2 = ((gm)this.case.class[56]).class(string);
        if (rrGb2 == null) {
            rrGb rrGb3;
            rrGb2 = new rrGb(string);
            if (ct_12.class(string) != null && (rrGb3 = ct_12.class(ct_12.class(string))) != null) {
                rrGb2 = rrGb3;
            }
            ((gm)this.case.class[56]).class(rrGb2);
        }
        rvf_22.class(rrGb2);
        ct_12.class(rrGb2);
    }

    @Override
    public void class(rZY rZY2) {
        ruz_1.class(rZY2, this, this.case);
        cb_1 cb_12 = (cb_1)this.case.class[57];
        rZo rZo2 = rZY2.break();
        float f2 = rZY2.byte();
        int n2 = rfU.protected(f2 + 0.5f);
        if (rZo2 == rZY.class) {
            ((rhd_2)cb_12).class((rgP)new rgn("block.minecraft.spawn.not_valid"), false);
        } else if (rZo2 == rZY.break) {
            this.catch.synchronized().class(true);
            this.catch.implements(0.0f);
        } else if (rZo2 == rZY.byte) {
            this.catch.synchronized().class(false);
            this.catch.implements(1.0f);
        } else if (rZo2 == rZY.protected) {
            ((ax_1)this.case.class[55]).break(rRl.class(n2));
        } else if (rZo2 == rZY.throws) {
            if (n2 == 0) {
                ((aq_1)((cb_1)this.case.class[57]).break[0]).class(new rmi_0(rmf.PERFORM_RESPAWN));
                this.case.break(new Zb());
            } else if (n2 == 1) {
                this.case.break(new vg_1(true, () -> ((aq_1)((cb_1)this.case.class[57]).break[0]).class(new rmi_0(rmf.PERFORM_RESPAWN))));
            }
        } else if (rZo2 == rZY.case) {
            qw_1 qw_12 = (qw_1)this.case.class[20];
            if (f2 == 0.0f) {
                this.case.break(new Zs());
            } else if (f2 == 101.0f) {
                ((cq_1)this.case.class[19]).throws().class(new rgn("demo.help.movement", qw_12.h.native(), qw_12.X.native(), qw_12.J.native(), qw_12.x.native()));
            } else if (f2 == 102.0f) {
                ((cq_1)this.case.class[19]).throws().class(new rgn("demo.help.jump", qw_12.d.native()));
            } else if (f2 == 103.0f) {
                ((cq_1)this.case.class[19]).throws().class(new rgn("demo.help.inventory", qw_12.z.native()));
            } else if (f2 == 104.0f) {
                ((cq_1)this.case.class[19]).throws().class(new rgn("demo.day.6", qw_12.n.native()));
            }
        } else if (rZo2 == rZY.catch) {
            this.catch.class(cb_12, cb_12.rx(), cb_12.rH(), cb_12.BO(), rqn.S, rql_0.PLAYERS, 0.18f, 0.45f);
        } else if (rZo2 == rZY.private) {
            this.catch.implements(f2);
        } else if (rZo2 == rZY.implements) {
            this.catch.catch(f2);
        } else if (rZo2 == rZY.finally) {
            this.catch.class(cb_12, cb_12.rx(), cb_12.re(), cb_12.BO(), rqn.XB, rql_0.NEUTRAL, 1.0f, 1.0f);
        } else if (rZo2 == rZY.extends) {
            this.catch.class(rlq_2.new, cb_12.rx(), cb_12.re(), cb_12.BO(), 0.0, 0.0, 0.0);
            if (n2 == 1) {
                this.catch.class(cb_12, cb_12.rx(), cb_12.re(), cb_12.BO(), rqn.BX, rql_0.HOSTILE, 1.0f, 1.0f);
            }
        } else if (rZo2 == rZY.native) {
            ((cb_1)this.case.class[57]).throws(f2 == 0.0f);
        }
    }

    @Override
    public void class(rvh_1 rvh_12) {
        ruz_1.class(rvh_12, this, this.case);
        an an2 = this.catch.break(rvh_12.protected());
        if (an2 instanceof rod_2) {
            rjq_2 rjq_22;
            rod_2 rod_22 = (rod_2)an2;
            cb_1 cb_12 = (cb_1)this.case.class[57];
            rxa_1 rxa_12 = new rxa_1(rvh_12.byte());
            rjq_2 rjq_23 = rjq_22 = new rjq_2(rvh_12.break(), (rhz_2)cb_12.implements[1], rxa_12, rod_22);
            cb_12.implements[4] = rjq_23;
            this.case.break(new fl_1(rjq_22, (rhz_2)cb_12.implements[1], rod_22));
        }
    }

    @Override
    public void class(rvu_2 rvu_22) {
        ruz_1.class(rvu_22, this, this.case);
        double d = rvu_22.throws();
        double d2 = rvu_22.case();
        double d3 = rvu_22.catch();
        if (Double.isInfinite(d) || Double.isInfinite(d2) || Double.isInfinite(d3)) {
            rrfZ.class();
            return;
        }
        rrw_0 rrw_02 = new rrw_0((gm)this.case.class[56], null, d, d2, d3, rvu_22.private(), rvu_22.implements());
        rrw_02.class(true);
        ((cb_1)this.case.class[57]).byte(((cb_1)this.case.class[57]).rv().break(rvu_22.break(), rvu_22.byte(), rvu_22.protected()));
    }

    @Override
    public void class(rvq_2 rvq_22) {
        ruz_1.class(rvq_22, this, this.case);
        an an2 = rvq_22.class(this.catch);
        if (an2 != null) {
            if (rvq_22.break() == 21) {
                this.case.c().class((nq_2)new nk_2((rei_2)an2));
            } else if (rvq_22.break() == 35) {
                ((cy_0)this.case.class[12]).class(an2, rlq_2.S, 30);
                this.catch.class(an2.rx(), an2.re(), an2.BO(), rqn.dM, an2.Pr(), 1.0f, 1.0f, false);
                if (an2 == (cb_1)this.case.class[57] && ((rrqx_1)rrqx_1.staticFields09f1f28026cd378cb9df490a64ac8f2a[0]).private().h().super()) {
                    ((hh_0)this.case.class[16]).class(aq_1.class((cb_1)this.case.class[57]));
                }
            } else {
                an2.class(rvq_22.break());
            }
        }
    }

    @Override
    public void class(rfn_1 rfn_12) {
        ruz_1.class(rfn_12, this, this.case);
        ((cb_1)this.case.class[57]).byte(rfn_12.break());
        ((cb_1)this.case.class[57]).sk().class(rfn_12.byte());
        ((cb_1)this.case.class[57]).sk().break(rfn_12.protected());
    }

    @Override
    public void class(rfg_2 rfg_22) {
        ruz_1.class(rfg_22, this, this.case);
        ((cb_1)this.case.class[57]).class(rfg_22.break(), rfg_22.byte(), rfg_22.protected());
    }

    @Override
    public void class(rfp_2 rfp_22) {
        Object object;
        ruz_1.class(rfp_22, this, this.case);
        rqm_0<rYB> rqm_02 = rfp_22.byte();
        rrj_0 rrj_02 = rfp_22.break();
        cb_1 cb_12 = (cb_1)this.case.class[57];
        int n2 = cb_12.V();
        this.implements = false;
        if (rqm_02 != ((rYB)cb_12.throws[7]).E()) {
            gv_0 gv_02;
            object = this.catch.package();
            boolean bl2 = rfp_22.catch();
            boolean bl3 = rfp_22.private();
            this.private = gv_02 = new gv_0(this.private.extends(), this.private.implements(), bl3);
            this.catch = new gm(this, gv_02, rqm_02, rrj_02, this.package, (yx_1)this.case.class[8], bl2, rfp_22.protected());
            this.catch.class((rns_0)object);
            this.case.class(this.catch);
            this.case.break(new Zb());
        }
        this.catch.private();
        object = cb_12.short();
        Object var14_11 = null;
        this.case.class[62] = var14_11;
        cb_1 cb_13 = ((ax_1)this.case.class[55]).class(this.catch, cb_12.abstract(), cb_12.Z(), cb_12.h(), cb_12.PF());
        cb_13.implements(n2);
        cb_1 cb_14 = cb_13;
        this.case.class[57] = cb_14;
        if (rqm_02 != ((rYB)cb_12.throws[7]).E()) {
            this.case.N().break();
        }
        cb_1 cb_15 = cb_13;
        this.case.class[62] = cb_15;
        cb_13.BQ().class(cb_12.BQ().byte());
        if (rfp_22.implements()) {
            cb_13.BT().class(cb_12.BT());
        }
        cb_13.Bc();
        cb_13.byte((String)object);
        this.catch.class(n2, cb_13);
        Float f2 = Float.valueOf(-180.0f);
        cb_13.throws[15] = f2;
        rqp_0 rqp_02 = new rqp_0((qw_1)this.case.class[20]);
        cb_13.break[17] = rqp_02;
        ((ax_1)this.case.class[55]).class(cb_13);
        cb_13.synchronized(cb_12.sW());
        cb_13.throws(cb_12.d());
        if ((vm_1)this.case.class[73] instanceof zs_0) {
            this.case.break((vm_1)null);
        }
        ((ax_1)this.case.class[55]).break(rfp_22.throws());
        ((ax_1)this.case.class[55]).class(rfp_22.case());
    }

    @Override
    public void class(rvs_2 rvs_22) {
        ruz_1.class(rvs_22, this, this.case);
        rjr_2 rjr_22 = null;
        cb_1 cb_12 = (cb_1)this.case.class[57];
        if (rvs_22.break() == 0) {
            rjr_22 = (rjt_1)cb_12.implements[3];
        } else if (rvs_22.break() == ((rjr_2)cb_12.implements[4]).case) {
            rjr_22 = (rjr_2)cb_12.implements[4];
        }
        if (rjr_22 != null && !rvs_22.protected()) {
            this.class(new rmg(rvs_22.break(), rvs_22.byte(), true));
        }
    }

    @Override
    public void class(rft_2 rft_22) {
        ruz_1.class(rft_22, this, this.case);
        cb_1 cb_12 = (cb_1)this.case.class[57];
        if (rft_22.break() == 0) {
            ((rjt_1)cb_12.implements[3]).class(rft_22.byte());
        } else if (rft_22.break() == ((rjr_2)cb_12.implements[4]).case) {
            ((rjr_2)cb_12.implements[4]).class(rft_22.byte());
        }
    }

    @Override
    public void class(rfm_2 rfm_22) {
        ruz_1.class(rfm_22, this, this.case);
        cb_1 cb_12 = (cb_1)this.case.class[57];
        rdn_1 rdn_12 = rfm_22.protected();
        int n2 = rfm_22.byte();
        if (rfm_22.break() == -1) {
            if (!((vm_1)this.case.class[73] instanceof fv_1)) {
                ((rhz_2)cb_12.implements[1]).private(rdn_12);
            }
        } else if (rfm_22.break() == -2) {
            ((rhz_2)cb_12.implements[1]).break(n2, rdn_12);
        } else {
            Object object;
            boolean bl2 = false;
            vm_1 vm_12 = (vm_1)this.case.class[73];
            if (vm_12 instanceof fv_1) {
                object = (fv_1)vm_12;
                boolean bl3 = bl2 = ((fv_1)object).interface() != rdx_1.final.class();
            }
            if (rfm_22.break() == 0 && rfm_22.byte() >= 36 && n2 < 45) {
                if (!rdn_12.class() && (((rdn_1)(object = ((rjt_1)cb_12.implements[3]).class(n2).class())).class() || ((rdn_1)object).char() < rdn_12.char())) {
                    rdn_12.protected(5);
                }
                ((rjt_1)cb_12.implements[3]).class(n2, rdn_12);
            } else if (!(rfm_22.break() != ((rjr_2)cb_12.implements[4]).case || rfm_22.break() == 0 && bl2)) {
                ((rjr_2)cb_12.implements[4]).class(n2, rdn_12);
            }
        }
    }

    private static rdn_1 class(rhd_2 rhd_22) {
        for (rpm rpm2 : rpm.values()) {
            rdn_1 rdn_12 = rhd_22.protected(rpm2);
            if (rdn_12.break() != rdy_2.kL) continue;
            return rdn_12;
        }
        return new rdn_1(rdy_2.kL);
    }

    @Override
    public void class(rva_2 rva_22) {
        ruz_1.class(rva_22, this, this.case);
        an an2 = this.catch.break(rva_22.break());
        if (an2 instanceof is) {
            ((is)an2).super(rva_22.byte());
        }
    }

    @Override
    public void class(rvp_1 rvp_12) {
        ruz_1.class(rvp_12, this, this.case);
        cg_1.class(rvp_12.byte(), this.case, rvp_12.break(), rvp_12.protected());
    }

    public void break(rus_2<?> rus_22) {
        this.byte.break(rus_22);
    }

    public ax_2 break() {
        return this.native;
    }

    private boolean break(String string) {
        try {
            URI uRI = new URI(string);
            String string2 = uRI.getScheme();
            boolean bl2 = "level".equals(string2);
            if (!("http".equals(string2) || "https".equals(string2) || bl2)) {
                throw new URISyntaxException(string, "Wrong protocol");
            }
            if (!bl2 || !string.contains("..") && string.endsWith("/resources.zip")) {
                return true;
            }
            throw new URISyntaxException(string, "Invalid levelstorage resourcepack path");
        }
        catch (URISyntaxException uRISyntaxException) {
            this.class(rzn_0.FAILED_DOWNLOAD);
            return false;
        }
    }

    public Collection<aw_1> throws() {
        return this.finally.values();
    }

    public gm finally() {
        return this.catch;
    }

    public GameProfile catch() {
        return this.protected;
    }

    public rlq_0 extends() {
        return this.volatile;
    }

    public Collection<UUID> case() {
        return this.finally.keySet();
    }

    public CommandDispatcher<gR> implements() {
        return this.new;
    }

    public rVm package() {
        return this.else;
    }

    public rwb_2 protected() {
        return this.continue;
    }

    public ab_1 private() {
        return this.extends;
    }

    public Set<rqm_0<rYB>> final() {
        return this.this;
    }

    public UUID volatile() {
        return this.super;
    }

    public gg_0 native() {
        return this.final;
    }
}

