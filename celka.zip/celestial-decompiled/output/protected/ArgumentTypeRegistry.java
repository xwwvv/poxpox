/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Arrays;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.abstract;
import protected.sa_1;
import protected.sb_0;
import protected.si_1;
import protected.sp_0;
import protected.sr_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.Se
 */
public class se_1 {
    public static Object[] class;
    private static boolean[] break;
    private static byte[] byte;

    private static void byte() {
        Object[] objectArray = new Object[1];
        abstract[] abstractArray = new abstract[]{new sp_0(), new sb_0(), new sr_0(), new si_1(), new sa_1()};
        objectArray[0] = Arrays.asList((Object[])abstractArray);
        se_1.class = objectArray;
    }

    static {
        se_1.ntfClinit();
    }

    public static String class(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{41, -2, -85, 110, 100, 83, -68, 24}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0x59CD4D68;
    }

    private static void class() {
        byte = new byte[]{5, 2, 3, 4};
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0x8F6DC9B99F5D4E6AL;
    }

    private static void break() {
        boolean[] blArray = new boolean[9];
        blArray[2] = true;
        blArray[8] = true;
        break = blArray;
    }

    private static /* synthetic */ void ntfClinit() {
        se_1.break();
        se_1.class();
        se_1.byte();
    }
}

