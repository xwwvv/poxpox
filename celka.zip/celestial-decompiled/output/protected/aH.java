/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.serialization.Codec
 */
package protected;

import com.mojang.serialization.Codec;
import java.util.Arrays;
import java.util.Map;
import java.util.stream.Collectors;
import protected.rpH;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class aH
extends Enum<aH>
implements rpH {
    public static final /* enum */ aH MONSTER = new aH("monster", 70, false, false, 128);
    public static final /* enum */ aH CREATURE = new aH("creature", 10, true, true, 128);
    public static final /* enum */ aH AMBIENT = new aH("ambient", 15, true, false, 128);
    public static final /* enum */ aH WATER_CREATURE = new aH("water_creature", 5, true, false, 128);
    public static final /* enum */ aH WATER_AMBIENT = new aH("water_ambient", 20, true, false, 64);
    public static final /* enum */ aH MISC = new aH("misc", -1, true, true, 128);
    public static final Codec<aH> CODEC;
    private static final Map<String, aH> VALUES_MAP;
    private final int maxNumberOfCreature;
    private final boolean isPeacefulCreature;
    private final boolean isAnimal;
    private final String name;
    private final int randomDespawnDistance;
    private final int instantDespawnDistance;
    private static final /* synthetic */ aH[] $VALUES;

    public int byte() {
        return this.maxNumberOfCreature;
    }

    private aH(String string2, int n3, boolean bl2, boolean bl3, int n4) {
        this.randomDespawnDistance = 32;
        this.name = string2;
        this.maxNumberOfCreature = n3;
        this.isPeacefulCreature = bl2;
        this.isAnimal = bl3;
        this.instantDespawnDistance = n4;
    }

    static {
        $VALUES = aH.implements();
        CODEC = rpH.class(aH::values, aH::class);
        VALUES_MAP = Arrays.stream(aH.values()).collect(Collectors.toMap(aH::break, aH2 -> aH2));
    }

    public static aH[] values() {
        return (aH[])$VALUES.clone();
    }

    public static aH valueOf(String string) {
        return Enum.valueOf(aH.class, string);
    }

    @Override
    public String class() {
        return this.name;
    }

    public static aH class(String string) {
        return VALUES_MAP.get(string);
    }

    public String break() {
        return this.name;
    }

    public boolean throws() {
        return this.isAnimal;
    }

    public int catch() {
        return 32;
    }

    public int case() {
        return this.instantDespawnDistance;
    }

    private static /* synthetic */ aH[] implements() {
        return new aH[]{MONSTER, CREATURE, AMBIENT, WATER_CREATURE, WATER_AMBIENT, MISC};
    }

    public boolean protected() {
        return this.isPeacefulCreature;
    }

    public boolean private() {
        return this == MONSTER;
    }
}

