/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.brigadier.StringReader
 *  com.mojang.brigadier.arguments.ArgumentType
 *  com.mojang.brigadier.context.CommandContext
 *  com.mojang.brigadier.exceptions.CommandSyntaxException
 *  com.mojang.brigadier.suggestion.Suggestions
 *  com.mojang.brigadier.suggestion.SuggestionsBuilder
 */
package protected;

import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import java.util.Arrays;
import java.util.Collection;
import java.util.concurrent.CompletableFuture;
import protected.gy_0;
import protected.rd_0;
import protected.rk_0;
import protected.rls;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class Rx
implements ArgumentType<rd_0> {
    private static final Collection<String> class = Arrays.asList("stone", "minecraft:stone", "stone[foo=bar]", "foo{bar=baz}");

    public static Rx class() {
        return new Rx();
    }

    public static rd_0 class(CommandContext<gy_0> commandContext, String string) {
        return (rd_0)commandContext.getArgument(string, rd_0.class);
    }

    public rd_0 class(StringReader stringReader) throws CommandSyntaxException {
        rk_0 rk_02 = new rk_0(stringReader, false).class(true);
        return new rd_0(rk_02.break(), rk_02.class().keySet(), rk_02.byte());
    }

    public /* synthetic */ Object parse(StringReader stringReader) throws CommandSyntaxException {
        return this.class(stringReader);
    }

    public Collection<String> getExamples() {
        return Rx.class;
    }

    public <S> CompletableFuture<Suggestions> listSuggestions(CommandContext<S> commandContext, SuggestionsBuilder suggestionsBuilder) {
        StringReader stringReader = new StringReader(suggestionsBuilder.getInput());
        stringReader.setCursor(suggestionsBuilder.getStart());
        rk_0 rk_02 = new rk_0(stringReader, false);
        try {
            rk_02.class(true);
        }
        catch (CommandSyntaxException commandSyntaxException) {
            // empty catch block
        }
        return rk_02.class(suggestionsBuilder, rls.class());
    }
}

