/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.class;
import protected.pp_2;
import protected.ps_1;
import protected.rff;
import protected.rjg_0;
import protected.rjm_0;
import protected.rpm;
import protected.ryz_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class bt
implements pp_2 {
    private static boolean[] throws;
    private static short[] case;
    public Object[] class;
    public static Object[] break;
    private static byte[] catch;

    private void byte() {
        if (this.class == null) {
            Object[] objectArray = this.class = new Object[catch[0]];
            objectArray[bt.throws[3]] = throws[4];
        }
    }

    public bt(ps_1 ps_12) {
        this.byte();
        ps_1 ps_13 = ps_12;
        this.class[bt.case[0]] = ps_13;
    }

    static {
        bt.ntfClinit();
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0xEFCACAF3BCFD2E28L;
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0xC6218B27;
    }

    public static String class(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{-24, 57, 14, 90, -78, 30, -95, 3}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    public void class(boolean bl2) {
        if ((Integer)this.class[case[1]] > 0) {
            bt bt2 = this;
            Integer n2 = (Integer)bt2.class[case[2]] - throws[0];
            bt2.class[bt.case[3]] = n2;
            return;
        }
        rjg_0 rjg_02 = ((ps_1)this.class[case[4]]).byte();
        if (!bl2 || ((ps_1)this.class[case[5]]).catch().long() || rjg_02 == null || rjg_02.byte() != rjm_0.BLOCK) {
            return;
        }
        Integer n3 = (Integer)protected.class.instanceof().PO.class[case[6]] - throws[1];
        this.class[bt.case[7]] = n3;
        rpm[] rpmArray = rpm.values();
        int n4 = rpmArray.length;
        for (int k = throws[2]; k < n4; ++k) {
            rpm rpm2 = rpmArray[k];
            if (((ps_1)this.class[case[8]]).native().break(((ps_1)this.class[case[9]]).catch(), ((ps_1)this.class[case[10]]).case(), rpm2, (rff)rjg_02) == ryz_1.SUCCESS) {
                ((ps_1)this.class[case[11]]).catch().class(rpm2);
                return;
            }
            if (((ps_1)this.class[case[12]]).catch().protected(rpm2).class() || ((ps_1)this.class[case[13]]).native().class(rpm2) != ryz_1.SUCCESS) continue;
            return;
        }
    }

    private static void class() {
        boolean[] blArray = new boolean[8];
        blArray[0] = true;
        blArray[1] = true;
        blArray[3] = true;
        blArray[5] = true;
        blArray[7] = true;
        throws = blArray;
    }

    private static void break() {
        Object[] objectArray = new Object[]{1};
        break = objectArray;
    }

    private static void throws() {
        short[] sArray = new short[14];
        sArray[1] = 1;
        sArray[2] = 1;
        sArray[3] = 1;
        sArray[7] = 1;
        case = sArray;
    }

    private static /* synthetic */ void ntfClinit() {
        bt.class();
        bt.throws();
        bt.protected();
        bt.break();
    }

    private static void protected() {
        catch = new byte[]{2};
    }
}

