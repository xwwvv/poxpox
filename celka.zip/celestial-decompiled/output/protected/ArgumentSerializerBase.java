/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.io.DataInput;
import java.io.IOException;
import protected.rcf_2;
import protected.rcg_1;
import protected.rcn_2;
import protected.rcz_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.rcv
 */
public interface rcv_2<T extends rcz_1> {
    default public boolean byte() {
        return false;
    }

    public static rcv_2<rcn_2> class(int n2) {
        return new rcf_2(n2);
    }

    public String class();

    public String break();

    public T break(DataInput var1, int var2, rcg_1 var3) throws IOException;
}

