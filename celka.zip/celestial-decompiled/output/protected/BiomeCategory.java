/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.serialization.Codec
 */
package protected;

import com.mojang.serialization.Codec;
import java.util.Arrays;
import java.util.Map;
import java.util.stream.Collectors;
import protected.rpH;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.rYh
 */
public final class ryh_0
extends Enum<ryh_0>
implements rpH {
    public static final /* enum */ ryh_0 NONE = new ryh_0("none");
    public static final /* enum */ ryh_0 TAIGA = new ryh_0("taiga");
    public static final /* enum */ ryh_0 EXTREME_HILLS = new ryh_0("extreme_hills");
    public static final /* enum */ ryh_0 JUNGLE = new ryh_0("jungle");
    public static final /* enum */ ryh_0 MESA = new ryh_0("mesa");
    public static final /* enum */ ryh_0 PLAINS = new ryh_0("plains");
    public static final /* enum */ ryh_0 SAVANNA = new ryh_0("savanna");
    public static final /* enum */ ryh_0 ICY = new ryh_0("icy");
    public static final /* enum */ ryh_0 THEEND = new ryh_0("the_end");
    public static final /* enum */ ryh_0 BEACH = new ryh_0("beach");
    public static final /* enum */ ryh_0 FOREST = new ryh_0("forest");
    public static final /* enum */ ryh_0 OCEAN = new ryh_0("ocean");
    public static final /* enum */ ryh_0 DESERT = new ryh_0("desert");
    public static final /* enum */ ryh_0 RIVER = new ryh_0("river");
    public static final /* enum */ ryh_0 SWAMP = new ryh_0("swamp");
    public static final /* enum */ ryh_0 MUSHROOM = new ryh_0("mushroom");
    public static final /* enum */ ryh_0 NETHER = new ryh_0("nether");
    public static final Codec<ryh_0> CODEC;
    private static final Map<String, ryh_0> BY_NAME;
    private final String name;
    private static final /* synthetic */ ryh_0[] $VALUES;

    private static /* synthetic */ ryh_0[] byte() {
        return new ryh_0[]{NONE, TAIGA, EXTREME_HILLS, JUNGLE, MESA, PLAINS, SAVANNA, ICY, THEEND, BEACH, FOREST, OCEAN, DESERT, RIVER, SWAMP, MUSHROOM, NETHER};
    }

    private ryh_0(String string2) {
        this.name = string2;
    }

    static {
        $VALUES = ryh_0.byte();
        CODEC = rpH.class(ryh_0::values, ryh_0::class);
        BY_NAME = Arrays.stream(ryh_0.values()).collect(Collectors.toMap(ryh_0::break, ryh_02 -> ryh_02));
    }

    public static ryh_0[] values() {
        return (ryh_0[])$VALUES.clone();
    }

    public static ryh_0 valueOf(String string) {
        return Enum.valueOf(ryh_0.class, string);
    }

    public static ryh_0 class(String string) {
        return BY_NAME.get(string);
    }

    @Override
    public String class() {
        return this.name;
    }

    public String break() {
        return this.name;
    }
}

