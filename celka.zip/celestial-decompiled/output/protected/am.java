/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.aU;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class am
implements aU {
    private int class;
    private final boolean break;
    private final float byte;

    public boolean byte() {
        return this.break;
    }

    private am(boolean bl2, float f2) {
        this.break = bl2;
        this.byte = f2;
    }

    public am(float f2) {
        this(true, f2);
    }

    public am(boolean bl2) {
        this(bl2, 0.05f);
    }

    public int class() {
        return this.class;
    }

    public void break() {
        ++this.class;
    }

    public float protected() {
        return this.byte;
    }
}

