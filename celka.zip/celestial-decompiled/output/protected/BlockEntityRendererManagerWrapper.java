/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonObject
 */
package protected;

import com.google.gson.JsonObject;
import protected.hg_2;
import protected.ho_1;
import protected.hz_1;
import protected.rdn_1;
import protected.rhn_2;
import protected.rhz_2;
import protected.rpY;
import protected.rqo_0;
import protected.rwl_1;
import protected.xb_1;
import protected.xf_2;
import protected.xh_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.XG
 */
public class xg_2
extends hg_2<xb_1> {
    static final rqo_0 class = new rqo_0("inventory_changed");

    private void class(rhn_2 rhn_22, rhz_2 rhz_22, rdn_1 rdn_12, int n2, int n3, int n4) {
        this.class(rhn_22, (T xb_12) -> xb_12.class(rhz_22, rdn_12, n2, n3, n4));
    }

    @Override
    public rqo_0 class() {
        return xg_2.class;
    }

    public void class(rhn_2 rhn_22, rhz_2 rhz_22, rdn_1 rdn_12) {
        int n2 = 0;
        int n3 = 0;
        int n4 = 0;
        for (int k = 0; k < rhz_22.else(); ++k) {
            rdn_1 rdn_13 = rhz_22.extends(k);
            if (rdn_13.class()) {
                ++n3;
                continue;
            }
            ++n4;
            if (rdn_13.char() < rdn_13.byte()) continue;
            ++n2;
        }
        this.class(rhn_22, rhz_22, rdn_12, n2, n3, n4);
    }

    @Override
    public /* synthetic */ hz_1 class(JsonObject jsonObject, ho_1 ho_12, rwl_1 rwl_12) {
        return this.break(jsonObject, ho_12, rwl_12);
    }

    public xb_1 break(JsonObject jsonObject, ho_1 ho_12, rwl_1 rwl_12) {
        JsonObject jsonObject2 = rpY.class(jsonObject, "slots", new JsonObject());
        xf_2 xf_22 = xf_2.class(jsonObject2.get("occupied"));
        xf_2 xf_23 = xf_2.class(jsonObject2.get("full"));
        xf_2 xf_24 = xf_2.class(jsonObject2.get("empty"));
        xh_2[] xh_2Array = xh_2.break(jsonObject.get("items"));
        return new xb_1(ho_12, xf_22, xf_23, xf_24, xh_2Array);
    }
}

