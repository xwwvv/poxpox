/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.ch_0;
import protected.cj_0;
import protected.gm;
import protected.lo_0;
import protected.rfU;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class Co
extends lo_0 {
    private final ch_0 class;
    private final double break;

    protected Co(gm gm2, double d, double d2, double d3, float f2, float f3, float f4, double d4, double d5, double d6, float f5, ch_0 ch_02, float f6, int n2, double d7, boolean bl2) {
        super(gm2, d, d2, d3, 0.0, 0.0, 0.0);
        float f7;
        this.break = d7;
        this.class = ch_02;
        this.finally *= (double)f2;
        this.extends *= (double)f3;
        this.native *= (double)f4;
        this.finally += d4;
        this.extends += d5;
        this.native += d6;
        this.synchronized = f7 = gm2.int.nextFloat() * f6;
        this.return = f7;
        this.public = f7;
        this.throw *= 0.75f * f5;
        this.this = (int)((double)n2 / ((double)gm2.int.nextFloat() * 0.8 + 0.2));
        this.this = (int)((float)this.this * f5);
        this.this = Math.max(this.this, 1);
        this.break(ch_02);
        this.final = bl2;
    }

    @Override
    public float class(float f2) {
        return this.throw * rfU.class(((float)this.super + f2) / (float)this.this * 32.0f, 0.0f, 1.0f);
    }

    @Override
    public cj_0 class() {
        return cj_0.break;
    }

    @Override
    public void case() {
        this.protected = this.catch;
        this.throws = this.private;
        this.case = this.implements;
        if (this.super++ >= this.this) {
            this.finally();
        } else {
            this.break(this.class);
            this.extends += this.break;
            this.class(this.finally, this.extends, this.native);
            if (this.private == this.throws) {
                this.finally *= 1.1;
                this.native *= 1.1;
            }
            this.finally *= (double)0.96f;
            this.extends *= (double)0.96f;
            this.native *= (double)0.96f;
            if (this.volatile) {
                this.finally *= (double)0.7f;
                this.native *= (double)0.7f;
            }
        }
    }
}

