/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.io.DataInput;
import java.io.IOException;
import protected.rcd_1;
import protected.rcg_1;
import protected.rcv_2;
import protected.rcz_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.rcU
 */
class rcu_1
implements rcv_2<rcd_1> {
    @Override
    public boolean byte() {
        return true;
    }

    rcu_1() {
    }

    public rcd_1 class(DataInput dataInput, int n2, rcg_1 rcg_12) throws IOException {
        rcg_12.class(80L);
        return rcd_1.class(dataInput.readShort());
    }

    @Override
    public String class() {
        return "SHORT";
    }

    @Override
    public /* synthetic */ rcz_1 break(DataInput dataInput, int n2, rcg_1 rcg_12) throws IOException {
        return this.class(dataInput, n2, rcg_12);
    }

    @Override
    public String break() {
        return "TAG_Short";
    }
}

