/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.dh_1;
import protected.jq_1;
import protected.rRq;
import protected.rfH;
import protected.xc_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.Wn
 */
public class wn_1
extends dh_1 {
    private final int volatile;

    public wn_1(int n2, jq_1 jq_12) {
        super(jq_12);
        this.volatile = n2;
    }

    @Override
    public int catch(xc_0 xc_02, rRq rRq2, rfH rfH2) {
        return this.volatile;
    }
}

