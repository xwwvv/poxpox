/*
 * Decompiled with CFR 0.152.
 */
package protected;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.to
 */
public interface to_0 {
    public void class(boolean var1);
}

