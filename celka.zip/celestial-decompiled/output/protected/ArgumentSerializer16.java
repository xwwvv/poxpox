/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 */
package protected;

import com.google.common.collect.Lists;
import java.io.DataInput;
import java.io.IOException;
import java.util.ArrayList;
import protected.rcg_1;
import protected.rcv_2;
import protected.rcy_1;
import protected.rcy_2;
import protected.rcz_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.rcp
 */
class rcp_1
implements rcv_2<rcy_2> {
    rcp_1() {
    }

    @Override
    public String class() {
        return "LIST";
    }

    public rcy_2 class(DataInput dataInput, int n2, rcg_1 rcg_12) throws IOException {
        rcg_12.class(296L);
        if (n2 > 512) {
            throw new RuntimeException("Tried to read NBT tag with too high complexity, depth > 512");
        }
        byte by = dataInput.readByte();
        int n3 = dataInput.readInt();
        if (by == 0 && n3 > 0) {
            throw new RuntimeException("Missing type on ListTag");
        }
        rcg_12.class(32L * (long)n3);
        rcv_2<?> rcv_22 = rcy_1.class(by);
        ArrayList arrayList = Lists.newArrayListWithCapacity((int)n3);
        for (int k = 0; k < n3; ++k) {
            arrayList.add(rcv_22.break(dataInput, n2 + 1, rcg_12));
        }
        return new rcy_2(arrayList, by);
    }

    @Override
    public String break() {
        return "TAG_List";
    }

    @Override
    public /* synthetic */ rcz_1 break(DataInput dataInput, int n2, rcg_1 rcg_12) throws IOException {
        return this.class(dataInput, n2, rcg_12);
    }
}

