/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.cj_0;
import protected.gm;
import protected.lo_0;
import protected.rRq;
import protected.rfH;
import protected.rpb_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class Cf
extends lo_0 {
    protected Cf(gm gm2, double d, double d2, double d3) {
        super(gm2, d, d2, d3, 0.0, 0.0, 0.0);
        this.finally *= (double)0.3f;
        this.extends = Math.random() * (double)0.2f + (double)0.1f;
        this.native *= (double)0.3f;
        this.class(0.01f, 0.01f);
        this.else = 0.06f;
        this.this = (int)(8.0 / (Math.random() * 0.8 + 0.2));
    }

    @Override
    public cj_0 class() {
        return cj_0.break;
    }

    @Override
    public void case() {
        this.protected = this.catch;
        this.throws = this.private;
        this.case = this.implements;
        if (this.this-- <= 0) {
            this.finally();
        } else {
            rfH rfH2;
            double d;
            this.extends -= (double)this.else;
            this.class(this.finally, this.extends, this.native);
            this.finally *= (double)0.98f;
            this.extends *= (double)0.98f;
            this.native *= (double)0.98f;
            if (this.volatile) {
                if (Math.random() < 0.5) {
                    this.finally();
                }
                this.finally *= (double)0.7f;
                this.native *= (double)0.7f;
            }
            if ((d = Math.max(this.byte.byte(rfH2 = new rfH(this.catch, this.private, this.implements)).extends(this.byte, rfH2).class(rpb_0.Y, this.catch - (double)rfH2.b_(), this.implements - (double)rfH2.d_()), (double)this.byte.break(rfH2).class((rRq)this.byte, rfH2))) > 0.0 && this.private < (double)rfH2.c_() + d) {
                this.finally();
            }
        }
    }
}

