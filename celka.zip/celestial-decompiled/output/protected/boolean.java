/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Comparator;
import java.util.stream.Stream;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.case;
import protected.double;
import protected.else;
import protected.for;
import protected.synchronized;
import protected.this;
import protected.v_0;
import protected.x;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class boolean
extends Enum<boolean>
implements double<this[]> {
    private static short[] shorts1efcd1a6ae203b428c7ab1f68db4b5b6;
    public static Object[] staticFields1efcd1a6ae203b428c7ab1f68db4b5b6;
    private static byte[] bytes1efcd1a6ae203b428c7ab1f68db4b5b6;
    private static String[] strings1efcd1a6ae203b428c7ab1f68db4b5b6;
    private static boolean[] booleans1efcd1a6ae203b428c7ab1f68db4b5b6;

    @Override
    public /* synthetic */ Object byte(for for_) throws x {
        return this.break(for_);
    }

    private static void byte() {
        Object[] objectArray;
        objectArray = new Object[]{new boolean(), new boolean[]{(boolean)objectArray[0]}};
        staticFields1efcd1a6ae203b428c7ab1f68db4b5b6 = objectArray;
    }

    private static int byte(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0x640457EF;
    }

    public static String[] byte(case case_) {
        return (String[])Stream.of(boolean.class(case_)).map(this::byte).filter(string -> !string.isEmpty() ? booleans1efcd1a6ae203b428c7ab1f68db4b5b6[0] : booleans1efcd1a6ae203b428c7ab1f68db4b5b6[1]).toArray(String[]::new);
    }

    static {
        boolean.ntfClinit();
    }

    public static boolean[] values() {
        return (boolean[])((boolean[])staticFields1efcd1a6ae203b428c7ab1f68db4b5b6[shorts1efcd1a6ae203b428c7ab1f68db4b5b6[0]]).clone();
    }

    public static boolean valueOf(String string) {
        return Enum.valueOf(boolean.class, string);
    }

    private static void class() {
        strings1efcd1a6ae203b428c7ab1f68db4b5b6 = new String[]{new String("INSTANCE")};
    }

    public static this[] class(case case_) {
        return (this[])boolean.break(case_).class().stream().sorted(Comparator.comparingLong(this::protected).reversed()).toArray(this[]::new);
    }

    public static String class(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{1, -24, 0, 45, 23, 14, 7, -76}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    public static this[] class(case case_, String string) {
        return (this[])Stream.of(boolean.class(case_)).filter(this_ -> this_.byte().equalsIgnoreCase(string)).toArray(this[]::new);
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0xB46CC90323B472AFL;
    }

    public static this[] class(case case_, else else_) {
        return (this[])boolean.break(case_).break(else_).stream().sorted(Comparator.comparingLong(this::protected).reversed()).toArray(this[]::new);
    }

    @Override
    public Stream<String> class(for for_) throws x {
        return new v_0().break(boolean.byte(for_.break())).break().class(else.break()).class(for_.class().extends()).protected();
    }

    public static synchronized break(case case_) {
        return case_.implements().class().class();
    }

    private static void break() {
        boolean[] blArray = new boolean[7];
        blArray[0] = true;
        blArray[2] = true;
        blArray[6] = true;
        booleans1efcd1a6ae203b428c7ab1f68db4b5b6 = blArray;
    }

    public this[] break(for for_) throws x {
        String string = for_.class().extends();
        else else_ = else.class(string);
        return else_ == null ? boolean.class(for_.break(), string) : boolean.class(for_.break(), else_);
    }

    private static void throws() {
        short[] sArray = new short[2];
        sArray[0] = 1;
        shorts1efcd1a6ae203b428c7ab1f68db4b5b6 = sArray;
    }

    private static /* synthetic */ void ntfClinit() {
        boolean.break();
        boolean.class();
        boolean.throws();
        boolean.case();
        boolean.byte();
    }

    private static void case() {
        bytes1efcd1a6ae203b428c7ab1f68db4b5b6 = new byte[]{2};
    }

    private static /* synthetic */ boolean[] protected() {
        boolean[] booleanArray = new boolean[booleans1efcd1a6ae203b428c7ab1f68db4b5b6[2]];
        booleanArray[boolean.booleans1efcd1a6ae203b428c7ab1f68db4b5b6[3]] = (boolean)staticFields1efcd1a6ae203b428c7ab1f68db4b5b6[shorts1efcd1a6ae203b428c7ab1f68db4b5b6[1]];
        return booleanArray;
    }
}

