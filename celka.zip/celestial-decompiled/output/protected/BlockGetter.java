/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.ao_2;
import protected.ba;
import protected.bi_0;
import protected.class;
import protected.ps_1;
import protected.qy_1;
import protected.rYB;
import protected.rfH;
import protected.rfw;
import protected.roj_0;
import protected.ron_0;
import protected.roq_0;
import protected.rrpy_2;
import protected.si_2;
import protected.sr_1;
import protected.sw_1;
import protected.xc_0;
import protected.xd_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class bw {
    private static byte[] byte;
    public Object[] class;
    private static boolean[] protected;
    public static Object[] break;
    private static short[] throws;

    private void byte() {
        if (this.class == null) {
            Object[] objectArray = this.class = new Object[byte[22]];
            objectArray[bw.byte[23]] = protected[10];
        }
    }

    public bw(ps_1 ps_12) {
        this(ps_12, protected[0]);
    }

    public bw(ps_1 ps_12, boolean bl2) {
        this(ps_12.case(), (sr_1)ps_12.package(), bl2);
    }

    public bw(rYB rYB2, sr_1 sr_12, boolean bl2) {
        this.byte();
        Object var8_4 = null;
        this.class[bw.throws[0]] = var8_4;
        Object var9_5 = null;
        this.class[bw.throws[1]] = var9_5;
        rYB rYB3 = rYB2;
        this.class[bw.throws[2]] = rYB3;
        ba ba2 = new ba(rYB2.instanceof());
        this.class[bw.throws[3]] = ba2;
        sr_1 sr_13 = sr_12;
        this.class[bw.throws[4]] = sr_13;
        if (bl2) {
            ao_2 ao_22 = ((ao_2)rYB2.goto()).throws();
            this.class[bw.throws[5]] = ao_22;
        } else {
            ao_2 ao_23 = (ao_2)rYB2.goto();
            this.class[bw.throws[6]] = ao_23;
        }
        Boolean bl3 = (Boolean)protected.class.instanceof().rU.class[throws[7]] == false ? protected[1] : protected[2];
        this.class[bw.throws[8]] = bl3;
        if (!qy_1.instanceof().rX()) {
            throw new IllegalStateException();
        }
        rfw rfw2 = new rfw();
        this.class[bw.throws[9]] = rfw2;
        bi_0 bi_02 = new bi_0(this);
        this.class[bw.throws[10]] = bi_02;
    }

    static {
        bw.ntfClinit();
    }

    public boolean class(int n2, int n3) {
        return ((ao_2)this.class[throws[11]]).case(n2 >> byte[0], n3 >> byte[1]);
    }

    private static void class() {
        Object[] objectArray = new Object[]{rrpy_2.class};
        break = objectArray;
    }

    public static String class(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{96, 83, -66, 89, -73, 18, -107, 58}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    public static xc_0 class(roj_0 roj_02, int n2, int n3, int n4) {
        roq_0 roq_02 = roj_02.byte()[n3 >> byte[18]];
        if (roq_0.class(roq_02)) {
            return (xc_0)break[throws[40]];
        }
        return roq_02.class(n2 & byte[19], n3 & byte[20], n4 & byte[21]);
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0xF99E18F760ED91D4L;
    }

    public xc_0 class(int n2, int n3, int n4) {
        Object object;
        Object object2;
        if (n3 < 0 || n3 >= throws[12]) {
            return (xc_0)break[throws[13]];
        }
        if (((Boolean)this.class[throws[14]]).booleanValue()) {
            object2 = (roj_0)this.class[throws[15]];
            if (object2 != null && ((roj_0)object2).private().break == n2 >> byte[2] && ((roj_0)object2).private().byte == n4 >> byte[3]) {
                return bw.class((roj_0)object2, n2, n3, n4);
            }
            object = ((ao_2)this.class[throws[16]]).class(n2 >> byte[4], n4 >> byte[5], ron_0.volatile, protected[3]);
            if (object != null && !((roj_0)object).catch()) {
                roj_0 roj_02 = object;
                this.class[bw.throws[17]] = roj_02;
                return bw.class((roj_0)object, n2, n3, n4);
            }
        }
        if ((object2 = (sw_1)this.class[throws[18]]) == null || ((sw_1)object2).break() != n2 >> byte[6] || ((sw_1)object2).class() != n4 >> byte[7]) {
            Object object3;
            if ((sr_1)this.class[throws[19]] == null) {
                return (xc_0)break[throws[20]];
            }
            object = ((si_2)((sr_1)this.class[bw.throws[21]]).class[throws[22]]).throws(n2 >> byte[8], n4 >> byte[9]);
            if (object == null) {
                return (xc_0)break[throws[23]];
            }
            this.class[bw.throws[24]] = object3 = object;
            object2 = object;
        }
        if ((object = ((sw_1)object2).class(n2 & throws[25], n3, n4 & throws[26])) == null) {
            return (xc_0)break[throws[27]];
        }
        return object;
    }

    public xc_0 class(rfH rfH2) {
        return this.class(rfH2.b_(), rfH2.c_(), rfH2.d_());
    }

    public static xc_0 class(ps_1 ps_12, rfH rfH2) {
        return new bw(ps_12).class(rfH2.b_(), rfH2.c_(), rfH2.d_());
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0x705CABB5;
    }

    public boolean break(int n2, int n3) {
        roj_0 roj_02 = (roj_0)this.class[throws[28]];
        if (roj_02 != null && roj_02.private().break == n2 >> byte[10] && roj_02.private().byte == n3 >> byte[11]) {
            return protected[4];
        }
        roj_02 = ((ao_2)this.class[throws[29]]).class(n2 >> byte[12], n3 >> byte[13], ron_0.volatile, protected[5]);
        if (roj_02 != null && !roj_02.catch()) {
            roj_0 roj_03 = roj_02;
            this.class[bw.throws[30]] = roj_03;
            return protected[6];
        }
        sw_1 sw_12 = (sw_1)this.class[throws[31]];
        if (sw_12 != null && sw_12.break() == n2 >> byte[14] && sw_12.class() == n3 >> byte[15]) {
            return sw_12.class(n2 & throws[32], n3 & throws[33]);
        }
        if ((sr_1)this.class[throws[34]] == null) {
            return protected[7];
        }
        sw_12 = ((si_2)((sr_1)this.class[bw.throws[35]]).class[throws[36]]).throws(n2 >> byte[16], n3 >> byte[17]);
        if (sw_12 == null) {
            return protected[8];
        }
        sw_1 sw_13 = sw_12;
        this.class[bw.throws[37]] = sw_13;
        return sw_12.class(n2 & throws[38], n3 & throws[39]);
    }

    public static xd_0 break(ps_1 ps_12, rfH rfH2) {
        return bw.class(ps_12, rfH2).break();
    }

    private static void break() {
        short[] sArray = new short[41];
        sArray[0] = 6;
        sArray[1] = 7;
        sArray[2] = 2;
        sArray[3] = 5;
        sArray[4] = 1;
        sArray[8] = 8;
        sArray[9] = 3;
        sArray[10] = 4;
        sArray[12] = 256;
        sArray[14] = 8;
        sArray[15] = 6;
        sArray[17] = 6;
        sArray[18] = 7;
        sArray[19] = 1;
        sArray[21] = 1;
        sArray[24] = 7;
        sArray[25] = 511;
        sArray[26] = 511;
        sArray[28] = 6;
        sArray[30] = 6;
        sArray[31] = 7;
        sArray[32] = 511;
        sArray[33] = 511;
        sArray[34] = 1;
        sArray[35] = 1;
        sArray[37] = 7;
        sArray[38] = 511;
        sArray[39] = 511;
        throws = sArray;
    }

    private static void throws() {
        byte = new byte[]{4, 4, 4, 4, 4, 4, 9, 9, 9, 9, 4, 4, 4, 4, 9, 9, 9, 9, 4, 15, 15, 15, 9, 8};
    }

    private static /* synthetic */ void ntfClinit() {
        bw.protected();
        bw.break();
        bw.throws();
        bw.class();
    }

    private static void protected() {
        boolean[] blArray = new boolean[12];
        blArray[1] = true;
        blArray[4] = true;
        blArray[6] = true;
        blArray[11] = true;
        protected = blArray;
    }
}

