/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.Y;
import protected.bf_2;
import protected.bl_2;
import protected.bn_2;
import protected.bp_2;
import protected.bq_2;
import protected.bt_1;
import protected.bt_2;
import protected.bw_2;
import protected.class;
import protected.pv_2;
import protected.q;
import protected.rja;
import protected.rrfp;
import protected.rrfq;
import protected.rrje;
import protected.rrlo_2;
import protected.rrqx_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.BI
 */
public class bi_2
extends pv_2 {
    private static short[] byte;
    private static boolean[] protected;
    public Object[] break;
    private static String[] throws;
    private static byte[] case;

    private static void byte() {
        short[] sArray = new short[22];
        sArray[1] = 1;
        sArray[2] = 1;
        sArray[3] = 2;
        sArray[4] = 1;
        sArray[5] = 4;
        sArray[7] = 1;
        sArray[8] = 2;
        sArray[9] = 3;
        sArray[10] = 1;
        sArray[12] = 1;
        sArray[13] = 1;
        sArray[14] = 1;
        sArray[19] = 1;
        byte = sArray;
    }

    private boolean byte(String string) {
        this.class();
        bt_1 bt_12 = ((bw_2)this.break[byte[15]]).class(string);
        if (bt_12 == null) {
            return protected[0];
        }
        rja rja2 = null;
        if (bt_12 instanceof bn_2) {
            bn_2 bn_22 = (bn_2)bt_12;
            try {
                rja2 = bn_22.break(string);
            }
            catch (Exception exception) {
                exception.printStackTrace();
                return protected[1];
            }
            if (rja2 == null) {
                return protected[2];
            }
            bn_22.class(rja2);
        }
        bt_12.throws(string);
        if (rja2 != null) {
            boolean bl2 = ((rrje)((Object)rrje.staticFields67a5399629443d9d93e54c2de6d74063[byte[16]])).class(rja2);
            bt_12.protected(this.class(bt_12.throws(), bl2));
            if (((rrje)((Object)rrje.staticFields67a5399629443d9d93e54c2de6d74063[byte[17]])).protected(bt_12.throws()) && bl2) {
                return protected[3];
            }
        }
        ((rrqx_1)rrqx_1.staticFields09f1f28026cd378cb9df490a64ac8f2a[byte[18]]).finally().class(bp_2.class((bq_2)((Object)bq_2.staticFieldsc48d9c2a6a943f1684eec8a5f13e9034[byte[19]]), bt_12, (bt_2)((Object)bt_2.staticFields10e8ecd1ac80321e9230ae9a938c7436[byte[20]])));
        return protected[4];
    }

    public bi_2(class clazz) {
        super(clazz);
        ArrayList arrayList;
        this.class();
        bf_2 bf_22 = new bf_2();
        this.break[bi_2.byte[0]] = bf_22;
        this.break[bi_2.byte[1]] = arrayList = new ArrayList();
    }

    static {
        bi_2.ntfClinit();
    }

    @Override
    public void class(q q2) {
        this.class();
        if (q2.class() == (Y)((Object)Y.staticFields22c81230f53b33f2a682b4198db24cc4[byte[11]]) && !((List)this.break[byte[12]]).isEmpty()) {
            for (String string : this.class((List)this.break[byte[13]]).values()) {
                this.byte(string);
            }
            ((List)this.break[byte[14]]).clear();
        }
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0xB153521B;
    }

    static boolean class(String string, String[] stringArray) {
        String[] stringArray2 = stringArray;
        int n2 = stringArray2.length;
        for (int k = protected[12]; k < n2; ++k) {
            String string2 = stringArray2[k];
            if (string.contains(string2)) continue;
            return protected[13];
        }
        return protected[14];
    }

    private Map<Integer, String> class(List<String> list) {
        if (list.size() == protected[8]) {
            return Map.of(protected[9], list.get(protected[10]));
        }
        HashMap<Integer, String> hashMap = new HashMap<Integer, String>();
        int n2 = protected[11];
        for (String string : list) {
            Object object = hashMap.get(n2) != null ? (String)hashMap.get(n2) + " " + string : string;
            if (string.contains(throws[0])) {
                hashMap.put(n2, (String)object);
                ++n2;
                continue;
            }
            hashMap.put(n2, (String)object);
        }
        return hashMap;
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0xAA0072EF7B10EDDL;
    }

    @Override
    public void class(rrlo_2 rrlo_22) {
        this.class();
        if (rrlo_22.class() != null || (rrfq)((Object)rrfp.class[byte[2]]) != (rrfq)((Object)rrfq.staticFields8f8c034c8eef39ccbbc33e665d937d16[byte[3]]) && (rrfq)((Object)rrfp.class[byte[4]]) != (rrfq)((Object)rrfq.staticFields8f8c034c8eef39ccbbc33e665d937d16[byte[5]])) {
            return;
        }
        String string = rrlo_22.protected();
        if (this.byte(string)) {
            return;
        }
        if (((Pattern)bl_2.class[byte[6]]).matcher(string).find() || ((Pattern)bl_2.class[byte[7]]).matcher(string).find() || ((Pattern)bl_2.class[byte[8]]).matcher(string).find() || ((Pattern)bl_2.class[byte[9]]).matcher(string).find()) {
            ((List)this.break[byte[10]]).add(string);
        }
    }

    private String class(String string, boolean bl2) {
        String string2 = string;
        int n2 = protected[5];
        while (((rrje)((Object)rrje.staticFields67a5399629443d9d93e54c2de6d74063[byte[21]])).protected(string2) && !bl2) {
            Object[] objectArray = new Object[protected[6]];
            objectArray[bi_2.protected[7]] = ++n2;
            string2 = String.format(string + " %d", objectArray);
        }
        return string2;
    }

    private void class() {
        if (this.break == null) {
            Object[] objectArray = this.break = new Object[case[0]];
        }
    }

    public static String break(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{-25, -83, 46, 23, -128, 57, 28, 17}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    private static void break() {
        case = new byte[]{2};
    }

    private static void throws() {
        throws = new String[]{new String("\u041a\u043e\u043e\u0440\u0434\u0438\u043d\u0430\u0442\u044b:")};
    }

    private static /* synthetic */ void ntfClinit() {
        bi_2.protected();
        bi_2.throws();
        bi_2.byte();
        bi_2.break();
    }

    private static void protected() {
        boolean[] blArray = new boolean[15];
        blArray[4] = true;
        blArray[5] = true;
        blArray[6] = true;
        blArray[8] = true;
        blArray[14] = true;
        protected = blArray;
    }
}

