/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.rgP;
import protected.rgn;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.Az
 */
public final class az_2
extends Enum<az_2> {
    public static final /* enum */ az_2 ENABLED = new az_2("enabled");
    public static final /* enum */ az_2 DISABLED = new az_2("disabled");
    public static final /* enum */ az_2 PROMPT = new az_2("prompt");
    private final rgP motd;
    private static final /* synthetic */ az_2[] $VALUES;

    private az_2(String string2) {
        this.motd = new rgn("addServer.resourcePack." + string2);
    }

    static {
        $VALUES = az_2.break();
    }

    public static az_2[] values() {
        return (az_2[])$VALUES.clone();
    }

    public static az_2 valueOf(String string) {
        return Enum.valueOf(az_2.class, string);
    }

    public rgP class() {
        return this.motd;
    }

    private static /* synthetic */ az_2[] break() {
        return new az_2[]{ENABLED, DISABLED, PROMPT};
    }
}

