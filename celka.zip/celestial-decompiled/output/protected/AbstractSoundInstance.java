/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.nf_1;
import protected.ni_2;
import protected.nn_2;
import protected.nq_1;
import protected.nq_2;
import protected.rqa_0;
import protected.rql_0;
import protected.rqo_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.Nv
 */
public abstract class nv_2
implements nq_2 {
    protected nq_1 break;
    protected final rql_0 byte;
    protected final rqo_0 protected;
    protected float throws = 1.0f;
    protected float case = 1.0f;
    protected double catch;
    protected double private;
    protected double implements;
    protected boolean finally;
    protected int extends;
    protected nn_2 native = nn_2.LINEAR;
    protected boolean volatile;
    protected boolean final;

    @Override
    public double int() {
        return this.implements;
    }

    protected nv_2(rqa_0 rqa_02, rql_0 rql_02) {
        this(rqa_02.class(), rql_02);
    }

    protected nv_2(rqo_0 rqo_02, rql_0 rql_02) {
        this.protected = rqo_02;
        this.byte = rql_02;
    }

    public String toString() {
        return "SoundInstance[" + this.protected + "]";
    }

    @Override
    public ni_2 class(nf_1 nf_12) {
        ni_2 ni_22 = nf_12.class(this.protected);
        this.break = ni_22 == null ? nf_1.class : ni_22.byte();
        return ni_22;
    }

    @Override
    public boolean finally() {
        return this.final;
    }

    @Override
    public nq_1 catch() {
        return this.break;
    }

    @Override
    public int extends() {
        return this.extends;
    }

    @Override
    public rqo_0 case() {
        return this.protected;
    }

    @Override
    public boolean implements() {
        return this.finally;
    }

    @Override
    public nn_2 new() {
        return this.native;
    }

    @Override
    public double package() {
        return this.private;
    }

    @Override
    public rql_0 private() {
        return this.byte;
    }

    @Override
    public double final() {
        return this.catch;
    }

    @Override
    public float volatile() {
        return this.case * this.break.case();
    }

    @Override
    public float native() {
        return this.throws * this.break.throws();
    }
}

