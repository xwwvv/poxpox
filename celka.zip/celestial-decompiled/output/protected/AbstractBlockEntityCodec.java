/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.serialization.Codec
 */
package protected;

import com.mojang.serialization.Codec;
import protected.rkd_0;
import protected.rkk_0;
import protected.rku_0;
import protected.rky_0;
import protected.rvl_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class rKo<P extends rky_0> {
    public static final rKo<rku_0> class = rKo.class("simple_block_placer", rku_0.break);
    public static final rKo<rkd_0> break = rKo.class("double_plant_placer", rkd_0.break);
    public static final rKo<rkk_0> byte = rKo.class("column_placer", rkk_0.break);
    private final Codec<P> protected;

    private rKo(Codec<P> codec) {
        this.protected = codec;
    }

    private static <P extends rky_0> rKo<P> class(String string, Codec<P> codec) {
        return rvl_0.class(rvl_0.rr, string, new rKo<P>(codec));
    }

    public Codec<P> class() {
        return this.protected;
    }
}

