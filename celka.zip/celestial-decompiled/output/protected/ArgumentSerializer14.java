/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.io.DataInput;
import java.io.IOException;
import protected.rcg_1;
import protected.rcm_2;
import protected.rcv_2;
import protected.rcz_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.rcO
 */
class rco_2
implements rcv_2<rcm_2> {
    rco_2() {
    }

    @Override
    public String class() {
        return "BYTE[]";
    }

    public rcm_2 class(DataInput dataInput, int n2, rcg_1 rcg_12) throws IOException {
        rcg_12.class(192L);
        int n3 = dataInput.readInt();
        rcg_12.class(8L * (long)n3);
        byte[] byArray = new byte[n3];
        dataInput.readFully(byArray);
        return new rcm_2(byArray);
    }

    @Override
    public String break() {
        return "TAG_Byte_Array";
    }

    @Override
    public /* synthetic */ rcz_1 break(DataInput dataInput, int n2, rcg_1 rcg_12) throws IOException {
        return this.class(dataInput, n2, rcg_12);
    }
}

