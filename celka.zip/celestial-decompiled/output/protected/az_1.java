/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.rqR;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.AZ
 */
public class az_1 {
    private final String class;
    private final String break;
    private long byte;

    public void byte() {
        this.byte = rqR.break();
    }

    public az_1(String string, String string2) {
        this.class = string;
        this.break = string2;
        this.byte = rqR.break();
    }

    public String class() {
        return this.class;
    }

    public String break() {
        return this.break;
    }
}

