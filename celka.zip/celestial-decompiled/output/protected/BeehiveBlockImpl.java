/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.util.List;
import java.util.Random;
import protected.an;
import protected.db_2;
import protected.dt_1;
import protected.ea_0;
import protected.ey_0;
import protected.ib_0;
import protected.jq_1;
import protected.ke_2;
import protected.oo_1;
import protected.rCL;
import protected.rCm;
import protected.rHx;
import protected.rRg;
import protected.rRq;
import protected.rYB;
import protected.rbf_0;
import protected.rcc_0;
import protected.rcd_2;
import protected.rct_0;
import protected.rdn_1;
import protected.rdy_2;
import protected.rej_2;
import protected.rfH;
import protected.rfU;
import protected.rff;
import protected.rfl;
import protected.rhd_2;
import protected.rhk_0;
import protected.rhn_2;
import protected.rhu_1;
import protected.rhz_2;
import protected.rjC;
import protected.rlq_2;
import protected.rls;
import protected.rpb_0;
import protected.rpm;
import protected.rpr_0;
import protected.rqR;
import protected.rql_0;
import protected.rqn;
import protected.rru_0;
import protected.rsX;
import protected.rse_0;
import protected.rsn_1;
import protected.rsv_0;
import protected.rxx;
import protected.ryo_2;
import protected.ryz_1;
import protected.rzp_2;
import protected.rzq_2;
import protected.xc_0;
import protected.xd_0;
import protected.xn;
import protected.xn_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.xO
 */
public class xo_0
extends db_2 {
    private static final rpr_0[] package = new rpr_0[]{rpr_0.WEST, rpr_0.EAST, rpr_0.SOUTH};
    public static final rcc_0 volatile = ke_2.p;
    public static final rCm final = rct_0.L;

    public xo_0(jq_1 jq_12) {
        super(jq_12);
        this.extends((xc_0)((xc_0)((xc_0)this.abstract.break()).class(final, 0)).class(volatile, rpr_0.NORTH));
    }

    @Override
    public ryo_2 class(rRq rRq2) {
        return new rHx();
    }

    @Override
    public xn_0 class(xc_0 xc_02) {
        return xn_0.MODEL;
    }

    @Override
    protected void class(rCL<xd_0, xc_0> rCL2) {
        rCL2.class(final, volatile);
    }

    @Override
    public xc_0 class(rxx rxx2) {
        return (xc_0)this.continue().class(volatile, rxx2.case().case());
    }

    private void class(rYB rYB2, rfH rfH2, rjC rjC2, double d) {
        this.class(rYB2, (double)rfH2.b_() + rjC2.break(rpb_0.X), (double)rfH2.b_() + rjC2.byte(rpb_0.X), (double)rfH2.d_() + rjC2.break(rpb_0.Z), (double)rfH2.d_() + rjC2.byte(rpb_0.Z), d);
    }

    public static rpr_0 class(Random random) {
        return rqR.class(package, random);
    }

    @Override
    public xc_0 class(xc_0 xc_02, rpr_0 rpr_02, xc_0 xc_03, rRg rRg2, rfH rfH2, rfH rfH3) {
        ryo_2 ryo_22;
        if (rRg2.byte(rfH3).break() instanceof dt_1 && (ryo_22 = rRg2.class(rfH2)) instanceof rHx) {
            rHx rHx2 = (rHx)ryo_22;
            rHx2.class(null, xc_02, rhk_0.EMERGENCY);
        }
        return super.class(xc_02, rpr_02, xc_03, rRg2, rfH2, rfH3);
    }

    @Override
    public List<rdn_1> class(xc_0 xc_02, rzp_2 rzp_22) {
        ryo_2 ryo_22;
        an an2 = rzp_22.break(rzq_2.class);
        if ((an2 instanceof rsX || an2 instanceof rej_2 || an2 instanceof rhu_1 || an2 instanceof rsn_1 || an2 instanceof rsv_0) && (ryo_22 = rzp_22.break(rzq_2.private)) instanceof rHx) {
            rHx rHx2 = (rHx)ryo_22;
            rHx2.class(null, xc_02, rhk_0.EMERGENCY);
        }
        return super.class(xc_02, rzp_22);
    }

    @Override
    public void class(rYB rYB2, rfH rfH2, xc_0 xc_02, rhd_2 rhd_22) {
        ryo_2 ryo_22;
        if (!rYB2.continue && rhd_22.implements() && rYB2.B().break(rru_0.case) && (ryo_22 = rYB2.class(rfH2)) instanceof rHx) {
            rcd_2 rcd_22;
            boolean bl2;
            rHx rHx2 = (rHx)ryo_22;
            rdn_1 rdn_12 = new rdn_1(this);
            int n2 = xc_02.byte(final);
            boolean bl3 = bl2 = !rHx2.catch();
            if (!bl2 && n2 == 0) {
                return;
            }
            if (bl2) {
                rcd_22 = new rcd_2();
                rcd_22.class("Bees", rHx2.volatile());
                rdn_12.class("BlockEntityTag", rcd_22);
            }
            rcd_22 = new rcd_2();
            rcd_22.break("honey_level", n2);
            rdn_12.class("BlockStateTag", rcd_22);
            rse_0 rse_02 = new rse_0(rYB2, rfH2.b_(), rfH2.c_(), rfH2.d_(), rdn_12);
            rse_02.private();
            rYB2.a_(rse_02);
        }
        super.class(rYB2, rfH2, xc_02, rhd_22);
    }

    public void class(rYB rYB2, xc_0 xc_02, rfH rfH2, rhd_2 rhd_22, rhk_0 rhk_02) {
        this.class(rYB2, xc_02, rfH2);
        ryo_2 ryo_22 = rYB2.class(rfH2);
        if (ryo_22 instanceof rHx) {
            rHx rHx2 = (rHx)ryo_22;
            rHx2.class(rhd_22, xc_02, rhk_02);
        }
    }

    private void class(rYB rYB2, double d, double d2, double d3, double d4, double d5) {
        rYB2.class(rlq_2.d, rfU.protected(rYB2.int.nextDouble(), d, d2), d5, rfU.protected(rYB2.int.nextDouble(), d3, d4), 0.0, 0.0, 0.0);
    }

    @Override
    public void class(rYB rYB2, rhd_2 rhd_22, rfH rfH2, xc_0 xc_02, ryo_2 ryo_22, rdn_1 rdn_12) {
        super.class(rYB2, rhd_22, rfH2, xc_02, ryo_22, rdn_12);
        if (!rYB2.continue && ryo_22 instanceof rHx) {
            rHx rHx2 = (rHx)ryo_22;
            if (ea_0.class(ey_0.else, rdn_12) == 0) {
                rHx2.class(rhd_22, xc_02, rhk_0.EMERGENCY);
                rYB2.byte(rfH2, this);
                this.break(rYB2, rfH2);
            }
            oo_1.import.class((rhn_2)rhd_22, xc_02.break(), rdn_12, rHx2.finally());
        }
    }

    public static void class(rYB rYB2, rfH rfH2) {
        xo_0.class(rYB2, rfH2, new rdn_1(rdy_2.Wm, 3));
    }

    @Override
    public ryz_1 class(xc_0 xc_02, rYB rYB2, rfH rfH2, rhd_2 rhd_23, rpm rpm2, rff rff2) {
        rdn_1 rdn_12 = rhd_23.protected(rpm2);
        int n2 = xc_02.byte(final);
        boolean bl2 = false;
        if (n2 >= 5) {
            if (rdn_12.break() == rdy_2.JJ) {
                rYB2.class(rhd_23, rhd_23.rx(), rhd_23.re(), rhd_23.BO(), rqn.f, rql_0.NEUTRAL, 1.0f, 1.0f);
                xo_0.class(rYB2, rfH2);
                rdn_12.class(1, rhd_23, (T rhd_22) -> rhd_22.byte(rpm2));
                bl2 = true;
            } else if (rdn_12.break() == rdy_2.Jn) {
                rdn_12.catch(1);
                rYB2.class(rhd_23, rhd_23.rx(), rhd_23.re(), rhd_23.BO(), rqn.rb, rql_0.NEUTRAL, 1.0f, 1.0f);
                if (rdn_12.class()) {
                    rhd_23.class(rpm2, new rdn_1(rdy_2.WF));
                } else if (!((rhz_2)rhd_23.implements[1]).throws(new rdn_1(rdy_2.WF))) {
                    rhd_23.class(new rdn_1(rdy_2.WF), false);
                }
                bl2 = true;
            }
        }
        if (bl2) {
            if (!xn.class(rYB2, rfH2)) {
                if (this.protected(rYB2, rfH2)) {
                    this.break(rYB2, rfH2);
                }
                this.class(rYB2, xc_02, rfH2, rhd_23, rhk_0.EMERGENCY);
            } else {
                this.class(rYB2, xc_02, rfH2);
            }
            return ryz_1.class(rYB2.continue);
        }
        return super.class(xc_02, rYB2, rfH2, rhd_23, rpm2, rff2);
    }

    private void class(rYB rYB2, rfH rfH2, xc_0 xc_02) {
        rjC rjC2;
        double d;
        if (xc_02.volatile().byte() && !(rYB2.int.nextFloat() < 0.3f) && (d = (rjC2 = xc_02.extends(rYB2, rfH2)).byte(rpb_0.Y)) >= 1.0 && !xc_02.class(rls.B)) {
            double d2 = rjC2.break(rpb_0.Y);
            if (d2 > 0.0) {
                this.class(rYB2, rfH2, rjC2, (double)rfH2.c_() + d2 - 0.05);
            } else {
                rfH rfH3 = rfH2.break();
                xc_0 xc_03 = rYB2.byte(rfH3);
                rjC rjC3 = xc_03.extends(rYB2, rfH3);
                double d3 = rjC3.byte(rpb_0.Y);
                if ((d3 < 1.0 || !xc_03.new(rYB2, rfH3)) && xc_03.volatile().byte()) {
                    this.class(rYB2, rfH2, rjC2, (double)rfH2.c_() - 0.05);
                }
            }
        }
    }

    @Override
    public void class(xc_0 xc_02, rYB rYB2, rfH rfH2, Random random) {
        if (xc_02.byte(final) >= 5) {
            for (int k = 0; k < random.nextInt(1) + 1; ++k) {
                this.class(rYB2, rfH2, xc_02);
            }
        }
    }

    public void class(rYB rYB2, xc_0 xc_02, rfH rfH2) {
        rYB2.class(rfH2, (xc_0)xc_02.class(final, 0), 3);
    }

    private void break(rYB rYB2, rfH rfH2) {
        List<rbf_0> list = rYB2.class(rbf_0.class, new rfl(rfH2).byte(8.0, 6.0, 8.0));
        if (!list.isEmpty()) {
            List<rhd_2> list2 = rYB2.class(rhd_2.class, new rfl(rfH2).byte(8.0, 6.0, 8.0));
            int n2 = list2.size();
            for (rbf_0 rbf_02 : list) {
                if (rbf_02.I_() != null) continue;
                rbf_02.byte((ib_0)list2.get(rYB2.int.nextInt(n2)));
            }
        }
    }

    @Override
    public int break(xc_0 xc_02, rYB rYB2, rfH rfH2) {
        return xc_02.byte(final);
    }

    @Override
    public boolean case(xc_0 xc_02) {
        return true;
    }

    private boolean protected(rYB rYB2, rfH rfH2) {
        ryo_2 ryo_22 = rYB2.class(rfH2);
        if (ryo_22 instanceof rHx) {
            rHx rHx2 = (rHx)ryo_22;
            return !rHx2.catch();
        }
        return false;
    }
}

