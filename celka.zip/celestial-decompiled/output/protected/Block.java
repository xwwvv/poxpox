/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.cache.CacheBuilder
 *  com.google.common.cache.CacheLoader
 *  com.google.common.cache.LoadingCache
 *  it.unimi.dsi.fastutil.objects.Object2ByteLinkedOpenHashMap
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
package protected;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import it.unimi.dsi.fastutil.objects.Object2ByteLinkedOpenHashMap;
import java.util.List;
import java.util.Random;
import java.util.stream.Stream;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import protected.VD;
import protected.an;
import protected.cb_1;
import protected.ib_0;
import protected.ja_2;
import protected.jq_1;
import protected.kz_1;
import protected.qy_1;
import protected.rCF;
import protected.rCL;
import protected.rRR;
import protected.rRg;
import protected.rRq;
import protected.rVi;
import protected.rYB;
import protected.rbw_0;
import protected.rdb_1;
import protected.rdn_1;
import protected.rdx_1;
import protected.rfH;
import protected.rfw;
import protected.rgP;
import protected.rgn;
import protected.rhd_2;
import protected.rjC;
import protected.rjU;
import protected.rja;
import protected.rjn_0;
import protected.rjw;
import protected.rlb;
import protected.rlb_0;
import protected.rls;
import protected.rpb_0;
import protected.rpl_0;
import protected.rpr_0;
import protected.rqR;
import protected.rqe_0;
import protected.rqs;
import protected.rrEm;
import protected.rrae_0;
import protected.rrqx_1;
import protected.rru_0;
import protected.rrw_0;
import protected.rse_0;
import protected.rsp_0;
import protected.rvl_0;
import protected.rxj_0;
import protected.rxx;
import protected.ryh_1;
import protected.ryo_2;
import protected.rzp_2;
import protected.rzq_2;
import protected.xc_0;
import protected.xk_0;
import protected.xu_0;
import protected.xw_0;
import protected.xz_0;
import protected.zr_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.xd
 */
public class xd_0
extends ja_2
implements rpl_0 {
    protected static final Logger interface = LogManager.getLogger();
    public static final rqe_0<xc_0> char = new rqe_0();
    private static final LoadingCache<rjC, Boolean> volatile = CacheBuilder.newBuilder().maximumSize(512L).weakKeys().build((CacheLoader)new xk_0());
    protected final rCF<xd_0, xc_0> abstract;
    private xc_0 final;
    private String package;
    private rdb_1 int;
    private static final ThreadLocal<Object2ByteLinkedOpenHashMap<xz_0>> new = ThreadLocal.withInitial(() -> {
        xw_0 xw_02 = new xw_0(2048, 0.25f);
        xw_02.defaultReturnValue((byte)127);
        return xw_02;
    });

    public void byte(rYB rYB2, rfH rfH2) {
    }

    public static boolean byte(xc_0 xc_02, rRq rRq2, rfH rfH2, rpr_0 rpr_02) {
        rfH rfH3 = rfH2.break(rpr_02);
        xc_0 xc_03 = rRq2.byte(rfH3);
        if (xc_02.class(xc_03, rpr_02)) {
            return false;
        }
        if (xc_03.native()) {
            xz_0 xz_02 = new xz_0(xc_02, xc_03, rpr_02);
            Object2ByteLinkedOpenHashMap<xz_0> object2ByteLinkedOpenHashMap = new.get();
            byte by = object2ByteLinkedOpenHashMap.getAndMoveToFirst((Object)xz_02);
            if (by != 127) {
                return by != 0;
            }
            rjC rjC2 = xc_02.class(rRq2, rfH2, rpr_02);
            rjC rjC3 = xc_03.class(rRq2, rfH3, rpr_02.case());
            boolean bl2 = rjw.byte(rjC2, rjC3, rjn_0.throws);
            if (object2ByteLinkedOpenHashMap.size() == 2048) {
                object2ByteLinkedOpenHashMap.removeLastByte();
            }
            object2ByteLinkedOpenHashMap.putAndMoveToFirst((Object)xz_02, (byte)(bl2 ? 1 : 0));
            return bl2;
        }
        return true;
    }

    public static boolean byte(rRq rRq2, rfH rfH2) {
        return rRq2.byte(rfH2).class(rRq2, rfH2, rpr_0.UP, ryh_1.RIGID);
    }

    public static boolean byte(xd_0 xd_02) {
        return xd_02 instanceof kz_1 || xd_02 == xu_0.Ec || xd_02 == xu_0.Br || xd_02 == xu_0.BP || xd_02 == xu_0.Bg || xd_02 == xu_0.Pg || xd_02.class(rls.L);
    }

    public float int() {
        return this.implements;
    }

    public xd_0(jq_1 jq_12) {
        super(jq_12);
        rCL<xd_0, xc_0> rCL2 = new rCL<xd_0, xc_0>(this);
        this.class(rCL2);
        this.abstract = rCL2.class(xd_0::continue, xc_0::new);
        this.extends(this.abstract.break());
    }

    public String toString() {
        return "Block{" + rvl_0.strictfp.break(this) + "}";
    }

    public void class(rYB rYB2, rhd_2 rhd_22, rfH rfH2, xc_0 xc_02, ryo_2 ryo_22, rdn_1 rdn_12) {
        rhd_22.class(rlb_0.class.break(this));
        rhd_22.while(0.005f);
        xd_0.class(xc_02, rYB2, rfH2, ryo_22, (an)rhd_22, rdn_12);
    }

    public static void class(rYB rYB2, rfH rfH2, rdn_1 rdn_12) {
        if (!rYB2.continue && !rdn_12.class() && rYB2.B().break(rru_0.case)) {
            float f2 = 0.5f;
            double d = (double)(rYB2.int.nextFloat() * 0.5f) + 0.25;
            double d2 = (double)(rYB2.int.nextFloat() * 0.5f) + 0.25;
            double d3 = (double)(rYB2.int.nextFloat() * 0.5f) + 0.25;
            rse_0 rse_02 = new rse_0(rYB2, (double)rfH2.b_() + d, (double)rfH2.c_() + d2, (double)rfH2.d_() + d3, rdn_12);
            rse_02.private();
            rYB2.a_(rse_02);
        }
    }

    public static void class(xc_0 xc_02, rYB rYB2, rfH rfH2, ryo_2 ryo_22, an an2, rdn_1 rdn_13) {
        if (rYB2 instanceof rrEm) {
            xd_0.class(xc_02, (rrEm)rYB2, rfH2, ryo_22, an2, rdn_13).forEach(rdn_12 -> xd_0.class(rYB2, rfH2, rdn_12));
            xc_02.class((rrEm)rYB2, rfH2, rdn_13);
        }
    }

    public void class(rYB rYB2, rfH rfH2, xc_0 xc_02, ib_0 ib_02, rdn_1 rdn_12) {
        if (ib_02 == (cb_1)qy_1.instanceof().class[57]) {
            ((rrqx_1)rrqx_1.staticFields09f1f28026cd378cb9df490a64ac8f2a[0]).finally().class(rrae_0.class(rfH2, rdn_12));
        }
    }

    public boolean class() {
        return !this.break.break() && !this.break.class();
    }

    public void class(rYB rYB2, rfH rfH2, an an2) {
    }

    public void class(rYB rYB2, rfH rfH2, rrw_0 rrw_02) {
    }

    public xc_0 class(rxx rxx2) {
        return this.continue();
    }

    protected void class(rrEm rrEm2, rfH rfH2, int n2) {
        if (rrEm2.B().break(rru_0.case)) {
            while (n2 > 0) {
                int n3 = rsp_0.class(n2);
                n2 -= n3;
                rrEm2.a_(new rsp_0(rrEm2, (double)rfH2.b_() + 0.5, (double)rfH2.c_() + 0.5, (double)rfH2.d_() + 0.5, n3));
            }
        }
    }

    public void class(rYB rYB2, rfH rfH2, xc_0 xc_02, rhd_2 rhd_22) {
        rYB2.class(rhd_22, 2001, rfH2, xd_0.finally(xc_02));
        if (this.class(rls.H)) {
            rbw_0.class(rhd_22, false);
        }
    }

    public boolean class(rrw_0 rrw_02) {
        return true;
    }

    protected void class(rCL<xd_0, xc_0> rCL2) {
    }

    public void class(rdn_1 rdn_12, rRq rRq2, List<rgP> list, VD vD) {
    }

    public void class(rYB rYB2, rfH rfH2, an an2, float f2) {
        an2.class(f2, 1.0f);
    }

    public void class(rRq rRq2, an an2) {
        an2.byte(an2.rv().throws(1.0, 0.0, 1.0));
    }

    public rdn_1 class(rRq rRq2, rfH rfH2, xc_0 xc_02) {
        return new rdn_1(this);
    }

    public void class(rdx_1 rdx_12, rqs<rdn_1> rqs2) {
        rqs2.add(new rdn_1(this));
    }

    public static boolean class(rjC rjC2, rpr_0 rpr_02) {
        rjC rjC3 = rjC2.class(rpr_02);
        return xd_0.class(rjC3);
    }

    public static xc_0 class(xc_0 xc_02, xc_0 xc_03, rYB rYB2, rfH rfH2) {
        rjC rjC2 = rjw.break(xc_02.extends(rYB2, rfH2), xc_03.extends(rYB2, rfH2), rjn_0.byte).class(rfH2.b_(), (double)rfH2.c_(), (double)rfH2.d_());
        for (an an2 : rYB2.class((an)null, rjC2.class())) {
            double d = rjw.class(rpb_0.Y, an2.rN().protected(0.0, 1.0, 0.0), Stream.of(rjC2), -1.0);
            an2.case(an2.rx(), an2.re() + 1.0 + d, an2.BO());
        }
        return xc_03;
    }

    public static void class(xc_0 xc_02, xc_0 xc_03, rRg rRg2, rfH rfH2, int n2) {
        xd_0.class(xc_02, xc_03, rRg2, rfH2, n2, 512);
    }

    public static boolean class(rjC rjC2) {
        return (Boolean)volatile.getUnchecked((Object)rjC2);
    }

    public boolean class(rlb<xd_0> rlb2) {
        return rlb2.class(this);
    }

    public static void class(xc_0 xc_02, xc_0 xc_03, rRg rRg2, rfH rfH2, int n2, int n3) {
        if (xc_03 != xc_02) {
            if (xc_03.catch()) {
                if (!rRg2.import()) {
                    rRg2.class(rfH2, (n2 & 0x20) == 0, (an)null, n3);
                }
            } else {
                rRg2.class(rfH2, xc_03, n2 & 0xFFFFFFDF, n3);
            }
        }
    }

    public static rjC class(double d, double d2, double d3, double d4, double d5, double d6) {
        return rjw.class(d / 16.0, d2 / 16.0, d3 / 16.0, d4 / 16.0, d5 / 16.0, d6 / 16.0);
    }

    public static boolean class(rRR rRR2, rfH rfH2, rpr_0 rpr_02) {
        xc_0 xc_02 = rRR2.byte(rfH2);
        return rpr_02 == rpr_0.DOWN && xc_02.class(rls.q) ? false : xc_02.class((rRq)rRR2, rfH2, rpr_02, ryh_1.CENTER);
    }

    public static List<rdn_1> class(xc_0 xc_02, rrEm rrEm2, rfH rfH2, ryo_2 ryo_22) {
        rzp_2 rzp_22 = new rzp_2(rrEm2).class(rrEm2.int).class(rzq_2.case, rjU.class(rfH2)).class(rzq_2.implements, rdn_1.break).break(rzq_2.private, ryo_22);
        return xc_02.class(rzp_22);
    }

    public static List<rdn_1> class(xc_0 xc_02, rrEm rrEm2, rfH rfH2, ryo_2 ryo_22, an an2, rdn_1 rdn_12) {
        rzp_2 rzp_22 = new rzp_2(rrEm2).class(rrEm2.int).class(rzq_2.case, rjU.class(rfH2)).class(rzq_2.implements, rdn_12).break(rzq_2.class, an2).break(rzq_2.private, ryo_22);
        return xc_02.class(rzp_22);
    }

    public static xc_0 class(int n2) {
        xc_0 xc_02 = char.class(n2);
        return xc_02 == null ? xu_0.class.continue() : xc_02;
    }

    public static void class(xc_0 xc_02, rRg rRg2, rfH rfH2, ryo_2 ryo_22) {
        if (rRg2 instanceof rrEm) {
            xd_0.class(xc_02, (rrEm)rRg2, rfH2, ryo_22).forEach(rdn_12 -> xd_0.class((rrEm)rRg2, rfH2, rdn_12));
            xc_02.class((rrEm)rRg2, rfH2, rdn_1.break);
        }
    }

    public static xd_0 class(rdb_1 rdb_12) {
        return rdb_12 instanceof rxj_0 ? ((rxj_0)rdb_12).catch() : xu_0.class;
    }

    public void class(xc_0 xc_02, rYB rYB2, rfH rfH2, Random random) {
    }

    public void class(rRg rRg2, rfH rfH2, xc_0 xc_02) {
    }

    public boolean break(xd_0 xd_02) {
        return this == xd_02;
    }

    public static xd_0 break(int n2) {
        return rvl_0.strictfp.class(n2);
    }

    public static xc_0 break(xc_0 xc_02, rRg rRg2, rfH rfH2) {
        xc_0 xc_03 = xc_02;
        rfw rfw2 = new rfw();
        for (rpr_0 rpr_02 : xd_0.class) {
            rfw2.class((rja)rfH2, rpr_02);
            xc_03 = xc_03.class(rpr_02, rRg2.byte(rfw2), rRg2, rfH2, rfw2);
        }
        return xc_03;
    }

    public static int finally(xc_0 xc_02) {
        if (xc_02 == null) {
            return 0;
        }
        int n2 = char.class(xc_02);
        return n2 == -1 ? 0 : n2;
    }

    @Override
    protected xd_0 catch() {
        return this;
    }

    public float extends() {
        return this.protected;
    }

    protected final void extends(xc_0 xc_02) {
        this.final = xc_02;
    }

    @Override
    public rdb_1 case() {
        if (this.int == null) {
            this.int = rdb_1.class(this);
        }
        return this.int;
    }

    public final xc_0 continue() {
        return this.final;
    }

    public rCF<xd_0, xc_0> new() {
        return this.abstract;
    }

    public float package() {
        return this.private;
    }

    public boolean super() {
        return this.finally;
    }

    public static void protected(xc_0 xc_02, rYB rYB2, rfH rfH2) {
        if (rYB2 instanceof rrEm) {
            xd_0.class(xc_02, (rrEm)rYB2, rfH2, (ryo_2)null).forEach(rdn_12 -> xd_0.class(rYB2, rfH2, rdn_12));
            xc_02.class((rrEm)rYB2, rfH2, rdn_1.break);
        }
    }

    public float final() {
        return this.catch;
    }

    public String volatile() {
        if (this.package == null) {
            this.package = rqR.class("block", rvl_0.strictfp.break(this));
        }
        return this.package;
    }

    public zr_2 native(xc_0 xc_02) {
        return this.case;
    }

    public rVi native() {
        return new rgn(this.volatile());
    }

    public boolean a_(xc_0 xc_02) {
        return this.throws;
    }

    public boolean a_(xc_0 xc_02, rRq rRq2, rfH rfH2) {
        return !xd_0.class(xc_02.finally(rRq2, rfH2)) && xc_02.volatile().byte();
    }
}

