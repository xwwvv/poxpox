/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Collections;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.SD;
import protected.case;
import protected.catch;
import protected.char;
import protected.class;
import protected.goto;
import protected.mg_2;
import protected.rt_1;
import protected.sk_1;
import protected.so_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class byte
implements catch {
    public Object[] class;
    private static byte[] break;
    private static short[] byte;

    @Override
    public char byte() {
        return (sk_1)sk_1.staticFields84fbf20de4d13027acc13a6866788039[byte[7]];
    }

    public byte() {
        List<class> list;
        this.finally();
        class clazz = new class();
        this.class[protected.byte.byte[0]] = clazz;
        this.class[protected.byte.byte[2]] = list = Collections.singletonList((class)this.class[byte[1]]);
        new SD((class)this.class[byte[3]]);
    }

    static {
        protected.byte.ntfClinit();
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0x2EC1D17F54BD22FBL;
    }

    public static String class(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{-124, -91, 43, -77, 114, 122, -2, 81}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0x4442F273;
    }

    @Override
    public rt_1 class() {
        return (mg_2)mg_2.staticFields4592673f607b3ff2b69d116fa51286d2[byte[8]];
    }

    @Override
    public case break() {
        return (class)this.class[byte[4]];
    }

    @Override
    public goto throws() {
        return (so_1)so_1.staticFields4d15df505e473c14b11aa564ea558cfe[byte[6]];
    }

    private static /* synthetic */ void ntfClinit() {
        protected.byte.extends();
        protected.byte.implements();
    }

    private void finally() {
        if (this.class == null) {
            Object[] objectArray = this.class = new Object[break[0]];
        }
    }

    private static void extends() {
        short[] sArray = new short[10];
        sArray[2] = 1;
        sArray[5] = 1;
        byte = sArray;
    }

    @Override
    public List<case> case() {
        return (List)this.class[byte[5]];
    }

    private static void implements() {
        break = new byte[]{2};
    }

    public class protected() {
        return (class)this.class[byte[9]];
    }
}

