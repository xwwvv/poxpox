/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableList
 *  com.google.common.collect.ImmutableList$Builder
 */
package protected;

import com.google.common.collect.ImmutableList;
import java.util.Optional;
import java.util.Random;
import protected.ai_0;
import protected.jq_1;
import protected.rCL;
import protected.rCZ;
import protected.rCm;
import protected.rRq;
import protected.rYB;
import protected.rct_0;
import protected.rdn_1;
import protected.rdy_2;
import protected.rfH;
import protected.rfU;
import protected.rff;
import protected.rfw;
import protected.rhd_2;
import protected.rhn_2;
import protected.rhx_1;
import protected.rjU;
import protected.rja;
import protected.rlg_0;
import protected.rlq_2;
import protected.rlt_2;
import protected.rpb;
import protected.rpm;
import protected.rqi_0;
import protected.rql_0;
import protected.rqn;
import protected.rrt_0;
import protected.rrz_0;
import protected.rxe_2;
import protected.rye_1;
import protected.ryz_1;
import protected.wf_2;
import protected.xc_0;
import protected.xd_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.Wv
 */
public class wv_2
extends xd_0 {
    public static final rCm volatile = rct_0.q;
    private static final ImmutableList<rja> final = ImmutableList.of((Object)new rja(0, 0, -1), (Object)new rja(-1, 0, 0), (Object)new rja(0, 0, 1), (Object)new rja(1, 0, 0), (Object)new rja(-1, 0, -1), (Object)new rja(1, 0, -1), (Object)new rja(-1, 0, 1), (Object)new rja(1, 0, 1));
    private static final ImmutableList<rja> package = new ImmutableList.Builder().addAll(final).addAll(final.stream().map(rja::catch).iterator()).addAll(final.stream().map(rja::implements).iterator()).add((Object)new rja(0, 1, 0)).build();

    private void byte(xc_0 xc_02, rYB rYB2, rfH rfH3) {
        rYB2.class(rfH3, false);
        boolean bl2 = rpb.HORIZONTAL.class().map(rfH3::break).anyMatch(rfH2 -> wv_2.class(rfH2, rYB2));
        boolean bl3 = bl2 || rYB2.break(rfH3.final()).class(rlg_0.break);
        wf_2 wf_22 = new wf_2(this, bl3);
        rYB2.class(null, rye_1.class(), wf_22, (double)rfH3.b_() + 0.5, (double)rfH3.c_() + 0.5, (double)rfH3.d_() + 0.5, 5.0f, true, rrz_0.DESTROY);
    }

    public wv_2(jq_1 jq_12) {
        super(jq_12);
        this.extends((xc_0)((xc_0)this.abstract.break()).class(volatile, 0));
    }

    @Override
    public ryz_1 class(xc_0 xc_02, rYB rYB2, rfH rfH2, rhd_2 rhd_22, rpm rpm2, rff rff2) {
        rhn_2 rhn_22;
        rdn_1 rdn_12 = rhd_22.protected(rpm2);
        if (rpm2 == rpm.MAIN_HAND && !wv_2.class(rdn_12) && wv_2.class(rhd_22.protected(rpm.OFF_HAND))) {
            return ryz_1.PASS;
        }
        if (wv_2.class(rdn_12) && wv_2.private(xc_02)) {
            wv_2.class(rYB2, rfH2, xc_02);
            if (!((rhx_1)rhd_22.implements[18]).protected) {
                rdn_12.catch(1);
            }
            return ryz_1.class(rYB2.continue);
        }
        if (xc_02.byte(volatile) == 0) {
            return ryz_1.PASS;
        }
        if (!wv_2.class(rYB2)) {
            if (!rYB2.continue) {
                this.byte(xc_02, rYB2, rfH2);
            }
            return ryz_1.class(rYB2.continue);
        }
        if (!(rYB2.continue || (rhn_22 = (rhn_2)rhd_22).E() == rYB2.E() && rhn_22.S().equals(rfH2))) {
            rhn_22.class(rYB2.E(), rfH2, 0.0f, false, true);
            rYB2.class((rhd_2)null, (double)rfH2.b_() + 0.5, (double)rfH2.c_() + 0.5, (double)rfH2.d_() + 0.5, rqn.Xy, rql_0.BLOCKS, 1.0f, 1.0f);
            return ryz_1.SUCCESS;
        }
        return ryz_1.CONSUME;
    }

    public static int class(xc_0 xc_02, int n2) {
        return rfU.protected((float)(xc_02.byte(volatile) - 0) / 4.0f * (float)n2);
    }

    public static Optional<rjU> class(ai_0<?> ai_02, rrt_0 rrt_02, rfH rfH2) {
        Optional<rjU> optional = wv_2.class(ai_02, rrt_02, rfH2, true);
        return optional.isPresent() ? optional : wv_2.class(ai_02, rrt_02, rfH2, false);
    }

    private static Optional<rjU> class(ai_0<?> ai_02, rrt_0 rrt_02, rfH rfH2, boolean bl2) {
        rfw rfw2 = new rfw();
        for (rja rja2 : package) {
            rfw2.class(rfH2).case(rja2);
            rjU rjU2 = rqi_0.class(ai_02, rrt_02, rfw2, bl2);
            if (rjU2 == null) continue;
            return Optional.of(rjU2);
        }
        return Optional.empty();
    }

    @Override
    public boolean class(xc_0 xc_02, rRq rRq2, rfH rfH2, rlt_2 rlt_22) {
        return false;
    }

    private static boolean class(rfH rfH2, rYB rYB2) {
        rxe_2 rxe_22 = rYB2.break(rfH2);
        if (!rxe_22.class(rlg_0.break)) {
            return false;
        }
        if (rxe_22.break()) {
            return true;
        }
        float f2 = rxe_22.throws();
        if (f2 < 2.0f) {
            return false;
        }
        rxe_2 rxe_23 = rYB2.break(rfH2.break());
        return !rxe_23.class(rlg_0.break);
    }

    private static boolean class(rdn_1 rdn_12) {
        return rdn_12.break() == rdy_2.Bm;
    }

    @Override
    protected void class(rCL<xd_0, xc_0> rCL2) {
        rCL2.class(new rCZ[]{volatile});
    }

    @Override
    public void class(xc_0 xc_02, rYB rYB2, rfH rfH2, Random random) {
        if (xc_02.byte(volatile) != 0) {
            if (random.nextInt(100) == 0) {
                rYB2.class((rhd_2)null, (double)rfH2.b_() + 0.5, (double)rfH2.c_() + 0.5, (double)rfH2.d_() + 0.5, rqn.XC, rql_0.BLOCKS, 1.0f, 1.0f);
            }
            double d = (double)rfH2.b_() + 0.5 + (0.5 - random.nextDouble());
            double d2 = (double)rfH2.c_() + 1.0;
            double d3 = (double)rfH2.d_() + 0.5 + (0.5 - random.nextDouble());
            double d4 = (double)random.nextFloat() * 0.04;
            rYB2.class(rlq_2.v, d, d2, d3, 0.0, d4, 0.0);
        }
    }

    public static void class(rYB rYB2, rfH rfH2, xc_0 xc_02) {
        rYB2.class(rfH2, (xc_0)xc_02.class(volatile, xc_02.byte(volatile) + 1), 3);
        rYB2.class((rhd_2)null, (double)rfH2.b_() + 0.5, (double)rfH2.c_() + 0.5, (double)rfH2.d_() + 0.5, rqn.Xl, rql_0.BLOCKS, 1.0f, 1.0f);
    }

    public static boolean class(rYB rYB2) {
        return rYB2.default().implements();
    }

    @Override
    public int break(xc_0 xc_02, rYB rYB2, rfH rfH2) {
        return wv_2.class(xc_02, 15);
    }

    @Override
    public boolean case(xc_0 xc_02) {
        return true;
    }

    private static boolean private(xc_0 xc_02) {
        return xc_02.byte(volatile) < 4;
    }
}

