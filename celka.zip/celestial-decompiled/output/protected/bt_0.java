/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.pp_2;
import protected.ps_1;
import protected.rff;
import protected.rjg_0;
import protected.rjm_0;
import protected.rpm;
import protected.throws;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.bT
 */
public class bt_0
implements pp_2 {
    private static short[] throws;
    private static boolean[] case;
    public static Object[] class;
    public Object[] break;
    private static byte[] catch;

    private void byte() {
        if (this.break == null) {
            Object[] objectArray = this.break = new Object[catch[0]];
            objectArray[bt_0.case[12]] = case[13];
            objectArray[bt_0.catch[1]] = case[14];
        }
    }

    public bt_0(ps_1 ps_12) {
        this.byte();
        Integer n2 = case[0];
        this.break[bt_0.throws[0]] = n2;
        ps_1 ps_13 = ps_12;
        this.break[bt_0.throws[1]] = ps_13;
    }

    static {
        bt_0.ntfClinit();
    }

    public void class(int n2) {
        Integer n3 = n2;
        this.break[bt_0.throws[27]] = n3;
    }

    public void class(boolean bl2) {
        boolean bl3;
        if ((Integer)this.break[throws[7]] > 0) {
            bt_0 bt_02 = this;
            Integer n2 = (Integer)bt_02.break[throws[8]] - case[3];
            bt_02.break[bt_0.throws[9]] = n2;
            return;
        }
        rjg_0 rjg_02 = ((ps_1)this.break[throws[10]]).byte();
        boolean bl4 = bl3 = rjg_02 != null && rjg_02.byte() == rjm_0.BLOCK ? case[4] : case[5];
        if (bl2 && bl3) {
            ((ps_1)this.break[throws[11]]).native().class((Boolean)this.break[throws[12]]);
            if (((ps_1)this.break[throws[13]]).native().protected()) {
                ((ps_1)this.break[throws[14]]).native().class();
                ((ps_1)this.break[throws[15]]).native().break(((rff)rjg_02).class(), ((rff)rjg_02).break());
                ((ps_1)this.break[throws[16]]).catch().class(rpm.MAIN_HAND);
            } else {
                if (((ps_1)this.break[throws[17]]).native().class(((rff)rjg_02).class(), ((rff)rjg_02).break())) {
                    ((ps_1)this.break[throws[18]]).catch().class(rpm.MAIN_HAND);
                }
                if (((ps_1)this.break[throws[19]]).native().protected()) {
                    Integer n3 = (Integer)protected.throws.break().Pg.class[throws[20]] - case[6];
                    this.break[bt_0.throws[21]] = n3;
                    ((ps_1)this.break[throws[22]]).native().break(case[7]);
                }
            }
            Boolean bl5 = !((ps_1)this.break[throws[23]]).native().protected() ? case[8] : case[9];
            this.break[bt_0.throws[24]] = bl5;
            ((ps_1)this.break[throws[25]]).native().class(case[10]);
        } else {
            Boolean bl6 = case[11];
            this.break[bt_0.throws[26]] = bl6;
        }
    }

    public void class() {
        if (((ps_1)this.break[throws[2]]).catch() != null && ((Boolean)this.break[throws[3]]).booleanValue()) {
            ((ps_1)this.break[throws[4]]).native().class(case[1]);
            ((ps_1)this.break[throws[5]]).native().break();
            Boolean bl2 = case[2];
            this.break[bt_0.throws[6]] = bl2;
        }
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0x589799072E162C35L;
    }

    public static String class(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{-114, -17, 3, 71, 81, -91, 66, -50}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    private static int break(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0x84888FB1;
    }

    private static void break() {
        short[] sArray = new short[28];
        sArray[0] = 2;
        sArray[3] = 1;
        sArray[6] = 1;
        sArray[7] = 2;
        sArray[8] = 2;
        sArray[9] = 2;
        sArray[12] = 1;
        sArray[21] = 2;
        sArray[24] = 1;
        sArray[26] = 1;
        sArray[27] = 2;
        throws = sArray;
    }

    private static void throws() {
        Object[] objectArray = new Object[]{1};
        bt_0.class = objectArray;
    }

    private static /* synthetic */ void ntfClinit() {
        bt_0.protected();
        bt_0.break();
        bt_0.case();
        bt_0.throws();
    }

    private static void case() {
        catch = new byte[]{3, 2};
    }

    private static void protected() {
        boolean[] blArray = new boolean[18];
        blArray[3] = true;
        blArray[4] = true;
        blArray[6] = true;
        blArray[8] = true;
        blArray[12] = true;
        blArray[15] = true;
        blArray[17] = true;
        case = blArray;
    }
}

