/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.serialization.Codec
 *  org.apache.commons.lang3.Validate
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
package protected;

import com.mojang.serialization.Codec;
import java.util.Optional;
import java.util.Random;
import java.util.function.Predicate;
import java.util.stream.IntStream;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;
import org.apache.commons.lang3.Validate;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import protected.an;
import protected.ex_0;
import protected.rfU;
import protected.rfi;
import protected.rfl;
import protected.rfp;
import protected.rfq;
import protected.rft_0;
import protected.rfw;
import protected.rfy_0;
import protected.rjU;
import protected.rja;
import protected.rpb_0;
import protected.rpr_0;
import protected.rqR;
import protected.rqd_0;
import protected.rrtj_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class rfH
extends rja
implements rrtj_1 {
    public static final Codec<rfH> byte = Codec.INT_STREAM.comapFlatMap(intStream -> rqR.class(intStream, 3).map(nArray -> new rfH(nArray[0], nArray[1], nArray[2])), rfH2 -> IntStream.of(rfH2.b_(), rfH2.c_(), rfH2.d_())).stable();
    private static final Logger class = LogManager.getLogger();
    public static final rfH protected = new rfH(0, 0, 0);
    private static final int break;
    private static final int catch;
    private static final int private;
    private static final long implements;
    private static final long finally;
    private static final long extends;
    private static final int native;
    private static final int volatile;

    public rfH byte(double d, double d2, double d3) {
        return d == 0.0 && d2 == 0.0 && d3 == 0.0 ? this : new rfH((double)this.b_() + d, (double)this.c_() + d2, (double)this.d_() + d3);
    }

    public rfH byte() {
        return this.break(rpr_0.WEST);
    }

    public static int byte(long l2) {
        return (int)(l2 << 64 - native - catch >> 64 - catch);
    }

    public rfH byte(rja rja2) {
        return this.break(-rja2.b_(), -rja2.c_(), -rja2.d_());
    }

    public rfH int() {
        return this;
    }

    public rfH(an an2) {
        this(an2.rx(), an2.re(), an2.BO());
    }

    public rfH(int n2, int n3, int n4) {
        super(n2, n3, n4);
    }

    public rfH(double d, double d2, double d3) {
        super(d, d2, d3);
    }

    public rfH(rfl rfl2) {
        this(rfU.byte(rfl2.class), rfU.byte(rfl2.break), rfU.byte(rfl2.byte));
    }

    public rfH(ex_0 ex_02) {
        this(ex_02.class(), ex_02.break(), ex_02.byte());
    }

    public rfH(rja rja2) {
        this(rja2.b_(), rja2.c_(), rja2.d_());
    }

    public rfH(rjU rjU2) {
        this(rjU2.break, rjU2.byte, rjU2.protected);
    }

    static {
        catch = break = 1 + rfU.case(rfU.byte(30000000));
        private = 64 - break - catch;
        implements = (1L << break) - 1L;
        finally = (1L << private) - 1L;
        extends = (1L << catch) - 1L;
        native = private;
        volatile = private + catch;
    }

    public rfH class(double d, double d2, double d3) {
        return d == 0.0 && d2 == 0.0 && d3 == 0.0 ? this : new rfH((double)this.b_() + d, (double)this.c_() + d2, (double)this.d_() + d3);
    }

    public rfH class(rpr_0 rpr_02, int n2) {
        return n2 == 0 ? this : new rfH(this.b_() + rpr_02.implements() * n2, this.c_() + rpr_02.finally() * n2, this.d_() + rpr_02.extends() * n2);
    }

    public rfH class(rpb_0 rpb_02, int n2) {
        if (n2 == 0) {
            return this;
        }
        int n3 = rpb_02 == rpb_0.X ? n2 : 0;
        int n4 = rpb_02 == rpb_0.Y ? n2 : 0;
        int n5 = rpb_02 == rpb_0.Z ? n2 : 0;
        return new rfH(this.b_() + n3, this.c_() + n4, this.d_() + n5);
    }

    public rfH class(rqd_0 rqd_02) {
        switch (rqd_02) {
            default: {
                return this;
            }
            case CLOCKWISE_90: {
                return new rfH(-this.d_(), this.c_(), this.b_());
            }
            case CLOCKWISE_180: {
                return new rfH(-this.b_(), this.c_(), -this.d_());
            }
            case COUNTERCLOCKWISE_90: 
        }
        return new rfH(this.d_(), this.c_(), -this.b_());
    }

    public static int class(long l2) {
        return (int)(l2 << 64 - volatile - break >> 64 - break);
    }

    public static Stream<rfH> class(rfi rfi2) {
        return rfH.class(Math.min(rfi2.class, rfi2.protected), Math.min(rfi2.break, rfi2.throws), Math.min(rfi2.byte, rfi2.case), Math.max(rfi2.class, rfi2.protected), Math.max(rfi2.break, rfi2.throws), Math.max(rfi2.byte, rfi2.case));
    }

    public rfH class(int n2) {
        return this.class(rpr_0.WEST, n2);
    }

    public static Iterable<rfH> class(Random random, int n2, int n3, int n4, int n5, int n6, int n7, int n8) {
        int n9 = n6 - n3 + 1;
        int n10 = n7 - n4 + 1;
        int n11 = n8 - n5 + 1;
        return () -> new rfy_0(n2, n3, random, n9, n4, n10, n5, n11);
    }

    public static Iterable<rfH> class(rfH rfH2, int n2, int n3, int n4) {
        int n5 = n2 + n3 + n4;
        int n6 = rfH2.b_();
        int n7 = rfH2.c_();
        int n8 = rfH2.d_();
        return () -> new rfp(n8, n5, n2, n3, n4, n6, n7);
    }

    public static Optional<rfH> class(rfH rfH2, int n2, int n3, Predicate<rfH> predicate) {
        return rfH.break(rfH2, n2, n3, n2).filter(predicate).findFirst();
    }

    public static Iterable<rfH> class(rfH rfH2, rfH rfH3) {
        return rfH.break(Math.min(rfH2.b_(), rfH3.b_()), Math.min(rfH2.c_(), rfH3.c_()), Math.min(rfH2.d_(), rfH3.d_()), Math.max(rfH2.b_(), rfH3.b_()), Math.max(rfH2.c_(), rfH3.c_()), Math.max(rfH2.d_(), rfH3.d_()));
    }

    public static Stream<rfH> class(rfl rfl2) {
        return rfH.class(rfU.byte(rfl2.class), rfU.byte(rfl2.break), rfU.byte(rfl2.byte), rfU.byte(rfl2.protected), rfU.byte(rfl2.throws), rfU.byte(rfl2.case));
    }

    public static long class(long l2, int n2, int n3, int n4) {
        return rfH.throws(rfH.class(l2) + n2, rfH.break(l2) + n3, rfH.byte(l2) + n4);
    }

    public static Stream<rfH> class(int n2, int n3, int n4, int n5, int n6, int n7) {
        return StreamSupport.stream(rfH.break(n2, n3, n4, n5, n6, n7).spliterator(), false);
    }

    public static long class(long l2, rpr_0 rpr_02) {
        return rfH.class(l2, rpr_02.implements(), rpr_02.finally(), rpr_02.extends());
    }

    public static Iterable<rfw> class(rfH rfH2, int n2, rpr_0 rpr_02, rpr_0 rpr_03) {
        Validate.validState((rpr_02.final() != rpr_03.final() ? 1 : 0) != 0, (String)"The two directions cannot be on the same axis", (Object[])new Object[0]);
        return () -> new rft_0(rpr_02, rpr_03, rfH2, n2);
    }

    public rfH break(rpr_0 rpr_02) {
        return new rfH(this.b_() + rpr_02.implements(), this.c_() + rpr_02.finally(), this.d_() + rpr_02.extends());
    }

    public rfH break(int n2, int n3, int n4) {
        return n2 == 0 && n3 == 0 && n4 == 0 ? this : new rfH(this.b_() + n2, this.c_() + n3, this.d_() + n4);
    }

    public static Stream<rfH> break(rfH rfH2, rfH rfH3) {
        return StreamSupport.stream(rfH.class(rfH2, rfH3).spliterator(), false);
    }

    public static Stream<rfH> break(rfH rfH2, int n2, int n3, int n4) {
        return StreamSupport.stream(rfH.class(rfH2, n2, n3, n4).spliterator(), false);
    }

    @Override
    public /* synthetic */ rja break(rpr_0 rpr_02, int n2) {
        return this.class(rpr_02, n2);
    }

    public static Iterable<rfH> break(int n2, int n3, int n4, int n5, int n6, int n7) {
        int n8 = n5 - n2 + 1;
        int n9 = n6 - n3 + 1;
        int n10 = n7 - n4 + 1;
        int n11 = n8 * n9 * n10;
        return () -> new rfq(n11, n8, n9, n2, n3, n4);
    }

    public rfH break() {
        return this.break(rpr_0.DOWN);
    }

    public rfH break(rja rja2) {
        return this.break(rja2.b_(), rja2.c_(), rja2.d_());
    }

    public static int break(long l2) {
        return (int)(l2 << 64 - private >> 64 - private);
    }

    public rfH break(int n2) {
        return this.class(rpr_0.UP, n2);
    }

    @Override
    public /* synthetic */ rja throws(rja rja2) {
        return this.protected(rja2);
    }

    public static long throws(int n2, int n3, int n4) {
        long l2 = 0L;
        l2 |= ((long)n2 & implements) << volatile;
        return (l2 |= ((long)n3 & finally) << 0) | ((long)n4 & extends) << native;
    }

    public static long throws(long l2) {
        return l2 & 0xFFFFFFFFFFFFFFF0L;
    }

    @Override
    public /* synthetic */ rja catch() {
        return this.break();
    }

    public rfH catch(int n2) {
        return this.class(rpr_0.DOWN, n2);
    }

    public rfH extends() {
        return this.break(rpr_0.EAST);
    }

    @Override
    public /* synthetic */ rja case(int n2) {
        return this.break(n2);
    }

    @Override
    public /* synthetic */ rja implements() {
        return this.final();
    }

    @Override
    public /* synthetic */ rja implements(int n2) {
        return this.catch(n2);
    }

    public rfw new() {
        return new rfw(this.b_(), this.c_(), this.d_());
    }

    public long package() {
        return rfH.throws(this.b_(), this.c_(), this.d_());
    }

    public static rfH protected(long l2) {
        return new rfH(rfH.class(l2), rfH.break(l2), rfH.byte(l2));
    }

    public rfH protected() {
        return this.break(rpr_0.SOUTH);
    }

    public rfH protected(rja rja2) {
        return new rfH(this.c_() * rja2.d_() - this.d_() * rja2.c_(), this.d_() * rja2.b_() - this.b_() * rja2.d_(), this.b_() * rja2.c_() - this.c_() * rja2.b_());
    }

    public rfH private(int n2) {
        return this.class(rpr_0.SOUTH, n2);
    }

    public rfH private() {
        return this.break(rpr_0.NORTH);
    }

    public rfH final() {
        return this.break(rpr_0.UP);
    }

    public rfH volatile(int n2) {
        return this.class(rpr_0.EAST, n2);
    }

    public rfH native(int n2) {
        return this.class(rpr_0.NORTH, n2);
    }
}

