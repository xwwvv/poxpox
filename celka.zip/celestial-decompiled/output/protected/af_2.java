/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 *  com.mojang.authlib.GameProfile
 *  org.apache.commons.lang3.ArrayUtils
 */
package protected;

import com.google.common.collect.Lists;
import com.mojang.authlib.GameProfile;
import java.util.Objects;
import org.apache.commons.lang3.ArrayUtils;
import protected.af_1;
import protected.ak_2;
import protected.av_2;
import protected.rgF;
import protected.rgP;
import protected.rgn;
import protected.rgn_0;
import protected.rlb_1;
import protected.rlb_2;
import protected.rlg_2;
import protected.rqR;
import protected.rud_1;
import protected.run_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.AF
 */
class af_2
implements af_1 {
    private boolean throws;
    private boolean case;
    private long catch;
    final /* synthetic */ rud_1 class;
    final /* synthetic */ ak_2 break;
    final /* synthetic */ Runnable byte;
    final /* synthetic */ av_2 protected;

    /*
     * Ignored method signature, as it can't be verified against descriptor
     */
    af_2(av_2 av_22, rud_1 rud_12, ak_2 ak_22, Runnable runnable) {
        this.protected = av_22;
        this.class = rud_12;
        this.break = ak_22;
        this.byte = runnable;
    }

    @Override
    public rud_1 class() {
        return this.class;
    }

    @Override
    public void class(rgP rgP2, rgP rgP3) {
        if (!this.throws) {
            av_2.break.error("Can't ping {}: {}", (Object)this.break.break, (Object)rgP3.getString());
            this.break.protected = new rgn("multiplayer.status.cannot_connect").class(rgF.DARK_RED);
            this.break.byte = rgn_0.byte;
            this.protected.class(this.break);
        }
    }

    @Override
    public void class(rlg_2 rlg_22) {
        long l2 = this.catch;
        long l3 = rqR.break();
        this.break.throws = l3 - l2;
        this.class.class(new rgn("multiplayer.status.finished"));
    }

    @Override
    public void class(rlb_1 rlb_12) {
        if (this.case) {
            this.class.class(new rgn("multiplayer.status.unrequested"));
        } else {
            Object object;
            this.case = true;
            run_1 run_12 = rlb_12.break();
            this.break.protected = run_12.class() != null ? run_12.class() : rgn_0.byte;
            if (run_12.byte() != null) {
                this.break.catch = new rgn_0(run_12.byte().class());
                this.break.case = run_12.byte().break();
            } else {
                this.break.catch = new rgn("multiplayer.status.old");
                this.break.case = 0;
            }
            if (run_12.break() != null) {
                this.break.byte = av_2.class(run_12.break().break(), run_12.break().class());
                object = Lists.newArrayList();
                if (ArrayUtils.isNotEmpty((Object[])run_12.break().byte())) {
                    for (GameProfile gameProfile : run_12.break().byte()) {
                        object.add(new rgn_0(gameProfile.getName()));
                    }
                    if (run_12.break().byte().length < run_12.break().break()) {
                        object.add(new rgn("multiplayer.status.and_more", run_12.break().break() - run_12.break().byte().length));
                    }
                    this.break.implements = object;
                }
            } else {
                this.break.byte = new rgn("multiplayer.status.unknown").class(rgF.DARK_GRAY);
            }
            object = null;
            if (run_12.protected() != null) {
                GameProfile[] gameProfileArray = run_12.protected();
                if (gameProfileArray.startsWith("data:image/png;base64,")) {
                    object = gameProfileArray.substring("data:image/png;base64,".length());
                } else {
                    av_2.break.error("Invalid server icon (unknown format)");
                }
            }
            if (!Objects.equals(object, this.break.byte())) {
                this.break.class((String)object);
                this.byte.run();
            }
            this.catch = rqR.break();
            this.class.class(new rlb_2(this.catch));
            this.throws = true;
        }
    }
}

