/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonElement
 */
package protected;

import com.google.gson.JsonElement;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;
import protected.DD;
import protected.Do;
import protected.rqo_0;
import protected.uh_0;
import protected.uw_0;
import protected.xd_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.Uk
 */
public class uk_0 {
    public static final uw_0 class = uk_0.class(Do::class, uh_0.byte);
    public static final uw_0 break = uk_0.class(Do::class, uh_0.protected);
    public static final uw_0 byte = uk_0.class(Do::finally, uh_0.throws);
    public static final uw_0 protected = uk_0.class(Do::finally, uh_0.case);
    public static final uw_0 throws = uk_0.class(Do::volatile, uh_0.private);
    public static final uw_0 case = uk_0.class(Do::extends, uh_0.catch);
    public static final uw_0 catch = uk_0.class(Do::public, uh_0.implements);
    public static final uw_0 private = uk_0.class(Do::return, uh_0.finally);
    public static final uw_0 implements = uk_0.class(Do::case, uh_0.G);
    public static final uw_0 finally = uk_0.class(Do::private, uh_0.O);
    public static final uw_0 extends = uk_0.class(Do::implements, uh_0.b);
    public static final uw_0 native = uk_0.class(Do::new, uh_0.abstract);
    public static final uw_0 volatile = uk_0.class(Do::while, uh_0.Q);
    public static final uw_0 final = uk_0.class(Do::class, uh_0.void);
    public static final uw_0 package = uk_0.class(Do::this, uh_0.C);
    public static final uw_0 int = uk_0.class(Do::this, uh_0.l);
    public static final uw_0 new = uk_0.class(Do::break, uh_0.t);
    public static final uw_0 continue = uk_0.class(Do::native, uh_0.throws);
    public static final uw_0 super = uk_0.class(Do::native, uh_0.case);
    public static final uw_0 this = uk_0.class(Do::final, uh_0.private);
    public static final uw_0 else = uk_0.class(Do::package, uh_0.throws);
    private final Do synchronized;
    private final DD return;

    private uk_0(Do do_, DD dD) {
        this.synchronized = do_;
        this.return = dD;
    }

    public DD class() {
        return this.return;
    }

    public rqo_0 class(xd_0 xd_02, String string, BiConsumer<rqo_0, Supplier<JsonElement>> biConsumer) {
        return this.return.class(xd_02, string, this.synchronized, biConsumer);
    }

    public static uk_0 class(rqo_0 rqo_02) {
        return new uk_0(Do.break(rqo_02), uh_0.byte);
    }

    private static uw_0 class(Function<xd_0, Do> function, DD dD) {
        return xd_02 -> new uk_0((Do)function.apply(xd_02), dD);
    }

    public uk_0 class(Consumer<Do> consumer) {
        consumer.accept(this.synchronized);
        return this;
    }

    public rqo_0 class(xd_0 xd_02, BiConsumer<rqo_0, Supplier<JsonElement>> biConsumer) {
        return this.return.class(xd_02, this.synchronized, biConsumer);
    }

    public Do break() {
        return this.synchronized;
    }
}

