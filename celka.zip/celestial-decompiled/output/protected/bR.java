/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.ez_1;
import protected.rc_1;
import protected.rn_1;
import protected.rp_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class bR
extends rn_1 {
    public Object[] break;
    private static boolean[] byte;
    private static short[] protected;

    private static void byte() {
        protected = new short[1];
    }

    public bR(rp_2 rp_22, rc_1 rc_12, ez_1 ez_12) {
        super(rp_22, rc_12);
        this.protected();
        ez_1 ez_13 = ez_12;
        this.break[bR.protected[0]] = ez_13;
    }

    static {
        bR.ntfClinit();
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0x465875A;
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0xE9F55894D84BFB17L;
    }

    public static String break(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{-76, -128, -49, -66, -74, -101, 22, -19}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    private static void throws() {
        byte = new boolean[]{true};
    }

    private static /* synthetic */ void ntfClinit() {
        bR.throws();
        bR.byte();
    }

    private void protected() {
        if (this.break == null) {
            Object[] objectArray = this.break = new Object[byte[0]];
        }
    }
}

