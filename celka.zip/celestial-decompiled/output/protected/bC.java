/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.bZ;
import protected.bf_0;
import protected.bl_0;
import protected.bv_0;
import protected.ps_1;
import protected.rfl;
import protected.ru_1;
import protected.ry_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class bC
implements bZ {
    private static boolean[] class;
    private static short[] break;
    private static double[] byte;
    private static byte[] protected;

    private static void byte() {
        byte = new double[]{0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5};
    }

    static {
        bC.ntfClinit();
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0x20F9968D;
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0x9CDC735DF9073255L;
    }

    private static void class() {
        protected = new byte[]{2, 2};
    }

    public static String class(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{-70, -62, 80, -102, -11, -68, -116, -32}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    @Override
    public bv_0[] class(ps_1 ps_12, ry_1 ry_12) {
        int n2;
        if (ry_12 == null) {
            return null;
        }
        ru_1 ru_12 = ps_12.volatile();
        ru_1 ru_13 = ry_12.class();
        ru_1 ru_14 = ry_12.protected();
        int n3 = (Integer)ru_14.break[break[0]] - (Integer)ru_13.break[break[1]] + bC.class[0];
        boolean bl2 = n3 >= (n2 = (Integer)ru_14.break[break[2]] - (Integer)ru_13.break[break[3]] + bC.class[1]) ? bC.class[2] : bC.class[3];
        int n4 = bl2 ? n2 : n3;
        int n5 = bl2 ? n3 : n2;
        int n6 = (Integer)ru_13.break[break[4]];
        int n7 = bl2 ? (Integer)ru_13.break[break[5]] + n3 / protected[0] : (Integer)ru_13.break[break[6]];
        int n8 = bl2 ? (Integer)ru_13.break[break[7]] : (Integer)ru_13.break[break[8]] + n2 / protected[1];
        int n9 = bl2 ? n7 : (Integer)ru_13.break[break[9]] + n3 - bC.class[4];
        int n10 = bl2 ? (Integer)ru_13.break[break[10]] + n2 - bC.class[5] : n8;
        double d = ru_12.protected(n7, n6, n8);
        double d2 = ru_12.protected(n9, n6, n10);
        boolean bl3 = d2 < d ? bC.class[6] : bC.class[7];
        bv_0[] bv_0Array = new bv_0[n4];
        bl_0[] bl_0Array = new bl_0[n5];
        for (int k = bC.class[8]; k < n4; ++k) {
            int n11;
            int n12;
            int n13;
            int n14 = n13 = bl3 ? n4 - bC.class[9] - k : k;
            if (bl2) {
                n12 = (Integer)ru_13.break[break[11]] + n13;
                for (n11 = bC.class[10]; n11 < n5; ++n11) {
                    bl_0Array[n11] = new bl_0((Integer)ru_13.break[break[12]] + n11, n6, n12);
                }
                bv_0Array[k] = new bf_0(new rfl(((Integer)ru_13.break[break[13]]).intValue(), n6, n12, ((Integer)ru_14.break[break[14]]).intValue(), n6, n12).class(byte[0]).protected(byte[1], byte[2], byte[3]), (bl_0[])bl_0Array.clone(), k);
                continue;
            }
            n12 = (Integer)ru_13.break[break[15]] + n13;
            for (n11 = bC.class[11]; n11 < n5; ++n11) {
                bl_0Array[n11] = new bl_0(n12, n6, (Integer)ru_13.break[break[16]] + n11);
            }
            bv_0Array[k] = new bf_0(new rfl(n12, n6, ((Integer)ru_13.break[break[17]]).intValue(), n12, n6, ((Integer)ru_14.break[break[18]]).intValue()).class(byte[4]).protected(byte[5], byte[6], byte[7]), (bl_0[])bl_0Array.clone(), k);
        }
        return bv_0Array;
    }

    private static void break() {
        boolean[] blArray = new boolean[12];
        blArray[0] = true;
        blArray[1] = true;
        blArray[2] = true;
        blArray[4] = true;
        blArray[5] = true;
        blArray[6] = true;
        blArray[9] = true;
        bC.class = blArray;
    }

    private static /* synthetic */ void ntfClinit() {
        bC.break();
        bC.protected();
        bC.byte();
        bC.class();
    }

    private static void protected() {
        short[] sArray = new short[19];
        sArray[2] = 2;
        sArray[3] = 2;
        sArray[4] = 1;
        sArray[7] = 2;
        sArray[8] = 2;
        sArray[10] = 2;
        sArray[11] = 2;
        sArray[16] = 2;
        sArray[17] = 2;
        sArray[18] = 2;
        break = sArray;
    }
}

