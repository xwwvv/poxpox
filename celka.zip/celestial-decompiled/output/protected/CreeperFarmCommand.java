/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.bl;
import protected.case;
import protected.cb_1;
import protected.class;
import protected.hh_0;
import protected.k_0;
import protected.ps_1;
import protected.rjU;
import protected.rql;
import protected.rrHT;
import protected.rrqx_1;
import protected.rrth_0;
import protected.rrtx_0;
import protected.rrwY;
import protected.ru_1;
import protected.ry_1;
import protected.s_0;
import protected.sd_1;
import protected.sk_0;
import protected.static;
import protected.sw_0;
import protected.try;
import protected.v_0;
import protected.w_0;
import protected.x;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class sx
extends try {
    public Object[] break;
    private static double[] throws;
    private static String[] case;
    private static float[] catch;
    private static short[] private;
    private static byte[] implements;
    private static boolean[] finally;

    public sx(case case_) {
        String[] stringArray = new String[implements[0]];
        stringArray[sx.finally[0]] = case[0];
        stringArray[sx.finally[1]] = case[1];
        super(case_, stringArray);
        this.extends();
        Object var6_2 = null;
        this.break[sx.private[0]] = var6_2;
        case_.s().class(new sd_1(this));
    }

    static {
        sx.ntfClinit();
    }

    @Override
    public void class(String string, static static_) throws x {
        this.extends();
        sw_0 sw_02 = sw_0.break(static_.extends());
        if (sw_02 == null) {
            throw new w_0(static_.private(), case[2]);
        }
        rrHT rrHT2 = ((rrqx_1)rrqx_1.staticFields09f1f28026cd378cb9df490a64ac8f2a[private[1]]).private().i();
        switch (((int[])sk_0.class[private[2]])[sw_02.ordinal()]) {
            case 1: 
            case 2: {
                if (sw_02 == (sw_0)((Object)sw_0.staticFields6b259e9d4f13397ca074ec4185749984[private[3]]) && (ru_1)this.break[private[4]] == null) {
                    throw new k_0(case[3]);
                }
                rjU rjU2 = ((hh_0)((ps_1)this.class[sx.private[5]]).throws().class[private[6]]).finally().new();
                ru_1 ru_12 = rjU2 != null ? new ru_1(rjU2.class(throws[0], (double)(((cb_1)sx.b_.class[private[7]]).Bx() / catch[0]), throws[1])) : (b_.catch() != null ? ru_1.class(b_.catch().Bs()) : ((ps_1)this.class[private[8]]).volatile());
                ru_1 ru_13 = static_.final() ? (ru_1)static_.break((s_0)s_0.staticFields2b61d3be194f3208a61ab56674f124f7[private[9]], ru_12) : ru_12;
                static_.class(finally[2]);
                if (sw_02 == (sw_0)((Object)sw_0.staticFields6b259e9d4f13397ca074ec4185749984[private[10]])) {
                    ru_1 ru_14 = ru_13;
                    this.break[sx.private[11]] = ru_14;
                    this.case(case[4]);
                    break;
                }
                bl bl2 = new bl((ru_1)this.break[private[12]], ru_13);
                rrHT2.class(bl2);
                rrHT2.continue().add(bl2);
                Object var15_17 = null;
                this.break[sx.private[13]] = var15_17;
                this.case(case[5]);
                break;
            }
            case 3: {
                ry_1 ry_12 = rrHT2.new();
                if (ry_12 == null) {
                    this.case(case[6]);
                    break;
                }
                ru_1 ru_15 = ry_12.byte();
                ru_1 ru_16 = ry_12.case();
                int n2 = Math.abs(ru_16.b_() - ru_15.b_()) + finally[3];
                int n3 = Math.abs(ru_16.d_() - ru_15.d_()) + finally[4];
                this.case("\u041f\u043e\u0437\u0438\u0446\u0438\u044f 1: " + ru_15);
                this.case("\u041f\u043e\u0437\u0438\u0446\u0438\u044f 2: " + ru_16);
                this.case("\u0420\u0430\u0434\u0438\u0443\u0441 \u0432\u044b\u0434\u0435\u043b\u0435\u043d\u0438\u044f: " + n2 + "x" + n3);
                break;
            }
            case 4: {
                ry_1 ry_13 = rrHT2.new();
                if (ry_13 == null) {
                    this.case(case[7]);
                    ((rrth_0)rrth_0.staticFields39e3fc1d50923a0b997a92f976964031[private[14]]).class(new rrtx_0(rrHT2.final(), case[8], (int)private[15]));
                    return;
                }
                if (static_.case()) {
                    String string2 = static_.extends();
                    if (rql.break(string2)) {
                        throw new w_0(static_.private(), case[9]);
                    }
                    ((rrqx_1)rrqx_1.staticFields09f1f28026cd378cb9df490a64ac8f2a[private[16]]).implements().byte(string2, finally[5]);
                    break;
                }
                throw new w_0(static_.private(), case[10]);
            }
            case 5: {
                if (static_.case()) {
                    String string3 = static_.extends();
                    if (rql.break(string3)) {
                        throw new w_0(static_.private(), case[11]);
                    }
                    ((rrqx_1)rrqx_1.staticFields09f1f28026cd378cb9df490a64ac8f2a[private[17]]).implements().break(string3, finally[6]);
                    break;
                }
                throw new w_0(static_.private(), case[12]);
            }
        }
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0x2425640B5F7AC809L;
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0xED62B58F;
    }

    @Override
    public Stream<String> break(String string, static static_) throws x {
        if (static_.case()) {
            return new v_0().break(sw_0.class()).class(static_.extends()).protected();
        }
        sw_0 sw_02 = sw_0.break(static_.extends());
        if (sw_02 != null) {
            if (sw_02 == (sw_0)((Object)sw_0.staticFields6b259e9d4f13397ca074ec4185749984[private[18]]) || sw_02 == (sw_0)((Object)sw_0.staticFields6b259e9d4f13397ca074ec4185749984[private[19]])) {
                if (static_.catch(implements[1])) {
                    return static_.class((s_0)s_0.staticFields2b61d3be194f3208a61ab56674f124f7[private[20]]);
                }
            } else if (sw_02 == (sw_0)((Object)sw_0.staticFields6b259e9d4f13397ca074ec4185749984[private[21]]) || sw_02 == (sw_0)((Object)sw_0.staticFields6b259e9d4f13397ca074ec4185749984[private[22]])) {
                rrwY rrwY2 = ((rrqx_1)rrqx_1.staticFields09f1f28026cd378cb9df490a64ac8f2a[private[23]]).implements();
                rrwY2.byte(finally[7]);
                Stream<String> stream = rrwY2.break().stream().map(rrwR2 -> rrwR2.break());
                return new v_0().break(stream).class(static_.extends()).break().protected();
            }
        }
        return Stream.empty();
    }

    public static String break(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{113, 89, -126, -93, -14, 70, 33, -126}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    private static void throws() {
        implements = new byte[]{2, 3, 9, 2, 2, 2, 2, 3, 2, 4, 2, 5, 2, 6, 2, 7, 8, 2};
    }

    private static /* synthetic */ void ntfClinit() {
        sx.finally();
        sx.final();
        sx.volatile();
        sx.native();
        sx.package();
        sx.throws();
    }

    private static void finally() {
        boolean[] blArray = new boolean[28];
        blArray[1] = true;
        blArray[3] = true;
        blArray[4] = true;
        blArray[5] = true;
        blArray[6] = true;
        blArray[7] = true;
        blArray[11] = true;
        blArray[12] = true;
        blArray[14] = true;
        blArray[16] = true;
        blArray[18] = true;
        blArray[20] = true;
        blArray[22] = true;
        blArray[24] = true;
        blArray[26] = true;
        blArray[27] = true;
        finally = blArray;
    }

    @Override
    public List<String> catch() {
        String string = this.break().get(finally[8]);
        String string2 = (String)protected.class.instanceof().protected.class[private[24]];
        String[] stringArray = new String[implements[2]];
        Object[] objectArray = new Object[implements[3]];
        objectArray[sx.finally[10]] = string2;
        objectArray[sx.finally[11]] = string;
        stringArray[sx.finally[9]] = case[14].formatted(objectArray);
        Object[] objectArray2 = new Object[implements[4]];
        objectArray2[sx.finally[13]] = string2;
        objectArray2[sx.finally[14]] = string;
        stringArray[sx.finally[12]] = case[15].formatted(objectArray2);
        Object[] objectArray3 = new Object[implements[6]];
        objectArray3[sx.finally[15]] = string2;
        objectArray3[sx.finally[16]] = string;
        stringArray[sx.implements[5]] = case[16].formatted(objectArray3);
        Object[] objectArray4 = new Object[implements[8]];
        objectArray4[sx.finally[17]] = string2;
        objectArray4[sx.finally[18]] = string;
        stringArray[sx.implements[7]] = case[17].formatted(objectArray4);
        Object[] objectArray5 = new Object[implements[10]];
        objectArray5[sx.finally[19]] = string2;
        objectArray5[sx.finally[20]] = string;
        stringArray[sx.implements[9]] = case[18].formatted(objectArray5);
        Object[] objectArray6 = new Object[implements[12]];
        objectArray6[sx.finally[21]] = string2;
        objectArray6[sx.finally[22]] = string;
        stringArray[sx.implements[11]] = case[19].formatted(objectArray6);
        Object[] objectArray7 = new Object[implements[14]];
        objectArray7[sx.finally[23]] = string2;
        objectArray7[sx.finally[24]] = string;
        stringArray[sx.implements[13]] = case[20].formatted(objectArray7);
        stringArray[sx.implements[15]] = case[21];
        Object[] objectArray8 = new Object[implements[17]];
        objectArray8[sx.finally[25]] = string2;
        objectArray8[sx.finally[26]] = string;
        stringArray[sx.implements[16]] = case[22].formatted(objectArray8);
        return Arrays.asList(stringArray);
    }

    private void extends() {
        if (this.break == null) {
            Object[] objectArray = this.break = new Object[finally[27]];
        }
    }

    @Override
    public String implements() {
        return case[13];
    }

    private static void package() {
        catch = new float[]{2.0f};
    }

    public ru_1 protected() {
        this.extends();
        return (ru_1)this.break[private[25]];
    }

    private static void final() {
        case = new String[]{new String("cf"), new String("creeperfarm"), new String("\u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0435"), new String("\u0421\u043d\u0430\u0447\u0430\u043b\u0430 \u0443\u0441\u0442\u0430\u043d\u043e\u0432\u0438\u0442\u0435 pos1, \u043f\u0440\u0435\u0436\u0434\u0435 \u0447\u0435\u043c \u0438\u0441\u043f\u043e\u043b\u044c\u0437\u043e\u0432\u0430\u0442\u044c pos2"), new String("\u041f\u0435\u0440\u0432\u0430\u044f \u043f\u043e\u0437\u0438\u0446\u0438\u044f \u0431\u044b\u043b\u0430 \u0443\u0441\u0442\u0430\u043d\u043e\u0432\u043b\u0435\u043d\u0430, \u0442\u0435\u043f\u0435\u0440\u044c \u0443\u0441\u0442\u0430\u043d\u043e\u0432\u0438\u0442\u0435 \u0432\u0442\u043e\u0440\u0443\u044e"), new String("\u0412\u044b\u0434\u0435\u043b\u0435\u043d\u0438\u0435 \u0434\u043e\u0431\u0430\u0432\u043b\u0435\u043d\u043e"), new String("\u0412\u044b\u0434\u0435\u043b\u0435\u043d\u0438\u0435 \u043d\u0435 \u0443\u0441\u0442\u0430\u043d\u043e\u0432\u043b\u0435\u043d\u043e"), new String("\u0412\u044b\u0434\u0435\u043b\u0435\u043d\u0438\u0435 \u043d\u0435 \u0443\u0441\u0442\u0430\u043d\u043e\u0432\u043b\u0435\u043d\u043e"), new String("\u0412\u044b\u0434\u0435\u043b\u0435\u043d\u0438\u0435 \u043d\u0435 \u0443\u0441\u0442\u0430\u043d\u043e\u0432\u043b\u0435\u043d\u043e"), new String("\u0438\u043c\u044f"), new String("\u0438\u043c\u044f"), new String("\u0438\u043c\u044f"), new String("\u0438\u043c\u044f"), new String("\u041a\u043e\u043c\u0430\u043d\u0434\u0430 \u0434\u043b\u044f \u0443\u043f\u0440\u0430\u0432\u043b\u0435\u043d\u0438\u0435 \u043c\u043e\u0434\u0443\u043b\u0435\u043c \"CreeperFarm\""), new String("> %s%s pos1 - \u0423\u0441\u0442\u0430\u043d\u043e\u0432\u0438\u0442\u0435 \u043f\u0435\u0440\u0432\u0443\u044e \u043f\u043e\u0437\u0438\u0446\u0438\u044e \u043a \u0432\u0430\u0448\u0435\u043c\u0443 \u0442\u0435\u043a\u0443\u0449\u0435\u043c\u0443 \u043f\u043e\u043b\u043e\u0436\u0435\u043d\u0438\u044e"), new String("> %s%s pos1 <x> <y> <z> - \u0423\u0441\u0442\u0430\u043d\u043e\u0432\u0438\u0442\u0435 \u043f\u0435\u0440\u0432\u0443\u044e \u043f\u043e\u0437\u0438\u0446\u0438\u044e \u043d\u0430 \u043b\u044e\u0431\u044b\u0435 \u043a\u043e\u043e\u0440\u0434\u0438\u043d\u0430\u0442\u044b"), new String("> %s%s pos2 - \u0423\u0441\u0442\u0430\u043d\u043e\u0432\u0438\u0442\u0435 \u0432\u0442\u043e\u0440\u0443\u044e \u043f\u043e\u0437\u0438\u0446\u0438\u044e \u043a \u0432\u0430\u0448\u0435\u043c\u0443 \u0442\u0435\u043a\u0443\u0449\u0435\u043c\u0443 \u043f\u043e\u043b\u043e\u0436\u0435\u043d\u0438\u044e"), new String("> %s%s pos2 <x> <y> <z> - \u0423\u0441\u0442\u0430\u043d\u043e\u0432\u0438\u0442\u0435 \u0432\u0442\u043e\u0440\u0443\u044e \u043f\u043e\u0437\u0438\u0446\u0438\u044e \u043d\u0430 \u043b\u044e\u0431\u044b\u0435 \u043a\u043e\u043e\u0440\u0434\u0438\u043d\u0430\u0442\u044b"), new String("> %s%s sel - \u0423\u0437\u043d\u0430\u0442\u044c \u043a\u043e\u043e\u0440\u0434\u0438\u043d\u0430\u0442\u044b \u0432\u044b\u0434\u0435\u043b\u0435\u043d\u043d\u043e\u0439 \u043e\u0431\u043b\u0430\u0441\u0442\u0438"), new String("> %s%s save <name> - \u0421\u043e\u0445\u0440\u0430\u043d\u0438\u0442\u044c \u043a\u043e\u043d\u0444\u0438\u0433 \u0441 \u0432\u044b\u0434\u0435\u043b\u0435\u043d\u0438\u0435\u043c"), new String("> %s%s remove <name> - \u0423\u0434\u0430\u043b\u0438\u0442\u044c \u043a\u043e\u043d\u0444\u0438\u0433"), new String(""), new String("\u041f\u0440\u0438\u043c\u0435\u0440: %s%s pos1 100 65 100")};
    }

    private static void volatile() {
        short[] sArray = new short[26];
        sArray[3] = 1;
        sArray[5] = 1;
        sArray[6] = 16;
        sArray[7] = 57;
        sArray[8] = 1;
        sArray[15] = 2000;
        sArray[19] = 1;
        sArray[21] = 3;
        sArray[22] = 4;
        private = sArray;
    }

    private static void native() {
        throws = new double[2];
    }
}

