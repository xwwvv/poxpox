/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonObject
 */
package protected;

import com.google.gson.JsonObject;
import protected.hi_1;
import protected.ho_1;
import protected.hz_1;
import protected.rdn_1;
import protected.rwh_1;
import protected.xh_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.Xr
 */
public class xr_2
extends hz_1 {
    private final xh_2 class;

    public xr_2(ho_1 ho_12, xh_2 xh_22) {
        super(hi_1.class, ho_12);
        this.class = xh_22;
    }

    @Override
    public JsonObject class(rwh_1 rwh_12) {
        JsonObject jsonObject = super.class(rwh_12);
        jsonObject.add("item", this.class.class());
        return jsonObject;
    }

    public boolean class(rdn_1 rdn_12) {
        return this.class.class(rdn_12);
    }

    public static xr_2 class(xh_2 xh_22) {
        return new xr_2(ho_1.class, xh_22);
    }
}

