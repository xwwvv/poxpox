/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.Cw;
import protected.gm;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class CR
extends Cw {
    CR(gm gm2, double d, double d2, double d3, double d4, double d5, double d6) {
        super(gm2, d, d2, d3, d4, d5, d6);
        this.throw = (float)((double)this.throw * 1.5);
        this.this = (int)(Math.random() * 2.0) + 60;
    }

    @Override
    public float class(float f2) {
        float f3 = 1.0f - ((float)this.super + f2) / ((float)this.this * 1.5f);
        return this.throw * f3;
    }

    @Override
    public void case() {
        this.protected = this.catch;
        this.throws = this.private;
        this.case = this.implements;
        if (this.super++ >= this.this) {
            this.finally();
        } else {
            float f2 = (float)this.super / (float)this.this;
            this.catch += this.finally * (double)f2;
            this.private += this.extends * (double)f2;
            this.implements += this.native * (double)f2;
        }
    }
}

