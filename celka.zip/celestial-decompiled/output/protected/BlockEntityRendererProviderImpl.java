/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Maps
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonNull
 *  com.google.gson.JsonObject
 *  com.google.gson.JsonSyntaxException
 */
package protected;

import com.google.common.collect.Maps;
import com.google.gson.JsonElement;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import protected.an;
import protected.ib_0;
import protected.rlr_1;
import protected.rly_1;
import protected.rpY;
import protected.rqo_0;
import protected.rvl_0;
import protected.xn_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.XA
 */
public class xa_2 {
    public static final xa_2 class = new xa_2(Collections.emptyMap());
    private final Map<rlr_1, xn_1> break;

    public xa_2(Map<rlr_1, xn_1> map) {
        this.break = map;
    }

    public static xa_2 class() {
        return new xa_2(Maps.newLinkedHashMap());
    }

    public static xa_2 class(JsonElement jsonElement) {
        if (jsonElement != null && !jsonElement.isJsonNull()) {
            JsonObject jsonObject = rpY.private(jsonElement, "effects");
            LinkedHashMap linkedHashMap = Maps.newLinkedHashMap();
            for (Map.Entry entry : jsonObject.entrySet()) {
                rqo_0 rqo_02 = new rqo_0((String)entry.getKey());
                rlr_1 rlr_12 = rvl_0.const.break(rqo_02).orElseThrow(() -> new JsonSyntaxException("Unknown effect '" + rqo_02 + "'"));
                xn_1 xn_12 = xn_1.class(rpY.private((JsonElement)entry.getValue(), (String)entry.getKey()));
                linkedHashMap.put(rlr_12, xn_12);
            }
            return new xa_2(linkedHashMap);
        }
        return xa_2.class;
    }

    public boolean class(Map<rlr_1, rly_1> map) {
        if (this == xa_2.class) {
            return true;
        }
        for (Map.Entry<rlr_1, xn_1> entry : this.break.entrySet()) {
            rly_1 rly_12 = map.get(entry.getKey());
            if (entry.getValue().class(rly_12)) continue;
            return false;
        }
        return true;
    }

    public xa_2 class(rlr_1 rlr_12) {
        this.break.put(rlr_12, new xn_1());
        return this;
    }

    public boolean class(an an2) {
        if (this == xa_2.class) {
            return true;
        }
        return an2 instanceof ib_0 ? this.class(((ib_0)an2).sb()) : false;
    }

    public boolean class(ib_0 ib_02) {
        return this == xa_2.class ? true : this.class(ib_02.sb());
    }

    public JsonElement break() {
        if (this == xa_2.class) {
            return JsonNull.INSTANCE;
        }
        JsonObject jsonObject = new JsonObject();
        for (Map.Entry<rlr_1, xn_1> entry : this.break.entrySet()) {
            jsonObject.add(rvl_0.const.break(entry.getKey()).toString(), entry.getValue().class());
        }
        return jsonObject;
    }
}

