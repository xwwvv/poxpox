/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.io.DataInput;
import java.io.IOException;
import protected.rcg_1;
import protected.rch_2;
import protected.rcv_2;
import protected.rcz_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.rcX
 */
class rcx_2
implements rcv_2<rch_2> {
    @Override
    public boolean byte() {
        return true;
    }

    rcx_2() {
    }

    public rch_2 class(DataInput dataInput, int n2, rcg_1 rcg_12) throws IOException {
        rcg_12.class(72L);
        return rch_2.class(dataInput.readByte());
    }

    @Override
    public String class() {
        return "BYTE";
    }

    @Override
    public /* synthetic */ rcz_1 break(DataInput dataInput, int n2, rcg_1 rcg_12) throws IOException {
        return this.class(dataInput, n2, rcg_12);
    }

    @Override
    public String break() {
        return "TAG_Byte";
    }
}

