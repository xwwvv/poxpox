/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.roe_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class ba {
    private static double[] break;
    private static byte[] byte;
    private static short[] protected;
    public Object[] class;
    private static boolean[] throws;

    private static void byte() {
        break = new double[4];
    }

    public ba(roe_0 roe_02) {
        this.break();
        Double d = roe_02.throws();
        this.class[ba.protected[0]] = d;
        Double d2 = roe_02.catch();
        this.class[ba.protected[1]] = d2;
        Double d3 = roe_02.case();
        this.class[ba.protected[2]] = d3;
        Double d4 = roe_02.private();
        this.class[ba.protected[3]] = d4;
    }

    static {
        ba.ntfClinit();
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0x788D77CF;
    }

    public boolean class(int n2, int n3) {
        return (double)n2 > (Double)this.class[protected[8]] && (double)(n2 + throws[4]) < (Double)this.class[protected[9]] && (double)n3 > (Double)this.class[protected[10]] && (double)(n3 + throws[5]) < (Double)this.class[protected[11]] ? throws[6] : throws[7];
    }

    private static void class() {
        short[] sArray = new short[12];
        sArray[1] = 1;
        sArray[2] = 2;
        sArray[3] = 3;
        sArray[5] = 1;
        sArray[6] = 2;
        sArray[7] = 3;
        sArray[9] = 1;
        sArray[10] = 2;
        sArray[11] = 3;
        protected = sArray;
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0xFB85E15032E60E49L;
    }

    public static String class(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{64, 21, -101, -6, -29, -117, -113, 31}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    public boolean break(int n2, int n3) {
        return (double)(n2 + throws[0]) > (Double)this.class[protected[4]] && (double)n2 < (Double)this.class[protected[5]] && (double)(n3 + throws[1]) > (Double)this.class[protected[6]] && (double)n3 < (Double)this.class[protected[7]] ? throws[2] : throws[3];
    }

    private void break() {
        if (this.class == null) {
            Object[] objectArray = this.class = new Object[byte[0]];
            objectArray[ba.throws[8]] = break[0];
            objectArray[ba.throws[9]] = break[1];
            objectArray[ba.byte[1]] = break[2];
            objectArray[ba.byte[2]] = break[3];
        }
    }

    private static void throws() {
        byte = new byte[]{4, 2, 3};
    }

    private static /* synthetic */ void ntfClinit() {
        ba.protected();
        ba.class();
        ba.byte();
        ba.throws();
    }

    private static void protected() {
        boolean[] blArray = new boolean[10];
        blArray[0] = true;
        blArray[1] = true;
        blArray[2] = true;
        blArray[4] = true;
        blArray[5] = true;
        blArray[6] = true;
        blArray[9] = true;
        throws = blArray;
    }
}

