/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.bf_0;
import protected.bl_0;
import protected.bv_0;
import protected.rfl;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.bA
 */
public class ba_0
extends bv_0 {
    private static byte[] byte;
    private static short[] protected;
    public Object[] break;

    public ba_0(rfl rfl2, bl_0[] bl_0Array, int n2, bf_0 bf_02, bf_0 bf_03) {
        super(rfl2, bl_0Array, n2);
        this.native();
        bf_0 bf_04 = bf_02;
        this.break[ba_0.protected[0]] = bf_04;
        bf_0 bf_05 = bf_03;
        this.break[ba_0.protected[1]] = bf_05;
    }

    static {
        ba_0.ntfClinit();
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0x6E9EEDA0;
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0x1B8AC57BF85504C8L;
    }

    public static String break(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{84, -73, -126, 65, -61, 17, 24, 105}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    private static /* synthetic */ void ntfClinit() {
        ba_0.extends();
        ba_0.finally();
    }

    private static void finally() {
        byte = new byte[]{2};
    }

    private static void extends() {
        short[] sArray = new short[4];
        sArray[1] = 1;
        sArray[3] = 1;
        protected = sArray;
    }

    public bf_0 implements() {
        this.native();
        return (bf_0)this.break[protected[3]];
    }

    public bf_0 private() {
        this.native();
        return (bf_0)this.break[protected[2]];
    }

    private void native() {
        if (this.break == null) {
            Object[] objectArray = this.break = new Object[byte[0]];
        }
    }
}

