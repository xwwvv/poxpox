/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Stream;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.C;
import protected.D;
import protected.case;
import protected.ej_2;
import protected.extends;
import protected.f;
import protected.f_0;
import protected.import;
import protected.n_0;
import protected.pd_2;
import protected.pp_2;
import protected.private;
import protected.q_0;
import protected.rVe;
import protected.rVi;
import protected.rgF;
import protected.rgh_0;
import protected.rgl_0;
import protected.rgn_0;
import protected.rgp_0;
import protected.rgy_0;
import protected.rqj;
import protected.sS;
import protected.sg_0;
import protected.throw;
import protected.throws;
import protected.v_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class SD
implements D,
pp_2 {
    private static boolean[] throws;
    public Object[] class;
    public static Object[] break;
    private static String[] case;
    private static short[] catch;
    private static byte[] private;

    private static void byte() {
        short[] sArray = new short[29];
        sArray[13] = 1;
        sArray[22] = 1;
        catch = sArray;
    }

    public SD(case case_) {
        this.protected();
        f_0 f_02 = case_.switch();
        this.class[SD.catch[0]] = f_02;
        case_.s().class(this);
    }

    static {
        SD.ntfClinit();
    }

    private static void class() {
        case = new String[]{new String("> %s"), new String("Click to rerun command"), new String("help"), new String("set toggle %s"), new String("set %s"), new String("set %s %s"), new String("true"), new String("false"), new String("false"), new String("true")};
    }

    public static String class(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{5, 20, 116, -24, 33, -41, -67, 99}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    @Override
    public void class(f f2) {
        String[] stringArray;
        if (!((Boolean)((private)SD.break[SD.catch[17]]).l.class[catch[18]]).booleanValue()) {
            return;
        }
        String string = (String)f2.class[catch[19]];
        String string3 = (String)((private)SD.break[SD.catch[20]]).protected.class[catch[21]];
        if (!string.startsWith(string3)) {
            return;
        }
        String string4 = string.substring(string3.length());
        List<import> list = sg_0.class(string4, throws[12]);
        Stream<String> stream = this.private(string4);
        if (list.size() == throws[13]) {
            stream = stream.map(string2 -> string3 + string2);
        }
        if ((stringArray = (String[])stream.toArray(String[]::new)).length > 0) {
            String[] stringArray2;
            f2.class[SD.catch[22]] = stringArray2 = stringArray;
        }
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0x7CF52C4C23738406L;
    }

    @Override
    public void class(C c) {
        String string = c.class();
        String string2 = (String)((private)SD.break[SD.catch[1]]).protected.class[catch[2]];
        boolean bl2 = string.startsWith(throw.class);
        if (string.startsWith(string2)) {
            c.break();
            String string3 = string.substring(bl2 ? throw.class.length() : string2.length());
            if (!this.break(string3) && !string3.trim().isEmpty()) {
                new n_0(ej_2.throws(string3).class()).class(null, null);
            }
        }
    }

    private void class(String string, String string2) {
        if (((Boolean)((private)SD.break[SD.catch[3]]).rt.class[catch[4]]).booleanValue()) {
            String string3 = string + string2;
            String string4 = (Boolean)((private)SD.break[SD.catch[5]]).rp.class[catch[6]] != false ? string + " ..." : string3;
            Object[] objectArray = new Object[throws[0]];
            objectArray[SD.throws[1]] = string4;
            rVe rVe2 = new rVe(String.format(case[0], objectArray));
            rVe2.class(rVe2.class().class(rgF.WHITE).class(new rgy_0(rgp_0.class, new rgn_0(case[1]))).class(new rgl_0(rgh_0.RUN_COMMAND, throw.class + string3)));
            rVi[] rViArray = new rVi[throws[2]];
            rViArray[SD.throws[3]] = rVe2;
            this.class(rViArray);
        }
    }

    public boolean break(String string) {
        if (string.isEmpty()) {
            return this.break(case[2]);
        }
        rqj<String, List<import>> rqj2 = ej_2.throws(string);
        String string2 = rqj2.class();
        String string3 = string.substring(rqj2.class().length());
        sS sS2 = new sS((f_0)this.class[catch[7]], rqj2.break());
        if (!sS2.final()) {
            extends extends_ = (extends)((Map)((private)SD.break[SD.catch[8]]).Pj[catch[9]]).get(string2.toLowerCase(Locale.US));
            if (extends_ != null) {
                this.class(string2, string3);
                if (extends_.byte() == Boolean.class) {
                    Object[] objectArray = new Object[throws[4]];
                    objectArray[SD.throws[5]] = extends_.protected();
                    ((f_0)this.class[catch[10]]).class(String.format(case[3], objectArray));
                } else {
                    Object[] objectArray = new Object[throws[6]];
                    objectArray[SD.throws[7]] = extends_.protected();
                    ((f_0)this.class[catch[11]]).class(String.format(case[4], objectArray));
                }
                return throws[8];
            }
        } else if (sS2.case()) {
            for (extends extends_ : (List)((private)SD.break[SD.catch[12]]).Pj[catch[13]]) {
                if (pd_2.throws(extends_) || !extends_.protected().equalsIgnoreCase(rqj2.class())) continue;
                this.class(string2, string3);
                try {
                    Object[] objectArray = new Object[private[0]];
                    objectArray[SD.throws[9]] = extends_.protected();
                    objectArray[SD.throws[10]] = sS2.extends();
                    ((f_0)this.class[catch[14]]).class(String.format(case[5], objectArray));
                }
                catch (q_0 q_02) {
                    // empty catch block
                }
                return throws[11];
            }
        }
        if (((f_0)this.class[catch[15]]).break(rqj2.class()) != null) {
            this.class(string2, string3);
        }
        return ((f_0)this.class[catch[16]]).break(rqj2);
    }

    private static void break() {
        Object[] objectArray = new Object[]{protected.throws.break()};
        break = objectArray;
    }

    private static int break(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0x5B76E6DE;
    }

    private static void throws() {
        private = new byte[]{2, 2, 2, 2};
    }

    private static /* synthetic */ void ntfClinit() {
        SD.case();
        SD.class();
        SD.byte();
        SD.throws();
        SD.break();
    }

    private static void case() {
        boolean[] blArray = new boolean[23];
        blArray[0] = true;
        blArray[2] = true;
        blArray[4] = true;
        blArray[6] = true;
        blArray[8] = true;
        blArray[10] = true;
        blArray[11] = true;
        blArray[12] = true;
        blArray[13] = true;
        blArray[14] = true;
        blArray[15] = true;
        blArray[17] = true;
        blArray[19] = true;
        blArray[21] = true;
        blArray[22] = true;
        throws = blArray;
    }

    private void protected() {
        if (this.class == null) {
            Object[] objectArray = this.class = new Object[throws[21]];
        }
    }

    public Stream<String> private(String string) {
        try {
            List<import> list = sg_0.class(string, throws[14]);
            sS sS2 = new sS((f_0)this.class[catch[23]], list);
            if (sS2.catch(private[1])) {
                if (sS2.case(throws[15])) {
                    return new v_0().class((f_0)this.class[catch[24]]).byte().class(sS2.extends()).protected();
                }
                extends extends_ = (extends)((Map)((private)SD.break[SD.catch[25]]).Pj[catch[26]]).get(sS2.extends().toLowerCase(Locale.US));
                if (extends_ != null && !pd_2.throws(extends_)) {
                    if (extends_.byte() == Boolean.class) {
                        v_0 v_02 = new v_0();
                        if (((Boolean)extends_.class[catch[27]]).booleanValue()) {
                            String[] stringArray = new String[private[2]];
                            stringArray[SD.throws[16]] = case[6];
                            stringArray[SD.throws[17]] = case[7];
                            v_02.break(stringArray);
                        } else {
                            String[] stringArray = new String[private[3]];
                            stringArray[SD.throws[18]] = case[8];
                            stringArray[SD.throws[19]] = case[9];
                            v_02.break(stringArray);
                        }
                        return v_02.class(sS2.extends()).protected();
                    }
                    return Stream.of(pd_2.break(extends_));
                }
            }
            return ((f_0)this.class[catch[28]]).byte(string);
        }
        catch (q_0 q_02) {
            return Stream.empty();
        }
    }
}

