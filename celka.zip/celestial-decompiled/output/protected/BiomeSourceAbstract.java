/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableList
 *  com.google.common.collect.Maps
 *  com.google.common.collect.Sets
 *  com.mojang.serialization.Codec
 */
package protected;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.mojang.serialization.Codec;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;
import java.util.stream.Stream;
import protected.rYD;
import protected.rYK;
import protected.rYi;
import protected.rYn;
import protected.rYo;
import protected.rfH;
import protected.ror_0;
import protected.rrrZ;
import protected.rvl_0;
import protected.ryg_0;
import protected.xc_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public abstract class rYY
implements rYn {
    public static final Codec<rYY> class = rvl_0.rE.dispatchStable(rYY::class, Function.identity());
    protected final Map<rrrZ<?>, Boolean> break = Maps.newHashMap();
    protected final Set<xc_0> byte = Sets.newHashSet();
    protected final List<ryg_0> protected;

    public Set<xc_0> byte() {
        if (this.byte.isEmpty()) {
            for (ryg_0 ryg_02 : this.protected) {
                this.byte.add(ryg_02.throws().throws().class());
            }
        }
        return this.byte;
    }

    protected rYY(Stream<Supplier<ryg_0>> stream) {
        this((List)stream.map(Supplier::get).collect(ImmutableList.toImmutableList()));
    }

    protected rYY(List<ryg_0> list) {
        this.protected = list;
    }

    static {
        rvl_0.class(rvl_0.rE, "fixed", ror_0.throws);
        rvl_0.class(rvl_0.rE, "multi_noise", rYD.case);
        rvl_0.class(rvl_0.rE, "checkerboard", rYo.throws);
        rvl_0.class(rvl_0.rE, "vanilla_layered", rYi.throws);
        rvl_0.class(rvl_0.rE, "the_end", rYK.throws);
    }

    public rfH class(int n2, int n3, int n4, int n5, int n6, Predicate<ryg_0> predicate, Random random, boolean bl2) {
        int n7;
        int n8 = n2 >> 2;
        int n9 = n4 >> 2;
        int n10 = n5 >> 2;
        int n11 = n3 >> 2;
        rfH rfH2 = null;
        int n12 = 0;
        for (int k = n7 = bl2 ? 0 : n10; k <= n10; k += n6) {
            for (int i2 = -k; i2 <= k; i2 += n6) {
                boolean bl3 = Math.abs(i2) == k;
                for (int i3 = -k; i3 <= k; i3 += n6) {
                    int n13;
                    int n14;
                    if (bl2) {
                        int n15 = n14 = Math.abs(i3) == k ? 1 : 0;
                        if (n14 == 0 && !bl3) continue;
                    }
                    if (!predicate.test(this.protected(n14 = n8 + i3, n11, n13 = n9 + i2))) continue;
                    if (rfH2 == null || random.nextInt(n12 + 1) == 0) {
                        rfH2 = new rfH(n14 << 2, n3, n13 << 2);
                        if (bl2) {
                            return rfH2;
                        }
                    }
                    ++n12;
                }
            }
        }
        return rfH2;
    }

    public rfH class(int n2, int n3, int n4, int n5, Predicate<ryg_0> predicate, Random random) {
        return this.class(n2, n3, n4, n5, 1, predicate, random, false);
    }

    protected abstract Codec<? extends rYY> class();

    public boolean class(rrrZ<?> rrrZ3) {
        return this.break.computeIfAbsent(rrrZ3, rrrZ2 -> this.protected.stream().anyMatch(ryg_02 -> ryg_02.throws().class((rrrZ<?>)rrrZ2)));
    }

    public Set<ryg_0> class(int n2, int n3, int n4, int n5) {
        int n6 = n2 - n5 >> 2;
        int n7 = n3 - n5 >> 2;
        int n8 = n4 - n5 >> 2;
        int n9 = n2 + n5 >> 2;
        int n10 = n3 + n5 >> 2;
        int n11 = n4 + n5 >> 2;
        int n12 = n9 - n6 + 1;
        int n13 = n10 - n7 + 1;
        int n14 = n11 - n8 + 1;
        HashSet hashSet = Sets.newHashSet();
        for (int k = 0; k < n14; ++k) {
            for (int i2 = 0; i2 < n12; ++i2) {
                for (int i3 = 0; i3 < n13; ++i3) {
                    int n15 = n6 + i2;
                    int n16 = n7 + i3;
                    int n17 = n8 + k;
                    hashSet.add(this.protected(n15, n16, n17));
                }
            }
        }
        return hashSet;
    }

    public abstract rYY class(long var1);

    public List<ryg_0> break() {
        return this.protected;
    }
}

