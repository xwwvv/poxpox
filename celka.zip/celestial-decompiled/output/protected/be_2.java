/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.regex.Pattern;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.ba_2;
import protected.bl_2;
import protected.bn_2;
import protected.by_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.Be
 */
public class be_2
extends bn_2
implements by_1 {
    private static short[] protected;
    private static boolean[] throws;
    private static String[] case;
    public Object[] byte;

    public be_2() {
        super(case[0], (Pattern[])bl_2.class[protected[0]]);
        this.catch();
    }

    static {
        be_2.ntfClinit();
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0x407D823;
    }

    @Override
    public String class() {
        this.catch();
        if ((ba_2)((Object)this.byte[protected[4]]) == null) {
            return null;
        }
        return ((ba_2)((Object)this.byte[protected[5]])).class();
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0xA236B37192C49B69L;
    }

    @Override
    public void throws(String string) {
        this.catch();
        super.throws(string);
        ba_2 ba_22 = ba_2.class(string);
        this.byte[be_2.protected[1]] = ba_22;
        if ((ba_2)((Object)this.byte[protected[2]]) != null) {
            this.protected(((ba_2)((Object)this.byte[protected[3]])).class() + " " + this.throws().toLowerCase());
        }
    }

    private static /* synthetic */ void ntfClinit() {
        be_2.finally();
        be_2.implements();
        be_2.private();
    }

    private static void finally() {
        throws = new boolean[]{true};
    }

    private void catch() {
        if (this.byte == null) {
            Object[] objectArray = this.byte = new Object[throws[0]];
        }
    }

    public static String catch(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{96, -63, 84, -67, 81, 126, 57, -22}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    private static void implements() {
        case = new String[]{new String("\u041c\u0435\u0442\u0435\u043e\u0440. \u0434\u043e\u0436\u0434\u044c")};
    }

    private static void private() {
        short[] sArray = new short[6];
        sArray[0] = 15;
        protected = sArray;
    }
}

