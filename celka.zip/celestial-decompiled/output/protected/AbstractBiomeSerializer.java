/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.serialization.Codec
 */
package protected;

import com.mojang.serialization.Codec;
import java.util.Random;
import java.util.function.Supplier;
import protected.roC;
import protected.rrsa_1;
import protected.rrse_0;
import protected.rva_0;
import protected.rvl_0;
import protected.ryg_0;
import protected.xc_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.rrSR
 */
public class rrsr_1<SC extends rrsa_1> {
    public static final Codec<rrsr_1<?>> class = rvl_0.l.dispatch(rrsr_12 -> rrsr_12.byte, rrse_0::protected);
    public static final Codec<Supplier<rrsr_1<?>>> break = rva_0.class(rvl_0.m, rrsr_1.class);
    public final rrse_0<SC> byte;
    public final SC protected;

    public rrsr_1(rrse_0<SC> rrse_02, SC SC) {
        this.byte = rrse_02;
        this.protected = SC;
    }

    public SC class() {
        return this.protected;
    }

    public void class(Random random, roC roC2, ryg_0 ryg_02, int n2, int n3, int n4, double d, xc_0 xc_02, xc_0 xc_03, int n5, long l2) {
        this.byte.class(random, roC2, ryg_02, n2, n3, n4, d, xc_02, xc_03, n5, l2, this.protected);
    }

    public void class(long l2) {
        this.byte.class(l2);
    }
}

