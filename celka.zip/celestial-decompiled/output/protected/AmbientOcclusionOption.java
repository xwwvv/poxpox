/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.Vw;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public interface VH {
    public Vw byte();

    public int class();

    public void break();

    public Vw protected();
}

