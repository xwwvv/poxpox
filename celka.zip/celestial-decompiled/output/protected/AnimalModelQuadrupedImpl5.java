/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableList
 */
package protected;

import com.google.common.collect.ImmutableList;
import protected.iq_1;
import protected.rfU;
import protected.rok_1;
import protected.wn_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class wH<T extends rok_1>
extends wn_0<T> {
    private final iq_1 class;
    private final iq_1 break;
    private final iq_1 byte;
    private final iq_1 protected;
    private final iq_1 throws;
    private final iq_1 case;
    private final iq_1 catch;
    private final iq_1 private;
    private final iq_1 implements;

    public wH() {
        this.return = 64;
        this.public = 128;
        this.class = new iq_1(this, 0, 32);
        this.class.class(-4.0f, 8.0f, 0.0f);
        this.class.class(-2.0f, 0.0f, -2.0f, 4.0f, 16.0f, 4.0f, 0.0f);
        this.break = new iq_1(this, 0, 55);
        this.break.class(4.0f, 8.0f, 0.0f);
        this.break.class(-2.0f, 0.0f, -2.0f, 4.0f, 16.0f, 4.0f, 0.0f);
        this.byte = new iq_1(this, 0, 0);
        this.byte.class(0.0f, 1.0f, 0.0f);
        this.byte.class(-8.0f, -6.0f, -8.0f, 16.0f, 14.0f, 16.0f, 0.0f);
        this.protected = new iq_1(this, 16, 65);
        this.protected.class(-8.0f, 4.0f, -8.0f);
        this.protected.class(-12.0f, 0.0f, 0.0f, 12.0f, 0.0f, 16.0f, 0.0f, true);
        this.class(this.protected, 0.0f, 0.0f, -1.2217305f);
        this.throws = new iq_1(this, 16, 49);
        this.throws.class(-8.0f, -1.0f, -8.0f);
        this.throws.class(-12.0f, 0.0f, 0.0f, 12.0f, 0.0f, 16.0f, 0.0f, true);
        this.class(this.throws, 0.0f, 0.0f, -1.134464f);
        this.case = new iq_1(this, 16, 33);
        this.case.class(-8.0f, -5.0f, -8.0f);
        this.case.class(-12.0f, 0.0f, 0.0f, 12.0f, 0.0f, 16.0f, 0.0f, true);
        this.class(this.case, 0.0f, 0.0f, -0.87266463f);
        this.catch = new iq_1(this, 16, 33);
        this.catch.class(8.0f, -6.0f, -8.0f);
        this.catch.class(0.0f, 0.0f, 0.0f, 12.0f, 0.0f, 16.0f, 0.0f);
        this.class(this.catch, 0.0f, 0.0f, 0.87266463f);
        this.private = new iq_1(this, 16, 49);
        this.private.class(8.0f, -2.0f, -8.0f);
        this.private.class(0.0f, 0.0f, 0.0f, 12.0f, 0.0f, 16.0f, 0.0f);
        this.class(this.private, 0.0f, 0.0f, 1.134464f);
        this.implements = new iq_1(this, 16, 65);
        this.implements.class(8.0f, 3.0f, -8.0f);
        this.implements.class(0.0f, 0.0f, 0.0f, 12.0f, 0.0f, 16.0f, 0.0f);
        this.class(this.implements, 0.0f, 0.0f, 1.2217305f);
        this.byte.break(this.protected);
        this.byte.break(this.throws);
        this.byte.break(this.case);
        this.byte.break(this.catch);
        this.byte.break(this.private);
        this.byte.break(this.implements);
    }

    @Override
    public Iterable<iq_1> class() {
        return ImmutableList.of((Object)this.byte, (Object)this.break, (Object)this.class);
    }

    @Override
    public void class(iq_1 iq_12, float f2, float f3, float f4) {
        iq_12.case = f2;
        iq_12.catch = f3;
        iq_12.private = f4;
    }

    @Override
    public void class(rok_1 rok_12, float f2, float f3, float f4, float f5, float f6) {
        f3 = Math.min(0.25f, f3);
        if (rok_12.Bh().size() <= 0) {
            this.byte.case = f6 * ((float)Math.PI / 180);
            this.byte.catch = f5 * ((float)Math.PI / 180);
        } else {
            this.byte.case = 0.0f;
            this.byte.catch = 0.0f;
        }
        float f7 = 1.5f;
        this.byte.private = 0.1f * rfU.class(f2 * 1.5f) * 4.0f * f3;
        this.byte.protected = 2.0f;
        this.byte.protected -= 2.0f * rfU.break(f2 * 1.5f) * 2.0f * f3;
        this.break.case = rfU.class(f2 * 1.5f * 0.5f) * 2.0f * f3;
        this.class.case = rfU.class(f2 * 1.5f * 0.5f + (float)Math.PI) * 2.0f * f3;
        this.break.private = 0.17453292f * rfU.break(f2 * 1.5f * 0.5f) * f3;
        this.class.private = 0.17453292f * rfU.break(f2 * 1.5f * 0.5f + (float)Math.PI) * f3;
        this.break.protected = 8.0f + 2.0f * rfU.class(f2 * 1.5f * 0.5f + (float)Math.PI) * 2.0f * f3;
        this.class.protected = 8.0f + 2.0f * rfU.class(f2 * 1.5f * 0.5f) * 2.0f * f3;
        this.protected.private = -1.2217305f;
        this.throws.private = -1.134464f;
        this.case.private = -0.87266463f;
        this.catch.private = 0.87266463f;
        this.private.private = 1.134464f;
        this.implements.private = 1.2217305f;
        float f8 = rfU.break(f2 * 1.5f + (float)Math.PI) * f3;
        this.protected.private += f8 * 1.3f;
        this.throws.private += f8 * 1.2f;
        this.case.private += f8 * 0.6f;
        this.catch.private += f8 * 0.6f;
        this.private.private += f8 * 1.2f;
        this.implements.private += f8 * 1.3f;
        float f9 = 1.0f;
        float f10 = 1.0f;
        this.protected.private += 0.05f * rfU.class(f4 * 1.0f * -0.4f);
        this.throws.private += 0.1f * rfU.class(f4 * 1.0f * 0.2f);
        this.case.private += 0.1f * rfU.class(f4 * 1.0f * 0.4f);
        this.catch.private += 0.1f * rfU.class(f4 * 1.0f * 0.4f);
        this.private.private += 0.1f * rfU.class(f4 * 1.0f * 0.2f);
        this.implements.private += 0.05f * rfU.class(f4 * 1.0f * -0.4f);
    }
}

