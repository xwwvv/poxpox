/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.rrji_1;
import protected.rrmp_1;
import protected.rrxg_0;
import protected.rrxm_0;
import protected.rrxs;
import protected.rrxs_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.rrxB
 */
public class rrxb_0
implements rrji_1 {
    private String class = null;
    private boolean break = false;
    private Class byte = null;

    public boolean byte() {
        return this.break() != null;
    }

    public rrxb_0(String string) {
        this.class = string;
        rrxm_0.class(this);
    }

    public rrxb_0(Class clazz) {
        this.byte = clazz;
        this.class = clazz.getName();
        this.break = true;
    }

    public rrxs class(String string) {
        return new rrxs(this, string);
    }

    public rrxg_0 class(String string, Class[] classArray) {
        return new rrxg_0(this, string, classArray);
    }

    public rrxs_0 class(Class[] classArray) {
        return new rrxs_0(this, classArray);
    }

    @Override
    public void class() {
        Class clazz = this.break();
    }

    public boolean class(Object object) {
        return this.break() == null ? false : this.break().isInstance(object);
    }

    public Class break() {
        if (this.break) {
            return this.byte;
        }
        this.break = true;
        try {
            this.byte = Class.forName(this.class);
        }
        catch (ClassNotFoundException classNotFoundException) {
            rrmp_1.throws("(Reflector) Class not present: " + this.class);
        }
        catch (Throwable throwable) {
            throwable.printStackTrace();
        }
        return this.byte;
    }

    public rrxg_0 break(String string) {
        return new rrxg_0(this, string);
    }

    public String protected() {
        return this.class;
    }
}

