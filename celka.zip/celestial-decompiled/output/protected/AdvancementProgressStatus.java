/*
 * Decompiled with CFR 0.152.
 */
package protected;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.cK
 */
public final class ck_2
extends Enum<ck_2> {
    public static final /* enum */ ck_2 OBTAINED = new ck_2(0);
    public static final /* enum */ ck_2 UNOBTAINED = new ck_2(1);
    private final int id;
    private static final /* synthetic */ ck_2[] $VALUES;

    private ck_2(int n3) {
        this.id = n3;
    }

    static {
        $VALUES = ck_2.break();
    }

    public static ck_2[] values() {
        return (ck_2[])$VALUES.clone();
    }

    public static ck_2 valueOf(String string) {
        return Enum.valueOf(ck_2.class, string);
    }

    public int class() {
        return this.id;
    }

    private static /* synthetic */ ck_2[] break() {
        return new ck_2[]{OBTAINED, UNOBTAINED};
    }
}

