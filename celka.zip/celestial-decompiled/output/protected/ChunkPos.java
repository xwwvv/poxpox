/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.util.stream.Stream;
import java.util.stream.StreamSupport;
import protected.rfH;
import protected.rfV;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class rfj {
    public static final long class = rfj.class(1875016, 1875016);
    public final int break;
    public final int byte;
    private int protected = 0;

    public int byte() {
        return this.byte << 4;
    }

    public rfj(int n2, int n3) {
        this.break = n2;
        this.byte = n3;
    }

    public rfj(long l2) {
        this.break = (int)l2;
        this.byte = (int)(l2 >> 32);
    }

    public rfj(rfH rfH2) {
        this.break = rfH2.b_() >> 4;
        this.byte = rfH2.d_() >> 4;
    }

    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof rfj)) {
            return false;
        }
        rfj rfj2 = (rfj)object;
        return this.break == rfj2.break && this.byte == rfj2.byte;
    }

    public String toString() {
        return "[" + this.break + ", " + this.byte + "]";
    }

    public int hashCode() {
        if (this.protected != 0) {
            return this.protected;
        }
        int n2 = 1664525 * this.break + 1013904223;
        int n3 = 1664525 * (this.byte ^ 0xDEADBEEF) + 1013904223;
        this.protected = n2 ^ n3;
        return this.protected;
    }

    public static Stream<rfj> class(rfj rfj2, rfj rfj3) {
        int n2 = Math.abs(rfj2.break - rfj3.break) + 1;
        int n3 = Math.abs(rfj2.byte - rfj3.byte) + 1;
        int n4 = rfj2.break < rfj3.break ? 1 : -1;
        int n5 = rfj2.byte < rfj3.byte ? 1 : -1;
        return StreamSupport.stream(new rfV(n2 * n3, 64, rfj2, rfj3, n5, n4), false);
    }

    public static Stream<rfj> class(rfj rfj2, int n2) {
        return rfj.class(new rfj(rfj2.break - n2, rfj2.byte - n2), new rfj(rfj2.break + n2, rfj2.byte + n2));
    }

    public int class(rfj rfj2) {
        return Math.max(Math.abs(this.break - rfj2.break), Math.abs(this.byte - rfj2.byte));
    }

    public static int class(long l2) {
        return (int)(l2 & 0xFFFFFFFFL);
    }

    public long class() {
        return rfj.class(this.break, this.byte);
    }

    public static long class(int n2, int n3) {
        return (long)n2 & 0xFFFFFFFFL | ((long)n3 & 0xFFFFFFFFL) << 32;
    }

    public static int break(long l2) {
        return (int)(l2 >>> 32 & 0xFFFFFFFFL);
    }

    public int break() {
        return this.break << 4;
    }

    public int throws() {
        return (this.byte << 4) + 15;
    }

    public rfH finally() {
        return new rfH(this.break(), 0, this.byte());
    }

    public int catch() {
        return this.byte >> 5;
    }

    public int case() {
        return this.break >> 5;
    }

    public int implements() {
        return this.byte & 0x1F;
    }

    public int protected() {
        return (this.break << 4) + 15;
    }

    public int private() {
        return this.break & 0x1F;
    }
}

