/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.cn_2;
import protected.lf_2;
import protected.ll_2;
import protected.mo;
import protected.rgP;
import protected.vk_1;

/*
 * Renamed from protected.ve
 * Illegal identifiers - consider using --renameillegalidents true
 */
class ve_1
extends lf_2 {
    final /* synthetic */ mo class;
    final /* synthetic */ vk_1 throws;

    ve_1(vk_1 vk_12, int n2, int n3, int n4, int n5, rgP rgP2, ll_2 ll_22, mo mo2) {
        this.throws = vk_12;
        this.class = mo2;
        super(n2, n3, n4, n5, rgP2, ll_22);
    }

    @Override
    public rgP C_() {
        return cn_2.class(super.C_(), this.throws.package.byte() && !this.class.class);
    }
}

