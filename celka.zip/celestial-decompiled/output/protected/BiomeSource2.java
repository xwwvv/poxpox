/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  it.unimi.dsi.fastutil.longs.Long2FloatLinkedOpenHashMap
 */
package protected;

import it.unimi.dsi.fastutil.longs.Long2FloatLinkedOpenHashMap;
import protected.ryg_0;

/*
 * Renamed from protected.rYb
 * Illegal identifiers - consider using --renameillegalidents true
 */
class ryb_0
extends Long2FloatLinkedOpenHashMap {
    final /* synthetic */ ryg_0 class;

    ryb_0(ryg_0 ryg_02, int n2, float f2) {
        this.class = ryg_02;
        super(n2, f2);
    }

    protected void rehash(int n2) {
    }
}

