/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Collections;
import java.util.List;
import java.util.stream.Stream;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.case;
import protected.static;
import protected.try;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.sJ
 */
public class sj_0
extends try {
    public Object[] break;
    private static short[] throws;
    private static byte[] case;
    private static boolean[] catch;
    private static String[] private;

    public sj_0(case case_, List<String> list, String string, String string2) {
        super(case_, list.toArray(new String[catch[0]]));
        this.throws();
        String string3 = string;
        this.break[sj_0.throws[0]] = string3;
        String string4 = string2;
        this.break[sj_0.throws[1]] = string4;
    }

    public sj_0(case case_, String string, String string2, String string3) {
        String[] stringArray = new String[catch[1]];
        stringArray[sj_0.catch[2]] = string;
        super(case_, stringArray);
        this.throws();
        String string4 = string2;
        this.break[sj_0.throws[2]] = string4;
        String string5 = string3;
        this.break[sj_0.throws[3]] = string5;
    }

    static {
        sj_0.ntfClinit();
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0x9E3D11E6;
    }

    @Override
    public void class(String string, static static_) {
        this.throws();
        Object[] objectArray = new Object[case[0]];
        objectArray[sj_0.catch[3]] = (String)this.break[throws[5]];
        objectArray[sj_0.catch[4]] = static_.class();
        ((case)this.class[throws[4]]).switch().class(String.format(private[0], objectArray));
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0x53DEBFA621DB640EL;
    }

    @Override
    public Stream<String> break(String string, static static_) {
        this.throws();
        Object[] objectArray = new Object[case[1]];
        objectArray[sj_0.catch[5]] = (String)this.break[throws[7]];
        objectArray[sj_0.catch[6]] = static_.class();
        return ((case)this.class[throws[6]]).switch().byte(String.format(private[1], objectArray));
    }

    public static String break(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{-110, 85, 3, 63, 72, -32, 35, -26}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    private void throws() {
        if (this.break == null) {
            Object[] objectArray = this.break = new Object[case[2]];
        }
    }

    private static /* synthetic */ void ntfClinit() {
        sj_0.native();
        sj_0.extends();
        sj_0.finally();
        sj_0.protected();
    }

    private static void finally() {
        short[] sArray = new short[10];
        sArray[1] = 1;
        sArray[3] = 1;
        sArray[5] = 1;
        sArray[7] = 1;
        sArray[9] = 1;
        throws = sArray;
    }

    @Override
    public List<String> catch() {
        this.throws();
        Object[] objectArray = new Object[catch[7]];
        objectArray[sj_0.catch[8]] = (String)this.break[throws[9]];
        return Collections.singletonList(String.format(private[2], objectArray));
    }

    private static void extends() {
        private = new String[]{new String("%s %s"), new String("%s %s"), new String("This command is an alias, for: %s ...")};
    }

    @Override
    public String implements() {
        this.throws();
        return (String)this.break[throws[8]];
    }

    private static void protected() {
        case = new byte[]{2, 2, 2};
    }

    private static void native() {
        boolean[] blArray = new boolean[9];
        blArray[1] = true;
        blArray[4] = true;
        blArray[6] = true;
        blArray[7] = true;
        catch = blArray;
    }
}

