/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.brigadier.StringReader
 *  com.mojang.brigadier.exceptions.CommandSyntaxException
 */
package protected;

import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import protected.xu_2;

/*
 * Renamed from protected.Xv
 */
@FunctionalInterface
public interface xv_2<T extends Number, R extends xu_2<T>> {
    public R create(StringReader var1, T var2, T var3) throws CommandSyntaxException;
}

