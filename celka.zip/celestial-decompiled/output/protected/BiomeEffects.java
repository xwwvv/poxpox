/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.datafixers.kinds.App
 *  com.mojang.datafixers.kinds.Applicative
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.codecs.RecordCodecBuilder
 */
package protected;

import com.mojang.datafixers.kinds.App;
import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import protected.rqa_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class rYg {
    public static final Codec<rYg> class = RecordCodecBuilder.create(instance -> instance.group((App)rqa_0.class.fieldOf("sound").forGetter(rYg2 -> rYg2.break), (App)Codec.DOUBLE.fieldOf("tick_chance").forGetter(rYg2 -> rYg2.byte)).apply((Applicative)instance, rYg::new));
    private rqa_0 break;
    private double byte;

    public rYg(rqa_0 rqa_02, double d) {
        this.break = rqa_02;
        this.byte = d;
    }

    public rqa_0 class() {
        return this.break;
    }

    public double break() {
        return this.byte;
    }
}

