/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.eC;
import protected.ef_0;
import protected.ev_0;
import protected.ey_0;
import protected.rxq_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class ax
extends ev_0 {
    public ax(ef_0 ef_02, rxq_1 ... rxq_1Array) {
        super(ef_02, eC.TRIDENT, rxq_1Array);
    }

    @Override
    public int class() {
        return 3;
    }

    @Override
    public boolean class(ev_0 ev_02) {
        return super.class(ev_02) && ev_02 != ey_0.interface && ev_02 != ey_0.long;
    }

    @Override
    public int class(int n2) {
        return 10 + n2 * 7;
    }

    @Override
    public int break(int n2) {
        return 50;
    }
}

