/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.util.Random;
import protected.jq_1;
import protected.rCL;
import protected.rCZ;
import protected.rYB;
import protected.rcn_0;
import protected.rfH;
import protected.rrEm;
import protected.rxx;
import protected.wq_2;
import protected.xc_0;
import protected.xd_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.WW
 */
public class ww_2
extends xd_0 {
    public static final rcn_0 volatile = wq_2.volatile;

    public ww_2(jq_1 jq_12) {
        super(jq_12);
        this.extends((xc_0)this.continue().class(volatile, false));
    }

    @Override
    protected void class(rCL<xd_0, xc_0> rCL2) {
        rCL2.class(new rCZ[]{volatile});
    }

    @Override
    public xc_0 class(rxx rxx2) {
        return (xc_0)this.continue().class(volatile, rxx2.int().public(rxx2.class()));
    }

    @Override
    public void class(xc_0 xc_02, rYB rYB2, rfH rfH2, xd_0 xd_02, rfH rfH3, boolean bl2) {
        boolean bl3;
        if (!rYB2.continue && (bl3 = xc_02.byte(volatile).booleanValue()) != rYB2.public(rfH2)) {
            if (bl3) {
                rYB2.finally().class(rfH2, this, 4);
            } else {
                rYB2.class(rfH2, (xc_0)xc_02.class(volatile), 2);
            }
        }
    }

    @Override
    public void break(xc_0 xc_02, rrEm rrEm2, rfH rfH2, Random random) {
        if (xc_02.byte(volatile).booleanValue() && !rrEm2.public(rfH2)) {
            rrEm2.class(rfH2, (xc_0)xc_02.class(volatile), 2);
        }
    }
}

