/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.bE
 */
public class be_0
extends Enum<be_0> {
    private static boolean[] booleans41d67a8911663c568d38045d1ac26747;
    private static String[] strings41d67a8911663c568d38045d1ac26747;
    private static short[] shorts41d67a8911663c568d38045d1ac26747;
    private static byte[] bytes41d67a8911663c568d38045d1ac26747;
    public static Object[] staticFields41d67a8911663c568d38045d1ac26747;

    private static void byte() {
        strings41d67a8911663c568d38045d1ac26747 = new String[]{new String("CHEST"), new String("SHULKER_BOX"), new String("ANVIL"), new String("ENCHANTING_TABLE"), new String("BARREL"), new String("FURNACE")};
    }

    static {
        be_0.ntfClinit();
    }

    public static be_0[] values() {
        return (be_0[])((be_0[])staticFields41d67a8911663c568d38045d1ac26747[shorts41d67a8911663c568d38045d1ac26747[0]]).clone();
    }

    public static be_0 valueOf(String string) {
        return Enum.valueOf(be_0.class, string);
    }

    private static /* synthetic */ be_0[] class() {
        be_0[] be_0Array = new be_0[bytes41d67a8911663c568d38045d1ac26747[0]];
        be_0Array[be_0.booleans41d67a8911663c568d38045d1ac26747[0]] = (be_0)((Object)staticFields41d67a8911663c568d38045d1ac26747[shorts41d67a8911663c568d38045d1ac26747[1]]);
        be_0Array[be_0.booleans41d67a8911663c568d38045d1ac26747[1]] = (be_0)((Object)staticFields41d67a8911663c568d38045d1ac26747[shorts41d67a8911663c568d38045d1ac26747[2]]);
        be_0Array[be_0.bytes41d67a8911663c568d38045d1ac26747[1]] = (be_0)((Object)staticFields41d67a8911663c568d38045d1ac26747[shorts41d67a8911663c568d38045d1ac26747[3]]);
        be_0Array[be_0.bytes41d67a8911663c568d38045d1ac26747[2]] = (be_0)((Object)staticFields41d67a8911663c568d38045d1ac26747[shorts41d67a8911663c568d38045d1ac26747[4]]);
        be_0Array[be_0.bytes41d67a8911663c568d38045d1ac26747[3]] = (be_0)((Object)staticFields41d67a8911663c568d38045d1ac26747[shorts41d67a8911663c568d38045d1ac26747[5]]);
        be_0Array[be_0.bytes41d67a8911663c568d38045d1ac26747[4]] = (be_0)((Object)staticFields41d67a8911663c568d38045d1ac26747[shorts41d67a8911663c568d38045d1ac26747[6]]);
        return be_0Array;
    }

    public static String class(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{-63, 111, 77, 118, -106, -35, -127, 59}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0xA4A1C064;
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0xFC74771B525F0B54L;
    }

    private static void break() {
        short[] sArray = new short[7];
        sArray[0] = 6;
        sArray[2] = 1;
        sArray[3] = 2;
        sArray[4] = 3;
        sArray[5] = 4;
        sArray[6] = 5;
        shorts41d67a8911663c568d38045d1ac26747 = sArray;
    }

    private static void throws() {
        boolean[] blArray = new boolean[6];
        blArray[1] = true;
        blArray[4] = true;
        blArray[5] = true;
        booleans41d67a8911663c568d38045d1ac26747 = blArray;
    }

    private static /* synthetic */ void ntfClinit() {
        be_0.throws();
        be_0.byte();
        be_0.break();
        be_0.case();
        be_0.protected();
    }

    private static void case() {
        bytes41d67a8911663c568d38045d1ac26747 = new byte[]{6, 2, 3, 4, 5, 2, 2, 3, 3, 4, 4, 5, 5, 6, 7};
    }

    private static void protected() {
        Object[] objectArray;
        objectArray = new Object[]{new be_0(), new be_0(), new be_0(), new be_0(), new be_0(), new be_0(), new be_0[]{(be_0)((Object)objectArray[0]), (be_0)((Object)objectArray[1]), (be_0)((Object)objectArray[2]), (be_0)((Object)objectArray[3]), (be_0)((Object)objectArray[4]), (be_0)((Object)objectArray[5])}};
        staticFields41d67a8911663c568d38045d1ac26747 = objectArray;
    }
}

