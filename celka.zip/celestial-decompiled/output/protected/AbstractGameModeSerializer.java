/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.rRC;
import protected.rRZ;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.rRA
 */
public final class rra_0<T extends rRC<T>> {
    final String class;
    private final rRZ break;

    public rRZ byte() {
        return this.break;
    }

    public rra_0(String string, rRZ rRZ2) {
        this.class = string;
        this.break = rRZ2;
    }

    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        return object instanceof rra_0 && ((rra_0)object).class.equals(this.class);
    }

    public String toString() {
        return this.class;
    }

    public int hashCode() {
        return this.class.hashCode();
    }

    public String class() {
        return this.class;
    }

    public String break() {
        return "gamerule." + this.class;
    }
}

