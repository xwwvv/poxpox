/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.Gson
 *  com.google.gson.GsonBuilder
 *  com.google.gson.JsonParseException
 *  com.mojang.datafixers.DSL
 *  com.mojang.datafixers.Typed
 *  com.mojang.datafixers.schemas.Schema
 *  com.mojang.serialization.Dynamic
 *  org.apache.commons.lang3.StringUtils
 */
package protected;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonParseException;
import com.mojang.datafixers.DSL;
import com.mojang.datafixers.Typed;
import com.mojang.datafixers.schemas.Schema;
import com.mojang.serialization.Dynamic;
import org.apache.commons.lang3.StringUtils;
import protected.rTC;
import protected.rgP;
import protected.rgb_0;
import protected.rgn_0;
import protected.rpY;
import protected.rwa;
import protected.rww_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class rwe
extends rww_0 {
    public static final Gson class = new GsonBuilder().registerTypeAdapter(rgP.class, (Object)new rwa()).create();

    public rwe(Schema schema, boolean bl2) {
        super(schema, bl2, "BlockEntitySignTextStrictJsonFix", rTC.extends, "Sign");
    }

    private Dynamic<?> class(Dynamic<?> dynamic, String string) {
        String string2 = dynamic.get(string).asString("");
        rgP rgP2 = null;
        if (!"null".equals(string2) && !StringUtils.isEmpty((CharSequence)string2)) {
            if (string2.charAt(0) == '\"' && string2.charAt(string2.length() - 1) == '\"' || string2.charAt(0) == '{' && string2.charAt(string2.length() - 1) == '}') {
                try {
                    rgP2 = rpY.class(rwe.class, string2, rgP.class, true);
                    if (rgP2 == null) {
                        rgP2 = rgn_0.byte;
                    }
                }
                catch (JsonParseException jsonParseException) {
                    // empty catch block
                }
                if (rgP2 == null) {
                    try {
                        rgP2 = rgb_0.class(string2);
                    }
                    catch (JsonParseException jsonParseException) {
                        // empty catch block
                    }
                }
                if (rgP2 == null) {
                    try {
                        rgP2 = rgb_0.break(string2);
                    }
                    catch (JsonParseException jsonParseException) {
                        // empty catch block
                    }
                }
                if (rgP2 == null) {
                    rgP2 = new rgn_0(string2);
                }
            } else {
                rgP2 = new rgn_0(string2);
            }
        } else {
            rgP2 = rgn_0.byte;
        }
        return dynamic.set(string, dynamic.createString(rgb_0.class(rgP2)));
    }

    @Override
    protected Typed<?> class(Typed<?> typed) {
        return typed.update(DSL.remainderFinder(), dynamic -> {
            dynamic = this.class((Dynamic<?>)dynamic, "Text1");
            dynamic = this.class((Dynamic<?>)dynamic, "Text2");
            dynamic = this.class((Dynamic<?>)dynamic, "Text3");
            return this.class((Dynamic<?>)dynamic, "Text4");
        });
    }
}

