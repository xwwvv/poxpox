/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 *  it.unimi.dsi.fastutil.objects.ObjectArraySet
 */
package protected;

import com.google.common.collect.Lists;
import it.unimi.dsi.fastutil.objects.ObjectArraySet;
import java.util.BitSet;
import java.util.List;
import java.util.Set;
import protected.HU;
import protected.le;
import protected.rpr_0;
import protected.rrxx;
import protected.ryo_2;
import protected.yf_2;
import protected.yv_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.yZ
 */
public class yz_2 {
    public static final yz_2 class = new yv_2();
    final rrxx break = new rrxx();
    final Set<HU> byte = new ObjectArraySet();
    boolean protected = true;
    final List<ryo_2> throws = Lists.newArrayList();
    yf_2 case = new yf_2();
    le catch;
    private final BitSet[] private = new BitSet[HU.s.length];

    public boolean byte(HU hU) {
        return this.byte.contains(hU);
    }

    public void class(HU hU, BitSet bitSet) {
        this.private[hU.protected()] = bitSet;
    }

    public boolean class(HU hU) {
        return !this.break.break(hU);
    }

    public boolean class(rpr_0 rpr_02, rpr_0 rpr_03) {
        return this.case.class(rpr_02, rpr_03);
    }

    public boolean class() {
        return this.protected;
    }

    public BitSet break(HU hU) {
        return this.private[hU.protected()];
    }

    public List<ryo_2> break() {
        return this.throws;
    }

    public void throws(HU hU) {
        this.break.class(hU);
    }

    public void protected(HU hU) {
        this.byte.add(hU);
    }
}

