/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 *  com.mojang.brigadier.StringReader
 *  com.mojang.brigadier.arguments.ArgumentType
 *  com.mojang.brigadier.context.CommandContext
 *  com.mojang.brigadier.exceptions.CommandSyntaxException
 *  com.mojang.brigadier.exceptions.DynamicCommandExceptionType
 *  com.mojang.brigadier.suggestion.Suggestions
 *  com.mojang.brigadier.suggestion.SuggestionsBuilder
 */
package protected;

import com.google.common.collect.Lists;
import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.DynamicCommandExceptionType;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.concurrent.CompletableFuture;
import protected.gR;
import protected.gy_0;
import protected.rCi;
import protected.rai_1;
import protected.rgn;
import protected.rlr_0;
import protected.rvl_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.YW
 */
public class yw_0
implements ArgumentType<rai_1> {
    private static final Collection<String> break = Arrays.asList("foo", "foo.bar.baz", "minecraft:foo");
    public static final DynamicCommandExceptionType class = new DynamicCommandExceptionType(object -> new rgn("argument.criteria.invalid", object));

    private yw_0() {
    }

    public static yw_0 class() {
        return new yw_0();
    }

    public <T> String class(rlr_0<T> rlr_02, Object object) {
        return rCi.class(rlr_02, object);
    }

    public rai_1 class(StringReader stringReader) throws CommandSyntaxException {
        int n2 = stringReader.getCursor();
        while (stringReader.canRead() && stringReader.peek() != ' ') {
            stringReader.skip();
        }
        String string = stringReader.getString().substring(n2, stringReader.getCursor());
        return rai_1.class(string).orElseThrow(() -> {
            stringReader.setCursor(n2);
            return yw_0.class.create((Object)string);
        });
    }

    public static rai_1 class(CommandContext<gy_0> commandContext, String string) {
        return (rai_1)commandContext.getArgument(string, rai_1.class);
    }

    public /* synthetic */ Object parse(StringReader stringReader) throws CommandSyntaxException {
        return this.class(stringReader);
    }

    public Collection<String> getExamples() {
        return break;
    }

    public <S> CompletableFuture<Suggestions> listSuggestions(CommandContext<S> commandContext, SuggestionsBuilder suggestionsBuilder) {
        ArrayList arrayList = Lists.newArrayList(rai_1.class.keySet());
        for (rlr_0 rlr_02 : rvl_0.h) {
            for (Object e2 : rlr_02.class()) {
                String string = this.class(rlr_02, e2);
                arrayList.add(string);
            }
        }
        return gR.break(arrayList, suggestionsBuilder);
    }
}

