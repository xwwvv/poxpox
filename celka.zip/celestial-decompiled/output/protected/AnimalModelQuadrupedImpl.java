/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableList
 */
package protected;

import com.google.common.collect.ImmutableList;
import protected.an;
import protected.iq_1;
import protected.rfU;
import protected.tx_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.wB
 */
public class wb_0<T extends an>
extends tx_2<T> {
    protected final iq_1 class;
    protected final iq_1 break;
    protected final iq_1 byte;
    protected final iq_1 protected;
    protected final iq_1 throws;
    protected final iq_1 case;
    protected final iq_1 catch = new iq_1(this);
    protected final iq_1 private;
    protected int implements = 1;

    public wb_0(float f2) {
        super(true, 10.0f, 4.0f);
        this.catch.class("main", -2.5f, -2.0f, -3.0f, 5, 4, 5, f2, 0, 0);
        this.catch.class("nose", -1.5f, 0.0f, -4.0f, 3, 2, 2, f2, 0, 24);
        this.catch.class("ear1", -2.0f, -3.0f, 0.0f, 1, 1, 2, f2, 0, 10);
        this.catch.class("ear2", 1.0f, -3.0f, 0.0f, 1, 1, 2, f2, 6, 10);
        this.catch.class(0.0f, 15.0f, -9.0f);
        this.private = new iq_1(this, 20, 0);
        this.private.class(-2.0f, 3.0f, -8.0f, 4.0f, 16.0f, 6.0f, f2);
        this.private.class(0.0f, 12.0f, -10.0f);
        this.throws = new iq_1(this, 0, 15);
        this.throws.class(-0.5f, 0.0f, 0.0f, 1.0f, 8.0f, 1.0f, f2);
        this.throws.case = 0.9f;
        this.throws.class(0.0f, 15.0f, 8.0f);
        this.case = new iq_1(this, 4, 15);
        this.case.class(-0.5f, 0.0f, 0.0f, 1.0f, 8.0f, 1.0f, f2);
        this.case.class(0.0f, 20.0f, 14.0f);
        this.class = new iq_1(this, 8, 13);
        this.class.class(-1.0f, 0.0f, 1.0f, 2.0f, 6.0f, 2.0f, f2);
        this.class.class(1.1f, 18.0f, 5.0f);
        this.break = new iq_1(this, 8, 13);
        this.break.class(-1.0f, 0.0f, 1.0f, 2.0f, 6.0f, 2.0f, f2);
        this.break.class(-1.1f, 18.0f, 5.0f);
        this.byte = new iq_1(this, 40, 0);
        this.byte.class(-1.0f, 0.0f, 0.0f, 2.0f, 10.0f, 2.0f, f2);
        this.byte.class(1.2f, 14.1f, -5.0f);
        this.protected = new iq_1(this, 40, 0);
        this.protected.class(-1.0f, 0.0f, 0.0f, 2.0f, 10.0f, 2.0f, f2);
        this.protected.class(-1.2f, 14.1f, -5.0f);
    }

    @Override
    public void class(T t2, float f2, float f3, float f4, float f5, float f6) {
        this.catch.case = f6 * ((float)Math.PI / 180);
        this.catch.catch = f5 * ((float)Math.PI / 180);
        if (this.implements != 3) {
            this.private.case = 1.5707964f;
            if (this.implements == 2) {
                this.class.case = rfU.break(f2 * 0.6662f) * f3;
                this.break.case = rfU.break(f2 * 0.6662f + 0.3f) * f3;
                this.byte.case = rfU.break(f2 * 0.6662f + (float)Math.PI + 0.3f) * f3;
                this.protected.case = rfU.break(f2 * 0.6662f + (float)Math.PI) * f3;
                this.case.case = 1.7278761f + 0.31415927f * rfU.break(f2) * f3;
            } else {
                this.class.case = rfU.break(f2 * 0.6662f) * f3;
                this.break.case = rfU.break(f2 * 0.6662f + (float)Math.PI) * f3;
                this.byte.case = rfU.break(f2 * 0.6662f + (float)Math.PI) * f3;
                this.protected.case = rfU.break(f2 * 0.6662f) * f3;
                this.case.case = this.implements == 1 ? 1.7278761f + 0.7853982f * rfU.break(f2) * f3 : 1.7278761f + 0.47123894f * rfU.break(f2) * f3;
            }
        }
    }

    @Override
    public void class(T t2, float f2, float f3, float f4) {
        this.private.protected = 12.0f;
        this.private.throws = -10.0f;
        this.catch.protected = 15.0f;
        this.catch.throws = -9.0f;
        this.throws.protected = 15.0f;
        this.throws.throws = 8.0f;
        this.case.protected = 20.0f;
        this.case.throws = 14.0f;
        this.byte.protected = 14.1f;
        this.byte.throws = -5.0f;
        this.protected.protected = 14.1f;
        this.protected.throws = -5.0f;
        this.class.protected = 18.0f;
        this.class.throws = 5.0f;
        this.break.protected = 18.0f;
        this.break.throws = 5.0f;
        this.throws.case = 0.9f;
        if (((an)t2).x()) {
            this.private.protected += 1.0f;
            this.catch.protected += 2.0f;
            this.throws.protected += 1.0f;
            this.case.protected += -4.0f;
            this.case.throws += 2.0f;
            this.throws.case = 1.5707964f;
            this.case.case = 1.5707964f;
            this.implements = 0;
        } else if (((an)t2).PF()) {
            this.case.protected = this.throws.protected;
            this.case.throws += 2.0f;
            this.throws.case = 1.5707964f;
            this.case.case = 1.5707964f;
            this.implements = 2;
        } else {
            this.implements = 1;
        }
    }

    @Override
    protected Iterable<iq_1> class() {
        return ImmutableList.of((Object)this.catch);
    }

    @Override
    protected Iterable<iq_1> break() {
        return ImmutableList.of((Object)this.private, (Object)this.class, (Object)this.break, (Object)this.byte, (Object)this.protected, (Object)this.throws, (Object)this.case);
    }
}

