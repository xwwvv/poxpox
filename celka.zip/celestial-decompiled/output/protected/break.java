/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableSet
 *  com.mojang.brigadier.ParseResults
 *  com.mojang.brigadier.context.StringRange
 *  com.mojang.brigadier.suggestion.Suggestion
 *  com.mojang.brigadier.suggestion.Suggestions
 */
package protected;

import com.google.common.collect.ImmutableSet;
import com.mojang.brigadier.ParseResults;
import com.mojang.brigadier.context.StringRange;
import com.mojang.brigadier.suggestion.Suggestion;
import com.mojang.brigadier.suggestion.Suggestions;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.function.BiFunction;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.C;
import protected.H;
import protected.V;
import protected.Y;
import protected.an;
import protected.aq_1;
import protected.br_1;
import protected.case;
import protected.cb_1;
import protected.class;
import protected.cq_2;
import protected.cw_2;
import protected.f;
import protected.g;
import protected.gR;
import protected.gm;
import protected.i_0;
import protected.ib_0;
import protected.j;
import protected.l;
import protected.lu_1;
import protected.ml_1;
import protected.q;
import protected.rZD;
import protected.rZR;
import protected.rfH;
import protected.rfj;
import protected.rfz_1;
import protected.rhx_1;
import protected.rjV;
import protected.rrAH;
import protected.rrAZ;
import protected.rrAg;
import protected.rrAl;
import protected.rrAo;
import protected.rrAq;
import protected.rrac_0;
import protected.rrak_0;
import protected.rram_0;
import protected.rran_0;
import protected.rrao_0;
import protected.rraq_0;
import protected.rras_0;
import protected.rrat_0;
import protected.rrax_0;
import protected.rraz_0;
import protected.rrfe_1;
import protected.rrff_1;
import protected.rrfi_1;
import protected.rrfj_1;
import protected.rrfk_1;
import protected.rrfo_1;
import protected.rrfu_1;
import protected.rrfw_1;
import protected.rrfy_1;
import protected.rrla_1;
import protected.rrlc_1;
import protected.rrlc_2;
import protected.rrle_2;
import protected.rrlf_1;
import protected.rrlf_2;
import protected.rrlh_2;
import protected.rrli_2;
import protected.rrlm_1;
import protected.rrlo_2;
import protected.rrlp_1;
import protected.rrls_1;
import protected.rrlu_1;
import protected.rrlu_2;
import protected.rrlv_1;
import protected.rrlv_2;
import protected.rrlx_1;
import protected.rrlx_2;
import protected.rrlz_2;
import protected.rrnb_0;
import protected.rrnc_0;
import protected.rrnd_0;
import protected.rrng_0;
import protected.rrnm_0;
import protected.rrns;
import protected.rrnu_0;
import protected.rrqx_1;
import protected.rrtu;
import protected.rrze_1;
import protected.rum_1;
import protected.rus_2;
import protected.rvc_1;
import protected.st_1;
import protected.t;
import protected.t_0;
import protected.throws;
import protected.vm_1;
import protected.vu_0;
import protected.w;
import protected.xc_0;
import protected.y_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class break
extends Enum<break>
implements rrze_1 {
    private static short[] shortsf9703d96375232b196815afd59d1eb48;
    public static Object[] staticFieldsf9703d96375232b196815afd59d1eb48;
    private static String[] stringsf9703d96375232b196815afd59d1eb48;
    private static byte[] bytesf9703d96375232b196815afd59d1eb48;
    private static boolean[] booleansf9703d96375232b196815afd59d1eb48;

    public void byte() {
        BiFunction<Y, V, j> biFunction = j.break();
        for (case case_ : throws.class().case()) {
            V v = case_.throw().catch() != null && case_.throw().case() != null ? (V)((Object)V.staticFields30e1cd8580ce39faa61be3646b7cc079[shortsf9703d96375232b196815afd59d1eb48[44]]) : (V)((Object)V.staticFields30e1cd8580ce39faa61be3646b7cc079[shortsf9703d96375232b196815afd59d1eb48[45]]);
            j j2 = biFunction.apply((Y)((Object)Y.staticFields22c81230f53b33f2a682b4198db24cc4[shortsf9703d96375232b196815afd59d1eb48[46]]), v);
            case_.s().class(j2);
            ((rrqx_1)rrqx_1.staticFields09f1f28026cd378cb9df490a64ac8f2a[shortsf9703d96375232b196815afd59d1eb48[47]]).finally().class(j2);
            rrtu.protected();
        }
    }

    public void byte(rus_2<?> rus_22, rum_1 rum_12) {
        if (rum_12 != rum_1.CLIENTBOUND) {
            return;
        }
        for (case case_ : throws.class().case()) {
            if (case_.throw().catch() == null || ((aq_1)case_.throw().catch().break[shortsf9703d96375232b196815afd59d1eb48[53]]).class() != ((aq_1)((cb_1)break.import.class[break.shortsf9703d96375232b196815afd59d1eb48[54]]).break[shortsf9703d96375232b196815afd59d1eb48[55]]).class()) continue;
            case_.s().break(new y_0(((aq_1)((cb_1)break.import.class[break.shortsf9703d96375232b196815afd59d1eb48[56]]).break[shortsf9703d96375232b196815afd59d1eb48[57]]).class(), (Y)((Object)Y.staticFields22c81230f53b33f2a682b4198db24cc4[shortsf9703d96375232b196815afd59d1eb48[58]]), rus_22));
        }
    }

    static {
        break.ntfClinit();
    }

    public static break[] values() {
        return (break[])((break[])staticFieldsf9703d96375232b196815afd59d1eb48[shortsf9703d96375232b196815afd59d1eb48[0]]).clone();
    }

    public static break valueOf(String string) {
        return Enum.valueOf(break.class, string);
    }

    public void class(rrlc_1 rrlc_12) {
        for (case case_ : throws.class().case()) {
            case_.s().class(rrlc_12);
        }
    }

    public void class(rrnm_0 rrnm_02) {
        for (case case_ : throws.class().case()) {
            case_.s().class(rrnm_02);
        }
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0x359D7C24900A7B6EL;
    }

    public void class(rrlm_1 rrlm_12) {
        for (case case_ : throws.class().case()) {
            case_.s().class(rrlm_12);
        }
    }

    public void class(rrfy_1 rrfy_12) {
        for (case case_ : throws.class().case()) {
            case_.s().class(rrfy_12);
        }
    }

    public void class(rvc_1 rvc_12) {
        if (!((Boolean)class.instanceof().M.class[shortsf9703d96375232b196815afd59d1eb48[25]]).booleanValue()) {
            return;
        }
        rfj[] rfjArray = new rfj[booleansf9703d96375232b196815afd59d1eb48[4]];
        rvc_12.class((rfH rfH2, xc_0 xc_02) -> {
            if (((ImmutableSet)st_1.class[shortsf9703d96375232b196815afd59d1eb48[79]]).contains((Object)xc_02.break())) {
                rfjArray[break.booleansf9703d96375232b196815afd59d1eb48[17]] = new rfj((rfH)rfH2);
            }
        });
        if (rfjArray[booleansf9703d96375232b196815afd59d1eb48[5]] == null) {
            return;
        }
        for (case case_ : throws.class().case()) {
            cb_1 cb_12 = case_.throw().catch();
            if (cb_12 == null || (aq_1)cb_12.break[shortsf9703d96375232b196815afd59d1eb48[26]] != (aq_1)((cb_1)break.import.class[break.shortsf9703d96375232b196815afd59d1eb48[27]]).break[shortsf9703d96375232b196815afd59d1eb48[28]]) continue;
            l l2 = new l((Y)((Object)Y.staticFields22c81230f53b33f2a682b4198db24cc4[shortsf9703d96375232b196815afd59d1eb48[29]]), (H)((Object)H.staticFields1fafa9bf76ed3352892023b88da3732d[shortsf9703d96375232b196815afd59d1eb48[30]]), rfjArray[break.booleansf9703d96375232b196815afd59d1eb48[6]].break, rfjArray[break.booleansf9703d96375232b196815afd59d1eb48[7]].byte);
            case_.s().class(l2);
        }
    }

    public void class(rrle_2 rrle_22) {
        for (case case_ : throws.class().case()) {
            case_.s().class(rrle_22);
        }
    }

    public void class(rrlf_2 rrlf_22) {
        for (case case_ : throws.class().case()) {
            case_.s().class(rrlf_22);
        }
    }

    public void class(rrlc_2 rrlc_22) {
        for (case case_ : throws.class().case()) {
            case_.s().class(rrlc_22);
        }
    }

    public void class(rrAq rrAq2) {
        for (case case_ : throws.class().case()) {
            case_.s().class(rrAq2);
        }
    }

    public void class(rraz_0 rraz_02) {
        case case_ = throws.class().private();
        if (case_ != null) {
            case_.s().class(rraz_02);
        }
    }

    public void class(rrnb_0 rrnb_02) {
        for (case case_ : throws.class().case()) {
            case_.s().class(rrnb_02);
        }
    }

    public void class(rrnd_0 rrnd_02) {
        for (case case_ : throws.class().case()) {
            case_.s().class(rrnd_02);
        }
    }

    public void class(rrlf_1 rrlf_12) {
        for (case case_ : throws.class().case()) {
            case_.s().class(rrlf_12);
        }
    }

    public static String class(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{-43, 25, 19, -8, 69, -62, -79, 101}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    public void class(rrAH rrAH2) {
        for (case case_ : throws.class().case()) {
            case_.s().class(rrAH2);
        }
    }

    public void class(rZD rZD2) {
        for (case case_ : throws.class().case()) {
            cb_1 cb_12 = case_.throw().catch();
            if (cb_12 == null || (aq_1)cb_12.break[shortsf9703d96375232b196815afd59d1eb48[2]] != (aq_1)((cb_1)break.import.class[break.shortsf9703d96375232b196815afd59d1eb48[3]]).break[shortsf9703d96375232b196815afd59d1eb48[4]]) continue;
            l l2 = new l((Y)((Object)Y.staticFields22c81230f53b33f2a682b4198db24cc4[shortsf9703d96375232b196815afd59d1eb48[5]]), rZD2.case() ? (H)((Object)H.staticFields1fafa9bf76ed3352892023b88da3732d[shortsf9703d96375232b196815afd59d1eb48[6]]) : (H)((Object)H.staticFields1fafa9bf76ed3352892023b88da3732d[shortsf9703d96375232b196815afd59d1eb48[7]]), rZD2.byte(), rZD2.protected());
            case_.s().class(l2);
        }
    }

    public void class(rrfu_1 rrfu_12) {
        for (case case_ : throws.class().case()) {
            case_.s().class(rrfu_12);
        }
    }

    public void class(rrlu_2 rrlu_22) {
        for (case case_ : throws.class().case()) {
            case_.s().class(rrlu_22);
        }
    }

    public void class(rrAg rrAg2) {
        for (case case_ : throws.class().case()) {
            case_.s().class(rrAg2);
        }
    }

    public boolean class(rhx_1 rhx_12) {
        case case_ = throws.class().private();
        if (case_ == null) {
            return rhx_12.byte;
        }
        return !case_.this().catch() && rhx_12.byte ? booleansf9703d96375232b196815afd59d1eb48[0] : booleansf9703d96375232b196815afd59d1eb48[1];
    }

    public void class(rraq_0 rraq_02) {
        for (case case_ : throws.class().case()) {
            case_.s().class(rraq_02);
        }
    }

    public void class(rrli_2 rrli_22) {
        for (case case_ : throws.class().case()) {
            case_.s().class(rrli_22);
        }
    }

    public void class(rrfj_1 rrfj_12) {
        for (case case_ : throws.class().case()) {
            case_.s().class(rrfj_12);
        }
    }

    public void class(rZR rZR2) {
        if (!((Boolean)class.instanceof().M.class[shortsf9703d96375232b196815afd59d1eb48[18]]).booleanValue()) {
            return;
        }
        if (!((ImmutableSet)st_1.class[shortsf9703d96375232b196815afd59d1eb48[19]]).contains((Object)rZR2.break().break())) {
            return;
        }
        for (case case_ : throws.class().case()) {
            cb_1 cb_12 = case_.throw().catch();
            if (cb_12 == null || (aq_1)cb_12.break[shortsf9703d96375232b196815afd59d1eb48[20]] != (aq_1)((cb_1)break.import.class[break.shortsf9703d96375232b196815afd59d1eb48[21]]).break[shortsf9703d96375232b196815afd59d1eb48[22]]) continue;
            l l2 = new l((Y)((Object)Y.staticFields22c81230f53b33f2a682b4198db24cc4[shortsf9703d96375232b196815afd59d1eb48[23]]), (H)((Object)H.staticFields1fafa9bf76ed3352892023b88da3732d[shortsf9703d96375232b196815afd59d1eb48[24]]), rZR2.byte().b_() >> bytesf9703d96375232b196815afd59d1eb48[0], rZR2.byte().d_() >> bytesf9703d96375232b196815afd59d1eb48[1]);
            case_.s().class(l2);
        }
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0xA19CE69;
    }

    public boolean class(vu_0 vu_02) {
        case case_ = throws.class().private();
        if (case_ == null) {
            return vu_02.protected();
        }
        i_0 i_02 = ((rrqx_1)rrqx_1.staticFields09f1f28026cd378cb9df490a64ac8f2a[shortsf9703d96375232b196815afd59d1eb48[1]]).finally().class(i_0.break(null));
        case_.s().class(i_02);
        if (i_02.class() != null) {
            return i_02.class();
        }
        if (case_ != throws.class().break()) {
            return booleansf9703d96375232b196815afd59d1eb48[2];
        }
        return vu_02.protected();
    }

    public void class(rran_0 rran_02) {
        for (case case_ : throws.class().case()) {
            case_.s().class(rran_02);
        }
    }

    public void class(q q2) {
        case case_ = throws.class().private();
        if (case_ != null) {
            case_.s().class(q2);
        }
    }

    public void class(rrns rrns2) {
        case case_ = throws.class().private();
        if (case_ != null) {
            case_.s().class(rrns2);
        }
    }

    public void class(ib_0 ib_02) {
        case case_;
        if (cb_1.class.isInstance(ib_02) && (case_ = throws.class().private()) != null) {
            t t2 = ((t)t.class[shortsf9703d96375232b196815afd59d1eb48[42]]).break((w)((Object)w.staticFieldsa114f317008a3fe78339d2b3c5e6fe39[shortsf9703d96375232b196815afd59d1eb48[43]]));
            case_.s().class(t2);
        }
    }

    public void class(rrlx_2 rrlx_22) {
        for (case case_ : throws.class().case()) {
            case_.s().class(rrlx_22);
        }
    }

    public void class(rrao_0 rrao_02) {
        for (case case_ : throws.class().case()) {
            case_.s().class(rrao_02);
        }
    }

    public void class(rrlp_1 rrlp_12) {
        for (case case_ : throws.class().case()) {
            case_.s().class(rrlp_12);
        }
    }

    public void class(ml_1 ml_12, float f2, rjV rjV2) {
        for (case case_ : throws.class().case()) {
            case_.s().class(new t_0(f2, ml_12, rjV2));
        }
    }

    public void class(rrak_0 rrak_02) {
        for (case case_ : throws.class().case()) {
            case_.s().class(rrak_02);
        }
    }

    public void class(rrlx_1 rrlx_12) {
        for (case case_ : throws.class().case()) {
            case_.s().class(rrlx_12);
        }
    }

    public void class(rrlo_2 rrlo_22) {
        for (case case_ : throws.class().case()) {
            case_.s().class(rrlo_22);
        }
    }

    public void class(rrfi_1 rrfi_12) {
        for (case case_ : throws.class().case()) {
            case_.s().class(rrfi_12);
        }
    }

    public void class(rus_2<?> rus_22, rum_1 rum_12) {
        if (rum_12 != rum_1.CLIENTBOUND) {
            return;
        }
        for (case case_ : throws.class().case()) {
            if (case_.throw().catch() == null || ((aq_1)case_.throw().catch().break[shortsf9703d96375232b196815afd59d1eb48[59]]).class() != ((aq_1)((cb_1)break.import.class[break.shortsf9703d96375232b196815afd59d1eb48[60]]).break[shortsf9703d96375232b196815afd59d1eb48[61]]).class()) continue;
            case_.s().break(new y_0(((aq_1)((cb_1)break.import.class[break.shortsf9703d96375232b196815afd59d1eb48[62]]).break[shortsf9703d96375232b196815afd59d1eb48[63]]).class(), (Y)((Object)Y.staticFields22c81230f53b33f2a682b4198db24cc4[shortsf9703d96375232b196815afd59d1eb48[64]]), rus_22));
        }
    }

    public void class(rrfe_1 rrfe_12) {
        for (case case_ : throws.class().case()) {
            case_.s().class(rrfe_12);
        }
    }

    public void class() {
        for (case case_ : throws.class().case()) {
            cb_1 cb_12 = case_.throw().catch();
            if (cb_12 == null || (aq_1)cb_12.break[shortsf9703d96375232b196815afd59d1eb48[31]] != (aq_1)((cb_1)break.import.class[break.shortsf9703d96375232b196815afd59d1eb48[32]]).break[shortsf9703d96375232b196815afd59d1eb48[33]]) continue;
            case_.s().volatile();
        }
    }

    public void class(rrAZ rrAZ2) {
        for (case case_ : throws.class().case()) {
            case_.s().class(rrAZ2);
        }
    }

    public void class(t t2) {
        case case_ = throws.class().private();
        if (case_ != null) {
            case_.s().class(t2);
        }
    }

    public void class(rras_0 rras_02) {
        for (case case_ : throws.class().case()) {
            case_.s().class(rras_02);
        }
    }

    public void class(rrfk_1 rrfk_12) {
        for (case case_ : throws.class().case()) {
            case_.s().class(rrfk_12);
        }
    }

    public void class(rrAo rrAo2) {
        for (case case_ : throws.class().case()) {
            case_.s().class(rrAo2);
        }
    }

    public void class(rrac_0 rrac_02) {
        for (case case_ : throws.class().case()) {
            case_.s().class(rrac_02);
        }
    }

    public boolean class(vm_1 vm_12) {
        return throws.class().break().this().catch() && (cb_1)break.import.class[shortsf9703d96375232b196815afd59d1eb48[52]] != null || vm_12.continue ? booleansf9703d96375232b196815afd59d1eb48[15] : booleansf9703d96375232b196815afd59d1eb48[16];
    }

    public void class(rrlv_2 rrlv_22) {
        for (case case_ : throws.class().case()) {
            case_.s().class(rrlv_22);
        }
    }

    public boolean class(cw_2 cw_22) {
        lu_1 lu_12 = cw_22.byte();
        String string2 = lu_12.private();
        String string3 = string2.substring(booleansf9703d96375232b196815afd59d1eb48[8], Math.min(string2.length(), lu_12.final()));
        f f2 = new f(string3);
        throws.class().break().s().class(f2);
        if (f2.byte()) {
            return booleansf9703d96375232b196815afd59d1eb48[9];
        }
        if ((String[])f2.class[shortsf9703d96375232b196815afd59d1eb48[34]] != null) {
            f2.break();
            cw_22.class((ParseResults<gR>)null);
            if (cw_22.case()) {
                return booleansf9703d96375232b196815afd59d1eb48[10];
            }
            lu_12.byte(null);
            cw_22.class((cq_2)null);
            cw_22.throws().clear();
            if (((String[])f2.class[shortsf9703d96375232b196815afd59d1eb48[35]]).length == 0) {
                cw_22.class(Suggestions.empty());
            } else {
                StringRange stringRange = StringRange.between((int)(string3.lastIndexOf(stringsf9703d96375232b196815afd59d1eb48[0]) + booleansf9703d96375232b196815afd59d1eb48[11]), (int)string3.length());
                List list = Stream.of((String[])f2.class[shortsf9703d96375232b196815afd59d1eb48[36]]).map(string -> new Suggestion(stringRange, string)).collect(Collectors.toList());
                Suggestions suggestions = new Suggestions(stringRange, list);
                cw_22.class(new CompletableFuture<Suggestions>());
                cw_22.protected().complete(suggestions);
            }
            cw_22.break(booleansf9703d96375232b196815afd59d1eb48[12]);
            return booleansf9703d96375232b196815afd59d1eb48[13];
        }
        return booleansf9703d96375232b196815afd59d1eb48[14];
    }

    public void class(rrlu_1 rrlu_12) {
        for (case case_ : throws.class().case()) {
            case_.s().class(rrlu_12);
        }
    }

    public void class(an an2) {
        Float f2 = Float.valueOf(((Float)an2.throws[shortsf9703d96375232b196815afd59d1eb48[37]]).floatValue());
        an2.throws[break.shortsf9703d96375232b196815afd59d1eb48[38]] = f2;
        if (!cb_1.class.isInstance(an2) || throws.class().private() == null) {
            return;
        }
        t t2 = ((t)t.class[shortsf9703d96375232b196815afd59d1eb48[39]]).break((w)((Object)w.staticFieldsa114f317008a3fe78339d2b3c5e6fe39[shortsf9703d96375232b196815afd59d1eb48[40]]));
        Float f3 = Float.valueOf(t2.class().throws());
        an2.throws[break.shortsf9703d96375232b196815afd59d1eb48[41]] = f3;
    }

    public void class(rrfo_1 rrfo_12) {
        for (case case_ : throws.class().case()) {
            case_.s().class(rrfo_12);
        }
    }

    public void class(rrlz_2 rrlz_22) {
        for (case case_ : throws.class().case()) {
            case_.s().class(rrlz_22);
        }
    }

    public void class(rrat_0 rrat_02) {
        for (case case_ : throws.class().case()) {
            case_.s().class(rrat_02);
        }
    }

    public void class(rrlv_1 rrlv_12) {
        for (case case_ : throws.class().case()) {
            case_.s().class(rrlv_12);
        }
    }

    public void class(rrls_1 rrls_12) {
        if ((cb_1)break.import.class[shortsf9703d96375232b196815afd59d1eb48[77]] == null || (gm)break.import.class[shortsf9703d96375232b196815afd59d1eb48[78]] == null) {
            return;
        }
        for (case case_ : throws.class().case()) {
            case_.s().class(rrls_12);
        }
    }

    public void class(rrnc_0 rrnc_02) {
        for (case case_ : throws.class().case()) {
            case_.s().class(rrnc_02);
        }
    }

    public void class(rrax_0 rrax_02) {
        case case_ = throws.class().private();
        if (case_ != null) {
            case_.s().class(rrax_02);
        }
    }

    public void class(gm gm2) {
        throws.class().break().s().class(new g(gm2, (Y)((Object)Y.staticFields22c81230f53b33f2a682b4198db24cc4[shortsf9703d96375232b196815afd59d1eb48[51]])));
    }

    public void class(rram_0 rram_02) {
        for (case case_ : throws.class().case()) {
            case_.s().class(rram_02);
        }
    }

    public void class(rrng_0 rrng_02) {
        for (case case_ : throws.class().case()) {
            case_.s().class(rrng_02);
        }
    }

    public void class(rfz_1 rfz_12) {
        for (case case_ : throws.class().case()) {
            cb_1 cb_12 = case_.throw().catch();
            if (cb_12 == null || (aq_1)cb_12.break[shortsf9703d96375232b196815afd59d1eb48[8]] != (aq_1)((cb_1)break.import.class[break.shortsf9703d96375232b196815afd59d1eb48[9]]).break[shortsf9703d96375232b196815afd59d1eb48[10]]) continue;
            l l2 = new l((Y)((Object)Y.staticFields22c81230f53b33f2a682b4198db24cc4[shortsf9703d96375232b196815afd59d1eb48[11]]), (H)((Object)H.staticFields1fafa9bf76ed3352892023b88da3732d[shortsf9703d96375232b196815afd59d1eb48[12]]), rfz_12.break(), rfz_12.byte());
            case_.s().class(l2);
        }
    }

    public void class(rrla_1 rrla_12) {
        for (case case_ : throws.class().case()) {
            case_.s().class(rrla_12);
        }
    }

    public void class(rrlh_2 rrlh_22) {
        for (case case_ : throws.class().case()) {
            case_.s().class(rrlh_22);
        }
    }

    public void class(rrAl rrAl2) {
        for (case case_ : throws.class().case()) {
            case_.s().class(rrAl2);
        }
    }

    public void class(rrff_1 rrff_12) {
        for (case case_ : throws.class().case()) {
            case_.s().class(rrff_12);
        }
    }

    public void class(rrfw_1 rrfw_12) {
        for (case case_ : throws.class().case()) {
            case_.s().class(rrfw_12);
        }
    }

    public void break(rus_2<?> rus_22, rum_1 rum_12) {
        if (rum_12 != rum_1.CLIENTBOUND) {
            return;
        }
        for (case case_ : throws.class().case()) {
            if (case_.throw().catch() == null || ((aq_1)case_.throw().catch().break[shortsf9703d96375232b196815afd59d1eb48[65]]).class() != ((aq_1)((cb_1)break.import.class[break.shortsf9703d96375232b196815afd59d1eb48[66]]).break[shortsf9703d96375232b196815afd59d1eb48[67]]).class()) continue;
            case_.s().class(new y_0(((aq_1)((cb_1)break.import.class[break.shortsf9703d96375232b196815afd59d1eb48[68]]).break[shortsf9703d96375232b196815afd59d1eb48[69]]).class(), (Y)((Object)Y.staticFields22c81230f53b33f2a682b4198db24cc4[shortsf9703d96375232b196815afd59d1eb48[70]]), rus_22));
        }
    }

    public void break() {
        case case_ = throws.class().private();
        if (case_ != null) {
            ((br_1)case_.catch()).throws();
        }
    }

    public boolean break(String string) {
        C c = new C(string);
        case case_ = throws.class().private();
        if (case_ == null) {
            return booleansf9703d96375232b196815afd59d1eb48[3];
        }
        case_.s().class(c);
        return c.byte();
    }

    public void break(gm gm2) {
        if ((gm)break.import.class[shortsf9703d96375232b196815afd59d1eb48[48]] == null && gm2 == null) {
            return;
        }
        throws.class().break().s().class(new g(gm2, (Y)((Object)Y.staticFields22c81230f53b33f2a682b4198db24cc4[shortsf9703d96375232b196815afd59d1eb48[49]])));
        ((rrqx_1)rrqx_1.staticFields09f1f28026cd378cb9df490a64ac8f2a[shortsf9703d96375232b196815afd59d1eb48[50]]).finally().class(rrnu_0.class(gm2));
    }

    public void break(rfz_1 rfz_12) {
        for (case case_ : throws.class().case()) {
            cb_1 cb_12 = case_.throw().catch();
            if (cb_12 == null || (aq_1)cb_12.break[shortsf9703d96375232b196815afd59d1eb48[13]] != (aq_1)((cb_1)break.import.class[break.shortsf9703d96375232b196815afd59d1eb48[14]]).break[shortsf9703d96375232b196815afd59d1eb48[15]]) continue;
            l l2 = new l((Y)((Object)Y.staticFields22c81230f53b33f2a682b4198db24cc4[shortsf9703d96375232b196815afd59d1eb48[16]]), (H)((Object)H.staticFields1fafa9bf76ed3352892023b88da3732d[shortsf9703d96375232b196815afd59d1eb48[17]]), rfz_12.break(), rfz_12.byte());
            case_.s().class(l2);
        }
    }

    private static void throws() {
        Object[] objectArray;
        objectArray = new Object[]{new break(), new break[]{(break)objectArray[0]}};
        staticFieldsf9703d96375232b196815afd59d1eb48 = objectArray;
    }

    private static /* synthetic */ void ntfClinit() {
        break.implements();
        break.private();
        break.catch();
        break.protected();
        break.throws();
    }

    private static void catch() {
        short[] sArray = new short[81];
        sArray[0] = 1;
        sArray[3] = 57;
        sArray[5] = 1;
        sArray[6] = 2;
        sArray[7] = 3;
        sArray[9] = 57;
        sArray[12] = 1;
        sArray[14] = 57;
        sArray[16] = 1;
        sArray[17] = 1;
        sArray[21] = 57;
        sArray[23] = 1;
        sArray[24] = 2;
        sArray[27] = 57;
        sArray[29] = 1;
        sArray[30] = 2;
        sArray[32] = 57;
        sArray[34] = 1;
        sArray[35] = 1;
        sArray[36] = 1;
        sArray[37] = 15;
        sArray[38] = 72;
        sArray[41] = 15;
        sArray[45] = 1;
        sArray[48] = 56;
        sArray[51] = 1;
        sArray[52] = 57;
        sArray[54] = 57;
        sArray[56] = 57;
        sArray[60] = 57;
        sArray[62] = 57;
        sArray[64] = 1;
        sArray[66] = 57;
        sArray[68] = 57;
        sArray[72] = 57;
        sArray[74] = 57;
        sArray[76] = 1;
        sArray[77] = 57;
        sArray[78] = 56;
        shortsf9703d96375232b196815afd59d1eb48 = sArray;
    }

    private static /* synthetic */ break[] case() {
        break[] breakArray = new break[booleansf9703d96375232b196815afd59d1eb48[18]];
        breakArray[break.booleansf9703d96375232b196815afd59d1eb48[19]] = (break)staticFieldsf9703d96375232b196815afd59d1eb48[shortsf9703d96375232b196815afd59d1eb48[80]];
        return breakArray;
    }

    private static void implements() {
        boolean[] blArray = new boolean[23];
        blArray[0] = true;
        blArray[4] = true;
        blArray[11] = true;
        blArray[12] = true;
        blArray[14] = true;
        blArray[15] = true;
        blArray[18] = true;
        blArray[22] = true;
        booleansf9703d96375232b196815afd59d1eb48 = blArray;
    }

    private static void protected() {
        bytesf9703d96375232b196815afd59d1eb48 = new byte[]{4, 4, 2};
    }

    public void protected(rus_2<?> rus_22, rum_1 rum_12) {
        if (rum_12 != rum_1.CLIENTBOUND) {
            return;
        }
        for (case case_ : throws.class().case()) {
            if (case_.throw().catch() == null || ((aq_1)case_.throw().catch().break[shortsf9703d96375232b196815afd59d1eb48[71]]).class() != ((aq_1)((cb_1)break.import.class[break.shortsf9703d96375232b196815afd59d1eb48[72]]).break[shortsf9703d96375232b196815afd59d1eb48[73]]).class()) continue;
            case_.s().class(new y_0(((aq_1)((cb_1)break.import.class[break.shortsf9703d96375232b196815afd59d1eb48[74]]).break[shortsf9703d96375232b196815afd59d1eb48[75]]).class(), (Y)((Object)Y.staticFields22c81230f53b33f2a682b4198db24cc4[shortsf9703d96375232b196815afd59d1eb48[76]]), rus_22));
        }
    }

    private static void private() {
        stringsf9703d96375232b196815afd59d1eb48 = new String[]{new String(" "), new String("INSTANCE")};
    }
}

