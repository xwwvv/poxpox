/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableList
 *  com.google.common.collect.Maps
 *  com.mojang.datafixers.util.Function3
 *  com.mojang.datafixers.util.Pair
 */
package protected;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.Maps;
import com.mojang.datafixers.util.Function3;
import com.mojang.datafixers.util.Pair;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Supplier;
import protected.rYD;
import protected.rYl;
import protected.rqo_0;
import protected.rvl_0;
import protected.ryg_0;
import protected.rym_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class rYa {
    static final Map<rqo_0, rYa> break = Maps.newHashMap();
    public static final rYa class = new rYa(new rqo_0("nether"), (Function3<rYa, rvl_0<ryg_0>, Long, rYD>)((Function3)(rYa2, rvl_02, l2) -> new rYD((long)l2, (List<Pair<rym_0, Supplier<ryg_0>>>)ImmutableList.of((Object)Pair.of((Object)new rym_0(0.0f, 0.0f, 0.0f, 0.0f, 0.0f), () -> rvl_02.byte(rYl.implements)), (Object)Pair.of((Object)new rym_0(0.0f, -0.5f, 0.0f, 0.0f, 0.0f), () -> rvl_02.byte(rYl.C)), (Object)Pair.of((Object)new rym_0(0.4f, 0.0f, 0.0f, 0.0f, 0.0f), () -> rvl_02.byte(rYl.l)), (Object)Pair.of((Object)new rym_0(0.0f, 0.5f, 0.0f, 0.0f, 0.375f), () -> rvl_02.byte(rYl.H)), (Object)Pair.of((Object)new rym_0(-0.5f, 0.0f, 0.0f, 0.0f, 0.175f), () -> rvl_02.byte(rYl.y))), Optional.of(Pair.of((Object)rvl_02, (Object)rYa2)))));
    final rqo_0 byte;
    private final Function3<rYa, rvl_0<ryg_0>, Long, rYD> protected;

    public rYa(rqo_0 rqo_02, Function3<rYa, rvl_0<ryg_0>, Long, rYD> function3) {
        this.byte = rqo_02;
        this.protected = function3;
        break.put(rqo_02, this);
    }

    public rYD class(rvl_0<ryg_0> rvl_02, long l2) {
        return (rYD)this.protected.apply((Object)this, rvl_02, (Object)l2);
    }
}

