/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.C;
import protected.Y;
import protected.class;
import protected.pv_2;
import protected.q;
import protected.rrAl;
import protected.rrHe;
import protected.rrfi_2;
import protected.rrfk_1;
import protected.rrfp;
import protected.rrfq;
import protected.rrfu_0;
import protected.rrfw_1;
import protected.rrqx_1;
import protected.rrtd_0;
import protected.rrth_0;
import protected.rrze_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.BJ
 */
public class bj_1
extends pv_2
implements rrze_1 {
    private static short[] byte;
    private static float[] protected;
    private static String[] throws;
    private static byte[] case;
    private static boolean[] catch;
    public Object[] break;

    private static void byte() {
        short[] sArray = new short[22];
        sArray[2] = 1;
        sArray[6] = 5000;
        sArray[8] = 1;
        sArray[10] = 1;
        sArray[11] = 1;
        sArray[16] = 1;
        sArray[18] = 1;
        sArray[19] = 1;
        byte = sArray;
    }

    public bj_1(class clazz) {
        super(clazz);
        this.break();
    }

    static {
        bj_1.ntfClinit();
    }

    @Override
    public void class(rrfw_1 rrfw_12) {
        this.break();
        if (rrfw_12.class() == (rrfi_2)((Object)rrfi_2.staticFields7eee503931553d5586d91adc0f9df349[byte[11]])) {
            Boolean bl2 = catch[3];
            this.break[bj_1.byte[12]] = bl2;
        } else if (rrfw_12.class() == (rrfi_2)((Object)rrfi_2.staticFields7eee503931553d5586d91adc0f9df349[byte[13]])) {
            Boolean bl3 = catch[4];
            this.break[bj_1.byte[14]] = bl3;
        }
    }

    private static void class() {
        throws = new String[]{new String("/hub")};
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0xF9C7F677;
    }

    @Override
    public void class(C c) {
        this.break();
        String string = c.class();
        if (string.startsWith(throws[0])) {
            Boolean bl2 = catch[5];
            this.break[bj_1.byte[15]] = bl2;
            Boolean bl3 = catch[6];
            this.break[bj_1.byte[16]] = bl3;
        }
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0x639307F9165EC89FL;
    }

    @Override
    public void class(rrfk_1 rrfk_12) {
        this.break();
        Boolean bl2 = catch[7];
        this.break[bj_1.byte[17]] = bl2;
        Boolean bl3 = catch[8];
        this.break[bj_1.byte[18]] = bl3;
    }

    @Override
    public void class(q q2) {
        this.break();
        if (q2.class() == (Y)((Object)Y.staticFields22c81230f53b33f2a682b4198db24cc4[byte[0]])) {
            if (!this.protected()) {
                return;
            }
            if (((Boolean)this.break[byte[1]]).booleanValue() && ((Boolean)this.break[byte[2]]).booleanValue()) {
                rrHe rrHe2 = ((rrqx_1)rrqx_1.staticFields09f1f28026cd378cb9df490a64ac8f2a[byte[3]]).private().R();
                String string = "\u041d\u0430\u043f\u0438\u0448\u0438\u0442\u0435 '" + (String)protected.class.instanceof().protected.class[byte[4]] + "rct' \u0447\u0442\u043e\u0431\u044b \u0441\u0431\u0440\u043e\u0441\u0438\u0442\u044c \u0444\u043b\u0430\u0433\u0438 \u0430\u043d\u0442\u0438\u0447\u0438\u0442\u0430";
                ((rrth_0)rrth_0.staticFields39e3fc1d50923a0b997a92f976964031[byte[5]]).class(new rrtd_0(rrHe2.final(), string, (int)byte[6]));
                rrfu_0.byte(string);
                Boolean bl2 = catch[0];
                this.break[bj_1.byte[7]] = bl2;
                Boolean bl3 = catch[1];
                this.break[bj_1.byte[8]] = bl3;
            }
        }
    }

    @Override
    public void class(rrAl rrAl2) {
        this.break();
        if (((Boolean)this.break[byte[9]]).booleanValue() && rrAl2.class() > protected[0]) {
            Boolean bl2 = catch[2];
            this.break[bj_1.byte[10]] = bl2;
        }
    }

    public static String break(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{-61, -118, 61, 118, -70, 92, -101, -18}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    private void break() {
        if (this.break == null) {
            Object[] objectArray = this.break = new Object[case[0]];
            objectArray[bj_1.catch[12]] = catch[13];
            objectArray[bj_1.catch[14]] = catch[15];
        }
    }

    private static void throws() {
        boolean[] blArray = new boolean[16];
        blArray[2] = true;
        blArray[3] = true;
        blArray[11] = true;
        blArray[14] = true;
        catch = blArray;
    }

    private static /* synthetic */ void ntfClinit() {
        bj_1.throws();
        bj_1.class();
        bj_1.byte();
        bj_1.catch();
        bj_1.case();
    }

    private static void catch() {
        protected = new float[]{10.0f};
    }

    private static void case() {
        case = new byte[]{2};
    }

    private boolean protected() {
        if ((rrfq)((Object)rrfp.class[byte[19]]) != (rrfq)((Object)rrfq.staticFields8f8c034c8eef39ccbbc33e665d937d16[byte[20]])) {
            return catch[9];
        }
        if (!((rrqx_1)rrqx_1.staticFields09f1f28026cd378cb9df490a64ac8f2a[byte[21]]).private().R().aJ_()) {
            return catch[10];
        }
        return catch[11];
    }
}

