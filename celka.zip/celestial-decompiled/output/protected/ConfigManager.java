/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.stream.Stream;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.import;
import protected.su_1;
import protected.w_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.sE
 */
public class se_0
implements import {
    private static boolean[] break;
    private static byte[] byte;
    private static short[] protected;
    public Object[] class;

    @Override
    public String byte() {
        return (String)this.class[protected[5]];
    }

    @Override
    public <T> T byte(Class<T> clazz) throws w_0 {
        return ((su_1)su_1.staticFields60242b15623d3e12b4eaac026de79971[protected[6]]).class(clazz, this);
    }

    public se_0(int n2, String string, String string2) {
        this.protected();
        Integer n3 = n2;
        this.class[se_0.protected[0]] = n3;
        String string3 = string;
        this.class[se_0.protected[1]] = string3;
        String string4 = string2;
        this.class[se_0.protected[2]] = string4;
    }

    static {
        se_0.ntfClinit();
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0xB3B3C76D;
    }

    @Override
    public <T, S> boolean class(Class<T> clazz, Class<S> clazz2, S s2) {
        try {
            this.break(clazz, clazz2, s2);
            return break[2];
        }
        catch (Throwable throwable) {
            return break[3];
        }
    }

    @Override
    public int class() {
        return (Integer)this.class[protected[3]];
    }

    public static String class(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{-15, -1, -7, 75, 95, 0, 27, -61}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0xC044D426D82D9D23L;
    }

    @Override
    public <T> boolean class(Class<T> clazz) {
        try {
            this.byte(clazz);
            return break[0];
        }
        catch (Throwable throwable) {
            return break[1];
        }
    }

    @Override
    public String break() {
        return (String)this.class[protected[4]];
    }

    @Override
    public <T, S> T break(Class<T> clazz, Class<S> clazz2, S s2) throws w_0 {
        return ((su_1)su_1.staticFields60242b15623d3e12b4eaac026de79971[protected[7]]).class(clazz, clazz2, this, s2);
    }

    @Override
    public <E extends Enum<?>> E break(Class<E> clazz) throws w_0 {
        return (E)Stream.of((Enum[])clazz.getEnumConstants()).filter(enum_ -> enum_.name().equalsIgnoreCase((String)this.class[protected[8]])).findFirst().orElseThrow(() -> new w_0((import)this, clazz.getSimpleName()));
    }

    private static void throws() {
        boolean[] blArray = new boolean[6];
        blArray[0] = true;
        blArray[2] = true;
        break = blArray;
    }

    private static /* synthetic */ void ntfClinit() {
        se_0.throws();
        se_0.catch();
        se_0.case();
    }

    private static void catch() {
        short[] sArray = new short[9];
        sArray[1] = 1;
        sArray[2] = 2;
        sArray[4] = 1;
        sArray[5] = 2;
        sArray[8] = 1;
        protected = sArray;
    }

    private static void case() {
        byte = new byte[]{3};
    }

    private void protected() {
        if (this.class == null) {
            Object[] objectArray = this.class = new Object[byte[0]];
            objectArray[se_0.break[4]] = break[5];
        }
    }
}

