/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.import;
import protected.se_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.sG
 */
public class sg_0 {
    private static short[] break;
    private static boolean[] byte;
    public static Object[] class;
    private static byte[] protected;
    private static String[] throws;

    private static void byte() {
        boolean[] blArray = new boolean[3];
        blArray[2] = true;
        byte = blArray;
    }

    private sg_0() {
    }

    static {
        sg_0.ntfClinit();
    }

    public static List<import> class(String string, boolean bl2) {
        ArrayList<import> arrayList = new ArrayList<import>();
        Matcher matcher = ((Pattern)sg_0.class[break[0]]).matcher(string);
        int n2 = protected[0];
        while (matcher.find()) {
            arrayList.add(new se_0(arrayList.size(), matcher.group(), string.substring(matcher.start())));
            n2 = matcher.end();
        }
        if (bl2 && n2 < string.length()) {
            arrayList.add(new se_0(arrayList.size(), throws[0], throws[1]));
        }
        return arrayList;
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0x5F9E4CAD8C7C987CL;
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0x19D85365;
    }

    public static List<import> class(String string) {
        return sg_0.class(string, byte[0]);
    }

    public static se_0 class() {
        return new se_0(protected[1], throws[2], throws[3]);
    }

    private static void break() {
        Object[] objectArray = new Object[]{Pattern.compile(throws[4])};
        sg_0.class = objectArray;
    }

    public static String break(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{-77, 99, 108, -8, -84, -86, 28, 108}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    private static void throws() {
        protected = new byte[]{-1, -1};
    }

    private static /* synthetic */ void ntfClinit() {
        sg_0.byte();
        sg_0.case();
        sg_0.protected();
        sg_0.throws();
        sg_0.break();
    }

    private static void case() {
        throws = new String[]{new String(""), new String(""), new String("<unknown>"), new String(""), new String("\\S+")};
    }

    private static void protected() {
        break = new short[1];
    }
}

