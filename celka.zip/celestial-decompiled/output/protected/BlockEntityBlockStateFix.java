/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.datafixers.DSL
 *  com.mojang.datafixers.OpticFinder
 *  com.mojang.datafixers.Typed
 *  com.mojang.datafixers.schemas.Schema
 *  com.mojang.datafixers.types.Type
 *  com.mojang.datafixers.util.Pair
 *  com.mojang.serialization.Dynamic
 */
package protected;

import com.mojang.datafixers.DSL;
import com.mojang.datafixers.OpticFinder;
import com.mojang.datafixers.Typed;
import com.mojang.datafixers.schemas.Schema;
import com.mojang.datafixers.types.Type;
import com.mojang.datafixers.util.Pair;
import com.mojang.serialization.Dynamic;
import protected.rTC;
import protected.rts_2;
import protected.rww_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.rwL
 */
public class rwl_0
extends rww_0 {
    public rwl_0(Schema schema, boolean bl2) {
        super(schema, bl2, "BlockEntityBlockStateFix", rTC.extends, "minecraft:piston");
    }

    @Override
    protected Typed<?> class(Typed<?> typed) {
        Type type = this.getOutputSchema().getChoiceType(rTC.extends, "minecraft:piston");
        Type type2 = type.findFieldType("blockState");
        OpticFinder opticFinder = DSL.fieldFinder((String)"blockState", (Type)type2);
        Dynamic dynamic = (Dynamic)typed.get(DSL.remainderFinder());
        int n2 = dynamic.get("blockId").asInt(0);
        dynamic = dynamic.remove("blockId");
        int n3 = dynamic.get("blockData").asInt(0) & 0xF;
        dynamic = dynamic.remove("blockData");
        Dynamic<?> dynamic2 = rts_2.break(n2 << 4 | n3);
        Typed typed2 = (Typed)type.pointTyped(typed.getOps()).orElseThrow(() -> new IllegalStateException("Could not create new piston block entity."));
        return typed2.set(DSL.remainderFinder(), (Object)dynamic).set(opticFinder, (Typed)((Pair)type2.readTyped(dynamic2).result().orElseThrow(() -> new IllegalStateException("Could not parse newly created block state tag."))).getFirst());
    }
}

