/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonIOException
 *  com.google.gson.JsonParser
 *  com.google.gson.JsonSyntaxException
 *  com.mojang.serialization.DataResult
 *  com.mojang.serialization.DataResult$PartialResult
 *  com.mojang.serialization.DynamicOps
 *  com.mojang.serialization.JsonOps
 *  com.mojang.serialization.Lifecycle
 *  it.unimi.dsi.fastutil.booleans.BooleanConsumer
 *  org.apache.commons.lang3.StringUtils
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 *  org.lwjgl.PointerBuffer
 *  org.lwjgl.util.tinyfd.TinyFileDialogs
 */
package protected;

import com.google.gson.JsonIOException;
import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.DynamicOps;
import com.mojang.serialization.JsonOps;
import com.mojang.serialization.Lifecycle;
import it.unimi.dsi.fastutil.booleans.BooleanConsumer;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Optional;
import java.util.OptionalLong;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.function.Consumer;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.lwjgl.PointerBuffer;
import org.lwjgl.util.tinyfd.TinyFileDialogs;
import protected.ZR;
import protected.cm_1;
import protected.cp_1;
import protected.cv_2;
import protected.gq;
import protected.lf_2;
import protected.lu_1;
import protected.mN;
import protected.ml_1;
import protected.mn_0;
import protected.mo;
import protected.mt_0;
import protected.qy_1;
import protected.rVm;
import protected.rVp;
import protected.rVq;
import protected.raf_1;
import protected.rah_2;
import protected.rat_1;
import protected.raz_1;
import protected.raz_2;
import protected.rgP;
import protected.rgS;
import protected.rgn;
import protected.rgn_0;
import protected.rnW;
import protected.rqR;
import protected.rrsp_1;
import protected.rvv_0;
import protected.vd_1;
import protected.ve_1;
import protected.vm_1;
import protected.vu_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.vK
 */
public class vk_1
implements ZR,
cp_1 {
    private static final Logger break = LogManager.getLogger();
    static final rgP byte = new rgn("generator.custom");
    static final rgP protected = new rgn("generator.amplified.info");
    private static final rgP throws = new rgn("selectWorld.mapFeatures.info");
    private cv_2 case = cv_2.class;
    private cm_1 catch;
    private int private;
    private lu_1 implements;
    private lf_2 finally;
    public lf_2 class;
    private lf_2 extends;
    private lf_2 native;
    private lf_2 volatile;
    private rvv_0 final;
    rrsp_1 package;
    Optional<mN> int;
    private OptionalLong new;

    private OptionalLong byte() {
        OptionalLong optionalLong;
        String string = this.implements.private();
        OptionalLong optionalLong2 = StringUtils.isEmpty((CharSequence)string) ? OptionalLong.empty() : ((optionalLong = vk_1.class(string)).isPresent() && optionalLong.getAsLong() != 0L ? optionalLong : OptionalLong.of(string.hashCode()));
        return optionalLong2;
    }

    public vk_1(rvv_0 rvv_02, rrsp_1 rrsp_12, Optional<mN> optional, OptionalLong optionalLong) {
        this.final = rvv_02;
        this.package = rrsp_12;
        this.int = optional;
        this.new = optionalLong;
    }

    void class(rah_2 rah_22) {
        rvv_0 rvv_02 = rVm.break();
        rVp rVp2 = rVp.class(JsonOps.INSTANCE, this.final);
        rVq rVq2 = rVq.class(JsonOps.INSTANCE, rah_22.private(), rvv_02);
        DataResult dataResult = rrsp_1.class.encodeStart(rVp2, (Object)this.package).flatMap(jsonElement -> rrsp_1.class.parse((DynamicOps)rVq2, jsonElement));
        dataResult.resultOrPartial((Consumer)((Object)rqR.class("Error parsing worldgen settings after loading data packs: ", arg_0 -> ((Logger)break).error(arg_0)))).ifPresent(rrsp_12 -> {
            this.package = rrsp_12;
            this.final = rvv_02;
        });
    }

    private /* synthetic */ void class(qy_1 qy_12, mo mo2, rvv_0 rvv_02, Lifecycle lifecycle, rrsp_1 rrsp_12) {
        BooleanConsumer booleanConsumer = bl2 -> {
            qy_12.break(mo2);
            if (bl2) {
                this.class(rvv_02, rrsp_12);
            }
        };
        if (lifecycle == Lifecycle.stable()) {
            this.class(rvv_02, rrsp_12);
        } else if (lifecycle == Lifecycle.experimental()) {
            qy_12.break(new mt_0(booleanConsumer, new rgn("selectWorld.import_worldgen_settings.experimental.title"), new rgn("selectWorld.import_worldgen_settings.experimental.question")));
        } else {
            qy_12.break(new mt_0(booleanConsumer, new rgn("selectWorld.import_worldgen_settings.deprecated.title"), new rgn("selectWorld.import_worldgen_settings.deprecated.question")));
        }
    }

    private static OptionalLong class(String string) {
        try {
            return OptionalLong.of(Long.parseLong(string));
        }
        catch (NumberFormatException numberFormatException) {
            return OptionalLong.empty();
        }
    }

    protected void class(rrsp_1 rrsp_12) {
        this.package = rrsp_12;
    }

    @Override
    public void class(ml_1 ml_12, int n2, int n3, float f2) {
        if (this.finally.new) {
            this.catch.break(ml_12, throws, (float)(this.private / 2 - 150), 122.0f, -6250336);
        }
        this.implements.class(ml_12, n2, n3, f2);
        if (this.int.equals(Optional.of(mN.break))) {
            this.case.break(ml_12, this.extends.volatile + 2, this.extends.final + 22, 9, 0xA0A0A0);
        }
    }

    public void class(mo mo2, qy_1 qy_12, cm_1 cm_12) {
        this.catch = cm_12;
        this.private = mo2.package;
        this.implements = new lu_1(this.catch, this.private / 2 - 100, 60, 200, 20, new rgn("selectWorld.enterSeed"));
        this.implements.class(vk_1.class(this.new));
        this.implements.class((String string) -> {
            this.new = this.byte();
        });
        mo2.protected(this.implements);
        int n2 = this.private / 2 - 155;
        int n3 = this.private / 2 + 5;
        this.finally = mo2.class(new vd_1(this, n2, 100, 150, 20, new rgn("selectWorld.mapFeatures"), lf_22 -> {
            this.package = this.package.extends();
        }));
        this.finally.new = false;
        this.extends = mo2.class(new vu_1(this, n3, 100, 150, 20, new rgn("selectWorld.mapType"), lf_22 -> {
            while (this.int.isPresent()) {
                int n2 = mN.byte.indexOf(this.int.get()) + 1;
                if (n2 >= mN.byte.size()) {
                    n2 = 0;
                }
                mN mN2 = mN.byte.get(n2);
                this.int = Optional.of(mN2);
                this.package = mN2.class(this.final, this.package.class(), this.package.break(), this.package.byte());
                if (this.package.catch() && !vm_1.synchronized()) continue;
            }
            mo2.finally();
        }));
        this.extends.new = false;
        this.extends.int = this.int.isPresent();
        this.native = mo2.class(new lf_2(n3, 120, 150, 20, new rgn("selectWorld.customizeType"), lf_22 -> {
            mn_0 mn_02 = mN.protected.get(this.int);
            if (mn_02 != null) {
                qy_12.break(mn_02.createEditScreen(mo2, this.package));
            }
        }));
        this.native.new = false;
        this.class = mo2.class(new ve_1(this, n2, 151, 150, 20, new rgn("selectWorld.bonusItems"), lf_22 -> {
            this.package = this.package.native();
        }, mo2));
        this.class.new = false;
        this.volatile = mo2.class(new lf_2(n2, 185, 150, 20, new rgn("selectWorld.import_worldgen_settings"), lf_22 -> {
            rgn rgn2 = new rgn("selectWorld.import_worldgen_settings.select_file");
            String string = TinyFileDialogs.tinyfd_openFileDialog((CharSequence)rgn2.getString(), (CharSequence)null, (PointerBuffer)null, (CharSequence)null, (boolean)false);
            if (string != null) {
                DataResult dataResult;
                Object object;
                Object object2;
                rah_2 rah_22;
                Object object3;
                rvv_0 rvv_02 = rVm.break();
                rat_1 rat_12 = new rat_1(new raf_1(), new raz_2(mo2.final().toFile(), raz_1.byte));
                try {
                    rnW.class(rat_12, mo2.throws, false);
                    object3 = rah_2.class(rat_12.case(), gq.INTEGRATED, 2, rqR.case(), qy_12);
                    qy_12.byte(() -> object3.isDone());
                    rah_22 = ((CompletableFuture)object3).get();
                }
                catch (InterruptedException | ExecutionException exception) {
                    break.error("Error loading data packs when importing world settings", (Throwable)exception);
                    rgn rgn3 = new rgn("selectWorld.import_worldgen_settings.failure");
                    rgn_0 rgn_02 = new rgn_0(exception.getMessage());
                    rat_12.close();
                    return;
                }
                object3 = rVq.class(JsonOps.INSTANCE, rah_22.private(), rvv_02);
                JsonParser jsonParser = new JsonParser();
                try {
                    object2 = Files.newBufferedReader(Paths.get(string, new String[0]));
                    try {
                        object = jsonParser.parse((Reader)object2);
                        dataResult = rrsp_1.class.parse((DynamicOps)object3, object);
                    }
                    finally {
                        if (object2 != null) {
                            ((BufferedReader)object2).close();
                        }
                    }
                }
                catch (JsonIOException | JsonSyntaxException | IOException throwable) {
                    dataResult = DataResult.error((String)("Failed to parse file: " + throwable.getMessage()));
                }
                if (dataResult.error().isPresent()) {
                    object2 = new rgn("selectWorld.import_worldgen_settings.failure");
                    object = ((DataResult.PartialResult)dataResult.error().get()).message();
                    break.error("Error parsing world settings: {}", object);
                    rgn_0 rgn_03 = new rgn_0((String)object);
                }
                rah_22.close();
                object2 = dataResult.lifecycle();
                dataResult.resultOrPartial(arg_0 -> ((Logger)break).error(arg_0)).ifPresent(arg_0 -> this.class(qy_12, mo2, rvv_02, (Lifecycle)object2, arg_0));
            }
        }));
        this.volatile.new = false;
        this.case = cv_2.class(cm_12, (rgS)protected, this.extends.case());
    }

    private static String class(OptionalLong optionalLong) {
        return optionalLong.isPresent() ? Long.toString(optionalLong.getAsLong()) : "";
    }

    public boolean class() {
        return this.package.catch();
    }

    private void class(rvv_0 rvv_02, rrsp_1 rrsp_12) {
        this.final = rvv_02;
        this.package = rrsp_12;
        this.int = mN.class(rrsp_12);
        this.new = OptionalLong.of(rrsp_12.class());
        this.implements.class(vk_1.class(this.new));
        this.extends.int = this.int.isPresent();
    }

    public rrsp_1 class(boolean bl2) {
        OptionalLong optionalLong = this.byte();
        return this.package.class(bl2, optionalLong);
    }

    public void break(boolean bl2) {
        this.extends.new = bl2;
        if (this.package.catch()) {
            this.finally.new = false;
            this.class.new = false;
            this.native.new = false;
            this.volatile.new = false;
        } else {
            this.finally.new = bl2;
            this.class.new = bl2;
            this.native.new = bl2 && mN.protected.containsKey(this.int);
            this.volatile.new = bl2;
        }
        this.implements.private(bl2);
    }

    public rvv_0 break() {
        return this.final;
    }

    @Override
    public void private() {
        this.implements.catch();
    }
}

