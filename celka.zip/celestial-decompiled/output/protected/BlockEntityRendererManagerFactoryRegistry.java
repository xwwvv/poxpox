/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.util.Set;
import protected.rpr_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.yF
 */
public class yf_2 {
    private static final int class = rpr_0.values().length;
    private long break;

    private void byte(int n2) {
        this.break &= (long)(~(1 << n2));
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(' ');
        for (rpr_0 rpr_02 : rpr_0.values()) {
            stringBuilder.append(' ').append(rpr_02.toString().toUpperCase().charAt(0));
        }
        stringBuilder.append('\n');
        for (rpr_0 rpr_02 : rpr_0.values()) {
            stringBuilder.append(rpr_02.toString().toUpperCase().charAt(0));
            for (rpr_0 rpr_03 : rpr_0.values()) {
                if (rpr_02 == rpr_03) {
                    stringBuilder.append("  ");
                    continue;
                }
                boolean bl2 = this.class(rpr_02, rpr_03);
                stringBuilder.append(' ').append(bl2 ? (char)'Y' : 'n');
            }
            stringBuilder.append('\n');
        }
        return stringBuilder.toString();
    }

    private void class(int n2, boolean bl2) {
        if (bl2) {
            this.break(n2);
        } else {
            this.byte(n2);
        }
    }

    public void class(Set<rpr_0> set) {
        for (rpr_0 rpr_02 : set) {
            for (rpr_0 rpr_03 : set) {
                this.class(rpr_02, rpr_03, true);
            }
        }
    }

    public void class(boolean bl2) {
        this.break = bl2 ? -1L : 0L;
    }

    public boolean class(rpr_0 rpr_02, rpr_0 rpr_03) {
        return this.class(rpr_02.ordinal() + rpr_03.ordinal() * yf_2.class);
    }

    public void class(rpr_0 rpr_02, rpr_0 rpr_03, boolean bl2) {
        this.class(rpr_02.ordinal() + rpr_03.ordinal() * yf_2.class, bl2);
        this.class(rpr_03.ordinal() + rpr_02.ordinal() * yf_2.class, bl2);
    }

    private boolean class(int n2) {
        return (this.break & (long)(1 << n2)) != 0L;
    }

    private void break(int n2) {
        this.break |= (long)(1 << n2);
    }
}

