/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.cu_2;

/*
 * Renamed from protected.ce
 * Illegal identifiers - consider using --renameillegalidents true
 */
class ce_1 {
    static final /* synthetic */ int[] class;

    static {
        ce_1.class = new int[cu_2.values().length];
        try {
            ce_1.class[cu_2.ABOVE.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            ce_1.class[cu_2.BELOW.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            ce_1.class[cu_2.LEFT.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            ce_1.class[cu_2.RIGHT.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}

