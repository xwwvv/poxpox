/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.util.Optional;
import java.util.stream.IntStream;
import protected.DD;
import protected.rqo_0;
import protected.ux_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.Uh
 */
public class uh_0 {
    public static final DD class = uh_0.class("cube", ux_0.byte, ux_0.finally, ux_0.extends, ux_0.native, ux_0.volatile, ux_0.final, ux_0.package);
    public static final DD break = uh_0.class("cube_directional", ux_0.byte, ux_0.finally, ux_0.extends, ux_0.native, ux_0.volatile, ux_0.final, ux_0.package);
    public static final DD byte = uh_0.class("cube_all", ux_0.class);
    public static final DD protected = uh_0.class("cube_mirrored_all", "_mirrored", ux_0.class);
    public static final DD throws = uh_0.class("cube_column", ux_0.protected, ux_0.implements);
    public static final DD case = uh_0.class("cube_column_horizontal", "_horizontal", ux_0.protected, ux_0.implements);
    public static final DD catch = uh_0.class("cube_top", ux_0.case, ux_0.implements);
    public static final DD private = uh_0.class("cube_bottom_top", ux_0.case, ux_0.throws, ux_0.implements);
    public static final DD implements = uh_0.class("orientable", ux_0.case, ux_0.catch, ux_0.implements);
    public static final DD finally = uh_0.class("orientable_with_bottom", ux_0.case, ux_0.throws, ux_0.implements, ux_0.catch);
    public static final DD extends = uh_0.class("orientable_vertical", "_vertical", ux_0.catch, ux_0.implements);
    public static final DD native = uh_0.class("button", ux_0.break);
    public static final DD volatile = uh_0.class("button_pressed", "_pressed", ux_0.break);
    public static final DD final = uh_0.class("button_inventory", "_inventory", ux_0.break);
    public static final DD package = uh_0.class("door_bottom", "_bottom", ux_0.case, ux_0.throws);
    public static final DD int = uh_0.class("door_bottom_rh", "_bottom_hinge", ux_0.case, ux_0.throws);
    public static final DD new = uh_0.class("door_top", "_top", ux_0.case, ux_0.throws);
    public static final DD continue = uh_0.class("door_top_rh", "_top_hinge", ux_0.case, ux_0.throws);
    public static final DD super = uh_0.class("fence_post", "_post", ux_0.break);
    public static final DD this = uh_0.class("fence_side", "_side", ux_0.break);
    public static final DD else = uh_0.class("fence_inventory", "_inventory", ux_0.break);
    public static final DD synchronized = uh_0.class("template_wall_post", "_post", ux_0.continue);
    public static final DD return = uh_0.class("template_wall_side", "_side", ux_0.continue);
    public static final DD public = uh_0.class("template_wall_side_tall", "_side_tall", ux_0.continue);
    public static final DD goto = uh_0.class("wall_inventory", "_inventory", ux_0.continue);
    public static final DD while = uh_0.class("template_fence_gate", ux_0.break);
    public static final DD try = uh_0.class("template_fence_gate_open", "_open", ux_0.break);
    public static final DD instanceof = uh_0.class("template_fence_gate_wall", "_wall", ux_0.break);
    public static final DD throw = uh_0.class("template_fence_gate_wall_open", "_wall_open", ux_0.break);
    public static final DD interface = uh_0.class("pressure_plate_up", ux_0.break);
    public static final DD char = uh_0.class("pressure_plate_down", "_down", ux_0.break);
    public static final DD abstract = uh_0.class(ux_0.byte);
    public static final DD long = uh_0.class("slab", ux_0.throws, ux_0.case, ux_0.implements);
    public static final DD float = uh_0.class("slab_top", "_top", ux_0.throws, ux_0.case, ux_0.implements);
    public static final DD void = uh_0.class("leaves", ux_0.class);
    public static final DD static = uh_0.class("stairs", ux_0.throws, ux_0.case, ux_0.implements);
    public static final DD import = uh_0.class("inner_stairs", "_inner", ux_0.throws, ux_0.case, ux_0.implements);
    public static final DD short = uh_0.class("outer_stairs", "_outer", ux_0.throws, ux_0.case, ux_0.implements);
    public static final DD default = uh_0.class("template_trapdoor_top", "_top", ux_0.break);
    public static final DD const = uh_0.class("template_trapdoor_bottom", "_bottom", ux_0.break);
    public static final DD strictfp = uh_0.class("template_trapdoor_open", "_open", ux_0.break);
    public static final DD boolean = uh_0.class("template_orientable_trapdoor_top", "_top", ux_0.break);
    public static final DD transient = uh_0.class("template_orientable_trapdoor_bottom", "_bottom", ux_0.break);
    public static final DD for = uh_0.class("template_orientable_trapdoor_open", "_open", ux_0.break);
    public static final DD double = uh_0.class("cross", ux_0.int);
    public static final DD switch = uh_0.class("tinted_cross", ux_0.int);
    public static final DD r = uh_0.class("flower_pot_cross", ux_0.new);
    public static final DD P = uh_0.class("tinted_flower_pot_cross", ux_0.new);
    public static final DD B = uh_0.class("rail_flat", ux_0.super);
    public static final DD S = uh_0.class("rail_curved", "_corner", ux_0.super);
    public static final DD s = uh_0.class("template_rail_raised_ne", "_raised_ne", ux_0.super);
    public static final DD E = uh_0.class("template_rail_raised_sw", "_raised_sw", ux_0.super);
    public static final DD G = uh_0.class("carpet", ux_0.this);
    public static final DD b = uh_0.class("coral_fan", ux_0.public);
    public static final DD M = uh_0.class("coral_wall_fan", ux_0.public);
    public static final DD O = uh_0.class("template_glazed_terracotta", ux_0.else);
    public static final DD h = uh_0.class("template_chorus_flower", ux_0.break);
    public static final DD X = uh_0.class("template_daylight_detector", ux_0.case, ux_0.implements);
    public static final DD J = uh_0.class("template_glass_pane_noside", "_noside", ux_0.synchronized);
    public static final DD x = uh_0.class("template_glass_pane_noside_alt", "_noside_alt", ux_0.synchronized);
    public static final DD d = uh_0.class("template_glass_pane_post", "_post", ux_0.synchronized, ux_0.return);
    public static final DD k = uh_0.class("template_glass_pane_side", "_side", ux_0.synchronized, ux_0.return);
    public static final DD W = uh_0.class("template_glass_pane_side_alt", "_side_alt", ux_0.synchronized, ux_0.return);
    public static final DD z = uh_0.class("template_command_block", ux_0.catch, ux_0.private, ux_0.implements);
    public static final DD Q = uh_0.class("template_anvil", ux_0.case);
    public static final DD[] N = (DD[])IntStream.range(0, 8).mapToObj(n2 -> uh_0.class("stem_growth" + n2, "_stage" + n2, ux_0.goto)).toArray(DD[]::new);
    public static final DD c = uh_0.class("stem_fruit", ux_0.goto, ux_0.while);
    public static final DD u = uh_0.class("crop", ux_0.try);
    public static final DD m = uh_0.class("template_farmland", ux_0.instanceof, ux_0.case);
    public static final DD Z = uh_0.class("template_fire_floor", ux_0.throw);
    public static final DD v = uh_0.class("template_fire_side", ux_0.throw);
    public static final DD F = uh_0.class("template_fire_side_alt", ux_0.throw);
    public static final DD L = uh_0.class("template_fire_up", ux_0.throw);
    public static final DD A = uh_0.class("template_fire_up_alt", ux_0.throw);
    public static final DD n = uh_0.class("template_campfire", ux_0.throw, ux_0.void);
    public static final DD C = uh_0.class("template_lantern", ux_0.interface);
    public static final DD l = uh_0.class("template_hanging_lantern", "_hanging", ux_0.interface);
    public static final DD H = uh_0.class("template_torch", ux_0.long);
    public static final DD y = uh_0.class("template_torch_wall", ux_0.long);
    public static final DD p = uh_0.class("template_piston", ux_0.char, ux_0.throws, ux_0.implements);
    public static final DD q = uh_0.class("template_piston_head", ux_0.char, ux_0.implements, ux_0.abstract);
    public static final DD T = uh_0.class("template_piston_head_short", ux_0.char, ux_0.implements, ux_0.abstract);
    public static final DD t = uh_0.class("template_seagrass", ux_0.break);
    public static final DD w = uh_0.class("template_turtle_egg", ux_0.class);
    public static final DD I = uh_0.class("template_two_turtle_eggs", ux_0.class);
    public static final DD f = uh_0.class("template_three_turtle_eggs", ux_0.class);
    public static final DD j = uh_0.class("template_four_turtle_eggs", ux_0.class);
    public static final DD V = uh_0.class("template_single_face", ux_0.break);
    public static final DD g = uh_0.break("generated", ux_0.float);
    public static final DD R = uh_0.break("handheld", ux_0.float);
    public static final DD Y = uh_0.break("handheld_rod", ux_0.float);
    public static final DD o = uh_0.break("template_shulker_box", ux_0.byte);
    public static final DD K = uh_0.break("template_bed", ux_0.byte);
    public static final DD D = uh_0.break("template_banner", new ux_0[0]);
    public static final DD U = uh_0.break("template_skull", new ux_0[0]);

    private static DD class(String string, String string2, ux_0 ... ux_0Array) {
        return new DD(Optional.of(new rqo_0("minecraft", "block/" + string)), Optional.of(string2), ux_0Array);
    }

    private static DD class(ux_0 ... ux_0Array) {
        return new DD(Optional.empty(), Optional.empty(), ux_0Array);
    }

    private static DD class(String string, ux_0 ... ux_0Array) {
        return new DD(Optional.of(new rqo_0("minecraft", "block/" + string)), Optional.empty(), ux_0Array);
    }

    private static DD break(String string, ux_0 ... ux_0Array) {
        return new DD(Optional.of(new rqo_0("minecraft", "item/" + string)), Optional.empty(), ux_0Array);
    }
}

