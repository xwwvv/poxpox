/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableSet
 *  com.google.common.collect.Maps
 */
package protected;

import com.google.common.collect.ImmutableSet;
import com.google.common.collect.Maps;
import java.util.Map;
import java.util.Set;
import protected.du_2;
import protected.qs_2;
import protected.rCZ;
import protected.rRH;
import protected.rRp;
import protected.rYB;
import protected.rYm;
import protected.rcf_0;
import protected.rfH;
import protected.rqe_0;
import protected.rrn_0;
import protected.rvl_0;
import protected.wu_2;
import protected.xc_0;
import protected.xd_0;
import protected.xu_0;
import protected.yy_2;
import protected.zo_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.yC
 */
public class yc_1 {
    private final rqe_0<yy_2> class = new rqe_0(32);
    private final Map<xd_0, Set<rCZ<?>>> break = Maps.newHashMap();

    private void class(Set<rCZ<?>> set, xd_0 ... xd_0Array) {
        for (xd_0 xd_02 : xd_0Array) {
            this.break.put(xd_02, set);
        }
    }

    private void class(rCZ<?> rCZ2, xd_0 ... xd_0Array) {
        this.class((Set<rCZ<?>>)ImmutableSet.of(rCZ2), xd_0Array);
    }

    public Set<rCZ<?>> class(xd_0 xd_02) {
        return (Set)this.break.getOrDefault(xd_02, (Set<rCZ<?>>)ImmutableSet.of());
    }

    public static yc_1 class() {
        yc_1 yc_12 = new yc_1();
        yc_12.class((xc_0 xc_02, rRp rRp2, rfH rfH2, int n2) -> rRp2 != null && rfH2 != null ? rYm.class(rRp2, xc_02.byte(du_2.volatile) == rcf_0.UPPER ? rfH2.break() : rfH2) : -1, xu_0.GE, xu_0.Gs);
        yc_12.class(du_2.volatile, xu_0.GE, xu_0.Gs);
        yc_12.class((xc_0 xc_02, rRp rRp2, rfH rfH2, int n2) -> rRp2 != null && rfH2 != null ? rYm.class(rRp2, rfH2) : rRH.class(0.5, 1.0), xu_0.implements, xu_0.a, xu_0.e, xu_0.Sq);
        yc_12.class((xc_0 xc_02, rRp rRp2, rfH rfH2, int n2) -> rrn_0.class(), xu_0.d);
        yc_12.class((xc_0 xc_02, rRp rRp2, rfH rfH2, int n2) -> rrn_0.break(), xu_0.k);
        yc_12.class((xc_0 xc_02, rRp rRp2, rfH rfH2, int n2) -> rRp2 != null && rfH2 != null ? rYm.break(rRp2, rfH2) : rrn_0.byte(), xu_0.x, xu_0.W, xu_0.z, xu_0.Q, xu_0.BD);
        yc_12.class((xc_0 xc_02, rRp rRp2, rfH rfH2, int n2) -> rRp2 != null && rfH2 != null ? rYm.byte(rRp2, rfH2) : -1, xu_0.try, xu_0.hM, xu_0.Sb);
        yc_12.class((xc_0 xc_02, rRp rRp2, rfH rfH2, int n2) -> wu_2.byte(xc_02.byte(wu_2.new)), xu_0.ra);
        yc_12.class(wu_2.new, xu_0.ra);
        yc_12.class((xc_0 xc_02, rRp rRp2, rfH rfH2, int n2) -> rRp2 != null && rfH2 != null ? rYm.class(rRp2, rfH2) : -1, xu_0.Pf);
        yc_12.class((xc_0 xc_02, rRp rRp2, rfH rfH2, int n2) -> 14731036, xu_0.BY, xu_0.BR);
        yc_12.class((xc_0 xc_02, rRp rRp2, rfH rfH2, int n2) -> {
            int n3 = xc_02.byte(zo_2.volatile);
            int n4 = n3 * 32;
            int n5 = 255 - n3 * 8;
            int n6 = n3 * 4;
            return n4 << 16 | n5 << 8 | n6;
        }, xu_0.BK, xu_0.Bo);
        yc_12.class(zo_2.volatile, xu_0.BK, xu_0.Bo);
        yc_12.class((xc_0 xc_02, rRp rRp2, rfH rfH2, int n2) -> rRp2 != null && rfH2 != null ? 2129968 : 7455580, xu_0.Sr);
        return yc_12;
    }

    public void class(yy_2 yy_22, xd_0 ... xd_0Array) {
        for (xd_0 xd_02 : xd_0Array) {
            this.class.class(yy_22, rvl_0.strictfp.class(xd_02));
        }
    }

    public int class(xc_0 xc_02, rRp rRp2, rfH rfH2, int n2) {
        yy_2 yy_22 = this.class.class(rvl_0.strictfp.class(xc_02.break()));
        return yy_22 == null ? -1 : yy_22.getColor(xc_02, rRp2, rfH2, n2);
    }

    public int class(xc_0 xc_02, rYB rYB2, rfH rfH2) {
        yy_2 yy_22 = this.class.class(rvl_0.strictfp.class(xc_02.break()));
        if (yy_22 != null) {
            return yy_22.getColor(xc_02, null, null, 0);
        }
        qs_2 qs_22 = xc_02.protected(rYB2, rfH2);
        return qs_22 != null ? qs_22.d : -1;
    }
}

