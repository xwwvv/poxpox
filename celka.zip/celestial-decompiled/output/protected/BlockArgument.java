/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Maps
 *  com.mojang.brigadier.ImmutableStringReader
 *  com.mojang.brigadier.Message
 *  com.mojang.brigadier.StringReader
 *  com.mojang.brigadier.exceptions.CommandSyntaxException
 *  com.mojang.brigadier.exceptions.Dynamic2CommandExceptionType
 *  com.mojang.brigadier.exceptions.Dynamic3CommandExceptionType
 *  com.mojang.brigadier.exceptions.DynamicCommandExceptionType
 *  com.mojang.brigadier.exceptions.SimpleCommandExceptionType
 *  com.mojang.brigadier.suggestion.Suggestions
 *  com.mojang.brigadier.suggestion.SuggestionsBuilder
 */
package protected;

import com.google.common.collect.Maps;
import com.mojang.brigadier.ImmutableStringReader;
import com.mojang.brigadier.Message;
import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.Dynamic2CommandExceptionType;
import com.mojang.brigadier.exceptions.Dynamic3CommandExceptionType;
import com.mojang.brigadier.exceptions.DynamicCommandExceptionType;
import com.mojang.brigadier.exceptions.SimpleCommandExceptionType;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.function.BiFunction;
import protected.gR;
import protected.rCF;
import protected.rCZ;
import protected.rcd_2;
import protected.rch_1;
import protected.rgn;
import protected.rlb;
import protected.rlw_0;
import protected.rqo_0;
import protected.rvl_0;
import protected.xc_0;
import protected.xd_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.Rk
 */
public class rk_0 {
    public static final SimpleCommandExceptionType class = new SimpleCommandExceptionType((Message)new rgn("argument.block.tag.disallowed"));
    public static final DynamicCommandExceptionType break = new DynamicCommandExceptionType(object -> new rgn("argument.block.id.invalid", object));
    public static final Dynamic2CommandExceptionType byte = new Dynamic2CommandExceptionType((object, object2) -> new rgn("argument.block.property.unknown", object, object2));
    public static final Dynamic2CommandExceptionType protected = new Dynamic2CommandExceptionType((object, object2) -> new rgn("argument.block.property.duplicate", object2, object));
    public static final Dynamic3CommandExceptionType throws = new Dynamic3CommandExceptionType((object, object2, object3) -> new rgn("argument.block.property.invalid", object, object3, object2));
    public static final Dynamic2CommandExceptionType case = new Dynamic2CommandExceptionType((object, object2) -> new rgn("argument.block.property.novalue", object, object2));
    public static final SimpleCommandExceptionType catch = new SimpleCommandExceptionType((Message)new rgn("argument.block.property.unclosed"));
    private static final BiFunction<SuggestionsBuilder, rlw_0<xd_0>, CompletableFuture<Suggestions>> private = (suggestionsBuilder, rlw_02) -> suggestionsBuilder.buildFuture();
    private final StringReader implements;
    private final boolean finally;
    private final Map<rCZ<?>, Comparable<?>> extends = Maps.newHashMap();
    private final Map<String, String> native = Maps.newHashMap();
    private rqo_0 volatile = new rqo_0("");
    private rCF<xd_0, xc_0> final;
    private xc_0 package;
    private rcd_2 int;
    private rqo_0 new = new rqo_0("");
    private int continue;
    private BiFunction<SuggestionsBuilder, rlw_0<xd_0>, CompletableFuture<Suggestions>> super = private;

    private CompletableFuture<Suggestions> byte(SuggestionsBuilder suggestionsBuilder, rlw_0<xd_0> rlw_02) {
        if (suggestionsBuilder.getRemaining().isEmpty()) {
            suggestionsBuilder.suggest(String.valueOf(']'));
        }
        return this.throws(suggestionsBuilder, rlw_02);
    }

    public rcd_2 byte() {
        return this.int;
    }

    public rk_0(StringReader stringReader, boolean bl2) {
        this.implements = stringReader;
        this.finally = bl2;
    }

    private CompletableFuture<Suggestions> class(SuggestionsBuilder suggestionsBuilder, rlw_0<xd_0> rlw_02, String string) {
        rlb<xd_0> rlb2;
        boolean bl2 = false;
        if (this.new != null && !this.new.break().isEmpty() && (rlb2 = rlw_02.class(this.new)) != null) {
            block0: for (xd_0 xd_02 : rlb2.class()) {
                rCZ<?> rCZ2 = xd_02.new().class(string);
                if (rCZ2 != null) {
                    rk_0.class(suggestionsBuilder, rCZ2);
                }
                if (bl2) continue;
                for (rCZ<?> rCZ3 : xd_02.new().protected()) {
                    if (this.native.containsKey(rCZ3.throws())) continue;
                    bl2 = true;
                    continue block0;
                }
            }
        }
        if (bl2) {
            suggestionsBuilder.suggest(String.valueOf(','));
        }
        suggestionsBuilder.suggest(String.valueOf(']'));
        return suggestionsBuilder.buildFuture();
    }

    private static <T extends Comparable<T>> SuggestionsBuilder class(SuggestionsBuilder suggestionsBuilder, rCZ<T> rCZ2) {
        for (Comparable comparable : rCZ2.class()) {
            if (comparable instanceof Integer) {
                suggestionsBuilder.suggest(((Integer)comparable).intValue());
                continue;
            }
            suggestionsBuilder.suggest(rCZ2.class(comparable));
        }
        return suggestionsBuilder;
    }

    private <T extends Comparable<T>> void class(rCZ<T> rCZ2, String string, int n2) throws CommandSyntaxException {
        Optional<T> optional = rCZ2.break(string);
        if (!optional.isPresent()) {
            this.implements.setCursor(n2);
            throw throws.createWithContext((ImmutableStringReader)this.implements, (Object)this.volatile.toString(), (Object)rCZ2.throws(), (Object)string);
        }
        this.package = (xc_0)this.package.class(rCZ2, (Comparable)optional.get());
        this.extends.put(rCZ2, (Comparable)optional.get());
    }

    public static String class(xc_0 xc_02) {
        StringBuilder stringBuilder = new StringBuilder(rvl_0.strictfp.break(xc_02.break()).toString());
        if (!xc_02.public().isEmpty()) {
            stringBuilder.append('[');
            boolean bl2 = false;
            for (Map.Entry entry : xc_02.goto().entrySet()) {
                if (bl2) {
                    stringBuilder.append(',');
                }
                rk_0.class(stringBuilder, (rCZ)entry.getKey(), (Comparable)entry.getValue());
                bl2 = true;
            }
            stringBuilder.append(']');
        }
        return stringBuilder.toString();
    }

    private static <T extends Comparable<T>> void class(StringBuilder stringBuilder, rCZ<T> rCZ2, Comparable<?> comparable) {
        stringBuilder.append(rCZ2.throws());
        stringBuilder.append('=');
        stringBuilder.append(rCZ2.class(comparable));
    }

    public CompletableFuture<Suggestions> class(SuggestionsBuilder suggestionsBuilder, rlw_0<xd_0> rlw_02) {
        return this.super.apply(suggestionsBuilder.createOffset(this.implements.getCursor()), rlw_02);
    }

    public rk_0 class(boolean bl2) throws CommandSyntaxException {
        this.super = this::native;
        if (this.implements.canRead() && this.implements.peek() == '#') {
            this.case();
            this.super = this::implements;
            if (this.implements.canRead() && this.implements.peek() == '[') {
                this.private();
                this.super = this::case;
            }
        } else {
            this.throws();
            this.super = this::finally;
            if (this.implements.canRead() && this.implements.peek() == '[') {
                this.catch();
                this.super = this::case;
            }
        }
        if (bl2 && this.implements.canRead() && this.implements.peek() == '{') {
            this.super = private;
            this.implements();
        }
        return this;
    }

    public Map<rCZ<?>, Comparable<?>> class() {
        return this.extends;
    }

    private boolean class(rlw_0<xd_0> rlw_02) {
        rlb<xd_0> rlb2;
        if (this.package != null) {
            return this.package.break().protected();
        }
        if (this.new != null && (rlb2 = rlw_02.class(this.new)) != null) {
            for (xd_0 xd_02 : rlb2.class()) {
                if (!xd_02.protected()) continue;
                return true;
            }
        }
        return false;
    }

    private CompletableFuture<Suggestions> break(SuggestionsBuilder suggestionsBuilder, rlw_0<xd_0> rlw_02) {
        if (suggestionsBuilder.getRemaining().isEmpty()) {
            suggestionsBuilder.suggest(String.valueOf(']'));
        }
        return this.protected(suggestionsBuilder, rlw_02);
    }

    public xc_0 break() {
        return this.package;
    }

    public void throws() throws CommandSyntaxException {
        int n2 = this.implements.getCursor();
        this.volatile = rqo_0.class(this.implements);
        xd_0 xd_02 = rvl_0.strictfp.break(this.volatile).orElseThrow(() -> {
            this.implements.setCursor(n2);
            return break.createWithContext((ImmutableStringReader)this.implements, (Object)this.volatile.toString());
        });
        this.final = xd_02.new();
        this.package = xd_02.continue();
    }

    private CompletableFuture<Suggestions> throws(SuggestionsBuilder suggestionsBuilder, rlw_0<xd_0> rlw_02) {
        rlb<xd_0> rlb2;
        String string = suggestionsBuilder.getRemaining().toLowerCase(Locale.ROOT);
        if (this.new != null && !this.new.break().isEmpty() && (rlb2 = rlw_02.class(this.new)) != null) {
            for (xd_0 xd_02 : rlb2.class()) {
                for (rCZ<?> rCZ2 : xd_02.new().protected()) {
                    if (this.native.containsKey(rCZ2.throws()) || !rCZ2.throws().startsWith(string)) continue;
                    suggestionsBuilder.suggest(rCZ2.throws() + "=");
                }
            }
        }
        return suggestionsBuilder.buildFuture();
    }

    public Map<String, String> finally() {
        return this.native;
    }

    private CompletableFuture<Suggestions> finally(SuggestionsBuilder suggestionsBuilder, rlw_0<xd_0> rlw_02) {
        if (suggestionsBuilder.getRemaining().isEmpty()) {
            if (!this.package.break().new().protected().isEmpty()) {
                suggestionsBuilder.suggest(String.valueOf('['));
            }
            if (this.package.break().protected()) {
                suggestionsBuilder.suggest(String.valueOf('{'));
            }
        }
        return suggestionsBuilder.buildFuture();
    }

    private CompletableFuture<Suggestions> catch(SuggestionsBuilder suggestionsBuilder, rlw_0<xd_0> rlw_02) {
        if (suggestionsBuilder.getRemaining().isEmpty()) {
            suggestionsBuilder.suggest(String.valueOf('='));
        }
        return suggestionsBuilder.buildFuture();
    }

    public void catch() throws CommandSyntaxException {
        this.implements.skip();
        this.super = this::break;
        this.implements.skipWhitespace();
        while (this.implements.canRead() && this.implements.peek() != ']') {
            this.implements.skipWhitespace();
            int n2 = this.implements.getCursor();
            String string = this.implements.readString();
            rCZ<?> rCZ2 = this.final.class(string);
            if (rCZ2 == null) {
                this.implements.setCursor(n2);
                throw byte.createWithContext((ImmutableStringReader)this.implements, (Object)this.volatile.toString(), (Object)string);
            }
            if (this.extends.containsKey(rCZ2)) {
                this.implements.setCursor(n2);
                throw protected.createWithContext((ImmutableStringReader)this.implements, (Object)this.volatile.toString(), (Object)string);
            }
            this.implements.skipWhitespace();
            this.super = this::catch;
            if (!this.implements.canRead() || this.implements.peek() != '=') {
                throw case.createWithContext((ImmutableStringReader)this.implements, (Object)this.volatile.toString(), (Object)string);
            }
            this.implements.skip();
            this.implements.skipWhitespace();
            this.super = (suggestionsBuilder, rlw_02) -> rk_0.class(suggestionsBuilder, rCZ2).buildFuture();
            int n3 = this.implements.getCursor();
            this.class(rCZ2, this.implements.readString(), n3);
            this.super = this::private;
            this.implements.skipWhitespace();
            if (!this.implements.canRead()) continue;
            if (this.implements.peek() == ',') {
                this.implements.skip();
                this.super = this::protected;
                continue;
            }
            if (this.implements.peek() == ']') break;
            throw catch.createWithContext((ImmutableStringReader)this.implements);
        }
        if (this.implements.canRead()) {
            this.implements.skip();
            return;
        }
        throw catch.createWithContext((ImmutableStringReader)this.implements);
    }

    private CompletableFuture<Suggestions> extends(SuggestionsBuilder suggestionsBuilder, rlw_0<xd_0> rlw_02) {
        return gR.class(rlw_02.break(), suggestionsBuilder.createOffset(this.continue).add(suggestionsBuilder));
    }

    public void case() throws CommandSyntaxException {
        if (!this.finally) {
            throw rk_0.class.create();
        }
        this.super = this::extends;
        this.implements.expect('#');
        this.continue = this.implements.getCursor();
        this.new = rqo_0.class(this.implements);
    }

    private CompletableFuture<Suggestions> case(SuggestionsBuilder suggestionsBuilder, rlw_0<xd_0> rlw_02) {
        if (suggestionsBuilder.getRemaining().isEmpty() && this.class(rlw_02)) {
            suggestionsBuilder.suggest(String.valueOf('{'));
        }
        return suggestionsBuilder.buildFuture();
    }

    private CompletableFuture<Suggestions> implements(SuggestionsBuilder suggestionsBuilder, rlw_0<xd_0> rlw_02) {
        rlb<xd_0> rlb2;
        if (suggestionsBuilder.getRemaining().isEmpty() && (rlb2 = rlw_02.class(this.new)) != null) {
            xd_0 xd_02;
            boolean bl2 = false;
            boolean bl3 = false;
            Iterator<xd_0> iterator = rlb2.class().iterator();
            while (!(!iterator.hasNext() || (bl2 |= !(xd_02 = iterator.next()).new().protected().isEmpty()) && (bl3 |= xd_02.protected()))) {
            }
            if (bl2) {
                suggestionsBuilder.suggest(String.valueOf('['));
            }
            if (bl3) {
                suggestionsBuilder.suggest(String.valueOf('{'));
            }
        }
        return this.extends(suggestionsBuilder, rlw_02);
    }

    public void implements() throws CommandSyntaxException {
        this.int = new rch_1(this.implements).case();
    }

    private CompletableFuture<Suggestions> protected(SuggestionsBuilder suggestionsBuilder, rlw_0<xd_0> rlw_02) {
        String string = suggestionsBuilder.getRemaining().toLowerCase(Locale.ROOT);
        for (rCZ rCZ2 : this.package.public()) {
            if (this.extends.containsKey(rCZ2) || !rCZ2.throws().startsWith(string)) continue;
            suggestionsBuilder.suggest(rCZ2.throws() + "=");
        }
        return suggestionsBuilder.buildFuture();
    }

    public rqo_0 protected() {
        return this.new;
    }

    public void private() throws CommandSyntaxException {
        this.implements.skip();
        this.super = this::byte;
        int n2 = -1;
        this.implements.skipWhitespace();
        while (this.implements.canRead() && this.implements.peek() != ']') {
            this.implements.skipWhitespace();
            int n3 = this.implements.getCursor();
            String string = this.implements.readString();
            if (this.native.containsKey(string)) {
                this.implements.setCursor(n3);
                throw protected.createWithContext((ImmutableStringReader)this.implements, (Object)this.volatile.toString(), (Object)string);
            }
            this.implements.skipWhitespace();
            if (!this.implements.canRead() || this.implements.peek() != '=') {
                this.implements.setCursor(n3);
                throw case.createWithContext((ImmutableStringReader)this.implements, (Object)this.volatile.toString(), (Object)string);
            }
            this.implements.skip();
            this.implements.skipWhitespace();
            this.super = (suggestionsBuilder, rlw_02) -> this.class((SuggestionsBuilder)suggestionsBuilder, (rlw_0<xd_0>)rlw_02, string);
            n2 = this.implements.getCursor();
            String string2 = this.implements.readString();
            this.native.put(string, string2);
            this.implements.skipWhitespace();
            if (!this.implements.canRead()) continue;
            n2 = -1;
            if (this.implements.peek() == ',') {
                this.implements.skip();
                this.super = this::throws;
                continue;
            }
            if (this.implements.peek() == ']') break;
            throw catch.createWithContext((ImmutableStringReader)this.implements);
        }
        if (this.implements.canRead()) {
            this.implements.skip();
            return;
        }
        if (n2 >= 0) {
            this.implements.setCursor(n2);
        }
        throw catch.createWithContext((ImmutableStringReader)this.implements);
    }

    private CompletableFuture<Suggestions> private(SuggestionsBuilder suggestionsBuilder, rlw_0<xd_0> rlw_02) {
        if (suggestionsBuilder.getRemaining().isEmpty()) {
            suggestionsBuilder.suggest(String.valueOf(']'));
        }
        if (suggestionsBuilder.getRemaining().isEmpty() && this.extends.size() < this.package.public().size()) {
            suggestionsBuilder.suggest(String.valueOf(','));
        }
        return suggestionsBuilder.buildFuture();
    }

    private CompletableFuture<Suggestions> native(SuggestionsBuilder suggestionsBuilder, rlw_0<xd_0> rlw_02) {
        if (this.finally) {
            gR.class(rlw_02.break(), suggestionsBuilder, String.valueOf('#'));
        }
        gR.class(rvl_0.strictfp.protected(), suggestionsBuilder);
        return suggestionsBuilder.buildFuture();
    }
}

