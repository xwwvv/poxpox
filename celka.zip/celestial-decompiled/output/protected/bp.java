/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.awt.Color;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.D;
import protected.bj;
import protected.by_0;
import protected.class;
import protected.ml_1;
import protected.rfl;
import protected.ry_1;
import protected.t_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class bp
implements D,
bj {
    private static short[] catch;
    private static double[] private;
    public static Object[] class;
    private static boolean[] implements;
    public Object[] break;

    private void byte() {
        if (this.break == null) {
            Object[] objectArray = this.break = new Object[implements[9]];
        }
    }

    public bp(class clazz, by_0 by_02) {
        this.byte();
        by_0 by_03 = by_02;
        this.break[bp.catch[0]] = by_03;
        clazz.s().class(this);
    }

    static {
        bp.ntfClinit();
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0x6672D23324063233L;
    }

    public static void class(ml_1 ml_12, ry_1[] ry_1Array) {
        ry_1 ry_12;
        int n2;
        float f2 = ((Float)bp.protected.super.class[catch[1]]).floatValue();
        boolean bl2 = (Boolean)bp.protected.package.class[catch[2]];
        float f3 = ((Float)bp.protected.PT.class[catch[3]]).floatValue();
        if (!((Boolean)bp.protected.J.class[catch[4]]).booleanValue()) {
            return;
        }
        bj.class((Color)bp.protected.try.class[catch[5]], f2, f3, bl2);
        ry_1[] ry_1Array2 = ry_1Array;
        int n3 = ry_1Array2.length;
        for (n2 = implements[0]; n2 < n3; ++n2) {
            ry_12 = ry_1Array2[n2];
            bj.class(ml_12, ry_12.break(), private[0]);
        }
        if (((Boolean)bp.protected.Pw.class[catch[6]]).booleanValue()) {
            bj.class((Color)bp.protected.short.class[catch[7]], f2);
            ry_1Array2 = ry_1Array;
            n3 = ry_1Array2.length;
            for (n2 = implements[1]; n2 < n3; ++n2) {
                ry_12 = ry_1Array2[n2];
                bj.class(ml_12, new rfl(ry_12.byte(), ry_12.byte().class(implements[2], implements[3], implements[4])));
            }
            bj.class((Color)bp.protected.float.class[catch[8]], f2);
            ry_1Array2 = ry_1Array;
            n3 = ry_1Array2.length;
            for (n2 = implements[5]; n2 < n3; ++n2) {
                ry_12 = ry_1Array2[n2];
                bj.class(ml_12, new rfl(ry_12.case(), ry_12.case().class(implements[6], implements[7], implements[8])));
            }
        }
        bj.class(bl2);
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0xBCFFEFEB;
    }

    public static String class(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{-105, 49, -43, 123, -67, 100, -2, 65}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    private static void class() {
        catch = new short[10];
    }

    @Override
    public void class(t_0 t_02) {
        bp.class(t_02.byte(), ((by_0)this.break[catch[9]]).byte());
    }

    private static void break() {
        boolean[] blArray = new boolean[12];
        blArray[2] = true;
        blArray[3] = true;
        blArray[4] = true;
        blArray[6] = true;
        blArray[7] = true;
        blArray[8] = true;
        blArray[9] = true;
        blArray[10] = true;
        implements = blArray;
    }

    private static void throws() {
        Object[] objectArray = new Object[]{0.005};
        bp.class = objectArray;
    }

    private static /* synthetic */ void ntfClinit() {
        bp.break();
        bp.class();
        bp.protected();
        bp.throws();
    }

    private static void protected() {
        private = new double[]{0.005, 0.005};
    }
}

