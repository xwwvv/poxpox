/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.bX;
import protected.rfH;
import protected.rs_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.bJ
 */
public class bj_0
extends rs_2 {
    private static boolean[] break;
    private static short[] byte;

    private static void byte() {
        short[] sArray = new short[2];
        sArray[1] = 2;
        byte = sArray;
    }

    public bj_0(bX bX2, rfH rfH2) {
        super(rfH2);
    }

    static {
        bj_0.ntfClinit();
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0x10803766134B89C0L;
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0xBDD6FCF7;
    }

    @Override
    public boolean break(int n2, int n3, int n4) {
        return (Integer)this.class[byte[0]] == n2 && (Integer)this.class[byte[1]] == n4 ? break[0] : break[1];
    }

    public static String break(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{54, -70, -24, -59, -59, -113, -69, -52}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    private static /* synthetic */ void ntfClinit() {
        bj_0.protected();
        bj_0.byte();
    }

    private static void protected() {
        boolean[] blArray = new boolean[2];
        blArray[0] = true;
        break = blArray;
    }
}

