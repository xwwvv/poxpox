/*
 * Decompiled with CFR 0.152.
 */
package protected;

/*
 * Renamed from protected.yd
 */
public class yd_1
extends RuntimeException {
    public yd_1(String string, Throwable throwable) {
        super(string, throwable);
    }
}

