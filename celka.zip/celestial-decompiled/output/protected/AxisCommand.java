/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.case;
import protected.rb_2;
import protected.static;
import protected.try;
import protected.x;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class sb
extends try {
    private static short[] break;
    private static boolean[] throws;
    private static byte[] case;
    private static String[] catch;

    public sb(case case_) {
        String[] stringArray = new String[case[0]];
        stringArray[sb.throws[0]] = catch[0];
        stringArray[sb.throws[1]] = catch[1];
        super(case_, stringArray);
    }

    static {
        sb.ntfClinit();
    }

    @Override
    public void class(String string, static static_) throws x {
        static_.class(throws[2]);
        rb_2 rb_22 = new rb_2();
        ((case)this.class[break[0]]).import().class(rb_22);
        Object[] objectArray = new Object[throws[3]];
        objectArray[sb.throws[4]] = ((Object)rb_22).toString();
        this.case(String.format(catch[2], objectArray));
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0x9967E64B981817BL;
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0x27AD2325;
    }

    @Override
    public Stream<String> break(String string, static static_) {
        return Stream.empty();
    }

    public static String break(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{-46, 16, -123, -114, 31, -41, -60, -111}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    private static void throws() {
        catch = new String[]{new String("axis"), new String("highway"), new String("Goal: %s"), new String("Set a goal to the axes"), new String("The axis command sets a goal that tells Baritone to head towards the nearest axis. That is, X=0 or Z=0."), new String(""), new String("Usage:"), new String("> axis")};
    }

    private static /* synthetic */ void ntfClinit() {
        sb.finally();
        sb.throws();
        sb.protected();
        sb.extends();
    }

    private static void finally() {
        boolean[] blArray = new boolean[7];
        blArray[1] = true;
        blArray[3] = true;
        blArray[6] = true;
        throws = blArray;
    }

    @Override
    public List<String> catch() {
        String[] stringArray = new String[case[1]];
        stringArray[sb.throws[5]] = catch[4];
        stringArray[sb.throws[6]] = catch[5];
        stringArray[sb.case[2]] = catch[6];
        stringArray[sb.case[3]] = catch[7];
        return Arrays.asList(stringArray);
    }

    private static void extends() {
        case = new byte[]{2, 4, 2, 3};
    }

    @Override
    public String implements() {
        return catch[3];
    }

    private static void protected() {
        break = new short[1];
    }
}

