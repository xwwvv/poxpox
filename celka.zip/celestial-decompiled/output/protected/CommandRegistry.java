/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.case;
import protected.sZ;
import protected.sc_0;
import protected.sm;
import protected.su_0;
import protected.sv_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.sN
 */
public class sn_0 {
    private static boolean[] break;
    private static String[] byte;
    private static byte[] protected;
    public Object[] class;
    private static short[] throws;

    private static void byte() {
        protected = new byte[]{3, 2, 4, 2, 3, 3, 2, 4};
    }

    public sn_0(case case_) {
        this.break();
        boolean[] blArray = new boolean[break[0]];
        blArray[sn_0.break[1]] = break[2];
        boolean[] blArray2 = blArray;
        case_.goto().class(new sc_0(this, blArray2, case_));
        String[] stringArray = new String[protected[0]];
        stringArray[sn_0.break[3]] = byte[0];
        stringArray[sn_0.break[4]] = byte[1];
        stringArray[sn_0.protected[1]] = byte[2];
        su_0 su_02 = new su_0(this, case_, stringArray, blArray2);
        this.class[sn_0.throws[0]] = su_02;
        String[] stringArray2 = new String[protected[2]];
        stringArray2[sn_0.break[5]] = byte[3];
        stringArray2[sn_0.break[6]] = byte[4];
        stringArray2[sn_0.protected[3]] = byte[5];
        stringArray2[sn_0.protected[4]] = byte[6];
        sm sm2 = new sm(this, case_, stringArray2, blArray2);
        this.class[sn_0.throws[1]] = sm2;
        String[] stringArray3 = new String[break[7]];
        stringArray3[sn_0.break[8]] = byte[7];
        sZ sZ2 = new sZ(this, case_, stringArray3, blArray2);
        this.class[sn_0.throws[2]] = sZ2;
        String[] stringArray4 = new String[protected[5]];
        stringArray4[sn_0.break[9]] = byte[8];
        stringArray4[sn_0.break[10]] = byte[9];
        stringArray4[sn_0.protected[6]] = byte[10];
        sv_0 sv_02 = new sv_0(this, case_, stringArray4, blArray2);
        this.class[sn_0.throws[3]] = sv_02;
    }

    static {
        sn_0.ntfClinit();
    }

    public static String class(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{95, -64, -86, 101, -87, 36, -24, 94}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0xDBA68183;
    }

    private static void class() {
        byte = new String[]{new String("pause"), new String("p"), new String("paws"), new String("resume"), new String("r"), new String("unpause"), new String("unpaws"), new String("paused"), new String("cancel"), new String("c"), new String("stop")};
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0xD2DEEB0828F4229CL;
    }

    private void break() {
        if (this.class == null) {
            Object[] objectArray = this.class = new Object[protected[7]];
        }
    }

    private static void throws() {
        short[] sArray = new short[4];
        sArray[1] = 1;
        sArray[2] = 2;
        sArray[3] = 3;
        throws = sArray;
    }

    private static /* synthetic */ void ntfClinit() {
        sn_0.protected();
        sn_0.class();
        sn_0.throws();
        sn_0.byte();
    }

    private static void protected() {
        boolean[] blArray = new boolean[11];
        blArray[0] = true;
        blArray[4] = true;
        blArray[6] = true;
        blArray[7] = true;
        blArray[10] = true;
        break = blArray;
    }
}

