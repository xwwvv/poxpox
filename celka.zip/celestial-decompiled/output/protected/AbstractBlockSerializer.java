/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.serialization.Codec
 */
package protected;

import com.mojang.serialization.Codec;
import protected.rrsd_0;
import protected.rrsj_0;
import protected.rrsk_0;
import protected.rrsx;
import protected.rrsx_0;
import protected.rrsz_0;
import protected.rvl_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.rrsW
 */
public class rrsw_0<P extends rrsk_0> {
    public static final rrsw_0<rrsz_0> class = rrsw_0.class("trunk_vine", rrsz_0.class);
    public static final rrsw_0<rrsd_0> break = rrsw_0.class("leave_vine", rrsd_0.class);
    public static final rrsw_0<rrsx> byte = rrsw_0.class("cocoa", rrsx.class);
    public static final rrsw_0<rrsj_0> protected = rrsw_0.class("beehive", rrsj_0.class);
    public static final rrsw_0<rrsx_0> throws = rrsw_0.class("alter_ground", rrsx_0.class);
    private final Codec<P> case;

    private rrsw_0(Codec<P> codec) {
        this.case = codec;
    }

    private static <P extends rrsk_0> rrsw_0<P> class(String string, Codec<P> codec) {
        return rvl_0.class(rvl_0.rS, string, new rrsw_0<P>(codec));
    }

    public Codec<P> class() {
        return this.case;
    }
}

