/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.ai_0;
import protected.iG;
import protected.ib_0;
import protected.is;
import protected.rYB;
import protected.rfH;
import protected.rjU;
import protected.xc_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public abstract class aV
extends is {
    protected aV(ai_0<? extends aV> ai_02, rYB rYB2) {
        super((ai_0<? extends is>)ai_02, rYB2);
    }

    @Override
    protected void class(double d, boolean bl2, xc_0 xc_02, rfH rfH2) {
    }

    @Override
    public boolean class(float f2, float f3) {
        return false;
    }

    @Override
    public void private(rjU rjU2) {
        if (this.rT()) {
            this.class(0.02f, rjU2);
            this.class(iG.SELF, this.rv());
            this.byte(this.rv().class((double)0.8f));
        } else if (this.ry()) {
            this.class(0.02f, rjU2);
            this.class(iG.SELF, this.rv());
            this.byte(this.rv().class(0.5));
        } else {
            float f2 = 0.91f;
            if (((Boolean)this.throws[20]).booleanValue()) {
                f2 = ((rYB)this.throws[7]).byte(new rfH(this.rx(), this.re() - 1.0, this.BO())).break().final() * 0.91f;
            }
            float f3 = 0.16277137f / (f2 * f2 * f2);
            f2 = 0.91f;
            if (((Boolean)this.throws[20]).booleanValue()) {
                f2 = ((rYB)this.throws[7]).byte(new rfH(this.rx(), this.re() - 1.0, this.BO())).break().final() * 0.91f;
            }
            this.class((Boolean)this.throws[20] != false ? 0.1f * f3 : 0.02f, rjU2);
            this.class(iG.SELF, this.rv());
            this.byte(this.rv().class((double)f2));
        }
        this.class((ib_0)this, false);
    }

    @Override
    public boolean o_() {
        return false;
    }
}

