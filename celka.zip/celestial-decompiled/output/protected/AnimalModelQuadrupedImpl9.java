/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableList
 */
package protected;

import com.google.common.collect.ImmutableList;
import protected.an;
import protected.iq_1;
import protected.rfU;
import protected.tx_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.wk
 */
public class wk_0<T extends an>
extends tx_2<T> {
    protected iq_1 class = new iq_1(this, 0, 0);
    protected iq_1 break;
    protected iq_1 byte;
    protected iq_1 protected;
    protected iq_1 throws;
    protected iq_1 case;

    public wk_0(int n2, float f2, boolean bl2, float f3, float f4, float f5, float f6, int n3) {
        super(bl2, f3, f4, f5, f6, n3);
        this.class.class(-4.0f, -4.0f, -8.0f, 8.0f, 8.0f, 8.0f, f2);
        this.class.class(0.0f, 18 - n2, -6.0f);
        this.break = new iq_1(this, 28, 8);
        this.break.class(-5.0f, -10.0f, -7.0f, 10.0f, 16.0f, 8.0f, f2);
        this.break.class(0.0f, 17 - n2, 2.0f);
        this.byte = new iq_1(this, 0, 16);
        this.byte.class(-2.0f, 0.0f, -2.0f, 4.0f, (float)n2, 4.0f, f2);
        this.byte.class(-3.0f, 24 - n2, 7.0f);
        this.protected = new iq_1(this, 0, 16);
        this.protected.class(-2.0f, 0.0f, -2.0f, 4.0f, (float)n2, 4.0f, f2);
        this.protected.class(3.0f, 24 - n2, 7.0f);
        this.throws = new iq_1(this, 0, 16);
        this.throws.class(-2.0f, 0.0f, -2.0f, 4.0f, (float)n2, 4.0f, f2);
        this.throws.class(-3.0f, 24 - n2, -5.0f);
        this.case = new iq_1(this, 0, 16);
        this.case.class(-2.0f, 0.0f, -2.0f, 4.0f, (float)n2, 4.0f, f2);
        this.case.class(3.0f, 24 - n2, -5.0f);
    }

    @Override
    public void class(T t2, float f2, float f3, float f4, float f5, float f6) {
        this.class.case = f6 * ((float)Math.PI / 180);
        this.class.catch = f5 * ((float)Math.PI / 180);
        this.break.case = 1.5707964f;
        this.byte.case = rfU.break(f2 * 0.6662f) * 1.4f * f3;
        this.protected.case = rfU.break(f2 * 0.6662f + (float)Math.PI) * 1.4f * f3;
        this.throws.case = rfU.break(f2 * 0.6662f + (float)Math.PI) * 1.4f * f3;
        this.case.case = rfU.break(f2 * 0.6662f) * 1.4f * f3;
    }

    @Override
    protected Iterable<iq_1> class() {
        return ImmutableList.of((Object)this.class);
    }

    @Override
    protected Iterable<iq_1> break() {
        return ImmutableList.of((Object)this.break, (Object)this.byte, (Object)this.protected, (Object)this.throws, (Object)this.case);
    }
}

