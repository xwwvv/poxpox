/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.io.DataInput;
import java.io.IOException;
import protected.rcg_1;
import protected.rcv_2;
import protected.rcz_1;
import protected.rcz_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.rcQ
 */
class rcq_2
implements rcv_2<rcz_2> {
    @Override
    public boolean byte() {
        return true;
    }

    rcq_2() {
    }

    public rcz_2 class(DataInput dataInput, int n2, rcg_1 rcg_12) throws IOException {
        rcg_12.class(128L);
        return rcz_2.class(dataInput.readDouble());
    }

    @Override
    public String class() {
        return "DOUBLE";
    }

    @Override
    public /* synthetic */ rcz_1 break(DataInput dataInput, int n2, rcg_1 rcg_12) throws IOException {
        return this.class(dataInput, n2, rcg_12);
    }

    @Override
    public String break() {
        return "TAG_Double";
    }
}

