/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.util.concurrent.atomic.AtomicReferenceArray;
import protected.ao_2;
import protected.rfj;
import protected.roj_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.Ah
 */
final class ah_2 {
    final AtomicReferenceArray<roj_0> break;
    final int byte;
    private final int protected;
    volatile int throws;
    volatile int case;
    int catch;
    final /* synthetic */ ao_2 class;

    public int byte() {
        return this.byte;
    }

    ah_2(ao_2 ao_22, int n2) {
        this.class = ao_22;
        this.byte = n2;
        this.protected = n2 * 2 + 1;
        this.break = new AtomicReferenceArray(this.protected * this.protected);
    }

    public void class(ah_2 ah_22) {
        this.throws = ah_22.class();
        this.case = ah_22.break();
        AtomicReferenceArray<roj_0> atomicReferenceArray = ah_22.protected();
        for (int k = 0; k < atomicReferenceArray.length(); ++k) {
            roj_0 roj_02 = atomicReferenceArray.get(k);
            if (roj_02 == null) continue;
            rfj rfj2 = roj_02.private();
            if (!this.break(rfj2.break, rfj2.byte)) continue;
            int n2 = this.class(rfj2.break, rfj2.byte);
            if (this.break.get(n2) != null) {
                throw new IllegalStateException("Doing this would mutate the client's REAL loaded chunks?!");
            }
            this.class(n2, roj_02);
        }
    }

    public int class() {
        return this.throws;
    }

    protected roj_0 class(int n2) {
        return this.break.get(n2);
    }

    int class(int n2, int n3) {
        return Math.floorMod(n3, this.protected) * this.protected + Math.floorMod(n2, this.protected);
    }

    protected roj_0 class(int n2, roj_0 roj_02, roj_0 roj_03) {
        if (this.break.compareAndSet(n2, roj_02, roj_03) && roj_03 == null) {
            --this.catch;
        }
        this.class.throws.class(roj_02);
        return roj_02;
    }

    protected void class(int n2, roj_0 roj_02) {
        roj_0 roj_03 = this.break.getAndSet(n2, roj_02);
        if (roj_03 != null) {
            --this.catch;
            this.class.throws.class(roj_03);
        }
        if (roj_02 != null) {
            ++this.catch;
        }
    }

    boolean break(int n2, int n3) {
        return Math.abs(n2 - this.throws) <= this.byte && Math.abs(n3 - this.case) <= this.byte;
    }

    public int break() {
        return this.case;
    }

    public AtomicReferenceArray<roj_0> protected() {
        return this.break;
    }
}

