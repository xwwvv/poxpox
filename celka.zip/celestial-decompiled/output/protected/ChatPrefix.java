/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.util.UUID;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public interface throw {
    public static final String class = String.format("<<%s>>", UUID.randomUUID());
}

