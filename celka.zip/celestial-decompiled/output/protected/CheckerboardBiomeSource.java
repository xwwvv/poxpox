/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
package protected;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import protected.rYY;
import protected.rYn;
import protected.rfU;
import protected.rfj;
import protected.rpn;
import protected.ryg_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class rYZ
implements rYn {
    private static final Logger protected = LogManager.getLogger();
    private static final int throws = (int)Math.round(Math.log(16.0) / Math.log(2.0)) - 2;
    private static final int case = (int)Math.round(Math.log(256.0) / Math.log(2.0)) - 2;
    public static final int class = 1 << throws + throws + case;
    public static final int break = (1 << throws) - 1;
    public static final int byte = (1 << case) - 1;
    private final rpn<ryg_0> catch;
    private final ryg_0[] private;

    public rYZ(rpn<ryg_0> rpn2, rfj rfj2, rYY rYY2, int[] nArray) {
        this(rpn2);
        int n2 = rfj2.break() >> 2;
        int n3 = rfj2.byte() >> 2;
        if (nArray != null) {
            for (int k = 0; k < nArray.length; ++k) {
                this.private[k] = rpn2.class(nArray[k]);
                if (this.private[k] != null) continue;
                int n4 = k & break;
                int n5 = k >> throws + throws & byte;
                int n6 = k >> throws & break;
                this.private[k] = rYY2.protected(n2 + n4, n5, n3 + n6);
            }
        } else {
            for (int k = 0; k < this.private.length; ++k) {
                int n7 = k & break;
                int n8 = k >> throws + throws & byte;
                int n9 = k >> throws & break;
                this.private[k] = rYY2.protected(n2 + n7, n8, n3 + n9);
            }
        }
    }

    public rYZ(rpn<ryg_0> rpn2, rfj rfj2, rYY rYY2) {
        this(rpn2);
        int n2 = rfj2.break() >> 2;
        int n3 = rfj2.byte() >> 2;
        for (int k = 0; k < this.private.length; ++k) {
            int n4 = k & break;
            int n5 = k >> throws + throws & byte;
            int n6 = k >> throws & break;
            this.private[k] = rYY2.protected(n2 + n4, n5, n3 + n6);
        }
    }

    public rYZ(rpn<ryg_0> rpn2, int[] nArray) {
        this(rpn2);
        for (int k = 0; k < this.private.length; ++k) {
            int n2 = nArray[k];
            ryg_0 ryg_02 = rpn2.class(n2);
            if (ryg_02 == null) {
                protected.warn("Received invalid biome id: " + n2);
                this.private[k] = rpn2.class(0);
                continue;
            }
            this.private[k] = ryg_02;
        }
    }

    private rYZ(rpn<ryg_0> rpn2) {
        this(rpn2, new ryg_0[rYZ.class]);
    }

    public rYZ(rpn<ryg_0> rpn2, ryg_0[] ryg_0Array) {
        this.catch = rpn2;
        this.private = ryg_0Array;
    }

    public int[] class() {
        int[] nArray = new int[this.private.length];
        for (int k = 0; k < this.private.length; ++k) {
            nArray[k] = this.catch.class(this.private[k]);
        }
        return nArray;
    }

    @Override
    public ryg_0 protected(int n2, int n3, int n4) {
        int n5 = n2 & break;
        int n6 = rfU.class(n3, 0, byte);
        int n7 = n4 & break;
        return this.private[n6 << throws + throws | n7 << throws | n5];
    }
}

