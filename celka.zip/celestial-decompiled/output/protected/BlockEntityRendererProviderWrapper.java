/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonElement
 *  com.mojang.brigadier.ImmutableStringReader
 *  com.mojang.brigadier.StringReader
 *  com.mojang.brigadier.exceptions.BuiltInExceptionProvider
 *  com.mojang.brigadier.exceptions.CommandSyntaxException
 */
package protected;

import com.google.gson.JsonElement;
import com.mojang.brigadier.ImmutableStringReader;
import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.exceptions.BuiltInExceptionProvider;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import java.util.function.Function;
import protected.rpY;
import protected.xu_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.XF
 */
public class xf_2
extends xu_2<Integer> {
    public static final xf_2 throws = new xf_2((Integer)null, (Integer)null);
    private final Long case;
    private final Long catch;

    public boolean byte(int n2) {
        if (this.byte != null && (Integer)this.byte > n2) {
            return false;
        }
        return this.protected == null || (Integer)this.protected >= n2;
    }

    private xf_2(Integer n2, Integer n3) {
        super(n2, n3);
        this.case = xf_2.class(n2);
        this.catch = xf_2.class(n3);
    }

    public static xf_2 class(JsonElement jsonElement) {
        return xf_2.class(jsonElement, throws, rpY::case, xf_2::new);
    }

    public static xf_2 class(StringReader stringReader) throws CommandSyntaxException {
        return xf_2.class(stringReader, n2 -> n2);
    }

    public static xf_2 class(StringReader stringReader, Function<Integer, Integer> function) throws CommandSyntaxException {
        return xf_2.class(stringReader, xf_2::class, Integer::parseInt, () -> ((BuiltInExceptionProvider)CommandSyntaxException.BUILT_IN_EXCEPTIONS).readerInvalidInt(), function);
    }

    private static xf_2 class(StringReader stringReader, Integer n2, Integer n3) throws CommandSyntaxException {
        if (n2 != null && n3 != null && n2 > n3) {
            throw break.createWithContext((ImmutableStringReader)stringReader);
        }
        return new xf_2(n2, n3);
    }

    public static xf_2 class(int n2) {
        return new xf_2(n2, n2);
    }

    private static Long class(Integer n2) {
        return n2 == null ? null : Long.valueOf(n2.longValue() * n2.longValue());
    }

    public static xf_2 break(int n2) {
        return new xf_2(n2, (Integer)null);
    }
}

