/*
 * Decompiled with CFR 0.152.
 */
package protected;

/*
 * Renamed from protected.BC
 */
public class bc_2 {
}

