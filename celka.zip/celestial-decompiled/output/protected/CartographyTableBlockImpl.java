/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.dm_2;
import protected.jq_1;
import protected.rYB;
import protected.rfH;
import protected.rff;
import protected.rgP;
import protected.rgn;
import protected.rhd_2;
import protected.rjo_1;
import protected.rjr_1;
import protected.rjz_1;
import protected.rlb_0;
import protected.rpm;
import protected.rpq;
import protected.ryz_1;
import protected.xc_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.Wo
 */
public class wo_1
extends dm_2 {
    private static final rgP volatile = new rgn("container.upgrade");

    protected wo_1(jq_1 jq_12) {
        super(jq_12);
    }

    @Override
    public rjz_1 class(xc_0 xc_02, rYB rYB2, rfH rfH2) {
        return new rjr_1((n2, rhz_22, rhd_22) -> new rjo_1(n2, rhz_22, rpq.class(rYB2, rfH2)), volatile);
    }

    @Override
    public ryz_1 class(xc_0 xc_02, rYB rYB2, rfH rfH2, rhd_2 rhd_22, rpm rpm2, rff rff2) {
        if (rYB2.continue) {
            return ryz_1.SUCCESS;
        }
        rhd_22.class(xc_02.break(rYB2, rfH2));
        rhd_22.break(rlb_0.t);
        return ryz_1.CONSUME;
    }
}

