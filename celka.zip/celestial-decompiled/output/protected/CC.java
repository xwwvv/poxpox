/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.cj_0;
import protected.gm;
import protected.lo_0;
import protected.rfU;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class CC
extends lo_0 {
    CC(gm gm2, double d, double d2, double d3, double d4) {
        super(gm2, d, d2, d3, 0.0, 0.0, 0.0);
        this.finally *= (double)0.01f;
        this.extends *= (double)0.01f;
        this.native *= (double)0.01f;
        this.extends += 0.2;
        this.synchronized = Math.max(0.0f, rfU.class(((float)d4 + 0.0f) * ((float)Math.PI * 2)) * 0.65f + 0.35f);
        this.return = Math.max(0.0f, rfU.class(((float)d4 + 0.33333334f) * ((float)Math.PI * 2)) * 0.65f + 0.35f);
        this.public = Math.max(0.0f, rfU.class(((float)d4 + 0.6666667f) * ((float)Math.PI * 2)) * 0.65f + 0.35f);
        this.throw *= 1.5f;
        this.this = 6;
    }

    @Override
    public float class(float f2) {
        return this.throw * rfU.class(((float)this.super + f2) / (float)this.this * 32.0f, 0.0f, 1.0f);
    }

    @Override
    public cj_0 class() {
        return cj_0.break;
    }

    @Override
    public void case() {
        this.protected = this.catch;
        this.throws = this.private;
        this.case = this.implements;
        if (this.super++ >= this.this) {
            this.finally();
        } else {
            this.class(this.finally, this.extends, this.native);
            if (this.private == this.throws) {
                this.finally *= 1.1;
                this.native *= 1.1;
            }
            this.finally *= (double)0.66f;
            this.extends *= (double)0.66f;
            this.native *= (double)0.66f;
            if (this.volatile) {
                this.finally *= (double)0.7f;
                this.native *= (double)0.7f;
            }
        }
    }
}

