/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonObject
 */
package protected;

import com.google.gson.JsonObject;
import protected.hg_2;
import protected.hl_1;
import protected.ho_1;
import protected.hz_1;
import protected.rhn_2;
import protected.rjU;
import protected.rqo_0;
import protected.rwl_1;
import protected.xf_2;
import protected.xz_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.XW
 */
public class xw_2
extends hg_2<xz_2> {
    static final rqo_0 class = new rqo_0("levitation");

    public void class(rhn_2 rhn_22, rjU rjU2, int n2) {
        this.class(rhn_22, (T xz_22) -> xz_22.class(rhn_22, rjU2, n2));
    }

    @Override
    public rqo_0 class() {
        return xw_2.class;
    }

    @Override
    public /* synthetic */ hz_1 class(JsonObject jsonObject, ho_1 ho_12, rwl_1 rwl_12) {
        return this.break(jsonObject, ho_12, rwl_12);
    }

    public xz_2 break(JsonObject jsonObject, ho_1 ho_12, rwl_1 rwl_12) {
        hl_1 hl_12 = hl_1.class(jsonObject.get("distance"));
        xf_2 xf_22 = xf_2.class(jsonObject.get("duration"));
        return new xz_2(ho_12, hl_12, xf_22);
    }
}

