/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.regex.Pattern;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.bl_2;
import protected.bn_2;
import protected.br_2;
import protected.by_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.Bg
 */
public class bg_2
extends bn_2
implements by_1 {
    private static boolean[] protected;
    public Object[] byte;
    private static short[] throws;
    private static String[] case;

    public bg_2() {
        super(case[0], (Pattern[])bl_2.class[throws[0]]);
        this.catch();
    }

    static {
        bg_2.ntfClinit();
    }

    @Override
    public String class() {
        this.catch();
        if ((br_2)((Object)this.byte[throws[4]]) == null) {
            return null;
        }
        return ((br_2)((Object)this.byte[throws[5]])).class();
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0xDAD9F41C;
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0xD1CA6BBB26DBA479L;
    }

    @Override
    public void throws(String string) {
        this.catch();
        super.throws(string);
        br_2 br_22 = br_2.class(string);
        this.byte[bg_2.throws[1]] = br_22;
        if ((br_2)((Object)this.byte[throws[2]]) != null) {
            this.protected(((br_2)((Object)this.byte[throws[3]])).class() + " " + this.throws().toLowerCase());
        }
    }

    private static /* synthetic */ void ntfClinit() {
        bg_2.finally();
        bg_2.implements();
        bg_2.private();
    }

    private static void finally() {
        protected = new boolean[]{true};
    }

    private void catch() {
        if (this.byte == null) {
            Object[] objectArray = this.byte = new Object[protected[0]];
        }
    }

    public static String catch(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{110, 26, -93, 80, -44, -29, 62, -117}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    private static void implements() {
        case = new String[]{new String("\u041c\u0430\u044f\u043a \u0443\u0431\u0438\u0439\u0446\u0430")};
    }

    private static void private() {
        short[] sArray = new short[6];
        sArray[0] = 18;
        throws = sArray;
    }
}

