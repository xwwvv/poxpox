/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.util.List;
import java.util.function.Function;
import protected.ral_1;
import protected.rap_1;
import protected.raz_1;
import protected.rgP;
import protected.rqo_0;
import protected.vd_2;
import protected.vh_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.vX
 */
abstract class vx_2
implements vd_2 {
    private final rap_1 break;
    final /* synthetic */ vh_2 class;

    @Override
    public rqo_0 byte() {
        return this.class.case.apply(this.break);
    }

    public vx_2(vh_2 vh_22, rap_1 rap_12) {
        this.class = vh_22;
        this.break = rap_12;
    }

    protected void class(int n2) {
        List<rap_1> list = this.class();
        int n3 = list.indexOf(this.break);
        list.remove(n3);
        list.add(n3 + n2, this.break);
        this.class.break.run();
    }

    protected abstract List<rap_1> class();

    protected abstract List<rap_1> break();

    @Override
    public rgP throws() {
        return this.break.class();
    }

    protected void finally() {
        this.class().remove(this.break);
        this.break.private().class(this.break(), this.break, Function.identity(), true);
        this.class.break.run();
    }

    @Override
    public raz_1 catch() {
        return this.break.implements();
    }

    @Override
    public boolean extends() {
        List<rap_1> list = this.class();
        int n2 = list.indexOf(this.break);
        return n2 > 0 && !list.get(n2 - 1).catch();
    }

    @Override
    public rgP case() {
        return this.break.break();
    }

    @Override
    public boolean implements() {
        return this.break.case();
    }

    @Override
    public ral_1 protected() {
        return this.break.byte();
    }

    @Override
    public boolean private() {
        return this.break.catch();
    }

    @Override
    public void final() {
        this.class(1);
    }

    @Override
    public boolean volatile() {
        List<rap_1> list = this.class();
        int n2 = list.indexOf(this.break);
        return n2 >= 0 && n2 < list.size() - 1 && !list.get(n2 + 1).catch();
    }

    @Override
    public void native() {
        this.class(-1);
    }
}

