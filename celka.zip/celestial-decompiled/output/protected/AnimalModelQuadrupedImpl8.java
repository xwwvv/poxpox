/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableList
 */
package protected;

import com.google.common.collect.ImmutableList;
import protected.an;
import protected.iq_1;
import protected.rfU;
import protected.wn_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.wJ
 */
public class wj_0<T extends an>
extends wn_0<T> {
    private final iq_1 class;
    private final iq_1 break;
    private final iq_1 byte;
    private final iq_1 protected;
    private final iq_1 throws;
    private final iq_1 case;
    private final iq_1 catch;
    private final iq_1 private;
    private final iq_1 implements;
    private final iq_1 finally;
    private final iq_1 extends;
    private final iq_1 native;
    private final iq_1 volatile;

    public wj_0() {
        this.return = 32;
        this.public = 32;
        int n2 = 22;
        this.class = new iq_1(this, 0, 0);
        this.class.class(-4.0f, -8.0f, -4.0f, 8.0f, 8.0f, 8.0f);
        this.class.class(0.0f, 22.0f, 0.0f);
        this.break = new iq_1(this, 24, 0);
        this.break.class(-2.0f, 0.0f, -1.0f, 2.0f, 1.0f, 2.0f);
        this.break.class(-4.0f, 15.0f, -2.0f);
        this.byte = new iq_1(this, 24, 3);
        this.byte.class(0.0f, 0.0f, -1.0f, 2.0f, 1.0f, 2.0f);
        this.byte.class(4.0f, 15.0f, -2.0f);
        this.protected = new iq_1(this, 15, 17);
        this.protected.class(-4.0f, -1.0f, 0.0f, 8.0f, 1.0f, 0.0f);
        this.protected.class(0.0f, 14.0f, -4.0f);
        this.protected.case = 0.7853982f;
        this.throws = new iq_1(this, 14, 16);
        this.throws.class(-4.0f, -1.0f, 0.0f, 8.0f, 1.0f, 1.0f);
        this.throws.class(0.0f, 14.0f, 0.0f);
        this.case = new iq_1(this, 23, 18);
        this.case.class(-4.0f, -1.0f, 0.0f, 8.0f, 1.0f, 0.0f);
        this.case.class(0.0f, 14.0f, 4.0f);
        this.case.case = -0.7853982f;
        this.catch = new iq_1(this, 5, 17);
        this.catch.class(-1.0f, -8.0f, 0.0f, 1.0f, 8.0f, 0.0f);
        this.catch.class(-4.0f, 22.0f, -4.0f);
        this.catch.catch = -0.7853982f;
        this.private = new iq_1(this, 1, 17);
        this.private.class(0.0f, -8.0f, 0.0f, 1.0f, 8.0f, 0.0f);
        this.private.class(4.0f, 22.0f, -4.0f);
        this.private.catch = 0.7853982f;
        this.implements = new iq_1(this, 15, 20);
        this.implements.class(-4.0f, 0.0f, 0.0f, 8.0f, 1.0f, 0.0f);
        this.implements.class(0.0f, 22.0f, -4.0f);
        this.implements.case = -0.7853982f;
        this.extends = new iq_1(this, 15, 20);
        this.extends.class(-4.0f, 0.0f, 0.0f, 8.0f, 1.0f, 0.0f);
        this.extends.class(0.0f, 22.0f, 0.0f);
        this.finally = new iq_1(this, 15, 20);
        this.finally.class(-4.0f, 0.0f, 0.0f, 8.0f, 1.0f, 0.0f);
        this.finally.class(0.0f, 22.0f, 4.0f);
        this.finally.case = 0.7853982f;
        this.native = new iq_1(this, 9, 17);
        this.native.class(-1.0f, -8.0f, 0.0f, 1.0f, 8.0f, 0.0f);
        this.native.class(-4.0f, 22.0f, 4.0f);
        this.native.catch = 0.7853982f;
        this.volatile = new iq_1(this, 9, 17);
        this.volatile.class(0.0f, -8.0f, 0.0f, 1.0f, 8.0f, 0.0f);
        this.volatile.class(4.0f, 22.0f, 4.0f);
        this.volatile.catch = -0.7853982f;
    }

    @Override
    public Iterable<iq_1> class() {
        return ImmutableList.of((Object)this.class, (Object)this.break, (Object)this.byte, (Object)this.protected, (Object)this.throws, (Object)this.case, (Object)this.catch, (Object)this.private, (Object)this.implements, (Object)this.extends, (Object)this.finally, (Object)this.native, (Object[])new iq_1[]{this.volatile});
    }

    @Override
    public void class(T t2, float f2, float f3, float f4, float f5, float f6) {
        this.break.private = -0.2f + 0.4f * rfU.class(f4 * 0.2f);
        this.byte.private = 0.2f - 0.4f * rfU.class(f4 * 0.2f);
    }
}

