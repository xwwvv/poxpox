/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableList
 *  com.google.common.collect.Iterables
 */
package protected;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.Iterables;
import protected.an;
import protected.iq_1;
import protected.ml_1;
import protected.ok_2;
import protected.rfU;
import protected.ron_1;
import protected.wk_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class wt<T extends ron_1>
extends wk_0<T> {
    private final iq_1 catch;

    public wt(float f2) {
        super(12, f2, true, 120.0f, 0.0f, 9.0f, 6.0f, 120);
        this.return = 128;
        this.public = 64;
        this.class = new iq_1(this, 3, 0);
        this.class.class(-3.0f, -1.0f, -3.0f, 6.0f, 5.0f, 6.0f, 0.0f);
        this.class.class(0.0f, 19.0f, -10.0f);
        this.break = new iq_1(this);
        this.break.class(7, 37).class(-9.5f, 3.0f, -10.0f, 19.0f, 20.0f, 6.0f, 0.0f);
        this.break.class(31, 1).class(-5.5f, 3.0f, -13.0f, 11.0f, 18.0f, 3.0f, 0.0f);
        this.break.class(0.0f, 11.0f, -10.0f);
        this.catch = new iq_1(this);
        this.catch.class(70, 33).class(-4.5f, 3.0f, -14.0f, 9.0f, 18.0f, 1.0f, 0.0f);
        this.catch.class(0.0f, 11.0f, -10.0f);
        boolean bl2 = true;
        this.byte = new iq_1(this, 1, 23);
        this.byte.class(-2.0f, 0.0f, 0.0f, 4.0f, 1.0f, 10.0f, 0.0f);
        this.byte.class(-3.5f, 22.0f, 11.0f);
        this.protected = new iq_1(this, 1, 12);
        this.protected.class(-2.0f, 0.0f, 0.0f, 4.0f, 1.0f, 10.0f, 0.0f);
        this.protected.class(3.5f, 22.0f, 11.0f);
        this.throws = new iq_1(this, 27, 30);
        this.throws.class(-13.0f, 0.0f, -2.0f, 13.0f, 1.0f, 5.0f, 0.0f);
        this.throws.class(-5.0f, 21.0f, -4.0f);
        this.case = new iq_1(this, 27, 24);
        this.case.class(0.0f, 0.0f, -2.0f, 13.0f, 1.0f, 5.0f, 0.0f);
        this.case.class(5.0f, 21.0f, -4.0f);
    }

    @Override
    public void class(ml_1 ml_12, ok_2 ok_22, int n2, int n3, float f2, float f3, float f4, float f5) {
        boolean bl2 = this.catch.finally;
        if (bl2) {
            ml_12.class();
            ml_12.class(0.0, (double)-0.08f, 0.0);
        }
        super.class(ml_12, ok_22, n2, n3, f2, f3, f4, f5);
        if (bl2) {
            ml_12.break();
        }
    }

    @Override
    public void class(T t2, float f2, float f3, float f4, float f5, float f6) {
        super.class(t2, f2, f3, f4, f5, f6);
        this.byte.case = rfU.break(f2 * 0.6662f * 0.6f) * 0.5f * f3;
        this.protected.case = rfU.break(f2 * 0.6662f * 0.6f + (float)Math.PI) * 0.5f * f3;
        this.throws.private = rfU.break(f2 * 0.6662f * 0.6f + (float)Math.PI) * 0.5f * f3;
        this.case.private = rfU.break(f2 * 0.6662f * 0.6f) * 0.5f * f3;
        this.throws.case = 0.0f;
        this.case.case = 0.0f;
        this.throws.catch = 0.0f;
        this.case.catch = 0.0f;
        this.byte.catch = 0.0f;
        this.protected.catch = 0.0f;
        this.catch.case = 1.5707964f;
        if (!((an)t2).rT() && ((an)t2).BL()) {
            float f7 = ((ron_1)t2).n() ? 4.0f : 1.0f;
            float f8 = ((ron_1)t2).n() ? 2.0f : 1.0f;
            float f9 = 5.0f;
            this.throws.catch = rfU.break(f7 * f2 * 5.0f + (float)Math.PI) * 8.0f * f3 * f8;
            this.throws.private = 0.0f;
            this.case.catch = rfU.break(f7 * f2 * 5.0f) * 8.0f * f3 * f8;
            this.case.private = 0.0f;
            this.byte.catch = rfU.break(f2 * 5.0f + (float)Math.PI) * 3.0f * f3;
            this.byte.case = 0.0f;
            this.protected.catch = rfU.break(f2 * 5.0f) * 3.0f * f3;
            this.protected.case = 0.0f;
        }
        this.catch.finally = !this.int && ((ron_1)t2).L();
    }

    @Override
    protected Iterable<iq_1> break() {
        return Iterables.concat(super.break(), (Iterable)ImmutableList.of((Object)this.catch));
    }
}

