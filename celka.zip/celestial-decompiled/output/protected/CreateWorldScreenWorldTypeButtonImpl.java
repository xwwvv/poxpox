/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.util.Objects;
import java.util.Optional;
import protected.lf_2;
import protected.ll_2;
import protected.mN;
import protected.rVi;
import protected.rgP;
import protected.vk_1;

/*
 * Renamed from protected.vU
 * Illegal identifiers - consider using --renameillegalidents true
 */
class vu_1
extends lf_2 {
    final /* synthetic */ vk_1 class;

    vu_1(vk_1 vk_12, int n2, int n3, int n4, int n5, rgP rgP2, ll_2 ll_22) {
        this.class = vk_12;
        super(n2, n3, n4, n5, rgP2, ll_22);
    }

    @Override
    protected rVi A_() {
        return Objects.equals(this.class.int, Optional.of(mN.break)) ? super.A_().break(". ").class(vk_1.protected) : super.A_();
    }

    @Override
    public rgP C_() {
        return super.C_().case().break(" ").class(this.class.int.map(mN::class).orElse(vk_1.byte));
    }
}

