/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.util.Map;
import java.util.Random;
import protected.an;
import protected.eC;
import protected.ea_0;
import protected.ef_0;
import protected.ev_0;
import protected.ey_0;
import protected.ib_0;
import protected.rdn_1;
import protected.rxS;
import protected.rxq_1;
import protected.rye_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.az
 */
public class az_0
extends ev_0 {
    public az_0(ef_0 ef_02, rxq_1 ... rxq_1Array) {
        super(ef_02, eC.ARMOR_CHEST, rxq_1Array);
    }

    @Override
    public boolean class(rdn_1 rdn_12) {
        return rdn_12.break() instanceof rxS ? true : super.class(rdn_12);
    }

    public static boolean class(int n2, Random random) {
        if (n2 <= 0) {
            return false;
        }
        return random.nextFloat() < 0.15f * (float)n2;
    }

    @Override
    public int class(int n2) {
        return 10 + 20 * (n2 - 1);
    }

    @Override
    public int class() {
        return 3;
    }

    @Override
    public int break(int n2) {
        return super.class(n2) + 50;
    }

    public static int break(int n2, Random random) {
        return n2 > 10 ? n2 - 10 : 1 + random.nextInt(4);
    }

    @Override
    public void break(ib_0 ib_03, an an2, int n2) {
        Random random = ib_03.Sa();
        Map.Entry<rxq_1, rdn_1> entry = ea_0.break(ey_0.private, ib_03);
        if (az_0.class(n2, random)) {
            if (an2 != null) {
                an2.break(rye_1.class(ib_03), az_0.break(n2, random));
            }
            if (entry != null) {
                entry.getValue().class(2, ib_03, ib_02 -> ib_02.break((rxq_1)((Object)((Object)entry.getKey()))));
            }
        }
    }
}

