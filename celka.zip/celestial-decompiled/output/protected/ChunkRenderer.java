/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import protected.HU;
import protected.rYB;
import protected.rfH;
import protected.rfU;
import protected.rfj;
import protected.rpr_0;
import protected.rrbb;
import protected.rrxH;
import protected.yq_2;
import protected.yx_1;
import protected.yz_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.yO
 */
public class yo_1 {
    protected final yx_1 class;
    protected final rYB break;
    protected int byte;
    protected int protected;
    protected int throws;
    public yq_2[] case;
    private Map<rfj, rrxH[]> catch = new HashMap<rfj, rrxH[]>();

    public yo_1(yz_1 yz_12, rYB rYB2, int n2, yx_1 yx_12) {
        this.class = yx_12;
        this.break = rYB2;
        this.class(n2);
        this.class(yz_12);
    }

    public void class(double d, double d2) {
        int n2 = rfU.byte(d);
        int n3 = rfU.byte(d2);
        for (int k = 0; k < this.protected; ++k) {
            int n4 = this.protected * 16;
            int n5 = n2 - 8 - n4 / 2;
            int n6 = n5 + Math.floorMod(k * 16 - n5, n4);
            for (int i2 = 0; i2 < this.throws; ++i2) {
                int n7 = this.throws * 16;
                int n8 = n3 - 8 - n7 / 2;
                int n9 = n8 + Math.floorMod(i2 * 16 - n8, n7);
                for (int i3 = 0; i3 < this.byte; ++i3) {
                    int n10 = i3 * 16;
                    yq_2 yq_22 = this.case[this.class(k, i3, i2)];
                    yq_22.class(n6, n10, n9);
                }
            }
        }
    }

    public void class(int n2, int n3, int n4, boolean bl2) {
        int n5 = Math.floorMod(n2, this.protected);
        int n6 = Math.floorMod(n3, this.byte);
        int n7 = Math.floorMod(n4, this.throws);
        yq_2 yq_22 = this.case[this.class(n5, n6, n7)];
        yq_22.class(bl2);
    }

    public yq_2 class(rfH rfH2) {
        int n2 = rfH2.b_() >> 4;
        int n3 = rfH2.c_() >> 4;
        int n4 = rfH2.d_() >> 4;
        if (n3 >= 0 && n3 < this.byte) {
            n2 = rfU.break(n2, this.protected);
            n4 = rfU.break(n4, this.throws);
            return this.case[this.class(n2, n3, n4)];
        }
        return null;
    }

    private void class(yq_2 yq_22) {
        int n2;
        rfH rfH2 = yq_22.throws();
        int n3 = rfH2.b_() >> 8 << 8;
        int n4 = rfH2.d_() >> 8 << 8;
        rfj rfj2 = new rfj(n3, n4);
        HU[] hUArray = HU.s;
        rrxH[] rrxHArray = this.catch.get(rfj2);
        if (rrxHArray == null) {
            rrxHArray = new rrxH[hUArray.length];
            for (n2 = 0; n2 < hUArray.length; ++n2) {
                rrxHArray[n2] = new rrxH(hUArray[n2]);
            }
            this.catch.put(rfj2, rrxHArray);
        }
        for (n2 = 0; n2 < hUArray.length; ++n2) {
            HU hU = hUArray[n2];
            rrxH rrxH2 = rrxHArray[n2];
            if (rrxH2 == null) continue;
            yq_22.class(hU).class(rrxH2);
        }
    }

    protected void class(yz_1 yz_12) {
        int n2;
        int n3;
        int n4 = this.protected * this.byte * this.throws;
        this.case = new yq_2[n4];
        for (n3 = 0; n3 < this.protected; ++n3) {
            for (int k = 0; k < this.byte; ++k) {
                for (n2 = 0; n2 < this.throws; ++n2) {
                    int n5 = this.class(n3, k, n2);
                    yz_1 yz_13 = yz_12;
                    Objects.requireNonNull(yz_13);
                    this.case[n5] = new yq_2(yz_13);
                    this.case[n5].class(n3 * 16, k * 16, n2 * 16);
                    if (!rrbb.rp() || !rrbb.ry()) continue;
                    this.class(this.case[n5]);
                }
            }
        }
        for (n3 = 0; n3 < this.case.length; ++n3) {
            yq_2 yq_22 = this.case[n3];
            for (n2 = 0; n2 < rpr_0.VALUES.length; ++n2) {
                rpr_0 rpr_02 = rpr_0.VALUES[n2];
                rfH rfH2 = yq_22.class(rpr_02);
                yq_2 yq_23 = this.class(rfH2);
                yq_22.class(rpr_02, yq_23);
            }
        }
    }

    public void class() {
        for (yq_2 yq_22 : this.case) {
            yq_22.protected();
        }
        this.break();
    }

    private int class(int n2, int n3, int n4) {
        return (n4 * this.byte + n3) * this.protected + n2;
    }

    protected void class(int n2) {
        int n3;
        this.protected = n3 = n2 * 2 + 1;
        this.byte = 16;
        this.throws = n3;
    }

    public void break() {
        for (rfj rfj2 : this.catch.keySet()) {
            rrxH[] rrxHArray = this.catch.get(rfj2);
            for (int k = 0; k < rrxHArray.length; ++k) {
                rrxH rrxH2 = rrxHArray[k];
                if (rrxH2 != null) {
                    rrxH2.protected();
                }
                rrxHArray[k] = null;
            }
        }
        this.catch.clear();
    }
}

