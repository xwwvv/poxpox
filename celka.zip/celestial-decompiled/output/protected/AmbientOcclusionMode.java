/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.util.Arrays;
import java.util.Comparator;
import protected.rfU;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.Vh
 */
public final class vh_0
extends Enum<vh_0> {
    public static final /* enum */ vh_0 OFF = new vh_0(0, "options.ao.off");
    public static final /* enum */ vh_0 MIN = new vh_0(1, "options.ao.min");
    public static final /* enum */ vh_0 MAX = new vh_0(2, "options.ao.max");
    private static final vh_0[] VALUES;
    private final int id;
    private final String resourceKey;
    private static final /* synthetic */ vh_0[] $VALUES;

    private static /* synthetic */ vh_0[] byte() {
        return new vh_0[]{OFF, MIN, MAX};
    }

    private vh_0(int n3, String string2) {
        this.id = n3;
        this.resourceKey = string2;
    }

    static {
        $VALUES = vh_0.byte();
        VALUES = (vh_0[])Arrays.stream(vh_0.values()).sorted(Comparator.comparingInt(vh_0::class)).toArray(vh_0[]::new);
    }

    public static vh_0[] values() {
        return (vh_0[])$VALUES.clone();
    }

    public static vh_0 valueOf(String string) {
        return Enum.valueOf(vh_0.class, string);
    }

    public int class() {
        return this.id;
    }

    public static vh_0 class(int n2) {
        return VALUES[rfU.break(n2, VALUES.length)];
    }

    public String break() {
        return this.resourceKey;
    }
}

