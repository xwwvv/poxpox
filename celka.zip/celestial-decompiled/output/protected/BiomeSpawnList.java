/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableList
 *  com.google.common.collect.ImmutableMap
 *  com.mojang.datafixers.kinds.App
 *  com.mojang.datafixers.kinds.Applicative
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.Keyable
 *  com.mojang.serialization.MapCodec
 *  com.mojang.serialization.codecs.RecordCodecBuilder
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
package protected;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import com.mojang.datafixers.kinds.App;
import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.Keyable;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import java.util.stream.Stream;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import protected.aH;
import protected.ai_0;
import protected.rYf;
import protected.rpH;
import protected.rqR;
import protected.rvl_0;
import protected.ryi_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class rYt {
    public static final Logger class = LogManager.getLogger();
    public static final rYt break = new rYt(0.1f, (Map)Stream.of(aH.values()).collect(ImmutableMap.toImmutableMap(aH2 -> aH2, aH2 -> ImmutableList.of())), (Map<ai_0<?>, ryi_0>)ImmutableMap.of(), false);
    public static final MapCodec<rYt> byte = RecordCodecBuilder.mapCodec(instance -> instance.group((App)Codec.FLOAT.optionalFieldOf("creature_spawn_probability", (Object)Float.valueOf(0.1f)).forGetter(rYt2 -> Float.valueOf(rYt2.protected)), (App)Codec.simpleMap(aH.CODEC, (Codec)rYf.class.listOf().promotePartial((Consumer)((Object)rqR.class("Spawn data: ", arg_0 -> ((Logger)rYt.class).error(arg_0)))), (Keyable)rpH.class(aH.values())).fieldOf("spawners").forGetter(rYt2 -> rYt2.throws), (App)Codec.simpleMap(rvl_0.transient, ryi_0.class, rvl_0.transient).fieldOf("spawn_costs").forGetter(rYt2 -> rYt2.case), (App)Codec.BOOL.fieldOf("player_spawn_friendly").orElse((Object)false).forGetter(rYt::break)).apply((Applicative)instance, rYt::new));
    private final float protected;
    private final Map<aH, List<rYf>> throws;
    private final Map<ai_0<?>, ryi_0> case;
    private final boolean catch;

    rYt(float f2, Map<aH, List<rYf>> map, Map<ai_0<?>, ryi_0> map2, boolean bl2) {
        this.protected = f2;
        this.throws = map;
        this.case = map2;
        this.catch = bl2;
    }

    public List<rYf> class(aH aH2) {
        return this.throws.getOrDefault(aH2, (List<rYf>)ImmutableList.of());
    }

    public float class() {
        return this.protected;
    }

    public ryi_0 class(ai_0<?> ai_02) {
        return this.case.get(ai_02);
    }

    public boolean break() {
        return this.catch;
    }
}

