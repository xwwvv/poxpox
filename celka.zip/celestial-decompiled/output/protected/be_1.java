/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.bg_1;
import protected.class;
import protected.pv_2;
import protected.rrbb;
import protected.rrfu_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.BE
 */
public class be_1
extends pv_2 {
    private static short[] break;
    private static boolean[] byte;

    public be_1(class clazz) {
        super(clazz);
    }

    static {
        be_1.ntfClinit();
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0x37C4A1CA;
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0xF1AA189013A66E9EL;
    }

    private static void class() {
        byte = new boolean[1];
    }

    @Override
    public void class(rrfu_1 rrfu_12) {
        try {
            bg_1[] bg_1Array = (bg_1[])bg_1.staticFieldsd25d445181413210921a2969c1bcd756[break[0]];
            int n2 = bg_1Array.length;
            for (int k = byte[0]; k < n2; ++k) {
                bg_1 bg_12 = bg_1Array[k];
                URI uRI = URI.create(bg_12.class());
                rrbb.class(uRI);
            }
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    private static void break() {
        break = new short[]{4};
    }

    public static String break(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{-72, -3, -80, 19, 120, 42, 57, -40}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    private static /* synthetic */ void ntfClinit() {
        be_1.class();
        be_1.break();
    }
}

