/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.bb_0;
import protected.bm_0;
import protected.br_0;
import protected.class;
import protected.rVi;
import protected.rrqx_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.bP
 */
public class bp_0
extends bm_0 {
    private static boolean[] byte;
    public Object[] class;
    private static short[] protected;

    public bp_0(br_0 br_02, class clazz) {
        super(clazz);
        this.implements();
        br_0 br_03 = br_02;
        this.class[bp_0.protected[0]] = br_03;
    }

    static {
        bp_0.ntfClinit();
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0x406DA31DBCB8F042L;
    }

    @Override
    public void class(bb_0 bb_02, rVi rVi2) {
        this.implements();
        super.class(bb_02, rVi2);
        ((br_0)this.class[protected[1]]).protected();
        ((rrqx_1)rrqx_1.staticFields09f1f28026cd378cb9df490a64ac8f2a[protected[2]]).private().static().class(rVi2);
    }

    public static String class(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{-65, -31, -36, 44, -107, 69, 2, -50}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0x23D6E1CE;
    }

    private static /* synthetic */ void ntfClinit() {
        bp_0.finally();
        bp_0.private();
    }

    private static void finally() {
        byte = new boolean[]{true};
    }

    private void implements() {
        if (this.class == null) {
            Object[] objectArray = this.class = new Object[byte[0]];
        }
    }

    private static void private() {
        protected = new short[3];
    }
}

