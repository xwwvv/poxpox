/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class bK {
    public static Object[] class;
    private static boolean[] break;
    private static byte[] byte;

    private static void byte() {
        boolean[] blArray = new boolean[10];
        blArray[2] = true;
        blArray[3] = true;
        blArray[9] = true;
        break = blArray;
    }

    static {
        bK.ntfClinit();
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0x242A8C9E;
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0xB44B9FA822B0790FL;
    }

    public static String class(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{70, 13, -10, 97, -98, -53, -124, -22}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    private static void class() {
        Object[] objectArray = new Object[1];
        int[] nArray = new int[6];
        nArray[0] = 5;
        nArray[1] = 1;
        nArray[2] = 2;
        nArray[3] = 4;
        nArray[4] = 3;
        objectArray[0] = nArray;
        bK.class = objectArray;
    }

    private static void break() {
        byte = new byte[]{2, 2, 4, 3, 3, 4, 5};
    }

    private static /* synthetic */ void ntfClinit() {
        bK.byte();
        bK.break();
        bK.class();
    }
}

