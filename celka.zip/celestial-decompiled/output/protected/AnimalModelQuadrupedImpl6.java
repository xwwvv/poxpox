/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableList
 *  com.google.common.collect.Iterables
 *  com.google.common.collect.Lists
 */
package protected;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import java.util.List;
import java.util.Random;
import protected.HU;
import protected.an;
import protected.ib_0;
import protected.iq_1;
import protected.ml_1;
import protected.ok_2;
import protected.rpZ;
import protected.rrup_0;
import protected.rxq_1;
import protected.tw_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.wh
 */
public class wh_0<T extends ib_0>
extends tw_1<T>
implements rrup_0 {
    private List<iq_1> native = Lists.newArrayList();
    public final iq_1 new;
    public final iq_1 continue;
    public final iq_1 super;
    public final iq_1 this;
    public final iq_1 else;
    private final iq_1 volatile;
    private final iq_1 goto;
    private final boolean while;

    public wh_0(float f2, boolean bl2) {
        super(HU::private, f2, 0.0f, 64, 64);
        this.while = bl2;
        this.goto = new iq_1(this, 24, 0);
        this.goto.class(-3.0f, -6.0f, -1.0f, 6.0f, 6.0f, 1.0f, f2);
        this.volatile = new iq_1(this, 0, 0);
        this.volatile.break(64, 32);
        this.volatile.class(-5.0f, 0.0f, -1.0f, 10.0f, 16.0f, 1.0f, f2);
        if (bl2) {
            this.throws = new iq_1(this, 32, 48);
            this.throws.class(-1.0f, -2.0f, -2.0f, 3.0f, 12.0f, 4.0f, f2);
            this.throws.class(5.0f, 2.5f, 0.0f);
            this.protected = new iq_1(this, 40, 16);
            this.protected.class(-2.0f, -2.0f, -2.0f, 3.0f, 12.0f, 4.0f, f2);
            this.protected.class(-5.0f, 2.5f, 0.0f);
            this.new = new iq_1(this, 48, 48);
            this.new.class(-1.0f, -2.0f, -2.0f, 3.0f, 12.0f, 4.0f, f2 + 0.25f);
            this.new.class(5.0f, 2.5f, 0.0f);
            this.continue = new iq_1(this, 40, 32);
            this.continue.class(-2.0f, -2.0f, -2.0f, 3.0f, 12.0f, 4.0f, f2 + 0.25f);
            this.continue.class(-5.0f, 2.5f, 10.0f);
        } else {
            this.throws = new iq_1(this, 32, 48);
            this.throws.class(-1.0f, -2.0f, -2.0f, 4.0f, 12.0f, 4.0f, f2);
            this.throws.class(5.0f, 2.0f, 0.0f);
            this.new = new iq_1(this, 48, 48);
            this.new.class(-1.0f, -2.0f, -2.0f, 4.0f, 12.0f, 4.0f, f2 + 0.25f);
            this.new.class(5.0f, 2.0f, 0.0f);
            this.continue = new iq_1(this, 40, 32);
            this.continue.class(-3.0f, -2.0f, -2.0f, 4.0f, 12.0f, 4.0f, f2 + 0.25f);
            this.continue.class(-5.0f, 2.0f, 10.0f);
        }
        this.catch = new iq_1(this, 16, 48);
        this.catch.class(-2.0f, 0.0f, -2.0f, 4.0f, 12.0f, 4.0f, f2);
        this.catch.class(1.9f, 12.0f, 0.0f);
        this.super = new iq_1(this, 0, 48);
        this.super.class(-2.0f, 0.0f, -2.0f, 4.0f, 12.0f, 4.0f, f2 + 0.25f);
        this.super.class(1.9f, 12.0f, 0.0f);
        this.this = new iq_1(this, 0, 32);
        this.this.class(-2.0f, 0.0f, -2.0f, 4.0f, 12.0f, 4.0f, f2 + 0.25f);
        this.this.class(-1.9f, 12.0f, 0.0f);
        this.else = new iq_1(this, 16, 32);
        this.else.class(-4.0f, 0.0f, -2.0f, 8.0f, 12.0f, 4.0f, f2 + 0.25f);
        this.else.class(0.0f, 0.0f, 0.0f);
    }

    @Override
    public void class(T t2, float f2, float f3, float f4, float f5, float f6) {
        super.class(t2, f2, f3, f4, f5, f6);
        this.super.class(this.catch);
        this.this.class(this.case);
        this.new.class(this.throws);
        this.continue.class(this.protected);
        this.else.class(this.byte);
        if (((ib_0)t2).class(rxq_1.CHEST).class()) {
            if (((an)t2).x()) {
                this.volatile.throws = 1.4f;
                this.volatile.protected = 1.85f;
            } else {
                this.volatile.throws = 0.0f;
                this.volatile.protected = 0.0f;
            }
        } else if (((an)t2).x()) {
            this.volatile.throws = 0.3f;
            this.volatile.protected = 0.8f;
        } else {
            this.volatile.throws = -1.1f;
            this.volatile.protected = -0.85f;
        }
    }

    @Override
    public void class(rpZ rpZ2, ml_1 ml_12) {
        iq_1 iq_12 = this.class(rpZ2);
        if (this.while) {
            float f2 = 0.5f * (float)(rpZ2 == rpZ.RIGHT ? 1 : -1);
            iq_12.byte += f2;
            iq_12.class(ml_12);
            iq_12.byte -= f2;
        } else {
            iq_12.class(ml_12);
        }
    }

    public iq_1 class(Random random) {
        return this.native.get(random.nextInt(this.native.size()));
    }

    public void class(ml_1 ml_12, ok_2 ok_22, int n2, int n3) {
        this.goto.class(this.class);
        this.goto.byte = 0.0f;
        this.goto.protected = 0.0f;
        this.goto.class(ml_12, ok_22, n2, n3);
    }

    @Override
    public /* synthetic */ void accept(Object object) {
        this.a_((iq_1)object);
    }

    public void break(ml_1 ml_12, ok_2 ok_22, int n2, int n3) {
        this.volatile.class(ml_12, ok_22, n2, n3);
    }

    @Override
    protected Iterable<iq_1> break() {
        return Iterables.concat(super.break(), (Iterable)ImmutableList.of((Object)this.super, (Object)this.this, (Object)this.new, (Object)this.continue, (Object)this.else));
    }

    @Override
    public iq_1 protected() {
        return this.volatile;
    }

    @Override
    public void a_(iq_1 iq_12) {
        if (this.native == null) {
            this.native = Lists.newArrayList();
        }
        this.native.add(iq_12);
    }

    @Override
    public void b_(boolean bl2) {
        super.b_(bl2);
        this.new.finally = bl2;
        this.continue.finally = bl2;
        this.super.finally = bl2;
        finally = bl2;
        this.else.finally = bl2;
        this.volatile.finally = bl2;
        this.goto.finally = bl2;
    }
}

