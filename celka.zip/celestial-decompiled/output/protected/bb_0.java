/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.D;
import protected.bm_0;
import protected.class;
import protected.rVi;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.bb
 */
public abstract class bb_0
implements D {
    private static boolean[] class;
    private static short[] break;
    private static byte[] protected;
    public Object[] byte;

    public class byte() {
        return (class)this.byte[break[7]];
    }

    public bb_0(class clazz, bm_0 bm_02) {
        this.catch();
        class clazz2 = clazz;
        this.byte[bb_0.break[0]] = clazz2;
        bm_0 bm_03 = bm_02;
        this.byte[bb_0.break[1]] = bm_03;
    }

    static {
        bb_0.ntfClinit();
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0x69C4DACBF2AEF56FL;
    }

    public void class(boolean bl2) {
        Boolean bl3 = bl2;
        this.byte[bb_0.break[3]] = bl3;
        if (((Boolean)this.byte[break[4]]).booleanValue()) {
            ((bm_0)this.byte[break[5]]).break(this);
        } else {
            ((bm_0)this.byte[break[6]]).byte(this);
        }
    }

    public void class(rVi rVi2) {
        ((bm_0)this.byte[break[2]]).class(this, rVi2);
    }

    public void class() {
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0xE6969144;
    }

    public static String break(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{7, -24, -125, -29, 56, 126, 95, 67}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    public bm_0 break() {
        return (bm_0)this.byte[break[8]];
    }

    private static void throws() {
        protected = new byte[]{3, 2};
    }

    private static /* synthetic */ void ntfClinit() {
        bb_0.private();
        bb_0.case();
        bb_0.throws();
    }

    private void catch() {
        if (this.byte == null) {
            Object[] objectArray = this.byte = new Object[protected[0]];
            objectArray[bb_0.protected[1]] = bb_0.class[0];
        }
    }

    private static void case() {
        short[] sArray = new short[10];
        sArray[1] = 1;
        sArray[2] = 1;
        sArray[3] = 2;
        sArray[4] = 2;
        sArray[5] = 1;
        sArray[6] = 1;
        sArray[8] = 1;
        sArray[9] = 2;
        break = sArray;
    }

    public boolean protected() {
        return (Boolean)this.byte[break[9]];
    }

    private static void private() {
        bb_0.class = new boolean[1];
    }
}

