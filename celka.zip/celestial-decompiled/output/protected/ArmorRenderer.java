/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Maps
 */
package protected;

import com.google.common.collect.Maps;
import java.util.Map;
import protected.HU;
import protected.Hx;
import protected.an;
import protected.fZ;
import protected.hz_0;
import protected.ib_0;
import protected.ml_1;
import protected.ok_2;
import protected.qe_0;
import protected.rdb_1;
import protected.rdn_1;
import protected.rds_1;
import protected.rqo_0;
import protected.rrbb;
import protected.rrby_0;
import protected.rrxr_0;
import protected.rxS;
import protected.rxq_1;
import protected.tf_1;
import protected.tw_1;
import protected.tx_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.Tc
 */
public class tc_2<T extends ib_0, M extends tw_1<T>, A extends tw_1<T>>
extends tf_1<T, M> {
    private static final Map<String, rqo_0> class = Maps.newHashMap();
    private final A break;
    private final A byte;

    public tc_2(qe_0<T, M> qe_02, A a2, A a3) {
        super(qe_02);
        this.break = a2;
        this.byte = a3;
    }

    private A class(rxq_1 rxq_12) {
        return this.break(rxq_12) ? this.break : this.byte;
    }

    private rqo_0 class(rxS rxS2, boolean bl2, String string) {
        String string2 = "textures/models/armor/" + rxS2.throws().protected() + "_layer_" + (bl2 ? 2 : 1) + (String)(string == null ? "" : "_" + string) + ".png";
        return tc_2.class.computeIfAbsent(string2, rqo_0::new);
    }

    protected A class(T t2, rdn_1 rdn_12, rxq_1 rxq_12, A a2) {
        return (A)((tw_1)(rrxr_0.rQ.byte() ? rrxr_0.rQ.class(new Object[]{t2, rdn_12, rxq_12, a2}) : a2));
    }

    public rqo_0 class(an an2, rdn_1 rdn_12, rxq_1 rxq_12, String string) {
        rqo_0 rqo_02;
        rxS rxS2 = (rxS)rdn_12.break();
        String string2 = rxS2.throws().protected();
        String string3 = "minecraft";
        int n2 = string2.indexOf(58);
        if (n2 != -1) {
            string3 = string2.substring(0, n2);
            string2 = string2.substring(n2 + 1);
        }
        String string4 = String.format("%s:textures/models/armor/%s_layer_%d%s.png", string3, string2, this.break(rxq_12) ? 2 : 1, string == null ? "" : String.format("_%s", string));
        if (rrxr_0.rN.byte()) {
            string4 = rrxr_0.catch(rrxr_0.rN, new Object[]{an2, rdn_12, string4, rxq_12, string});
        }
        if ((rqo_02 = tc_2.class.get(string4)) == null) {
            rqo_02 = new rqo_0(string4);
            tc_2.class.put(string4, rqo_02);
        }
        if (rrbb.rd()) {
            rqo_02 = rrby_0.class(rdn_12, rxq_12, string, rqo_02);
        }
        return rqo_02;
    }

    private void class(ml_1 ml_12, Hx hx, T t2, rxq_1 rxq_12, int n2, A a2) {
        rxS rxS2;
        rdn_1 rdn_12 = ((ib_0)t2).class(rxq_12);
        rdb_1 rdb_12 = rdn_12.break();
        if (rdb_12 instanceof rxS && (rxS2 = (rxS)rdb_12).byte() == rxq_12) {
            if (rrxr_0.rb.byte()) {
                a2 = this.class(t2, rdn_12, rxq_12, a2);
            }
            ((tw_1)this.byte()).class(a2);
            this.class(a2, rxq_12);
            boolean bl2 = rdn_12.else();
            if (rxS2 instanceof rds_1) {
                int n3 = ((rds_1)((Object)rxS2)).d_(rdn_12);
                float f2 = (float)(n3 >> 16 & 0xFF) / 255.0f;
                float f3 = (float)(n3 >> 8 & 0xFF) / 255.0f;
                float f4 = (float)(n3 & 0xFF) / 255.0f;
                this.class(ml_12, hx, n2, bl2, a2, f2, f3, f4, this.class((an)t2, rdn_12, rxq_12, null));
                this.class(ml_12, hx, n2, bl2, a2, 1.0f, 1.0f, 1.0f, this.class((an)t2, rdn_12, rxq_12, "overlay"));
            } else {
                this.class(ml_12, hx, n2, bl2, a2, 1.0f, 1.0f, 1.0f, this.class((an)t2, rdn_12, rxq_12, null));
            }
        }
    }

    protected void class(A a2, rxq_1 rxq_12) {
        ((tw_1)a2).b_(false);
        switch (rxq_12) {
            case HEAD: {
                ((tw_1)a2).class.finally = true;
                ((tw_1)a2).break.finally = true;
                break;
            }
            case CHEST: {
                ((tw_1)a2).byte.finally = true;
                ((tw_1)a2).protected.finally = true;
                ((tw_1)a2).throws.finally = true;
                break;
            }
            case LEGS: {
                ((tw_1)a2).byte.finally = true;
                ((tw_1)a2).case.finally = true;
                ((tw_1)a2).catch.finally = true;
                break;
            }
            case FEET: {
                ((tw_1)a2).case.finally = true;
                ((tw_1)a2).catch.finally = true;
            }
        }
    }

    private void class(ml_1 ml_12, Hx hx, int n2, rxS rxS2, boolean bl2, A a2, boolean bl3, float f2, float f3, float f4, String string) {
        this.class(ml_12, hx, n2, bl2, a2, f2, f3, f4, this.class(rxS2, bl3, string));
    }

    private void class(ml_1 ml_12, Hx hx, int n2, boolean bl2, A a2, float f2, float f3, float f4, rqo_0 rqo_02) {
        ok_2 ok_22 = hz_0.class(hx, HU.class(rqo_02), false, bl2);
        ((tx_2)a2).class(ml_12, ok_22, n2, fZ.class, f2, f3, f4, 1.0f);
    }

    @Override
    public void class(ml_1 ml_12, Hx hx, int n2, T t2, float f2, float f3, float f4, float f5, float f6, float f7) {
        this.class(ml_12, hx, t2, rxq_1.CHEST, n2, this.class(rxq_1.CHEST));
        this.class(ml_12, hx, t2, rxq_1.LEGS, n2, this.class(rxq_1.LEGS));
        this.class(ml_12, hx, t2, rxq_1.FEET, n2, this.class(rxq_1.FEET));
        this.class(ml_12, hx, t2, rxq_1.HEAD, n2, this.class(rxq_1.HEAD));
    }

    private boolean break(rxq_1 rxq_12) {
        return rxq_12 == rxq_1.LEGS;
    }
}

