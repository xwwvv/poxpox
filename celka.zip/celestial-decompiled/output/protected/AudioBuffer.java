/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.lwjgl.openal.AL10
 */
package protected;

import java.nio.ByteBuffer;
import java.util.OptionalInt;
import javax.sound.sampled.AudioFormat;
import org.lwjgl.openal.AL10;
import protected.nr_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.NP
 */
public class np_2 {
    private ByteBuffer class;
    private final AudioFormat break;
    private boolean byte;
    private int protected;

    public OptionalInt byte() {
        OptionalInt optionalInt = this.class();
        this.byte = false;
        return optionalInt;
    }

    public np_2(ByteBuffer byteBuffer, AudioFormat audioFormat) {
        this.class = byteBuffer;
        this.break = audioFormat;
    }

    OptionalInt class() {
        if (!this.byte) {
            if (this.class == null) {
                return OptionalInt.empty();
            }
            int n2 = nr_2.class(this.break);
            int[] nArray = new int[1];
            AL10.alGenBuffers((int[])nArray);
            if (nr_2.class("Creating buffer")) {
                return OptionalInt.empty();
            }
            AL10.alBufferData((int)nArray[0], (int)n2, (ByteBuffer)this.class, (int)((int)this.break.getSampleRate()));
            if (nr_2.class("Assigning buffer data")) {
                return OptionalInt.empty();
            }
            this.protected = nArray[0];
            this.byte = true;
            this.class = null;
        }
        return OptionalInt.of(this.protected);
    }

    public void break() {
        if (this.byte) {
            AL10.alDeleteBuffers((int[])new int[]{this.protected});
            if (nr_2.class("Deleting stream buffers")) {
                return;
            }
        }
        this.byte = false;
    }
}

