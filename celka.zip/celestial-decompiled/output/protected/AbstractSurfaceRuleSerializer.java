/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableSet
 *  com.mojang.datafixers.types.Type
 */
package protected;

import com.google.common.collect.ImmutableSet;
import com.mojang.datafixers.types.Type;
import java.util.Set;
import java.util.function.Supplier;
import protected.ryo_2;
import protected.ryw_2;
import protected.xd_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.ryz
 */
public final class ryz_2<T extends ryo_2> {
    private final Supplier<? extends T> class;
    final Set<xd_0> break;

    private ryz_2(Supplier<? extends T> supplier, Set<xd_0> set) {
        this.class = supplier;
        this.break = set;
    }

    public static <T extends ryo_2> ryz_2<T> class(Supplier<? extends T> supplier, xd_0 ... xd_0Array) {
        return new ryz_2<T>(supplier, (Set<xd_0>)ImmutableSet.copyOf((Object[])xd_0Array));
    }

    public ryw_2<T> class(Type<?> type) {
        return new ryw_2<T>(this.class, this.break, type);
    }
}

