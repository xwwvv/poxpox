/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.rpH;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.rCf
 */
public final class rcf_0
extends Enum<rcf_0>
implements rpH {
    public static final /* enum */ rcf_0 UPPER = new rcf_0();
    public static final /* enum */ rcf_0 LOWER = new rcf_0();
    private static final /* synthetic */ rcf_0[] $VALUES;

    static {
        $VALUES = rcf_0.break();
    }

    public String toString() {
        return this.class();
    }

    public static rcf_0[] values() {
        return (rcf_0[])$VALUES.clone();
    }

    public static rcf_0 valueOf(String string) {
        return Enum.valueOf(rcf_0.class, string);
    }

    @Override
    public String class() {
        return this == UPPER ? "upper" : "lower";
    }

    private static /* synthetic */ rcf_0[] break() {
        return new rcf_0[]{UPPER, LOWER};
    }
}

