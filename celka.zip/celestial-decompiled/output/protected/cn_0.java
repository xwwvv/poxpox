/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.CH;
import protected.an;
import protected.cj_0;
import protected.gm;
import protected.hd_0;
import protected.ly_0;
import protected.ml_1;
import protected.ok_2;
import protected.pg;
import protected.rfU;
import protected.rjU;
import protected.rrbb;
import protected.rrdG;
import protected.rrdZ;
import protected.rse_0;
import protected.yb_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.CN
 */
public class cn_0
extends CH {
    private final yb_2 class;
    private final an break;
    private final an instanceof;
    private int throw;
    private final pg interface;

    public cn_0(pg pg2, yb_2 yb_22, gm gm2, an an2, an an3) {
        this(pg2, yb_22, gm2, an2, an3, an2.rv());
    }

    private cn_0(pg pg2, yb_2 yb_22, gm gm2, an an2, an an3, rjU rjU2) {
        super(gm2, an2.rx(), an2.re(), an2.BO(), rjU2.break, rjU2.byte, rjU2.protected);
        this.class = yb_22;
        this.break = this.class(an2);
        this.instanceof = an3;
        this.interface = pg2;
    }

    @Override
    public cj_0 class() {
        return cj_0.throws;
    }

    @Override
    public void class(ok_2 ok_22, ly_0 ly_02, float f2) {
        rrdG rrdG2 = null;
        if (rrbb.rs()) {
            rrdG2 = rrdZ.Sz;
            rrdZ.class(this.break);
        }
        float f3 = ((float)this.throw + f2) / 3.0f;
        f3 *= f3;
        double d = rfU.protected((double)f2, (Double)this.instanceof.throws[34], this.instanceof.rx());
        double d2 = rfU.protected((double)f2, (Double)this.instanceof.throws[35], this.instanceof.re()) + 0.5;
        double d3 = rfU.protected((double)f2, (Double)this.instanceof.throws[36], this.instanceof.BO());
        double d4 = rfU.protected((double)f3, this.break.rx(), d);
        double d5 = rfU.protected((double)f3, this.break.re(), d2);
        double d6 = rfU.protected((double)f3, this.break.BO(), d3);
        hd_0 hd_02 = this.class.break();
        rjU rjU2 = ly_02.break();
        this.interface.class(this.break, d4 - rjU2.class(), d5 - rjU2.break(), d6 - rjU2.byte(), ((Float)this.break.throws[15]).floatValue(), f2, new ml_1(), hd_02, this.interface.class(this.break, f2));
        hd_02.break();
        if (rrbb.rs()) {
            rrdZ.break((an)null);
            rrdZ.class(rrdG2);
        }
    }

    private an class(an an2) {
        return !(an2 instanceof rse_0) ? an2 : ((rse_0)an2).continue();
    }

    @Override
    public void case() {
        ++this.throw;
        if (this.throw == 3) {
            this.finally();
        }
    }
}

