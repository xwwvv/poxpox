/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.rfH;

/*
 * Renamed from protected.ye
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class ye_2 {
    public final rfH class;
    public final int break;
    public final String byte;
    public final boolean protected;

    public ye_2(rfH rfH2, int n2, String string, boolean bl2) {
        this.class = rfH2;
        this.break = n2;
        this.byte = string;
        this.protected = bl2;
    }
}

