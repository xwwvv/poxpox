/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.annotation.ParametersAreNonnullByDefault
 */
package protected;

import javax.annotation.ParametersAreNonnullByDefault;
import protected.ou_2;

@ParametersAreNonnullByDefault
@ou_2
interface Vj {
}

