/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.io.DataInput;
import java.io.IOException;
import protected.rcg_1;
import protected.rct_1;
import protected.rcv_2;
import protected.rcz_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.rcw
 */
class rcw_1
implements rcv_2<rct_1> {
    @Override
    public boolean byte() {
        return true;
    }

    rcw_1() {
    }

    public rct_1 class(DataInput dataInput, int n2, rcg_1 rcg_12) throws IOException {
        rcg_12.class(128L);
        return rct_1.class(dataInput.readLong());
    }

    @Override
    public String class() {
        return "LONG";
    }

    @Override
    public /* synthetic */ rcz_1 break(DataInput dataInput, int n2, rcg_1 rcg_12) throws IOException {
        return this.class(dataInput, n2, rcg_12);
    }

    @Override
    public String break() {
        return "TAG_Long";
    }
}

