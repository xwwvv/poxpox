/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.case;
import protected.k_0;
import protected.rf_2;
import protected.static;
import protected.try;
import protected.x;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.sM
 */
public class sm_0
extends try {
    private static short[] break;
    private static byte[] throws;
    private static boolean[] case;
    private static String[] catch;

    public sm_0(case case_) {
        String[] stringArray = new String[case[0]];
        stringArray[sm_0.case[1]] = catch[0];
        super(case_, stringArray);
    }

    static {
        sm_0.ntfClinit();
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0xF9437E8E45C240F3L;
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0xE96DBD96;
    }

    @Override
    public void class(String string, static static_) throws x {
        static_.class(case[2]);
        rf_2 rf_22 = ((case)this.class[break[0]]).super();
        if (!rf_22.byte()) {
            throw new k_0(catch[1]);
        }
        if (!rf_22.private()) {
            throw new k_0(catch[3]);
        }
        this.case(catch[2]);
    }

    @Override
    public Stream<String> break(String string, static static_) {
        return Stream.empty();
    }

    public static String break(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{-104, -37, 42, 117, 91, 124, -95, -87}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    private static void throws() {
        throws = new byte[]{4, 2, 3};
    }

    private static /* synthetic */ void ntfClinit() {
        sm_0.protected();
        sm_0.finally();
        sm_0.extends();
        sm_0.throws();
    }

    private static void finally() {
        catch = new String[]{new String("blacklist"), new String("GetToBlockProcess is not currently active"), new String("Blacklisted closest instances"), new String("No known locations, unable to blacklist"), new String("Blacklist closest block"), new String("While going to a block this command blacklists the closest block so that Baritone won't attempt to get to it."), new String(""), new String("Usage:"), new String("> blacklist")};
    }

    @Override
    public List<String> catch() {
        String[] stringArray = new String[throws[0]];
        stringArray[sm_0.case[3]] = catch[5];
        stringArray[sm_0.case[4]] = catch[6];
        stringArray[sm_0.throws[1]] = catch[7];
        stringArray[sm_0.throws[2]] = catch[8];
        return Arrays.asList(stringArray);
    }

    private static void extends() {
        break = new short[1];
    }

    @Override
    public String implements() {
        return catch[4];
    }

    private static void protected() {
        boolean[] blArray = new boolean[5];
        blArray[0] = true;
        blArray[4] = true;
        case = blArray;
    }
}

