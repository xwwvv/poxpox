/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableList
 */
package protected;

import com.google.common.collect.ImmutableList;
import java.util.List;
import java.util.function.Consumer;
import protected.ai_0;
import protected.hc_1;
import protected.hc_2;
import protected.hd_2;
import protected.hf_1;
import protected.hh_2;
import protected.hk_1;
import protected.hl_1;
import protected.ho_1;
import protected.hs_2;
import protected.hv_1;
import protected.hw_2;
import protected.hy_2;
import protected.jk_2;
import protected.jo_2;
import protected.js_2;
import protected.oe_1;
import protected.or_1;
import protected.ot_1;
import protected.ot_2;
import protected.rYB;
import protected.rYl;
import protected.rbw_0;
import protected.rdy_2;
import protected.rgP;
import protected.rgn;
import protected.rlc_0;
import protected.rld_1;
import protected.rqm_0;
import protected.rqo_0;
import protected.rqx_1;
import protected.rrrZ;
import protected.ryg_0;
import protected.rzb_2;
import protected.uq_0;
import protected.wv_2;
import protected.xa_1;
import protected.xa_2;
import protected.xb_1;
import protected.xc_2;
import protected.xf_2;
import protected.xh_1;
import protected.xk_1;
import protected.xk_2;
import protected.xm_1;
import protected.xn_2;
import protected.xo_2;
import protected.xt_2;
import protected.xu_0;
import protected.xw_1;
import protected.xx_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.Uu
 */
public class uu_0
implements Consumer<Consumer<ot_1>> {
    private static final List<rqm_0<ryg_0>> class = ImmutableList.of(rYl.implements, rYl.C, rYl.H, rYl.l, rYl.y);
    private static final ho_1 break = ho_1.class(rqx_1.class(rzb_2.THIS, hk_1.class().class(hf_1.class().class(xx_2.class().class(rdy_2.hc).break()).break())).class().build(), rqx_1.class(rzb_2.THIS, hk_1.class().class(hf_1.class().break(xx_2.class().class(rdy_2.hu).break()).break())).class().build(), rqx_1.class(rzb_2.THIS, hk_1.class().class(hf_1.class().byte(xx_2.class().class(rdy_2.hm).break()).break())).class().build(), rqx_1.class(rzb_2.THIS, hk_1.class().class(hf_1.class().protected(xx_2.class().class(rdy_2.hZ).break()).break())).class().build());

    public void class(Consumer<ot_1> consumer) {
        ot_1 ot_12 = ot_2.class().class(xu_0.bR, (rgP)new rgn("advancements.nether.root.title"), (rgP)new rgn("advancements.nether.root.description"), new rqo_0("textures/gui/advancements/backgrounds/nether.png"), oe_1.TASK, false, false, false).class("entered_nether", hw_2.class(rYB.protected)).class(consumer, "nether/root");
        ot_1 ot_13 = ot_2.class().class(ot_12).class(rdy_2.xa, (rgP)new rgn("advancements.nether.return_to_sender.title"), (rgP)new rgn("advancements.nether.return_to_sender.description"), (rqo_0)null, oe_1.CHALLENGE, true, true, false).class(or_1.class(50)).class("killed_ghast", xk_2.class(hk_1.class().class(ai_0.interface), hc_1.class().class(true).class(hk_1.class().class(ai_0.const)))).class(consumer, "nether/return_to_sender");
        ot_1 ot_14 = ot_2.class().class(ot_12).class(xu_0.SP, (rgP)new rgn("advancements.nether.find_fortress.title"), (rgP)new rgn("advancements.nether.find_fortress.description"), (rqo_0)null, oe_1.TASK, true, true, false).class("fortress", xk_1.class(xn_2.class(rrrZ.final))).class(consumer, "nether/find_fortress");
        ot_2.class().class(ot_12).class(rdy_2.dM, (rgP)new rgn("advancements.nether.fast_travel.title"), (rgP)new rgn("advancements.nether.fast_travel.description"), (rqo_0)null, oe_1.CHALLENGE, true, true, false).class(or_1.class(100)).class("travelled", xh_1.class(hl_1.class(xm_1.class(7000.0f)))).class(consumer, "nether/fast_travel");
        ot_2.class().class(ot_13).class(rdy_2.Jv, (rgP)new rgn("advancements.nether.uneasy_alliance.title"), (rgP)new rgn("advancements.nether.uneasy_alliance.description"), (rqo_0)null, oe_1.CHALLENGE, true, true, false).class(or_1.class(100)).class("killed_ghast", xk_2.class(hk_1.class().class(ai_0.interface).class(xn_2.break(rYB.byte)))).class(consumer, "nether/uneasy_alliance");
        ot_1 ot_15 = ot_2.class().class(ot_14).class(xu_0.sh, (rgP)new rgn("advancements.nether.get_wither_skull.title"), (rgP)new rgn("advancements.nether.get_wither_skull.description"), (rqo_0)null, oe_1.TASK, true, true, false).class("wither_skull", xb_1.class(xu_0.sh)).class(consumer, "nether/get_wither_skull");
        ot_1 ot_16 = ot_2.class().class(ot_15).class(rdy_2.dQ, (rgP)new rgn("advancements.nether.summon_wither.title"), (rgP)new rgn("advancements.nether.summon_wither.description"), (rqo_0)null, oe_1.TASK, true, true, false).class("summoned", jo_2.class(hk_1.class().class(ai_0.i))).class(consumer, "nether/summon_wither");
        ot_1 ot_17 = ot_2.class().class(ot_14).class(rdy_2.JZ, (rgP)new rgn("advancements.nether.obtain_blaze_rod.title"), (rgP)new rgn("advancements.nether.obtain_blaze_rod.description"), (rqo_0)null, oe_1.TASK, true, true, false).class("blaze_rod", xb_1.class(rdy_2.JZ)).class(consumer, "nether/obtain_blaze_rod");
        ot_1 ot_18 = ot_2.class().class(ot_16).class(xu_0.Sv, (rgP)new rgn("advancements.nether.create_beacon.title"), (rgP)new rgn("advancements.nether.create_beacon.description"), (rqo_0)null, oe_1.TASK, true, true, false).class("beacon", hc_2.class(xf_2.break(1))).class(consumer, "nether/create_beacon");
        ot_2.class().class(ot_18).class(xu_0.Sv, (rgP)new rgn("advancements.nether.create_full_beacon.title"), (rgP)new rgn("advancements.nether.create_full_beacon.description"), (rqo_0)null, oe_1.GOAL, true, true, false).class("beacon", hc_2.class(xf_2.class(4))).class(consumer, "nether/create_full_beacon");
        ot_1 ot_19 = ot_2.class().class(ot_17).class(rdy_2.JA, (rgP)new rgn("advancements.nether.brew_potion.title"), (rgP)new rgn("advancements.nether.brew_potion.description"), (rqo_0)null, oe_1.TASK, true, true, false).class("potion", hd_2.break()).class(consumer, "nether/brew_potion");
        ot_1 ot_110 = ot_2.class().class(ot_19).class(rdy_2.hi, (rgP)new rgn("advancements.nether.all_potions.title"), (rgP)new rgn("advancements.nether.all_potions.description"), (rqo_0)null, oe_1.CHALLENGE, true, true, false).class(or_1.class(100)).class("all_effects", hy_2.class(xa_2.class().class(rld_1.class).class(rld_1.break).class(rld_1.throws).class(rld_1.private).class(rld_1.finally).class(rld_1.native).class(rld_1.volatile).class(rld_1.final).class(rld_1.int).class(rld_1.continue).class(rld_1.super).class(rld_1.instanceof).class(rld_1.extends))).class(consumer, "nether/all_potions");
        ot_2.class().class(ot_110).class(rdy_2.hg, (rgP)new rgn("advancements.nether.all_effects.title"), (rgP)new rgn("advancements.nether.all_effects.description"), (rqo_0)null, oe_1.CHALLENGE, true, true, true).class(or_1.class(1000)).class("all_effects", hy_2.class(xa_2.class().class(rld_1.class).class(rld_1.break).class(rld_1.throws).class(rld_1.private).class(rld_1.finally).class(rld_1.native).class(rld_1.volatile).class(rld_1.final).class(rld_1.int).class(rld_1.continue).class(rld_1.super).class(rld_1.this).class(rld_1.byte).class(rld_1.protected).class(rld_1.goto).class(rld_1.public).class(rld_1.synchronized).class(rld_1.new).class(rld_1.implements).class(rld_1.extends).class(rld_1.instanceof).class(rld_1.throw).class(rld_1.interface).class(rld_1.package).class(rld_1.char).class(rld_1.abstract))).class(consumer, "nether/all_effects");
        ot_1 ot_111 = ot_2.class().class(ot_12).class(rdy_2.Wl, (rgP)new rgn("advancements.nether.obtain_ancient_debris.title"), (rgP)new rgn("advancements.nether.obtain_ancient_debris.description"), (rqo_0)null, oe_1.TASK, true, true, false).class("ancient_debris", xb_1.class(rdy_2.Wl)).class(consumer, "nether/obtain_ancient_debris");
        ot_2.class().class(ot_111).class(rdy_2.hF, (rgP)new rgn("advancements.nether.netherite_armor.title"), (rgP)new rgn("advancements.nether.netherite_armor.description"), (rqo_0)null, oe_1.CHALLENGE, true, true, false).class(or_1.class(100)).class("netherite_armor", xb_1.class(rdy_2.hv, rdy_2.hF, rdy_2.hL, rdy_2.hA)).class(consumer, "nether/netherite_armor");
        ot_2.class().class(ot_111).class(rdy_2.Wn, (rgP)new rgn("advancements.nether.use_lodestone.title"), (rgP)new rgn("advancements.nether.use_lodestone.description"), (rqo_0)null, oe_1.TASK, true, true, false).class("use_lodestone", xa_1.class(xc_2.class().class(hh_2.class().class(xu_0.Jc).break()), xx_2.class().class(rdy_2.Xx))).class(consumer, "nether/use_lodestone");
        ot_1 ot_112 = ot_2.class().class(ot_12).class(rdy_2.Wy, (rgP)new rgn("advancements.nether.obtain_crying_obsidian.title"), (rgP)new rgn("advancements.nether.obtain_crying_obsidian.description"), (rqo_0)null, oe_1.TASK, true, true, false).class("crying_obsidian", xb_1.class(rdy_2.Wy)).class(consumer, "nether/obtain_crying_obsidian");
        ot_2.class().class(ot_112).class(rdy_2.Wo, (rgP)new rgn("advancements.nether.charge_respawn_anchor.title"), (rgP)new rgn("advancements.nether.charge_respawn_anchor.description"), (rqo_0)null, oe_1.TASK, true, true, false).class("charge_respawn_anchor", xa_1.class(xc_2.class().class(hh_2.class().class(xu_0.Jk).class(js_2.class().class(wv_2.volatile, 4).break()).break()), xx_2.class().class(xu_0.Pa))).class(consumer, "nether/charge_respawn_anchor");
        ot_1 ot_113 = ot_2.class().class(ot_12).class(rdy_2.dz, (rgP)new rgn("advancements.nether.ride_strider.title"), (rgP)new rgn("advancements.nether.ride_strider.description"), (rqo_0)null, oe_1.TASK, true, true, false).class("used_warped_fungus_on_a_stick", xo_2.class(ho_1.class(hk_1.class().class(hk_1.class().class(ai_0.w).break()).break()), xx_2.class().class(rdy_2.dz).break(), xf_2.throws)).class(consumer, "nether/ride_strider");
        uq_0.class(ot_2.class(), uu_0.class).class(ot_113).class(rdy_2.hA, (rgP)new rgn("advancements.nether.explore_nether.title"), (rgP)new rgn("advancements.nether.explore_nether.description"), (rqo_0)null, oe_1.CHALLENGE, true, true, false).class(or_1.class(500)).class(consumer, "nether/explore_nether");
        ot_1 ot_114 = ot_2.class().class(ot_12).class(rdy_2.WV, (rgP)new rgn("advancements.nether.find_bastion.title"), (rgP)new rgn("advancements.nether.find_bastion.description"), (rqo_0)null, oe_1.TASK, true, true, false).class("bastion", xk_1.class(xn_2.class(rrrZ.super))).class(consumer, "nether/find_bastion");
        ot_2.class().class(ot_114).class(xu_0.re, (rgP)new rgn("advancements.nether.loot_bastion.title"), (rgP)new rgn("advancements.nether.loot_bastion.description"), (rqo_0)null, oe_1.TASK, true, true, false).class(hs_2.break).class("loot_bastion_other", xw_1.class(new rqo_0("minecraft:chests/bastion_other"))).class("loot_bastion_treasure", xw_1.class(new rqo_0("minecraft:chests/bastion_treasure"))).class("loot_bastion_hoglin_stable", xw_1.class(new rqo_0("minecraft:chests/bastion_hoglin_stable"))).class("loot_bastion_bridge", xw_1.class(new rqo_0("minecraft:chests/bastion_bridge"))).class(consumer, "nether/loot_bastion");
        ot_2.class().class(ot_12).class(hs_2.break).class(rdy_2.Od, (rgP)new rgn("advancements.nether.distract_piglin.title"), (rgP)new rgn("advancements.nether.distract_piglin.description"), (rqo_0)null, oe_1.TASK, true, true, false).class("distract_piglin", jk_2.class(break, xx_2.class().class(rlc_0.strictfp), ho_1.class(hk_1.class().class(ai_0.d).class(hv_1.class().break(false).break()).break()))).class("distract_piglin_directly", xt_2.class(break, xx_2.class().class(rbw_0.class), ho_1.class(hk_1.class().class(ai_0.d).class(hv_1.class().break(false).break()).break()))).class(consumer, "nether/distract_piglin");
    }

    @Override
    public /* synthetic */ void accept(Object object) {
        this.class((Consumer)object);
    }
}

