/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.util.Random;
import protected.an;
import protected.ea_0;
import protected.ey_0;
import protected.jq_1;
import protected.rCL;
import protected.rCZ;
import protected.rYB;
import protected.rcn_0;
import protected.rdn_1;
import protected.rfH;
import protected.rff;
import protected.rhd_2;
import protected.rlc_2;
import protected.rpb_0;
import protected.rpm;
import protected.rpr_0;
import protected.rrEm;
import protected.rxj_0;
import protected.rxx;
import protected.ryz_1;
import protected.wq_2;
import protected.xc_0;
import protected.xd_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.Wz
 */
public class wz_2
extends xd_0 {
    public static final rcn_0 volatile = wq_2.volatile;

    private static void byte(xc_0 xc_02, rYB rYB2, rfH rfH2) {
        wz_2.class(rYB2, rfH2);
        if (!xc_02.byte(volatile).booleanValue()) {
            rYB2.class(rfH2, (xc_0)xc_02.class(volatile, true), 3);
        }
    }

    public wz_2(jq_1 jq_12) {
        super(jq_12);
        this.extends((xc_0)this.continue().class(volatile, false));
    }

    @Override
    public void class(xc_0 xc_02, rrEm rrEm2, rfH rfH2, rdn_1 rdn_12) {
        super.class(xc_02, rrEm2, rfH2, rdn_12);
        if (ea_0.class(ey_0.else, rdn_12) == 0) {
            int n2 = 1 + rrEm2.int.nextInt(5);
            this.class(rrEm2, rfH2, n2);
        }
    }

    @Override
    public void class(xc_0 xc_02, rYB rYB2, rfH rfH2, Random random) {
        if (xc_02.byte(volatile).booleanValue()) {
            wz_2.class(rYB2, rfH2);
        }
    }

    private static void class(rYB rYB2, rfH rfH2) {
        double d = 0.5625;
        Random random = rYB2.int;
        for (rpr_0 rpr_02 : rpr_0.values()) {
            rfH rfH3 = rfH2.break(rpr_02);
            if (rYB2.byte(rfH3).implements(rYB2, rfH3)) continue;
            rpb_0 rpb_02 = rpr_02.final();
            double d2 = rpb_02 == rpb_0.X ? 0.5 + 0.5625 * (double)rpr_02.implements() : (double)random.nextFloat();
            double d3 = rpb_02 == rpb_0.Y ? 0.5 + 0.5625 * (double)rpr_02.finally() : (double)random.nextFloat();
            double d4 = rpb_02 == rpb_0.Z ? 0.5 + 0.5625 * (double)rpr_02.extends() : (double)random.nextFloat();
            rYB2.class(rlc_2.class, (double)rfH2.b_() + d2, (double)rfH2.c_() + d3, (double)rfH2.d_() + d4, 0.0, 0.0, 0.0);
        }
    }

    @Override
    protected void class(rCL<xd_0, xc_0> rCL2) {
        rCL2.class(new rCZ[]{volatile});
    }

    @Override
    public void class(xc_0 xc_02, rrEm rrEm2, rfH rfH2, Random random) {
        if (xc_02.byte(volatile).booleanValue()) {
            rrEm2.class(rfH2, (xc_0)xc_02.class(volatile, false), 3);
        }
    }

    @Override
    public ryz_1 class(xc_0 xc_02, rYB rYB2, rfH rfH2, rhd_2 rhd_22, rpm rpm2, rff rff2) {
        if (rYB2.continue) {
            wz_2.class(rYB2, rfH2);
        } else {
            wz_2.byte(xc_02, rYB2, rfH2);
        }
        rdn_1 rdn_12 = rhd_22.protected(rpm2);
        return rdn_12.break() instanceof rxj_0 && new rxx(rhd_22, rpm2, rdn_12, rff2).break() ? ryz_1.PASS : ryz_1.SUCCESS;
    }

    @Override
    public void class(rYB rYB2, rfH rfH2, an an2) {
        wz_2.byte(rYB2.byte(rfH2), rYB2, rfH2);
        super.class(rYB2, rfH2, an2);
    }

    @Override
    public void class(xc_0 xc_02, rYB rYB2, rfH rfH2, rhd_2 rhd_22) {
        wz_2.byte(xc_02, rYB2, rfH2);
        super.class(xc_02, rYB2, rfH2, rhd_22);
    }

    @Override
    public boolean a_(xc_0 xc_02) {
        return xc_02.byte(volatile);
    }
}

