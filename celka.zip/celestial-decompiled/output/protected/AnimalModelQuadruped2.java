/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.util.function.Function;
import protected.HU;
import protected.an;
import protected.iq_1;
import protected.ml_1;
import protected.ok_2;
import protected.rqo_0;
import protected.tp_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.wN
 */
public abstract class wn_0<E extends an>
extends tp_0<E> {
    public wn_0() {
        this(HU::protected);
    }

    public wn_0(Function<rqo_0, HU> function) {
        super(function);
    }

    public abstract Iterable<iq_1> class();

    @Override
    public void class(ml_1 ml_12, ok_2 ok_22, int n2, int n3, float f2, float f3, float f4, float f5) {
        this.class().forEach(iq_12 -> iq_12.class(ml_12, ok_22, n2, n3, f2, f3, f4, f5));
    }
}

