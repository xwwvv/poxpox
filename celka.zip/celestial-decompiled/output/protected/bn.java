/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Arrays;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.bZ;
import protected.ba_0;
import protected.bf_0;
import protected.bl_0;
import protected.bv_0;
import protected.ps_1;
import protected.rfl;
import protected.ru_1;
import protected.ry_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class bn
implements bZ {
    private static short[] break;
    private static boolean[] byte;
    private static float[] protected;
    public static Object[] class;
    private static byte[] throws;

    private static void byte() {
        protected = new float[]{0.5f, 0.5f, 0.5f, 0.5f, 0.5f, 0.5f, 0.5f, 0.5f, 0.5f, 0.5f, 0.5f, 0.5f, 0.5f, 0.5f};
    }

    static {
        bn.ntfClinit();
    }

    public static String class(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{99, 48, 10, -16, -66, -99, 41, -55}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0x276B4140;
    }

    private bf_0 class(int n2, int n3, int n4, int n5, int n6) {
        int n7 = n3 - n2 + byte[18];
        bl_0[] bl_0Array = new bl_0[n7];
        for (int k = byte[19]; k < n7; ++k) {
            bl_0Array[k] = new bl_0(n2 + k, n4, n5);
        }
        rfl rfl2 = new rfl((float)n2 - protected[2] + protected[3], (float)n4 - protected[4] + protected[5], (float)n5 - protected[6] + protected[7], (float)n3 + protected[8] + protected[9], (float)n4 + protected[10] + protected[11], (float)n5 + protected[12] + protected[13]);
        return new bf_0(rfl2, bl_0Array, n6);
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0xE6B0B5775027445L;
    }

    @Override
    public bv_0[] class(ps_1 ps_12, ry_1 ry_12) {
        byte by;
        int n2;
        int n3;
        if (ry_12 == null) {
            return null;
        }
        ru_1 ru_12 = ps_12.volatile();
        ru_1 ru_13 = ry_12.class();
        ru_1 ru_14 = ry_12.protected();
        int n4 = (Integer)ru_13.break[break[0]];
        int n5 = (Integer)ru_13.break[break[1]];
        int n6 = (Integer)ru_13.break[break[2]];
        int n7 = (Integer)ru_14.break[break[3]];
        int n8 = (Integer)ru_14.break[break[4]];
        int n9 = n7 - n4 + byte[0];
        int n10 = n8 - n6 + byte[1];
        int n11 = (n9 + throws[0] - byte[2]) / throws[1];
        bv_0[] bv_0Array = new bv_0[n11];
        byte by2 = throws[2];
        int n12 = n10 >> byte[3];
        int n13 = n4 + by2;
        int n14 = n4 + (n11 - byte[4]) * throws[3] + by2;
        int n15 = n6 + n12;
        boolean bl2 = ru_12.protected(n14, n5, n15) < ru_12.protected(n13, n5, n15) ? byte[5] : byte[6];
        int n16 = (n10 + throws[4] - byte[7]) / throws[5];
        float f2 = protected[0];
        float f3 = protected[1];
        float f4 = (float)n5 - f2 + f3;
        float f5 = (float)n5 + f2 + f3;
        float f6 = (float)n6 - f2 + f3;
        float f7 = (float)n8 + f2 + f3;
        if (bl2) {
            n3 = n11 - byte[8];
            n2 = throws[6];
            by = throws[7];
        } else {
            n3 = byte[9];
            n2 = n11;
            by = byte[10];
        }
        int n17 = n3;
        int n18 = byte[11];
        while (n17 != n2) {
            int n19 = n4 + n17 * throws[8];
            int n20 = Math.min(n19 + throws[9] - byte[12], n7);
            int n21 = n20 - n19 + byte[13];
            int n22 = (n21 + throws[10] - byte[14]) / throws[11];
            float f8 = (float)n19 - f2 + f3;
            float f9 = (float)n20 + f2 + f3;
            bl_0[] bl_0Array = new bl_0[n22 * n16];
            int n23 = byte[15];
            int n24 = n6;
            for (int k = byte[16]; k < n16; ++k) {
                if (n24 <= n8) {
                    int n25 = n19;
                    for (int i2 = byte[17]; i2 < n22; ++i2) {
                        if (n25 <= n20) {
                            bl_0Array[n23++] = new bl_0(n25, n5, n24);
                        }
                        n25 += 3;
                    }
                }
                n24 += 3;
            }
            if (n23 < bl_0Array.length) {
                bl_0Array = Arrays.copyOf(bl_0Array, n23);
            }
            rfl rfl2 = new rfl(f8, f4, f6, f9, f5, f7);
            bf_0 bf_02 = this.class(n19, n20, n5, n6, n18);
            bf_0 bf_03 = this.class(n19, n20, n5, n8, n18);
            bv_0Array[n17] = new ba_0(rfl2, bl_0Array, n18, bf_02, bf_03);
            n17 += by;
            ++n18;
        }
        return bv_0Array;
    }

    private static void class() {
        short[] sArray = new short[5];
        sArray[1] = 1;
        sArray[2] = 2;
        sArray[4] = 2;
        break = sArray;
    }

    private static void break() {
        throws = new byte[]{6, 6, 3, 6, 3, 3, -1, -1, 6, 6, 3, 3, 3, 6, 3, 2, 3};
    }

    private static void throws() {
        Object[] objectArray = new Object[]{6, 3, 3};
        bn.class = objectArray;
    }

    private static /* synthetic */ void ntfClinit() {
        bn.protected();
        bn.class();
        bn.byte();
        bn.break();
        bn.throws();
    }

    private static void protected() {
        boolean[] blArray = new boolean[22];
        blArray[0] = true;
        blArray[1] = true;
        blArray[2] = true;
        blArray[3] = true;
        blArray[4] = true;
        blArray[5] = true;
        blArray[7] = true;
        blArray[8] = true;
        blArray[10] = true;
        blArray[12] = true;
        blArray[13] = true;
        blArray[14] = true;
        blArray[18] = true;
        blArray[21] = true;
        byte = blArray;
    }
}

