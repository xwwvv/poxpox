/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.case;
import protected.f_0;
import protected.for;
import protected.sS;
import protected.static;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.ss
 */
public class ss_0
implements for {
    private static boolean[] break;
    public Object[] class;
    private static short[] byte;

    public sS byte() {
        return (sS)this.class[byte[3]];
    }

    ss_0(sS sS2) {
        this.protected();
        sS sS3 = sS2;
        this.class[ss_0.byte[0]] = sS3;
    }

    static {
        ss_0.ntfClinit();
    }

    public static String class(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{-69, 30, 125, 26, -87, -75, 8, -105}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0x919A9B590CA6FEC6L;
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0x1C805ACA;
    }

    @Override
    public /* synthetic */ static class() {
        return this.byte();
    }

    @Override
    public case break() {
        return ((f_0)((sS)this.class[ss_0.byte[1]]).class[byte[2]]).break();
    }

    private static void throws() {
        byte = new short[4];
    }

    private static /* synthetic */ void ntfClinit() {
        ss_0.case();
        ss_0.throws();
    }

    private static void case() {
        break = new boolean[]{true};
    }

    private void protected() {
        if (this.class == null) {
            Object[] objectArray = this.class = new Object[break[0]];
        }
    }
}

