/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 */
package protected;

import com.google.common.collect.Lists;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.WeakHashMap;
import protected.jq_1;
import protected.rCL;
import protected.rCZ;
import protected.rRq;
import protected.rYB;
import protected.rcn_0;
import protected.rct_0;
import protected.rfH;
import protected.rlc_2;
import protected.rpr_0;
import protected.rrEm;
import protected.wn_2;
import protected.xc_0;
import protected.xd_0;
import protected.zz_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.WQ
 */
public class wq_2
extends zz_1 {
    public static final rcn_0 volatile = rct_0.continue;
    private static final Map<rRq, List<wn_2>> final = new WeakHashMap<rRq, List<wn_2>>();

    @Override
    public boolean byte(xc_0 xc_02) {
        return true;
    }

    protected wq_2(jq_1 jq_12) {
        super(jq_12, rlc_2.class);
        this.extends((xc_0)((xc_0)this.abstract.break()).class(volatile, true));
    }

    @Override
    public void class(xc_0 xc_02, rYB rYB2, rfH rfH2, xc_0 xc_03, boolean bl2) {
        for (rpr_0 rpr_02 : rpr_0.values()) {
            rYB2.break(rfH2.break(rpr_02), this);
        }
    }

    @Override
    public void class(xc_0 xc_02, rYB rYB2, rfH rfH2, Random random) {
        if (xc_02.byte(volatile).booleanValue()) {
            double d = (double)rfH2.b_() + 0.5 + (random.nextDouble() - 0.5) * 0.2;
            double d2 = (double)rfH2.c_() + 0.7 + (random.nextDouble() - 0.5) * 0.2;
            double d3 = (double)rfH2.d_() + 0.5 + (random.nextDouble() - 0.5) * 0.2;
            rYB2.class(this.new, d, d2, d3, 0.0, 0.0, 0.0);
        }
    }

    @Override
    protected void class(rCL<xd_0, xc_0> rCL2) {
        rCL2.class(new rCZ[]{volatile});
    }

    private static boolean class(rYB rYB2, rfH rfH2, boolean bl2) {
        List list = final.computeIfAbsent(rYB2, rRq2 -> Lists.newArrayList());
        if (bl2) {
            list.add(new wn_2(rfH2.int(), rYB2.r()));
        }
        int n2 = 0;
        for (int k = 0; k < list.size(); ++k) {
            wn_2 wn_22 = (wn_2)list.get(k);
            if (!wn_22.class.equals(rfH2) || ++n2 < 8) continue;
            return true;
        }
        return false;
    }

    @Override
    public int class(xc_0 xc_02, rRq rRq2, rfH rfH2, rpr_0 rpr_02) {
        return xc_02.byte(volatile) != false && rpr_0.UP != rpr_02 ? 15 : 0;
    }

    @Override
    public void class(xc_0 xc_02, rYB rYB2, rfH rfH2, xd_0 xd_02, rfH rfH3, boolean bl2) {
        if (xc_02.byte(volatile).booleanValue() == this.class(rYB2, rfH2, xc_02) && !rYB2.finally().break(rfH2, this)) {
            rYB2.finally().class(rfH2, this, 2);
        }
    }

    protected boolean class(rYB rYB2, rfH rfH2, xc_0 xc_02) {
        return rYB2.break(rfH2.break(), rpr_0.DOWN);
    }

    @Override
    public int break(xc_0 xc_02, rRq rRq2, rfH rfH2, rpr_0 rpr_02) {
        return rpr_02 == rpr_0.DOWN ? xc_02.break(rRq2, rfH2, rpr_02) : 0;
    }

    @Override
    public void break(xc_0 xc_02, rYB rYB2, rfH rfH2, xc_0 xc_03, boolean bl2) {
        if (!bl2) {
            for (rpr_0 rpr_02 : rpr_0.values()) {
                rYB2.break(rfH2.break(rpr_02), this);
            }
        }
    }

    @Override
    public void break(xc_0 xc_02, rrEm rrEm2, rfH rfH2, Random random) {
        boolean bl2 = this.class((rYB)rrEm2, rfH2, xc_02);
        List<wn_2> list = final.get(rrEm2);
        while (list != null && !list.isEmpty() && rrEm2.r() - list.get((int)0).break > 60L) {
            list.remove(0);
        }
        if (xc_02.byte(volatile).booleanValue()) {
            if (bl2) {
                rrEm2.class(rfH2, (xc_0)xc_02.class(volatile, false), 3);
                if (wq_2.class((rYB)rrEm2, rfH2, true)) {
                    rrEm2.byte(1502, rfH2, 0);
                    rrEm2.synchronized().class(rfH2, rrEm2.byte(rfH2).break(), 160);
                }
            }
        } else if (!bl2 && !wq_2.class((rYB)rrEm2, rfH2, false)) {
            rrEm2.class(rfH2, (xc_0)xc_02.class(volatile, true), 3);
        }
    }
}

