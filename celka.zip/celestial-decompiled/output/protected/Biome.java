/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableList
 *  com.mojang.datafixers.kinds.App
 *  com.mojang.datafixers.kinds.Applicative
 *  com.mojang.serialization.Codec
 *  com.mojang.serialization.codecs.RecordCodecBuilder
 *  it.unimi.dsi.fastutil.longs.Long2FloatLinkedOpenHashMap
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
package protected;

import com.google.common.collect.ImmutableList;
import com.mojang.datafixers.kinds.App;
import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import it.unimi.dsi.fastutil.longs.Long2FloatLinkedOpenHashMap;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Random;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import protected.KU;
import protected.KY;
import protected.dj_1;
import protected.ns_2;
import protected.rDg;
import protected.rKd;
import protected.rKf;
import protected.rKm;
import protected.rKw;
import protected.rRH;
import protected.rRR;
import protected.rRo;
import protected.rYV;
import protected.rYg;
import protected.rYj;
import protected.rYt;
import protected.rfH;
import protected.rfU;
import protected.rfi;
import protected.rfj;
import protected.rjh_0;
import protected.roC;
import protected.rqR;
import protected.rqa_0;
import protected.rqm;
import protected.rqo_0;
import protected.rrn_0;
import protected.rrrZ;
import protected.rrra_0;
import protected.rrsr_1;
import protected.ruo_0;
import protected.rva_0;
import protected.rvl_0;
import protected.rvy_0;
import protected.rxe_2;
import protected.rxg_2;
import protected.ryb_0;
import protected.ryh_0;
import protected.ryj_0;
import protected.ryv_0;
import protected.ryw_0;
import protected.ryx_0;
import protected.xc_0;
import protected.xu_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.rYG
 */
public final class ryg_0 {
    public static final Logger class = LogManager.getLogger();
    public static final Codec<ryg_0> break = RecordCodecBuilder.create(instance -> instance.group((App)ryx_0.class.forGetter(ryg_02 -> ryg_02.finally), (App)ryh_0.CODEC.fieldOf("category").forGetter(ryg_02 -> ryg_02.package), (App)Codec.FLOAT.fieldOf("depth").forGetter(ryg_02 -> Float.valueOf(ryg_02.volatile)), (App)Codec.FLOAT.fieldOf("scale").forGetter(ryg_02 -> Float.valueOf(ryg_02.final)), (App)ryw_0.class.fieldOf("effects").forGetter(ryg_02 -> ryg_02.int), (App)ryv_0.byte.forGetter(ryg_02 -> ryg_02.extends), (App)rYt.byte.forGetter(ryg_02 -> ryg_02.native)).apply((Applicative)instance, ryg_0::new));
    public static final Codec<ryg_0> byte = RecordCodecBuilder.create(instance -> instance.group((App)ryx_0.class.forGetter(ryg_02 -> ryg_02.finally), (App)ryh_0.CODEC.fieldOf("category").forGetter(ryg_02 -> ryg_02.package), (App)Codec.FLOAT.fieldOf("depth").forGetter(ryg_02 -> Float.valueOf(ryg_02.volatile)), (App)Codec.FLOAT.fieldOf("scale").forGetter(ryg_02 -> Float.valueOf(ryg_02.final)), (App)ryw_0.class.fieldOf("effects").forGetter(ryg_02 -> ryg_02.int)).apply((Applicative)instance, (ryx_02, ryh_02, f2, f3, ryw_02) -> new ryg_0((ryx_0)ryx_02, (ryh_0)ryh_02, f2.floatValue(), f3.floatValue(), (ryw_0)ryw_02, ryv_0.break, rYt.break)));
    public static final Codec<Supplier<ryg_0>> protected = rva_0.class(rvl_0.n, break);
    public static final Codec<List<Supplier<ryg_0>>> throws = rva_0.break(rvl_0.n, break);
    private final Map<Integer, List<rrrZ<?>>> catch = rvl_0.t.case().collect(Collectors.groupingBy(rrrZ2 -> rrrZ2.protected().ordinal()));
    private static final rKw private = new rKw(new rqm(1234L), (List<Integer>)ImmutableList.of((Object)0));
    static final rKw implements = new rKw(new rqm(3456L), (List<Integer>)ImmutableList.of((Object)-2, (Object)-1, (Object)0));
    public static final rKw case = new rKw(new rqm(2345L), (List<Integer>)ImmutableList.of((Object)0));
    private final ryx_0 finally;
    private final ryv_0 extends;
    private final rYt native;
    private final float volatile;
    private final float final;
    private final ryh_0 package;
    private final ryw_0 int;
    private final ThreadLocal<Long2FloatLinkedOpenHashMap> new = ThreadLocal.withInitial(() -> rqR.class(() -> {
        ryb_0 ryb_02 = new ryb_0(this, 1024, 0.25f);
        ryb_02.defaultReturnValue(Float.NaN);
        return ryb_02;
    }));

    public ryj_0 byte() {
        return this.finally.break;
    }

    public Optional<rqa_0> int() {
        return this.int.implements();
    }

    ryg_0(ryx_0 ryx_02, ryh_0 ryh_02, float f2, float f3, ryw_0 ryw_02, ryv_0 ryv_02, rYt rYt2) {
        this.finally = ryx_02;
        this.extends = ryv_02;
        this.native = rYt2;
        this.package = ryh_02;
        this.volatile = f2;
        this.final = f3;
        this.int = ryw_02;
    }

    public String toString() {
        rqo_0 rqo_02 = rvy_0.implements.break(this);
        return rqo_02 == null ? super.toString() : rqo_02.toString();
    }

    public final ryh_0 this() {
        return this.package;
    }

    public int class(double d, double d2) {
        int n2 = this.int.case().orElseGet(this::else);
        return this.int.catch().class(d, d2, n2);
    }

    public void class(Random random, roC roC2, int n2, int n3, int n4, double d, xc_0 xc_02, xc_0 xc_03, int n5, long l2) {
        rrsr_1<?> rrsr_12 = this.extends.protected().get();
        rrsr_12.class(l2);
        rrsr_12.class(random, roC2, this, n2, n3, n4, d, xc_02, xc_03, n5, l2);
    }

    public int class() {
        return this.int.protected();
    }

    public boolean class(rRR rRR2, rfH rfH2, boolean bl2) {
        if (this.class(rfH2) >= 0.15f) {
            return false;
        }
        if (rfH2.c_() >= 0 && rfH2.c_() < 256 && rRR2.class(rRo.BLOCK, rfH2) < 10) {
            xc_0 xc_02 = rRR2.byte(rfH2);
            rxe_2 rxe_22 = rRR2.break(rfH2);
            if (rxe_22.class() == rxg_2.byte && xc_02.break() instanceof dj_1) {
                boolean bl3;
                if (!bl2) {
                    return true;
                }
                boolean bl4 = bl3 = rRR2.final(rfH2.byte()) && rRR2.final(rfH2.extends()) && rRR2.final(rfH2.private()) && rRR2.final(rfH2.protected());
                if (!bl3) {
                    return true;
                }
            }
        }
        return false;
    }

    public boolean class(rRR rRR2, rfH rfH2) {
        return this.class(rRR2, rfH2, true);
    }

    public final float class(rfH rfH2) {
        long l2 = rfH2.package();
        Long2FloatLinkedOpenHashMap long2FloatLinkedOpenHashMap = this.new.get();
        float f2 = long2FloatLinkedOpenHashMap.get(l2);
        if (!Float.isNaN(f2)) {
            return f2;
        }
        float f3 = this.break(rfH2);
        if (long2FloatLinkedOpenHashMap.size() == 1024) {
            long2FloatLinkedOpenHashMap.removeFirstFloat();
        }
        long2FloatLinkedOpenHashMap.put(l2, f3);
        return f3;
    }

    public void class(rrra_0 rrra_02, rKd rKd2, rKf rKf2, long l2, rqm rqm2, rfH rfH2) {
        List<List<Supplier<rDg<?, ?>>>> list = this.extends.byte();
        int n2 = rKm.values().length;
        for (int k = 0; k < n2; ++k) {
            int n3 = 0;
            if (rrra_02.class()) {
                for (rrrZ rrrZ2 : this.catch.getOrDefault(k, Collections.emptyList())) {
                    rqm2.break(l2, n3, k);
                    int n4 = rfH2.b_() >> 4;
                    int n5 = rfH2.d_() >> 4;
                    int n6 = n4 << 4;
                    int n7 = n5 << 4;
                    try {
                        rrra_02.class(rjh_0.class(rfH2), rrrZ2).forEach(rrrH2 -> rrrH2.class(rKf2, rrra_02, rKd2, rqm2, new rfi(n6, n7, n6 + 15, n7 + 15), new rfj(n4, n5)));
                    }
                    catch (Exception exception) {
                        KY kY = KY.class(exception, "Feature placement");
                        kY.class("Feature").class("Id", rvl_0.t.break(rrrZ2)).class("Description", () -> rrrZ2.toString());
                        throw new KU(kY);
                    }
                    ++n3;
                }
            }
            if (list.size() <= k) continue;
            for (Supplier supplier : list.get(k)) {
                rDg rDg2 = (rDg)supplier.get();
                rqm2.break(l2, n3, k);
                try {
                    rDg2.class(rKf2, rKd2, rqm2, rfH2);
                }
                catch (Exception exception) {
                    KY kY = KY.class(exception, "Feature placement");
                    kY.class("Feature").class("Id", rvl_0.q.break((ruo_0<?>)rDg2.throws)).class("Config", rDg2.case).class("Description", () -> rDg2.throws.toString());
                    throw new KU(kY);
                }
                ++n3;
            }
        }
    }

    public rYt break() {
        return this.native;
    }

    public boolean break(rRR rRR2, rfH rfH2) {
        xc_0 xc_02;
        if (this.class(rfH2) >= 0.15f) {
            return false;
        }
        return rfH2.c_() >= 0 && rfH2.c_() < 256 && rRR2.class(rRo.BLOCK, rfH2) < 10 && (xc_02 = rRR2.byte(rfH2)).catch() && xu_0.Pq.continue().class(rRR2, rfH2);
    }

    private float break(rfH rfH2) {
        float f2 = this.finally.protected.class(rfH2, this.extends());
        if (rfH2.c_() > 64) {
            float f3 = (float)(private.class((float)rfH2.b_() / 8.0f, (float)rfH2.d_() / 8.0f, false) * 4.0);
            return f2 - (f3 + (float)rfH2.c_() - 64.0f) * 0.05f / 30.0f;
        }
        return f2;
    }

    public ryv_0 throws() {
        return this.extends;
    }

    public final float finally() {
        return this.final;
    }

    public int catch() {
        return this.int.throws().orElseGet(this::synchronized);
    }

    public final float extends() {
        return this.finally.byte;
    }

    public int case() {
        return this.int.class();
    }

    public Optional<rYg> continue() {
        return this.int.extends();
    }

    private int else() {
        double d = rfU.class(this.finally.byte, 0.0f, 1.0f);
        double d2 = rfU.class(this.finally.throws, 0.0f, 1.0f);
        return rRH.class(d, d2);
    }

    public final float implements() {
        return this.finally.throws;
    }

    public Optional<rYj> new() {
        return this.int.finally();
    }

    public Optional<rYV> package() {
        return this.int.private();
    }

    public Optional<ns_2> super() {
        return this.int.native();
    }

    public boolean protected() {
        return this.implements() > 0.85f;
    }

    public final float private() {
        return this.volatile;
    }

    public final int final() {
        return this.int.byte();
    }

    public final int volatile() {
        return this.int.break();
    }

    private int synchronized() {
        double d = rfU.class(this.finally.byte, 0.0f, 1.0f);
        double d2 = rfU.class(this.finally.throws, 0.0f, 1.0f);
        return rrn_0.class(d, d2);
    }

    public ryw_0 native() {
        return this.int;
    }
}

