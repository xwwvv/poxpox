/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.ai_0;
import protected.an;
import protected.bn_1;
import protected.bq_1;
import protected.bw_1;
import protected.bz_2;
import protected.cb_1;
import protected.class;
import protected.ib_0;
import protected.j;
import protected.ps_1;
import protected.pv_2;
import protected.rab_2;
import protected.ras_1;
import protected.rdn_1;
import protected.rjU;
import protected.rlr_1;
import protected.rly_1;
import protected.rqR;
import protected.rrfo_0;
import protected.rrld_1;
import protected.rrnd_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.Bk
 */
public class bk_1
extends pv_2 {
    private static double[] byte;
    private static byte[] protected;
    private static short[] throws;
    private static boolean[] case;
    public Object[] break;
    private static long[] catch;

    private void byte() {
        if (this.break == null) {
            Object[] objectArray = this.break = new Object[protected[1]];
        }
    }

    public bk_1(class clazz) {
        super(clazz);
        HashSet hashSet;
        LinkedList linkedList;
        this.byte();
        this.break[bk_1.throws[0]] = linkedList = new LinkedList();
        this.break[bk_1.throws[1]] = hashSet = new HashSet();
    }

    static {
        bk_1.ntfClinit();
    }

    @Override
    public void class(j j2) {
        this.byte();
        if (((LinkedList)this.break[throws[4]]).isEmpty() || ((Set)this.break[throws[5]]).isEmpty()) {
            return;
        }
        long l2 = rqR.break() - catch[0];
        if (!((LinkedList)this.break[throws[6]]).isEmpty()) {
            ((LinkedList)this.break[throws[7]]).removeIf(bq_12 -> bq_12.class() < l2 ? case[4] : case[5]);
        }
        if (!((Set)this.break[throws[8]]).isEmpty()) {
            ((Set)this.break[throws[9]]).removeIf(bw_12 -> bw_12.class() < l2 ? case[2] : case[3]);
        }
        if (((LinkedList)this.break[throws[10]]).isEmpty() || ((Set)this.break[throws[11]]).isEmpty()) {
            return;
        }
        this.private();
    }

    private bw_1 class(bq_1 bq_12, Collection<bw_1> collection) {
        if (collection.isEmpty()) {
            return null;
        }
        bw_1 bw_12 = null;
        double d = byte[0];
        rjU rjU2 = bq_12.break();
        for (bw_1 bw_13 : collection) {
            double d2 = rjU2.implements(bw_13.break());
            if (!(d2 < d)) continue;
            d = d2;
            bw_12 = bw_13;
        }
        return bw_12;
    }

    private void class(bz_2 bz_22) {
        rrfo_0 rrfo_02 = rrfo_0.class(((bw_1)bz_22.class[throws[15]]).byte());
        if (rrfo_02 == null) {
            return;
        }
        cb_1 cb_12 = ((ps_1)this.class[throws[16]]).catch();
        rdn_1 rdn_12 = rrfo_02.byte();
        rly_1[] rly_1Array = rrfo_02.class();
        for (bn_1 bn_12 : ((bq_1)bz_22.class[throws[17]]).protected()) {
            ib_0 ib_02 = bn_12.class();
            double d = bn_12.break();
            List<rly_1> list = this.class(rly_1Array, d);
            if (list.isEmpty()) continue;
            rrld_1.class(ib_02, rdn_12, list, d);
            if (ib_02 == cb_12 || ib_02.BC() != ai_0.rM) continue;
            for (rly_1 rly_12 : list) {
                ib_02.break(rly_12);
            }
        }
    }

    private List<rly_1> class(rly_1[] rly_1Array, double d) {
        ArrayList<rly_1> arrayList = new ArrayList<rly_1>(rly_1Array.length);
        rly_1[] rly_1Array2 = rly_1Array;
        int n2 = rly_1Array2.length;
        for (int k = case[0]; k < n2; ++k) {
            int n3;
            rly_1 rly_12 = rly_1Array2[k];
            rlr_1 rlr_12 = rly_12.class();
            if (rlr_12.class() || (n3 = (int)(d * (double)rly_12.break() + byte[1])) <= protected[0]) continue;
            arrayList.add(new rly_1(rlr_12, n3, rly_12.byte(), rly_12.protected(), rly_12.throws()));
        }
        return arrayList;
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0xD9DF137CF1E50A15L;
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0x66FC58EF;
    }

    public boolean class() {
        return case[1];
    }

    public void class(an an2, rjU rjU2, rdn_1 rdn_12, List<bn_1> list) {
        this.byte();
        ((LinkedList)this.break[throws[2]]).add(new bq_1(an2, rjU2, rdn_12, list));
    }

    @Override
    public void class(rrnd_0 rrnd_02) {
        this.byte();
        if (!this.class()) {
            return;
        }
        rjU rjU2 = rrnd_02.break();
        int n2 = rrnd_02.class();
        if (n2 != rab_2.class(ras_1.break)) {
            ((Set)this.break[throws[3]]).add(new bw_1(rjU2, n2));
        }
    }

    public static String break(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{42, -14, -10, -81, -95, -85, 19, -79}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    private static void break() {
        short[] sArray = new short[18];
        sArray[1] = 1;
        sArray[3] = 1;
        sArray[5] = 1;
        sArray[8] = 1;
        sArray[9] = 1;
        sArray[11] = 1;
        sArray[13] = 1;
        sArray[14] = 1;
        sArray[15] = 1;
        sArray[16] = 1;
        throws = sArray;
    }

    private static void throws() {
        protected = new byte[]{20, 2};
    }

    private static /* synthetic */ void ntfClinit() {
        bk_1.catch();
        bk_1.case();
        bk_1.break();
        bk_1.protected();
        bk_1.throws();
    }

    private static void catch() {
        boolean[] blArray = new boolean[6];
        blArray[1] = true;
        blArray[2] = true;
        blArray[4] = true;
        case = blArray;
    }

    private static void case() {
        catch = new long[]{1000L};
    }

    private static void protected() {
        byte = new double[]{Double.MAX_VALUE, 0.5};
    }

    private void private() {
        this.byte();
        ArrayList<bz_2> arrayList = new ArrayList<bz_2>();
        Iterator iterator = ((LinkedList)this.break[throws[12]]).iterator();
        while (iterator.hasNext()) {
            bq_1 bq_12 = (bq_1)iterator.next();
            bw_1 object = this.class(bq_12, (Set)this.break[throws[13]]);
            if (object == null) continue;
            arrayList.add(new bz_2(bq_12, object));
            iterator.remove();
            ((Set)this.break[throws[14]]).remove(object);
        }
        for (bz_2 bz_22 : arrayList) {
            this.class(bz_22);
        }
    }
}

