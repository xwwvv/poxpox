/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.CH;
import protected.ay_1;
import protected.cx_0;
import protected.gm;
import protected.rlo_2;
import protected.xu_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.Ao
 */
public class ao_1
implements cx_0<rlo_2> {
    @Override
    public CH class(rlo_2 rlo_22, gm gm2, double d, double d2, double d3, double d4, double d5, double d6) {
        return new ay_1(gm2, d, d2, d3, xu_0.Ec.case());
    }
}

