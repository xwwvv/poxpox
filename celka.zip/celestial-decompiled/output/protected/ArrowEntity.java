/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.cj_0;
import protected.gm;
import protected.lo_0;
import protected.rfH;
import protected.rlg_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.Aa
 */
public class aa_1
extends lo_0 {
    aa_1(gm gm2, double d, double d2, double d3, double d4, double d5, double d6) {
        super(gm2, d, d2, d3);
        this.class(0.02f, 0.02f);
        this.throw *= this.continue.nextFloat() * 0.6f + 0.2f;
        this.finally = d4 * (double)0.2f + (Math.random() * 2.0 - 1.0) * (double)0.02f;
        this.extends = d5 * (double)0.2f + (Math.random() * 2.0 - 1.0) * (double)0.02f;
        this.native = d6 * (double)0.2f + (Math.random() * 2.0 - 1.0) * (double)0.02f;
        this.this = (int)(40.0 / (Math.random() * 0.8 + 0.2));
    }

    @Override
    public cj_0 class() {
        return cj_0.break;
    }

    @Override
    public void case() {
        this.protected = this.catch;
        this.throws = this.private;
        this.case = this.implements;
        this.extends += 0.005;
        if (this.this-- <= 0) {
            this.finally();
        } else {
            this.class(this.finally, this.extends, this.native);
            this.finally *= (double)0.85f;
            this.extends *= (double)0.85f;
            this.native *= (double)0.85f;
            if (!this.byte.break(new rfH(this.catch, this.private, this.implements)).class(rlg_0.break)) {
                this.finally();
            }
        }
    }
}

