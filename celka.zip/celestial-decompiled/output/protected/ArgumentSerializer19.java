/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.io.DataOutput;
import java.io.IOException;
import protected.rVi;
import protected.rci_2;
import protected.rck_1;
import protected.rcv_2;
import protected.rcw_1;
import protected.rcz_1;
import protected.rgP;
import protected.rgn_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.rct
 */
public class rct_1
extends rck_1 {
    public static final rcv_2<rct_1> class = new rcw_1();
    private final long break;

    @Override
    public /* synthetic */ rcz_1 byte() {
        return this.protected();
    }

    rct_1(long l2) {
        this.break = l2;
    }

    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        return object instanceof rct_1 && this.break == ((rct_1)object).break;
    }

    @Override
    public String toString() {
        return this.break + "L";
    }

    public int hashCode() {
        return (int)(this.break ^ this.break >>> 32);
    }

    public static rct_1 class(long l2) {
        return l2 >= -128L && l2 <= 1024L ? rci_2.class[(int)l2 + 128] : new rct_1(l2);
    }

    @Override
    public void class(DataOutput dataOutput) throws IOException {
        dataOutput.writeLong(this.break);
    }

    @Override
    public rgP class(String string, int n2) {
        rVi rVi2 = new rgn_0("L").class(catch);
        return new rgn_0(String.valueOf(this.break)).class(rVi2).class(case);
    }

    @Override
    public byte class() {
        return 4;
    }

    public rcv_2<rct_1> break() {
        return rct_1.class;
    }

    @Override
    public long throws() {
        return this.break;
    }

    @Override
    public float finally() {
        return this.break;
    }

    @Override
    public short catch() {
        return (short)(this.break & 0xFFFFL);
    }

    @Override
    public Number extends() {
        return this.break;
    }

    @Override
    public int case() {
        return (int)(this.break & 0xFFFFFFFFFFFFFFFFL);
    }

    @Override
    public double implements() {
        return this.break;
    }

    public rct_1 protected() {
        return this;
    }

    @Override
    public byte private() {
        return (byte)(this.break & 0xFFL);
    }
}

