/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.bl_0;
import protected.bv_0;
import protected.rfl;

/*
 * Renamed from protected.bF
 */
public class bf_0
extends bv_0 {
    public bf_0(rfl rfl2, bl_0[] bl_0Array, int n2) {
        super(rfl2, bl_0Array, n2);
    }
}

