/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.CH;
import protected.ca_0;
import protected.cx_0;
import protected.gm;
import protected.rlo_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class Cn
implements cx_0<rlo_2> {
    @Override
    public CH class(rlo_2 rlo_22, gm gm2, double d, double d2, double d3, double d4, double d5, double d6) {
        return new ca_0(gm2, d, d2, d3);
    }
}

