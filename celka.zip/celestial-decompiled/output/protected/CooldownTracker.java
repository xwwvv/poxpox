/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.rgP;
import protected.rjU;
import protected.rqR;
import protected.uo_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.uK
 */
public class uk_1 {
    private final rgP class;
    private long break;
    private rjU byte;

    public rjU byte() {
        return this.byte;
    }

    public uk_1(uo_1 uo_12, rgP rgP2, rjU rjU2) {
        this.class = rgP2;
        this.byte = rjU2;
        this.break = rqR.break();
    }

    public void class(rjU rjU2) {
        this.byte = rjU2;
        this.break = rqR.break();
    }

    public rgP class() {
        return this.class;
    }

    public long break() {
        return this.break;
    }
}

