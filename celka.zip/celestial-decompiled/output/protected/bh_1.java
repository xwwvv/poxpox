/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.Bh
 */
public class bh_1 {
    private static byte[] break;
    private static boolean[] byte;
    public static Object[] class;

    private static void byte() {
        Object[] objectArray = new Object[]{new int[]{1, 2}};
        bh_1.class = objectArray;
    }

    static {
        bh_1.ntfClinit();
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0xA473A86A;
    }

    public static String class(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{-52, 49, 19, 47, -54, 73, -18, 80}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    private static void class() {
        boolean[] blArray = new boolean[7];
        blArray[3] = true;
        blArray[5] = true;
        blArray[6] = true;
        byte = blArray;
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0xCC71D240FDAD24A2L;
    }

    private static void break() {
        break = new byte[]{2};
    }

    private static /* synthetic */ void ntfClinit() {
        bh_1.class();
        bh_1.break();
        bh_1.byte();
    }
}

