/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Maps
 *  com.mojang.serialization.DataResult
 *  com.mojang.serialization.DynamicOps
 *  com.mojang.serialization.RecordBuilder$AbstractStringBuilder
 */
package protected;

import com.google.common.collect.Maps;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.DynamicOps;
import com.mojang.serialization.RecordBuilder;
import java.util.Map;
import protected.rcd_2;
import protected.rcf_1;
import protected.rcn_2;
import protected.rcz_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.rcV
 */
class rcv_1
extends RecordBuilder.AbstractStringBuilder<rcz_1, rcd_2> {
    protected rcv_1(rcf_1 rcf_12) {
        super((DynamicOps)rcf_12);
    }

    protected /* synthetic */ Object append(String string, Object object, Object object2) {
        return this.class(string, (rcz_1)object, (rcd_2)object2);
    }

    protected DataResult<rcz_1> class(rcd_2 rcd_22, rcz_1 rcz_12) {
        if (rcz_12 != null && rcz_12 != rcn_2.break) {
            if (!(rcz_12 instanceof rcd_2)) {
                return DataResult.error((String)("mergeToMap called with not a map: " + rcz_12), (Object)rcz_12);
            }
            rcd_2 rcd_23 = new rcd_2(Maps.newHashMap(((rcd_2)rcz_12).private()));
            for (Map.Entry<String, rcz_1> entry : rcd_22.private().entrySet()) {
                rcd_23.class(entry.getKey(), entry.getValue());
            }
            return DataResult.success((Object)rcd_23);
        }
        return DataResult.success((Object)rcd_22);
    }

    protected rcd_2 class(String string, rcz_1 rcz_12, rcd_2 rcd_22) {
        rcd_22.class(string, rcz_12);
        return rcd_22;
    }

    protected rcd_2 class() {
        return new rcd_2();
    }

    protected /* synthetic */ DataResult build(Object object, Object object2) {
        return this.class((rcd_2)object, (rcz_1)object2);
    }

    protected /* synthetic */ Object initBuilder() {
        return this.class();
    }
}

