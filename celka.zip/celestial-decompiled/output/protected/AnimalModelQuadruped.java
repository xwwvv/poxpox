/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableList
 */
package protected;

import com.google.common.collect.ImmutableList;
import protected.an;
import protected.iq_1;
import protected.wn_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.wA
 */
public class wa_0<T extends an>
extends wn_0<T> {
    private final iq_1 class;
    private final iq_1 break;
    private final iq_1 byte;
    private final iq_1 protected;

    public wa_0(int n2) {
        this.class = new iq_1(this, 0, n2);
        this.break = new iq_1(this, 32, 0);
        this.byte = new iq_1(this, 32, 4);
        this.protected = new iq_1(this, 32, 8);
        if (n2 > 0) {
            this.class.class(-3.0f, 17.0f, -3.0f, 6.0f, 6.0f, 6.0f);
            this.break.class(-3.25f, 18.0f, -3.5f, 2.0f, 2.0f, 2.0f);
            this.byte.class(1.25f, 18.0f, -3.5f, 2.0f, 2.0f, 2.0f);
            this.protected.class(0.0f, 21.0f, -3.5f, 1.0f, 1.0f, 1.0f);
        } else {
            this.class.class(-4.0f, 16.0f, -4.0f, 8.0f, 8.0f, 8.0f);
        }
    }

    @Override
    public void class(T t2, float f2, float f3, float f4, float f5, float f6) {
    }

    @Override
    public Iterable<iq_1> class() {
        return ImmutableList.of((Object)this.class, (Object)this.break, (Object)this.byte, (Object)this.protected);
    }
}

