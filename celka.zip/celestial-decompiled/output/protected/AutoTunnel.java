/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Map;
import java.util.function.Supplier;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.bB;
import protected.bS;
import protected.be_0;
import protected.bg_0;
import protected.bm_0;
import protected.bp_0;
import protected.bq;
import protected.br_1;
import protected.cb_1;
import protected.class;
import protected.ps_1;
import protected.px_2;
import protected.rYB;
import protected.ra_2;
import protected.rc_1;
import protected.rn_1;
import protected.ro_2;
import protected.roe_0;
import protected.rrik_0;
import protected.rrqx_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.br
 */
public class br_0
extends bq
implements ra_2 {
    private static short[] catch;
    private static boolean[] private;
    private static byte[] implements;
    private static String[] finally;
    public Object[] break;
    private static float[] extends;
    private static double[] native;
    public static Object[] throws;

    @Override
    public boolean byte() {
        this.volatile();
        return (Boolean)this.break[catch[19]] != false && ((Supplier)this.break[catch[20]] == null || (Boolean)((Supplier)this.break[catch[21]]).get() != false) ? private[2] : private[3];
    }

    private static void int() {
        implements = new byte[]{9, 7, 8, 2};
    }

    public br_0(class clazz) {
        super(clazz);
        this.volatile();
        Boolean bl2 = private[0];
        this.break[br_0.catch[0]] = bl2;
        bB bB2 = new bB();
        this.break[br_0.catch[1]] = bB2;
        bp_0 bp_02 = new bp_0(this, clazz);
        this.break[br_0.catch[2]] = bp_02;
        bS bS2 = new bS(clazz, (bm_0)this.break[catch[4]]);
        this.break[br_0.catch[5]] = bS2;
        ((bm_0)this.break[catch[3]]).class(bS2);
        bg_0 bg_02 = new bg_0(clazz, (bm_0)this.break[catch[7]]);
        this.break[br_0.catch[8]] = bg_02;
        ((bm_0)this.break[catch[6]]).class(bg_02);
    }

    static {
        br_0.ntfClinit();
    }

    @Override
    public String class() {
        return finally[0];
    }

    @Override
    public rn_1 class(boolean bl2, boolean bl3) {
        this.volatile();
        ((bB)this.break[catch[9]]).class(((ps_1)this.case[catch[10]]).catch().Ps());
        if (((bB)this.break[catch[11]]).class() >= extends[0]) {
            Boolean bl4 = private[1];
            this.break[br_0.catch[12]] = bl4;
        }
        ps_1 ps_12 = ((class)this.case[catch[13]]).throw();
        br_1 br_12 = ((class)this.case[catch[14]]).private();
        if (((Boolean)this.break[catch[15]]).booleanValue()) {
            this.class(ps_12, br_12);
            return new rn_1(null, (rc_1)((Object)rc_1.staticFields8c829f9bf33c3c2bb018688b591a16ef[catch[16]]));
        }
        this.class(ps_12);
        return new rn_1((ro_2)this.break[catch[17]], (rc_1)((Object)rc_1.staticFields8c829f9bf33c3c2bb018688b591a16ef[catch[18]]));
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0x396E1127;
    }

    private void class(ps_1 ps_12) {
        rYB rYB2 = ps_12.case();
        cb_1 cb_12 = ps_12.catch();
        roe_0 roe_02 = rYB2.instanceof();
        if (roe_02.class(cb_12) <= native[0]) {
            ((rrqx_1)rrqx_1.staticFields09f1f28026cd378cb9df490a64ac8f2a[catch[35]]).private().static().new();
            this.private();
        }
    }

    @Override
    public void class(Supplier<Boolean> supplier, Map<be_0, rrik_0> map) {
        Supplier<Boolean> supplier2;
        this.volatile();
        Boolean bl2 = private[4];
        this.break[br_0.catch[22]] = bl2;
        this.break[br_0.catch[23]] = supplier2 = supplier;
        ro_2 ro_22 = new ro_2(((ps_1)this.case[catch[24]]).volatile(), ((ps_1)this.case[catch[25]]).catch().Pg());
        this.break[br_0.catch[26]] = ro_22;
        ((bm_0)this.break[catch[27]]).protected();
        ((bS)this.break[catch[28]]).class(private[5]);
        ((bg_0)this.break[catch[29]]).class(private[6]);
        ((bS)this.break[catch[30]]).class(map);
    }

    public static String class(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{79, -47, -25, -118, 0, 74, -107, -74}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0x8322F1F17AC6ADC6L;
    }

    private void class(ps_1 ps_12, br_1 br_12) {
        this.volatile();
        px_2 px_22 = br_12.protected().orElse(ps_12.protected());
        if (((Boolean)this.break[catch[36]]).booleanValue()) {
            br_12.class(px_22.case(px_22.protected() - extends[1]), private[8]);
            if (px_22.protected() <= extends[2]) {
                Boolean bl2 = private[9];
                this.break[br_0.catch[37]] = bl2;
            }
        } else {
            br_12.class(px_22.case(px_22.protected() + extends[3]), private[10]);
            if (px_22.protected() >= extends[4]) {
                ((bB)this.break[catch[38]]).byte();
                Boolean bl3 = private[11];
                this.break[br_0.catch[39]] = bl3;
                Boolean bl4 = private[12];
                this.break[br_0.catch[40]] = bl4;
            }
        }
    }

    private static /* synthetic */ void ntfClinit() {
        br_0.finally();
        br_0.extends();
        br_0.implements();
        br_0.package();
        br_0.final();
        br_0.int();
        br_0.native();
    }

    private static void finally() {
        boolean[] blArray = new boolean[19];
        blArray[0] = true;
        blArray[1] = true;
        blArray[2] = true;
        blArray[4] = true;
        blArray[5] = true;
        blArray[6] = true;
        blArray[11] = true;
        blArray[18] = true;
        private = blArray;
    }

    private static void extends() {
        finally = new String[]{new String("Auto Tunneling")};
    }

    private static void implements() {
        short[] sArray = new short[43];
        sArray[0] = 8;
        sArray[1] = 5;
        sArray[2] = 2;
        sArray[3] = 2;
        sArray[4] = 2;
        sArray[5] = 3;
        sArray[6] = 2;
        sArray[7] = 2;
        sArray[8] = 4;
        sArray[9] = 5;
        sArray[10] = 1;
        sArray[11] = 5;
        sArray[12] = 7;
        sArray[15] = 7;
        sArray[16] = 1;
        sArray[17] = 6;
        sArray[20] = 1;
        sArray[21] = 1;
        sArray[23] = 1;
        sArray[24] = 1;
        sArray[25] = 1;
        sArray[26] = 6;
        sArray[27] = 2;
        sArray[28] = 3;
        sArray[29] = 4;
        sArray[30] = 3;
        sArray[33] = 2;
        sArray[34] = 5;
        sArray[36] = 8;
        sArray[37] = 8;
        sArray[38] = 5;
        sArray[39] = 8;
        sArray[40] = 7;
        sArray[41] = 2;
        sArray[42] = 2;
        catch = sArray;
    }

    private static void package() {
        extends = new float[]{15.0f, 50.0f, -90.0f, 50.0f, 90.0f, 15.0f, 50.0f};
    }

    @Override
    public void protected() {
        this.volatile();
        super.protected();
        if (((Boolean)this.break[catch[31]]).booleanValue()) {
            Boolean bl2 = private[7];
            this.break[br_0.catch[32]] = bl2;
            ((bm_0)this.break[catch[33]]).catch();
            ((bB)this.break[catch[34]]).byte();
        }
    }

    public void private() {
        this.volatile();
        this.protected();
        ((bm_0)this.break[catch[41]]).class();
        ((bm_0)this.break[catch[42]]).byte();
    }

    private static void final() {
        native = new double[]{2.0};
    }

    private void volatile() {
        if (this.break == null) {
            Object[] objectArray = this.break = new Object[implements[0]];
            objectArray[br_0.private[13]] = private[14];
            objectArray[br_0.implements[1]] = private[15];
            objectArray[br_0.implements[2]] = private[16];
        }
    }

    private static void native() {
        Object[] objectArray = new Object[]{Float.valueOf(0.0f), Float.valueOf(0.0f)};
        throws = objectArray;
    }
}

