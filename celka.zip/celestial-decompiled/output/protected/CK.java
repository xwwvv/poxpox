/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.ch_0;
import protected.cj_0;
import protected.gm;
import protected.lo_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class CK
extends lo_0 {
    protected final ch_0 class;
    private final float break;
    private float interface = 0.91f;
    private float char;
    private float abstract;
    private float long;
    private boolean float;

    public void byte(int n2) {
        this.char = (float)((n2 & 0xFF0000) >> 16) / 255.0f;
        this.abstract = (float)((n2 & 0xFF00) >> 8) / 255.0f;
        this.long = (float)((n2 & 0xFF) >> 0) / 255.0f;
        this.float = true;
    }

    protected CK(gm gm2, double d, double d2, double d3, ch_0 ch_02, float f2) {
        super(gm2, d, d2, d3);
        this.class = ch_02;
        this.break = f2;
    }

    @Override
    public cj_0 class() {
        return cj_0.byte;
    }

    @Override
    public int break(float f2) {
        return 0xF000F0;
    }

    public void break(int n2) {
        float f2 = (float)((n2 & 0xFF0000) >> 16) / 255.0f;
        float f3 = (float)((n2 & 0xFF00) >> 8) / 255.0f;
        float f4 = (float)((n2 & 0xFF) >> 0) / 255.0f;
        float f5 = 1.0f;
        this.class(f2 * 1.0f, f3 * 1.0f, f4 * 1.0f);
    }

    @Override
    public void case() {
        this.protected = this.catch;
        this.throws = this.private;
        this.case = this.implements;
        if (this.super++ >= this.this) {
            this.finally();
        } else {
            this.break(this.class);
            if (this.super > this.this / 2) {
                this.throws(1.0f - ((float)this.super - (float)(this.this / 2)) / (float)this.this);
                if (this.float) {
                    this.synchronized += (this.char - this.synchronized) * 0.2f;
                    this.return += (this.abstract - this.return) * 0.2f;
                    this.public += (this.long - this.public) * 0.2f;
                }
            }
            this.extends += (double)this.break;
            this.class(this.finally, this.extends, this.native);
            this.finally *= (double)this.interface;
            this.extends *= (double)this.interface;
            this.native *= (double)this.interface;
            if (this.volatile) {
                this.finally *= (double)0.7f;
                this.native *= (double)0.7f;
            }
        }
    }

    protected void case(float f2) {
        this.interface = f2;
    }
}

