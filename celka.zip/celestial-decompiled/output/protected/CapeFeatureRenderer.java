/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.fY;
import protected.lz_1;
import protected.ml_1;
import protected.qy_1;
import protected.zi_0;
import protected.zt_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class Zf
extends lz_1 {
    final zi_0 throws;
    private boolean case;
    final /* synthetic */ zt_0 class;

    public Zf(zt_0 zt_02, zi_0 zi_02, int n2, int n3) {
        this.class = zt_02;
        super(n2, n3, 25, 25, zi_02.class());
        this.throws = zi_02;
    }

    private void class(ml_1 ml_12, fY fY2) {
        fY2.class(zt_0.class);
        ml_12.class();
        ml_12.class((double)this.volatile, (double)this.final, 0.0);
        Zf.class(ml_12, 0, 0, 0.0f, 75.0f, 25, 25, 128, 128);
        ml_12.break();
    }

    public void class(boolean bl2) {
        this.case = bl2;
    }

    @Override
    public void break(ml_1 ml_12, int n2, int n3, float f2) {
        qy_1 qy_12 = qy_1.instanceof();
        this.class(ml_12, qy_12.A());
        this.throws.class(this.class.final, this.volatile + 5, this.final + 5);
        if (this.case) {
            this.break(ml_12, qy_12.A());
        }
    }

    private void break(ml_1 ml_12, fY fY2) {
        fY2.class(zt_0.class);
        ml_12.class();
        ml_12.class((double)this.volatile, (double)this.final, 0.0);
        Zf.class(ml_12, 0, 0, 25.0f, 75.0f, 25, 25, 128, 128);
        ml_12.break();
    }

    @Override
    public boolean B_() {
        return super.B_() || this.case;
    }
}

