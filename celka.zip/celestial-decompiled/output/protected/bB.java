/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.rjU;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class bB {
    private static byte[] break;
    private static boolean[] byte;
    private static float[] protected;
    private static short[] throws;
    public Object[] class;

    public void byte() {
        Object var5_1 = null;
        this.class[bB.throws[6]] = var5_1;
        Float f2 = Float.valueOf(protected[0]);
        this.class[bB.throws[7]] = f2;
    }

    public bB() {
        this.protected();
    }

    static {
        bB.ntfClinit();
    }

    public static String class(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{-38, -13, -126, -58, -81, 120, -10, -19}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    public void class(rjU rjU2) {
        if ((rjU)this.class[throws[0]] == null) {
            rjU rjU3 = rjU2;
            this.class[bB.throws[1]] = rjU3;
        }
        bB bB2 = this;
        Float f2 = Float.valueOf(((Float)bB2.class[throws[2]]).floatValue() + (float)((rjU)this.class[throws[3]]).case(rjU2));
        bB2.class[bB.throws[4]] = f2;
        rjU rjU4 = rjU2;
        this.class[bB.throws[5]] = rjU4;
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0x63810C63;
    }

    public float class() {
        return ((Float)this.class[throws[9]]).floatValue();
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0xCD71A977C92C11A8L;
    }

    public rjU break() {
        return (rjU)this.class[throws[8]];
    }

    private static void throws() {
        protected = new float[2];
    }

    private static /* synthetic */ void ntfClinit() {
        bB.private();
        bB.catch();
        bB.throws();
        bB.case();
    }

    private static void catch() {
        short[] sArray = new short[10];
        sArray[2] = 1;
        sArray[4] = 1;
        sArray[7] = 1;
        sArray[9] = 1;
        throws = sArray;
    }

    private static void case() {
        break = new byte[]{2};
    }

    private void protected() {
        if (this.class == null) {
            Object[] objectArray = this.class = new Object[break[0]];
            objectArray[bB.byte[0]] = Float.valueOf(protected[1]);
        }
    }

    private static void private() {
        byte = new boolean[]{true};
    }
}

