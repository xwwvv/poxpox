/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.rfH;
import protected.xc_0;

/*
 * Renamed from protected.bs
 */
@FunctionalInterface
public interface bs_0 {
    public boolean test(rfH var1, xc_0 var2);
}

