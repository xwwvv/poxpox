/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.util.Random;
import protected.eC;
import protected.ef_0;
import protected.ev_0;
import protected.rdn_1;
import protected.rxS;
import protected.rxq_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.aQ
 */
public class aq_0
extends ev_0 {
    protected aq_0(ef_0 ef_02, rxq_1 ... rxq_1Array) {
        super(ef_02, eC.BREAKABLE, rxq_1Array);
    }

    @Override
    public int class() {
        return 3;
    }

    @Override
    public boolean class(rdn_1 rdn_12) {
        return rdn_12.throws() ? true : super.class(rdn_12);
    }

    public static boolean class(rdn_1 rdn_12, int n2, Random random) {
        if (rdn_12.break() instanceof rxS && random.nextFloat() < 0.6f) {
            return false;
        }
        return random.nextInt(n2 + 1) > 0;
    }

    @Override
    public int class(int n2) {
        return 5 + (n2 - 1) * 8;
    }

    @Override
    public int break(int n2) {
        return super.class(n2) + 50;
    }
}

