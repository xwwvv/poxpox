/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.util.BitSet;
import protected.HU;
import protected.rpr_0;
import protected.yz_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.yv
 */
class yv_2
extends yz_2 {
    yv_2() {
    }

    @Override
    public boolean class(rpr_0 rpr_02, rpr_0 rpr_03) {
        return false;
    }

    @Override
    public void class(HU hU, BitSet bitSet) {
        throw new UnsupportedOperationException();
    }
}

