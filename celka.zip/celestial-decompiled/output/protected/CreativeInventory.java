/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.util.List;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public interface VK<T> {
    public List<T> class(String var1);
}

