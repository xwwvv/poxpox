/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.case;
import protected.eb_1;
import protected.eg_2;
import protected.eo_2;
import protected.ep_2;
import protected.er_2;
import protected.interface;
import protected.rrmH;
import protected.rrmX;
import protected.rrmY;
import protected.rrmf;
import protected.rrmf_0;
import protected.rrmh_0;
import protected.rrmi_0;
import protected.rrmm;
import protected.rrmo_0;
import protected.rrms;
import protected.rrmw;
import protected.rrmw_0;
import protected.rrua;
import protected.rruf;
import protected.rrug;
import protected.rrut;
import protected.sH;
import protected.sK;
import protected.sR;
import protected.sV;
import protected.sY;
import protected.sa_0;
import protected.sf;
import protected.sh_0;
import protected.sj;
import protected.sn_0;
import protected.so;
import protected.so_0;
import protected.sp;
import protected.sw;
import protected.sx;
import protected.sx_0;
import protected.try;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.sz
 */
public class sz_0 {
    private static boolean[] class;
    private static byte[] break;
    private static short[] byte;

    private static void byte() {
        short[] sArray = new short[4];
        sArray[1] = 1;
        sArray[2] = 2;
        sArray[3] = 3;
        byte = sArray;
    }

    private sz_0() {
    }

    static {
        sz_0.ntfClinit();
    }

    public static String class(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{-23, -98, -37, 85, -61, 114, -69, -50}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0x2BA3BAF07BA4843DL;
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0x15E5242C;
    }

    public static List<interface> class(case case_) {
        Objects.requireNonNull(case_);
        try[] tryArray = new try[break[0]];
        tryArray[sz_0.class[0]] = new sV(case_);
        tryArray[sz_0.class[1]] = new eg_2(case_);
        tryArray[sz_0.break[1]] = new sf(case_);
        tryArray[sz_0.break[2]] = new sj(case_);
        tryArray[sz_0.break[3]] = new so(case_);
        tryArray[sz_0.break[4]] = new so_0(case_);
        tryArray[sz_0.break[5]] = new er_2(case_);
        tryArray[sz_0.break[6]] = new sR(case_);
        tryArray[sz_0.break[7]] = new sx_0(case_);
        tryArray[sz_0.break[8]] = new sw(case_);
        tryArray[sz_0.break[9]] = new eo_2(case_);
        tryArray[sz_0.break[10]] = new eb_1(case_);
        tryArray[sz_0.break[11]] = new sH(case_);
        tryArray[sz_0.break[12]] = new sp(case_);
        tryArray[sz_0.break[13]] = new sK(case_);
        tryArray[sz_0.break[14]] = new sY(case_);
        tryArray[sz_0.break[15]] = new sh_0(case_);
        tryArray[sz_0.break[16]] = new ep_2(case_);
        tryArray[sz_0.break[17]] = new rruf(case_);
        tryArray[sz_0.break[18]] = new rrmf(case_);
        tryArray[sz_0.break[19]] = new rrms(case_);
        tryArray[sz_0.break[20]] = new rrmX(case_);
        tryArray[sz_0.break[21]] = new rrmf_0(case_);
        tryArray[sz_0.break[22]] = new rrmH(case_);
        tryArray[sz_0.break[23]] = new rrmm(case_);
        tryArray[sz_0.break[24]] = new rrmw(case_);
        tryArray[sz_0.break[25]] = new rrmi_0(case_);
        tryArray[sz_0.break[26]] = new rrmo_0(case_);
        tryArray[sz_0.break[27]] = new rrug(case_);
        tryArray[sz_0.break[28]] = new rrmY(case_);
        tryArray[sz_0.break[29]] = new rrmw_0(case_);
        tryArray[sz_0.break[30]] = new rrut(case_);
        tryArray[sz_0.break[31]] = new rrua(case_);
        tryArray[sz_0.break[32]] = new rrmh_0(case_);
        tryArray[sz_0.break[33]] = new sx(case_);
        tryArray[sz_0.break[34]] = new sa_0(case_);
        ArrayList<try> arrayList = new ArrayList<try>(Arrays.asList(tryArray));
        sn_0 sn_02 = new sn_0(case_);
        arrayList.add((try)sn_02.class[byte[0]]);
        arrayList.add((try)sn_02.class[byte[1]]);
        arrayList.add((try)sn_02.class[byte[2]]);
        arrayList.add((try)sn_02.class[byte[3]]);
        return Collections.unmodifiableList(arrayList);
    }

    private static void class() {
        break = new byte[]{36, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35};
    }

    private static void break() {
        boolean[] blArray = new boolean[2];
        blArray[1] = true;
        sz_0.class = blArray;
    }

    private static /* synthetic */ void ntfClinit() {
        sz_0.break();
        sz_0.byte();
        sz_0.class();
    }
}

