/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.tq_0;

/*
 * Renamed from protected.tz
 * Illegal identifiers - consider using --renameillegalidents true
 */
class tz_0 {
    static final /* synthetic */ int[] class;

    static {
        tz_0.class = new int[tq_0.values().length];
        try {
            tz_0.class[tq_0.EMPTY.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            tz_0.class[tq_0.BLOCK.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            tz_0.class[tq_0.ITEM.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            tz_0.class[tq_0.THROW_SPEAR.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            tz_0.class[tq_0.BOW_AND_ARROW.ordinal()] = 5;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            tz_0.class[tq_0.CROSSBOW_CHARGE.ordinal()] = 6;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            tz_0.class[tq_0.CROSSBOW_HOLD.ordinal()] = 7;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}

