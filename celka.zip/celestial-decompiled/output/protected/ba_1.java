/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.Y;
import protected.class;
import protected.fu_2;
import protected.pv_2;
import protected.rjr_2;
import protected.rmD;
import protected.rmU;
import protected.rmj;
import protected.rmt;
import protected.rram_0;
import protected.rrfo_1;
import protected.rrlu_1;
import protected.rus_2;
import protected.rxi_1;
import protected.vm_1;
import protected.y_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.BA
 */
public class ba_1
extends pv_2 {
    private static boolean[] byte;
    public Object[] break;
    private static short[] protected;

    private void byte() {
        if (this.break == null) {
            Object[] objectArray = this.break = new Object[byte[6]];
            objectArray[ba_1.byte[7]] = byte[8];
        }
    }

    public ba_1(class clazz) {
        super(clazz);
        this.byte();
    }

    static {
        ba_1.ntfClinit();
    }

    public boolean class() {
        this.byte();
        return (Boolean)this.break[protected[1]];
    }

    @Override
    public void class(rrlu_1 rrlu_12) {
        super.class(rrlu_12);
        vm_1 vm_12 = rrlu_12.class();
        if (vm_12 instanceof fu_2) {
            fu_2 fu_22 = (fu_2)vm_12;
            vm_12 = fu_22.G_();
            if (((rjr_2)((Object)vm_12)).case != 0 && !(vm_12 instanceof rxi_1)) {
                this.class(byte[3]);
            }
        }
    }

    @Override
    public void class(rrfo_1 rrfo_12) {
        super.class(rrfo_12);
        if (rrfo_12.break() instanceof fu_2) {
            this.class(byte[4]);
        }
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0xEB60E65D;
    }

    private void class(boolean bl2) {
        this.byte();
        Boolean bl3 = bl2;
        this.break[ba_1.protected[2]] = bl3;
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0xF8A2773E464FEECDL;
    }

    @Override
    public void class(rram_0 rram_02) {
        super.class(rram_02);
        this.class(byte[5]);
    }

    public static String break(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{110, 92, -71, -121, -64, 81, 50, -54}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    @Override
    public void break(y_0 y_02) {
        super.break(y_02);
        if (y_02.byte() == (Y)((Object)Y.staticFields22c81230f53b33f2a682b4198db24cc4[protected[0]])) {
            rus_2<?> rus_22 = y_02.protected();
            if (rus_22 instanceof rmt) {
                this.class(byte[0]);
            } else if (rus_22 instanceof rmD) {
                rmD rmD2 = (rmD)rus_22;
                if (rmD2.break() == rmU.OPEN_INVENTORY) {
                    this.class(byte[1]);
                }
            } else if (rus_22 instanceof rmj) {
                this.class(byte[2]);
            }
        }
    }

    private static void break() {
        protected = new short[3];
    }

    private static /* synthetic */ void ntfClinit() {
        ba_1.protected();
        ba_1.break();
    }

    private static void protected() {
        boolean[] blArray = new boolean[9];
        blArray[0] = true;
        blArray[1] = true;
        blArray[3] = true;
        blArray[6] = true;
        byte = blArray;
    }
}

