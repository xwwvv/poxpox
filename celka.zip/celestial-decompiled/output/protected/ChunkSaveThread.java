/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Map;
import java.util.concurrent.LinkedBlockingQueue;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.class;
import protected.rfj;
import protected.roj_0;
import protected.si_2;
import protected.sj_1;
import protected.st_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.Sf
 */
public class sf_1
implements Runnable {
    public Object[] class;
    private static boolean[] break;
    private static short[] byte;

    private void byte() {
        if (this.class == null) {
            Object[] objectArray = this.class = new Object[break[0]];
        }
    }

    sf_1(si_2 si_22) {
        this.byte();
        si_2 si_23 = si_22;
        this.class[sf_1.byte[0]] = si_23;
    }

    static {
        sf_1.ntfClinit();
    }

    @Override
    public void run() {
        while (true) {
            try {
                while (true) {
                    rfj rfj2 = (rfj)((LinkedBlockingQueue)((si_2)this.class[sf_1.byte[1]]).break[byte[2]]).take();
                    roj_0 roj_02 = (roj_0)((Map)((si_2)this.class[sf_1.byte[3]]).break[byte[4]]).remove(rfj2);
                    if (((LinkedBlockingQueue)((si_2)this.class[sf_1.byte[5]]).break[byte[6]]).size() > (Integer)protected.class.instanceof().rw.class[byte[7]]) continue;
                    st_1 st_12 = sj_1.class(roj_02);
                    ((si_2)this.class[byte[8]]).class(st_12);
                }
            }
            catch (InterruptedException interruptedException) {
                interruptedException.printStackTrace();
            }
            catch (Throwable throwable) {
                throwable.printStackTrace();
                continue;
            }
            break;
        }
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0x6B5F36D2;
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0xDE8EB52798DD2F2DL;
    }

    public static String class(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{53, 29, -88, -44, -4, -56, -89, -20}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    private static void class() {
        break = new boolean[]{true};
    }

    private static void break() {
        short[] sArray = new short[9];
        sArray[2] = 2;
        sArray[4] = 3;
        sArray[6] = 2;
        byte = sArray;
    }

    private static /* synthetic */ void ntfClinit() {
        sf_1.class();
        sf_1.break();
    }
}

