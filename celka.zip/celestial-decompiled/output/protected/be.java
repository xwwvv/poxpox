/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  it.unimi.dsi.fastutil.longs.Long2DoubleOpenHashMap
 */
package protected;

import it.unimi.dsi.fastutil.longs.Long2DoubleOpenHashMap;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.class;
import protected.is;
import protected.ps_1;
import protected.rbg_0;
import protected.reu_2;
import protected.rfH;
import protected.rgw_1;
import protected.ru_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class be {
    private static byte[] break;
    private static double[] byte;
    public Object[] class;
    private static short[] protected;
    private static boolean[] throws;
    private static String[] case;

    private static void byte() {
        boolean[] blArray = new boolean[14];
        blArray[0] = true;
        blArray[1] = true;
        blArray[3] = true;
        blArray[5] = true;
        blArray[9] = true;
        throws = blArray;
    }

    public be(rfH rfH2, double d, int n2) {
        this(rfH2.b_(), rfH2.c_(), rfH2.d_(), d, n2);
    }

    public be(int n2, int n3, int n4, double d, int n5) {
        this.class();
        Integer n6 = n2;
        this.class[be.protected[0]] = n6;
        Integer n7 = n3;
        this.class[be.protected[1]] = n7;
        Integer n8 = n4;
        this.class[be.protected[2]] = n8;
        Double d2 = d;
        this.class[be.protected[3]] = d2;
        Integer n9 = n5;
        this.class[be.protected[4]] = n9;
        Integer n10 = n5 * n5;
        this.class[be.protected[5]] = n10;
    }

    static {
        be.ntfClinit();
    }

    public void class(Long2DoubleOpenHashMap long2DoubleOpenHashMap) {
        for (int k = -((Integer)this.class[protected[16]]).intValue(); k <= (Integer)this.class[protected[17]]; ++k) {
            for (int i2 = -((Integer)this.class[protected[18]]).intValue(); i2 <= (Integer)this.class[protected[19]]; ++i2) {
                for (int i3 = -((Integer)this.class[protected[20]]).intValue(); i3 <= (Integer)this.class[protected[21]]; ++i3) {
                    if (k * k + i2 * i2 + i3 * i3 > (Integer)this.class[protected[22]] * (Integer)this.class[protected[23]]) continue;
                    long l2 = ru_1.byte((Integer)this.class[protected[24]] + k, (Integer)this.class[protected[25]] + i2, (Integer)this.class[protected[26]] + i3);
                    long2DoubleOpenHashMap.put(l2, long2DoubleOpenHashMap.get(l2) * (Double)this.class[protected[27]]);
                }
            }
        }
    }

    public double class(int n2, int n3, int n4) {
        int n5;
        int n6;
        int n7 = n2 - (Integer)this.class[protected[6]];
        return n7 * n7 + (n6 = n3 - (Integer)this.class[protected[7]]) * n6 + (n5 = n4 - (Integer)this.class[protected[8]]) * n5 <= (Integer)this.class[protected[9]] ? (Double)this.class[protected[10]] : byte[0];
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0x5ACFB5E0ECA82E62L;
    }

    public static String class(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{-121, -117, 8, 89, 21, -29, 27, 56}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0xAF6FCA40;
    }

    public static List<be> class(ps_1 ps_12) {
        if (!((Boolean)protected.class.instanceof().transient.class[protected[11]]).booleanValue()) {
            return Collections.emptyList();
        }
        ArrayList<be> arrayList = new ArrayList<be>();
        double d = (Double)protected.class.instanceof().D.class[protected[12]];
        double d2 = (Double)class[protected[13]];
        if (d != byte[1]) {
            ps_12.package().break().class(case[0], throws[0], (Integer)ps_12.volatile().break[protected[14]], (Integer)ps_12.volatile().break[protected[15]], break[0]).forEach(rfH2 -> arrayList.add(new be((rfH)rfH2, d, (Integer)protected.class.instanceof().BP.class[protected[29]])));
        }
        if (d2 != byte[2]) {
            ps_12.implements().filter(an2 -> an2 instanceof is).filter(an2 -> !(an2 instanceof rgw_1) || (double)ps_12.catch().rX() < byte[3] ? throws[5] : throws[6]).filter(an2 -> !(an2 instanceof rbg_0) || ((rbg_0)an2).Sr() != null ? throws[3] : throws[4]).filter(an2 -> !(an2 instanceof reu_2) || ((reu_2)an2).sk() ? throws[1] : throws[2]).forEach(an2 -> arrayList.add(new be(an2.Bs(), d2, (Integer)protected.class.instanceof().long.class[protected[28]])));
        }
        return arrayList;
    }

    private void class() {
        if (this.class == null) {
            Object[] objectArray = this.class = new Object[break[1]];
            objectArray[be.throws[7]] = throws[8];
            objectArray[be.throws[9]] = throws[10];
            objectArray[be.break[2]] = throws[11];
            objectArray[be.break[3]] = byte[4];
            objectArray[be.break[4]] = throws[12];
            objectArray[be.break[5]] = throws[13];
        }
    }

    private static void break() {
        case = new String[]{new String("mob_spawner")};
    }

    private static void throws() {
        short[] sArray = new short[30];
        sArray[1] = 1;
        sArray[2] = 2;
        sArray[3] = 3;
        sArray[4] = 4;
        sArray[5] = 5;
        sArray[7] = 1;
        sArray[8] = 2;
        sArray[9] = 5;
        sArray[10] = 3;
        sArray[15] = 2;
        sArray[16] = 4;
        sArray[17] = 4;
        sArray[18] = 4;
        sArray[19] = 4;
        sArray[20] = 4;
        sArray[21] = 4;
        sArray[22] = 4;
        sArray[23] = 4;
        sArray[25] = 1;
        sArray[26] = 2;
        sArray[27] = 3;
        protected = sArray;
    }

    private static /* synthetic */ void ntfClinit() {
        be.byte();
        be.break();
        be.throws();
        be.case();
        be.protected();
    }

    private static void case() {
        double[] dArray = new double[5];
        dArray[0] = 1.0;
        dArray[1] = 1.0;
        dArray[2] = 1.0;
        dArray[3] = 0.5;
        byte = dArray;
    }

    private static void protected() {
        break = new byte[]{2, 6, 2, 3, 4, 5};
    }
}

