/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.serialization.Codec
 */
package protected;

import com.mojang.serialization.Codec;
import java.util.Random;
import protected.roC;
import protected.rrsa_1;
import protected.rrsb;
import protected.rrsb_0;
import protected.rrsd_1;
import protected.rrse_1;
import protected.rrsg_0;
import protected.rrsg_1;
import protected.rrsi_1;
import protected.rrsk_1;
import protected.rrso_0;
import protected.rrso_1;
import protected.rrsp_0;
import protected.rrsr_0;
import protected.rrsr_1;
import protected.rrss;
import protected.rrss_0;
import protected.rrsu_1;
import protected.rrsv_1;
import protected.rvl_0;
import protected.ryg_0;
import protected.xc_0;
import protected.xu_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.rrsE
 */
public abstract class rrse_0<C extends rrsa_1> {
    private static final xc_0 class = xu_0.finally.continue();
    private static final xc_0 break = xu_0.implements.continue();
    private static final xc_0 byte = xu_0.native.continue();
    private static final xc_0 protected = xu_0.char.continue();
    private static final xc_0 throws = xu_0.break.continue();
    private static final xc_0 import = xu_0.extends.continue();
    private static final xc_0 short = xu_0.throw.continue();
    private static final xc_0 default = xu_0.interface.continue();
    private static final xc_0 const = xu_0.sw.continue();
    private static final xc_0 strictfp = xu_0.Bi.continue();
    private static final xc_0 boolean = xu_0.PY.continue();
    private static final xc_0 transient = xu_0.PR.continue();
    private static final xc_0 for = xu_0.Sh.continue();
    private static final xc_0 double = xu_0.XL.continue();
    private static final xc_0 switch = xu_0.Xz.continue();
    private static final xc_0 r = xu_0.bg.continue();
    private static final xc_0 P = xu_0.XN.continue();
    private static final xc_0 B = xu_0.Ju.continue();
    private static final xc_0 S = xu_0.PK.continue();
    private static final xc_0 s = xu_0.bV.continue();
    public static final rrsg_0 case = new rrsg_0(byte, rrse_0.class, protected);
    public static final rrsg_0 catch = new rrsg_0(protected, protected, protected);
    public static final rrsg_0 private = new rrsg_0(break, rrse_0.class, protected);
    public static final rrsg_0 implements = new rrsg_0(throws, throws, protected);
    public static final rrsg_0 finally = new rrsg_0(import, rrse_0.class, protected);
    public static final rrsg_0 extends = new rrsg_0(short, short, protected);
    public static final rrsg_0 native = new rrsg_0(break, rrse_0.class, short);
    public static final rrsg_0 volatile = new rrsg_0(short, short, short);
    public static final rrsg_0 final = new rrsg_0(default, const, protected);
    public static final rrsg_0 package = new rrsg_0(strictfp, rrse_0.class, protected);
    public static final rrsg_0 int = new rrsg_0(transient, transient, transient);
    public static final rrsg_0 new = new rrsg_0(boolean, boolean, boolean);
    public static final rrsg_0 continue = new rrsg_0(for, for, for);
    public static final rrsg_0 super = new rrsg_0(double, transient, r);
    public static final rrsg_0 this = new rrsg_0(switch, transient, P);
    public static final rrsg_0 else = new rrsg_0(B, S, s);
    public static final rrse_0<rrsg_0> synchronized = rrse_0.class("default", new rrso_1(rrsg_0.class));
    public static final rrse_0<rrsg_0> return = rrse_0.class("mountain", new rrsi_1(rrsg_0.class));
    public static final rrse_0<rrsg_0> public = rrse_0.class("shattered_savanna", new rrss_0(rrsg_0.class));
    public static final rrse_0<rrsg_0> goto = rrse_0.class("gravelly_mountain", new rrse_1(rrsg_0.class));
    public static final rrse_0<rrsg_0> while = rrse_0.class("giant_tree_taiga", new rrsu_1(rrsg_0.class));
    public static final rrse_0<rrsg_0> try = rrse_0.class("swamp", new rrsb(rrsg_0.class));
    public static final rrse_0<rrsg_0> instanceof = rrse_0.class("badlands", new rrsv_1(rrsg_0.class));
    public static final rrse_0<rrsg_0> throw = rrse_0.class("wooded_badlands", new rrso_0(rrsg_0.class));
    public static final rrse_0<rrsg_0> interface = rrse_0.class("eroded_badlands", new rrsk_1(rrsg_0.class));
    public static final rrse_0<rrsg_0> char = rrse_0.class("frozen_ocean", new rrsd_1(rrsg_0.class));
    public static final rrse_0<rrsg_0> abstract = rrse_0.class("nether", new rrsp_0(rrsg_0.class));
    public static final rrse_0<rrsg_0> long = rrse_0.class("nether_forest", new rrsr_0(rrsg_0.class));
    public static final rrse_0<rrsg_0> float = rrse_0.class("soul_sand_valley", new rrss(rrsg_0.class));
    public static final rrse_0<rrsg_0> void = rrse_0.class("basalt_deltas", new rrsg_1(rrsg_0.class));
    public static final rrse_0<rrsg_0> static = rrse_0.class("nope", new rrsb_0(rrsg_0.class));
    private final Codec<rrsr_1<C>> E;

    public rrse_0(Codec<C> codec) {
        this.E = codec.fieldOf("config").xmap(this::class, rrsr_1::class).codec();
    }

    public void class(long l2) {
    }

    public abstract void class(Random var1, roC var2, ryg_0 var3, int var4, int var5, int var6, double var7, xc_0 var9, xc_0 var10, int var11, long var12, C var14);

    private static <C extends rrsa_1, F extends rrse_0<C>> F class(String string, F f2) {
        return (F)rvl_0.class(rvl_0.l, string, f2);
    }

    public rrsr_1<C> class(C c) {
        return new rrsr_1<C>(this, c);
    }

    public Codec<rrsr_1<C>> protected() {
        return this.E;
    }
}

