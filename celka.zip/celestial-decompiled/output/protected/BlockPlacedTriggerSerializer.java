/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonObject
 */
package protected;

import com.google.gson.JsonObject;
import protected.ho_1;
import protected.hz_1;
import protected.js_1;
import protected.rdn_1;
import protected.rfH;
import protected.rrEm;
import protected.rvl_0;
import protected.rwh_1;
import protected.xc_0;
import protected.xd_0;
import protected.xh_2;
import protected.xn_2;
import protected.xy_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.Xp
 */
public class xp_1
extends hz_1 {
    private final xd_0 class;
    private final js_1 break;
    private final xn_2 byte;
    private final xh_2 protected;

    public xp_1(ho_1 ho_12, xd_0 xd_02, js_1 js_12, xn_2 xn_22, xh_2 xh_22) {
        super(xy_2.class, ho_12);
        this.class = xd_02;
        this.break = js_12;
        this.byte = xn_22;
        this.protected = xh_22;
    }

    @Override
    public JsonObject class(rwh_1 rwh_12) {
        JsonObject jsonObject = super.class(rwh_12);
        if (this.class != null) {
            jsonObject.addProperty("block", rvl_0.strictfp.break(this.class).toString());
        }
        jsonObject.add("state", this.break.class());
        jsonObject.add("location", this.byte.class());
        jsonObject.add("item", this.protected.class());
        return jsonObject;
    }

    public boolean class(xc_0 xc_02, rfH rfH2, rrEm rrEm2, rdn_1 rdn_12) {
        if (this.class != null && !xc_02.class(this.class)) {
            return false;
        }
        if (!this.break.class(xc_02)) {
            return false;
        }
        if (!this.byte.class(rrEm2, rfH2.b_(), rfH2.c_(), rfH2.d_())) {
            return false;
        }
        return this.protected.class(rdn_12);
    }

    public static xp_1 class(xd_0 xd_02) {
        return new xp_1(ho_1.class, xd_02, js_1.class, xn_2.class, xh_2.class);
    }
}

