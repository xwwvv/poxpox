/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.regex.Pattern;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.bl_2;
import protected.bn_2;
import protected.by_1;
import protected.sr_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.Bi
 */
public class bi_1
extends bn_2
implements by_1 {
    public Object[] byte;
    private static String[] protected;
    private static boolean[] throws;
    private static short[] case;

    public bi_1() {
        super(protected[0], (Pattern[])bl_2.class[case[0]]);
        this.catch();
    }

    static {
        bi_1.ntfClinit();
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0x3B01DC5CC43B26B0L;
    }

    @Override
    public String class() {
        this.catch();
        if ((sr_2)((Object)this.byte[case[4]]) == null) {
            return null;
        }
        return ((sr_2)((Object)this.byte[case[5]])).class();
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0x9C586608;
    }

    @Override
    public void throws(String string) {
        this.catch();
        super.throws(string);
        sr_2 sr_22 = sr_2.break(string);
        this.byte[bi_1.case[1]] = sr_22;
        if ((sr_2)((Object)this.byte[case[2]]) != null) {
            this.protected(((sr_2)((Object)this.byte[case[3]])).class() + " " + this.throws().toLowerCase());
        }
    }

    private static /* synthetic */ void ntfClinit() {
        bi_1.finally();
        bi_1.private();
        bi_1.implements();
    }

    private static void finally() {
        throws = new boolean[]{true};
    }

    public static String catch(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{52, 56, 36, -99, -63, 40, 37, 6}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    private void catch() {
        if (this.byte == null) {
            Object[] objectArray = this.byte = new Object[throws[0]];
        }
    }

    private static void implements() {
        short[] sArray = new short[6];
        sArray[0] = 17;
        case = sArray;
    }

    private static void private() {
        protected = new String[]{new String("\u0417\u0430\u0433\u0430\u0434\u043e\u0447\u043d\u044b\u0439 \u043c\u0430\u044f\u043a")};
    }
}

