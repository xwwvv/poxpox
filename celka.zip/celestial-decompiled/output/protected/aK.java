/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.rql_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public interface aK {
    public boolean byte();

    public void class(rql_0 var1);

    public boolean class();
}

