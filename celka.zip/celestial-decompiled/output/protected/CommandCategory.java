/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class sC {
    public static Object[] class;
    private static byte[] break;
    private static boolean[] byte;

    private static void byte() {
        break = new byte[]{2, 2, 3};
    }

    static {
        sC.ntfClinit();
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0x190B00AF;
    }

    public static String class(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{22, 27, -41, 105, 40, 58, -76, -43}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0x7EF99A89475B90AEL;
    }

    private static void class() {
        boolean[] blArray = new boolean[8];
        blArray[3] = true;
        blArray[5] = true;
        blArray[7] = true;
        byte = blArray;
    }

    private static void break() {
        Object[] objectArray = new Object[]{new int[]{1, 2, 3}};
        sC.class = objectArray;
    }

    private static /* synthetic */ void ntfClinit() {
        sC.class();
        sC.byte();
        sC.break();
    }
}

