/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.eC;
import protected.ef_0;
import protected.ev_0;
import protected.rxq_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.aJ
 */
public class aj_0
extends ev_0 {
    public aj_0(ef_0 ef_02, rxq_1 ... rxq_1Array) {
        super(ef_02, eC.ARMOR_HEAD, rxq_1Array);
    }

    @Override
    public int class() {
        return 3;
    }

    @Override
    public int class(int n2) {
        return 10 * n2;
    }

    @Override
    public int break(int n2) {
        return this.class(n2) + 30;
    }
}

