/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.commons.lang3.Validate
 */
package protected;

import java.util.List;
import org.apache.commons.lang3.Validate;
import protected.VD;
import protected.jl_2;
import protected.rYB;
import protected.rcd_2;
import protected.rcy_2;
import protected.rdn_1;
import protected.rdo_2;
import protected.rgF;
import protected.rgP;
import protected.rgn;
import protected.rhe_0;
import protected.rku_1;
import protected.rxl_0;
import protected.xd_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.rxO
 */
public class rxo_0
extends rku_1 {
    public rxl_0 byte() {
        return ((jl_2)this.catch()).break();
    }

    public rxo_0(xd_0 xd_02, xd_0 xd_03, rdo_2 rdo_22) {
        super(xd_02, xd_03, rdo_22);
        Validate.isInstanceOf(jl_2.class, (Object)xd_02);
        Validate.isInstanceOf(jl_2.class, (Object)xd_03);
    }

    public static void class(rdn_1 rdn_12, List<rgP> list) {
        rcd_2 rcd_22 = rdn_12.break("BlockEntityTag");
        if (rcd_22 != null && rcd_22.throws("Patterns")) {
            rcy_2 rcy_22 = rcd_22.protected("Patterns", 10);
            for (int k = 0; k < rcy_22.size() && k < 6; ++k) {
                rcd_2 rcd_23 = rcy_22.class(k);
                rxl_0 rxl_02 = rxl_0.class(rcd_23.private("Color"));
                rhe_0 rhe_02 = rhe_0.class(rcd_23.native("Pattern"));
                if (rhe_02 == null) continue;
                list.add(new rgn("block.minecraft.banner." + rhe_02.class() + "." + rxl_02.byte()).class(rgF.GRAY));
            }
        }
    }

    @Override
    public void class(rdn_1 rdn_12, rYB rYB2, List<rgP> list, VD vD) {
        rxo_0.class(rdn_12, list);
    }
}

