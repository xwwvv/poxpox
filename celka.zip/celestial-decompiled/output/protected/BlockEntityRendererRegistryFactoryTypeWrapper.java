/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Sets
 */
package protected;

import com.google.common.collect.Sets;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.atomic.AtomicReference;
import protected.HU;
import protected.gm;
import protected.hh_0;
import protected.hv_0;
import protected.jm;
import protected.ju_0;
import protected.lD;
import protected.ly_0;
import protected.qy_1;
import protected.rRq;
import protected.rYB;
import protected.rfH;
import protected.rfj;
import protected.rfl;
import protected.rfw;
import protected.roj_0;
import protected.ron_0;
import protected.rpr_0;
import protected.rqR;
import protected.rrGC;
import protected.rrbb;
import protected.rrbw_0;
import protected.rrji_2;
import protected.rrqx_1;
import protected.rrwm_2;
import protected.rrxa_0;
import protected.rrxj_0;
import protected.rrxr_0;
import protected.rxe_2;
import protected.ryo_2;
import protected.wu_2;
import protected.xc_0;
import protected.xl_0;
import protected.yc_2;
import protected.yn_2;
import protected.yo_1;
import protected.ys_2;
import protected.yu_2;
import protected.yw_2;
import protected.yx_2;
import protected.yz_1;
import protected.yz_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.yQ
 */
public class yq_2
implements rrGC {
    public final AtomicReference<yz_2> class = new AtomicReference<yz_2>(yz_2.class);
    private yc_2 case;
    private yu_2 catch;
    private final Set<ryo_2> private = Sets.newHashSet();
    private final rrxj_0<jm> implements = new rrxj_0<jm>(hU -> new jm(ju_0.private));
    public rfl break;
    private int finally = -1;
    private boolean extends = true;
    final rfw native = new rfw(-1, -1, -1);
    private final rfw[] volatile = rqR.class(new rfw[6], rfwArray -> {
        for (int k = 0; k < ((rfw[])rfwArray).length; ++k) {
            rfwArray[k] = new rfw();
        }
    });
    private boolean final;
    private final boolean package = rrbb.package();
    private final boolean int = !rrxr_0.class.byte();
    private boolean new = false;
    private final boolean continue = rrbb.ry();
    public int byte;
    public int protected;
    int super;
    int this;
    int else;
    private final yq_2[] synchronized = new yq_2[6];
    private boolean return = false;
    roj_0 public;
    private final yq_2[] goto = new yq_2[rpr_0.VALUES.length];
    private final yq_2[] while = new yq_2[rpr_0.VALUES.length];
    private boolean try = false;
    private final yx_2 instanceof = new yx_2(this, null, 0);
    final /* synthetic */ yz_1 throws;

    public yz_2 byte() {
        return this.class.get();
    }

    private roj_0 byte(rfH rfH2) {
        roj_0 roj_02 = this.public;
        if (rrwm_2.break(roj_02)) {
            return roj_02;
        }
        this.public = roj_02 = this.throws.native.this(rfH2);
        return roj_02;
    }

    private void int() {
        this.implements();
        this.class.set(yz_2.class);
        this.extends = true;
    }

    public yq_2(yz_1 yz_12) {
        this.throws = yz_12;
    }

    public String toString() {
        return "pos: " + this.throws() + ", frameIndex: " + this.finally;
    }

    public boolean class(HU hU, yz_1 yz_12) {
        yz_2 yz_22 = this.byte();
        if (this.catch != null) {
            this.catch.class();
        }
        if (!yz_22.byte.contains(hU)) {
            return false;
        }
        this.catch = yz_1.new ? new yu_2(this, new rfj(this.throws()), this.break(), yz_22) : new yu_2(this, this.break(), yz_22);
        yz_12.class(this.catch);
        return true;
    }

    @Override
    public yw_2 class(rYB rYB2, rfH rfH2, rfH rfH3, int n2) {
        return yw_2.class(rYB2, rfH2, rfH3, n2, false);
    }

    void class(hv_0 hv_02, yz_2 yz_22) {
        this.class(rrxa_0.byte, hv_02, yz_22);
        this.class(rrxa_0.break, hv_02, yz_22);
        this.class(rrxa_0.protected, hv_02, yz_22);
    }

    public rfH class(rpr_0 rpr_02) {
        return this.volatile[rpr_02.ordinal()];
    }

    HU[] class(xc_0 xc_02, HU[] hUArray) {
        if (yz_1.continue) {
            return yz_1.class;
        }
        hUArray[0] = ys_2.class(xc_02);
        return hUArray;
    }

    public yq_2 class(yo_1 yo_12, rpr_0 rpr_02) {
        if (!this.return) {
            for (int k = 0; k < rpr_0.VALUES.length; ++k) {
                rpr_0 rpr_03 = rpr_0.VALUES[k];
                rfH rfH2 = this.class(rpr_03);
                this.synchronized[k] = yo_12.class(rfH2);
            }
            this.return = true;
        }
        return this.synchronized[rpr_02.ordinal()];
    }

    private void class(HU hU, hv_0 hv_02, yz_2 yz_22) {
        lD lD2 = hv_02.class(hU);
        if (lD2.final()) {
            yz_22.protected(hU);
            if (lD2.int() > 0) {
                yz_22.throws(hU);
            }
        }
    }

    void class(Set<ryo_2> set) {
        HashSet hashSet = Sets.newHashSet(set);
        HashSet hashSet2 = Sets.newHashSet(this.private);
        hashSet.removeAll(this.private);
        hashSet2.removeAll(set);
        this.private.clear();
        this.private.addAll(set);
        this.throws.volatile.class(hashSet2, hashSet);
    }

    public void class(yz_1 yz_12) {
        yn_2 yn_22 = this.finally();
        yz_12.class(yn_22);
    }

    HU class(rRq rRq2, xc_0 xc_02, rfH rfH2, HU hU) {
        Object object;
        if (rrbw_0.break() && (object = rrbw_0.class(rRq2, xc_02, rfH2)) != null) {
            return object;
        }
        if (!this.int) {
            return hU;
        }
        if (this.package) {
            if (hU == rrxa_0.byte) {
                object = xc_02.break();
                if (object instanceof wu_2) {
                    return hU;
                }
                if (object instanceof xl_0) {
                    return hU;
                }
                return rrxa_0.break;
            }
        } else if (hU == rrxa_0.break) {
            return rrxa_0.byte;
        }
        return hU;
    }

    HU[] class(rxe_2 rxe_22, HU[] hUArray) {
        if (yz_1.super) {
            return yz_1.class;
        }
        hUArray[0] = ys_2.class(rxe_22);
        return hUArray;
    }

    public void class(int n2, int n3, int n4) {
        if (n2 != this.native.b_() || n3 != this.native.c_() || n4 != this.native.d_()) {
            this.int();
            this.native.class(n2, n3, n4);
            if (this.continue) {
                int n5 = 8;
                this.byte = n2 >> n5 << n5;
                this.protected = n4 >> n5 << n5;
                this.super = n2 - this.byte;
                this.this = n3;
                this.else = n4 - this.protected;
            }
            this.break = new rfl(n2, n3, n4, n2 + 16, n3 + 16, n4 + 16);
            for (rpr_0 rpr_02 : rpr_0.VALUES) {
                this.volatile[rpr_02.ordinal()].class(this.native).byte(rpr_02, 16);
            }
            this.return = false;
            this.try = false;
            for (int k = 0; k < this.goto.length; ++k) {
                yq_2 yq_22 = this.goto[k];
                if (yq_22 == null) continue;
                yq_22.try = false;
            }
            this.public = null;
        }
    }

    public jm class(HU hU) {
        return this.implements.class(hU);
    }

    public boolean class(int n2) {
        if (this.finally == n2) {
            return false;
        }
        this.finally = n2;
        return true;
    }

    public boolean class() {
        if (((rrqx_1)rrqx_1.staticFields09f1f28026cd378cb9df490a64ac8f2a[0]).private().K().aJ_() || !(this.break() > 576.0)) {
            return true;
        }
        return this.class(this.volatile[rpr_0.WEST.ordinal()]) && this.class(this.volatile[rpr_0.NORTH.ordinal()]) && this.class(this.volatile[rpr_0.EAST.ordinal()]) && this.class(this.volatile[rpr_0.SOUTH.ordinal()]);
    }

    private boolean class(rfH rfH2) {
        return this.throws.native.class(rfH2.b_() >> 4, rfH2.d_() >> 4, ron_0.volatile, false) != null;
    }

    public void class(boolean bl2) {
        boolean bl3 = this.extends;
        this.extends = true;
        this.final = bl2 | (bl3 && this.final);
        if (this.new()) {
            this.new = true;
        }
    }

    public void class(rpr_0 rpr_02, yq_2 yq_22) {
        this.goto[rpr_02.ordinal()] = yq_22;
        this.while[rpr_02.ordinal()] = yq_22;
    }

    void class(lD lD2) {
        lD2.class(7, ju_0.private);
    }

    rrji_2 break(rfH rfH2) {
        rfH rfH3 = rfH2.break(-1, -1, -1);
        rfH rfH4 = rfH2.break(16, 16, 16);
        yw_2 yw_22 = this.class(this.throws.native, rfH3, rfH4, 1);
        return new rrji_2(yw_22, rfH3, rfH4, 1);
    }

    public yq_2 break(rpr_0 rpr_02) {
        if (!this.try) {
            this.continue();
        }
        return this.while[rpr_02.ordinal()];
    }

    protected double break() {
        ly_0 ly_02 = ((hh_0)qy_1.instanceof().class[16]).finally();
        double d = this.break.class + 8.0 - ly_02.break().break;
        double d2 = this.break.break + 8.0 - ly_02.break().byte;
        double d3 = this.break.byte + 8.0 - ly_02.break().protected;
        return d * d + d2 * d2 + d3 * d3;
    }

    public rfH throws() {
        return this.native;
    }

    public yn_2 finally() {
        this.implements();
        yw_2 yw_22 = null;
        this.case = yz_1.new ? new yc_2(this, new rfj(this.throws()), this.break(), yw_22) : new yc_2(this, this.break(), yw_22);
        return this.case;
    }

    public boolean catch() {
        return this.extends;
    }

    public void extends() {
        yn_2 yn_22 = this.finally();
        yn_22.class(this.throws.implements);
    }

    public void case() {
        this.extends = false;
        this.final = false;
        this.new = false;
    }

    private void continue() {
        int n2 = this.throws().b_();
        int n3 = this.throws().d_();
        int n4 = rpr_0.NORTH.ordinal();
        int n5 = rpr_0.SOUTH.ordinal();
        int n6 = rpr_0.WEST.ordinal();
        int n7 = rpr_0.EAST.ordinal();
        this.while[n4] = this.goto[n4].throws().d_() == n3 - 16 ? this.goto[n4] : null;
        this.while[n5] = this.goto[n5].throws().d_() == n3 + 16 ? this.goto[n5] : null;
        this.while[n6] = this.goto[n6].throws().b_() == n2 - 16 ? this.goto[n6] : null;
        this.while[n7] = this.goto[n7].throws().b_() == n2 + 16 ? this.goto[n7] : null;
        this.try = true;
    }

    protected void implements() {
        if (this.case != null) {
            this.case.class();
            this.case = null;
        }
        if (this.catch != null) {
            this.catch.class();
            this.catch = null;
        }
    }

    private boolean new() {
        rYB rYB2 = this.throws.native;
        if (rYB2 instanceof gm) {
            gm gm2 = (gm)rYB2;
            return gm2.volatile();
        }
        return false;
    }

    public yx_2 package() {
        return this.instanceof;
    }

    public void protected() {
        this.int();
        this.implements.class().forEach(jm::close);
    }

    boolean protected(rfH rfH2) {
        int n2 = rfH2.c_();
        int n3 = n2 + 15;
        return this.byte(rfH2).class(n2, n3);
    }

    public boolean private() {
        return this.extends && this.final;
    }

    public boolean final() {
        return this.protected(this.native);
    }

    public roj_0 volatile() {
        return this.byte(this.native);
    }

    public boolean native() {
        return this.new;
    }
}

