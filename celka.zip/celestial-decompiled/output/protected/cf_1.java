/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 */
package protected;

import com.google.common.collect.Lists;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import protected.cm_1;
import protected.qw_1;
import protected.qy_1;
import protected.rgF;
import protected.rgS;
import protected.rga_0;
import protected.rgc_0;
import protected.rgx_0;
import protected.rpl;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.cf
 */
public class cf_1 {
    private static final rpl class = rpl.class(32, rgc_0.class);

    private static String class(String string) {
        return ((qw_1)qy_1.instanceof().class[20]).short ? string : rgF.class(string);
    }

    public static List<rpl> class(rgS rgS3, int n2, cm_1 cm_12) {
        rga_0 rga_02 = new rga_0();
        rgS3.class((rgc_02, string) -> {
            rga_02.class(rgS.class(cf_1.class(string), rgc_02));
            return Optional.empty();
        }, rgc_0.class);
        ArrayList arrayList = Lists.newArrayList();
        cm_12.break().class(rga_02.break(), n2, rgc_0.class, (rgS2, bl2) -> {
            rpl rpl2 = rgx_0.byte().class((rgS)rgS2);
            arrayList.add(bl2 != false ? rpl.class(cf_1.class, rpl2) : rpl2);
        });
        return arrayList.isEmpty() ? Lists.newArrayList((Object[])new rpl[]{rpl.class}) : arrayList;
    }
}

