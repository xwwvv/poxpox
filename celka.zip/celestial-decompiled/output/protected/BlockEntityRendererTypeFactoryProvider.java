/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 *  com.google.common.collect.Sets
 */
package protected;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import java.util.ArrayList;
import java.util.BitSet;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.CancellationException;
import java.util.concurrent.CompletableFuture;
import protected.HU;
import protected.KY;
import protected.hv_0;
import protected.jw_0;
import protected.jz_0;
import protected.lD;
import protected.lT;
import protected.lo;
import protected.ml_1;
import protected.qy_1;
import protected.rfH;
import protected.rfj;
import protected.rjU;
import protected.roj_0;
import protected.rox;
import protected.rqR;
import protected.rrGi;
import protected.rrGq;
import protected.rrbb;
import protected.rrdZ;
import protected.rrdk;
import protected.rrji_2;
import protected.rrnw_0;
import protected.rrqx_1;
import protected.rrxf_0;
import protected.rrxr_0;
import protected.rxe_2;
import protected.ryo_2;
import protected.xc_0;
import protected.xn_0;
import protected.yl_2;
import protected.ym_2;
import protected.yn_2;
import protected.yq_2;
import protected.yw_2;
import protected.yz_1;
import protected.yz_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.yc
 */
class yc_2
extends yn_2 {
    protected yw_2 protected;
    final /* synthetic */ yq_2 throws;

    public yc_2(yq_2 yq_22, double d, yw_2 yw_22) {
        this(yq_22, null, d, yw_22);
    }

    public yc_2(yq_2 yq_22, rfj rfj2, double d, yw_2 yw_22) {
        this.throws = yq_22;
        super(yq_22, rfj2, d);
        this.protected = yw_22;
    }

    @Override
    public void class() {
        this.protected = null;
        if (this.break.compareAndSet(false, true)) {
            this.throws.class(false);
        }
    }

    private <E extends ryo_2> void class(yz_2 yz_22, Set<ryo_2> set, E e2) {
        jw_0<E> jw_02 = jz_0.break.class(e2);
        if (jw_02 != null) {
            if (jw_02.class(e2)) {
                set.add(e2);
            } else {
                yz_22.throws.add(e2);
            }
        }
    }

    private Set<ryo_2> class(float f2, float f3, float f4, yz_2 yz_22, hv_0 hv_02) {
        rfH rfH2 = this.throws.native.int();
        rfH rfH3 = rfH2.break(15, 15, 15);
        yl_2 yl_22 = new yl_2();
        HashSet hashSet = Sets.newHashSet();
        this.protected = null;
        ml_1 ml_12 = new ml_1();
        if (!this.throws.protected(rfH2)) {
            ++yz_1.break;
            rrji_2 rrji_22 = this.throws.break(rfH2);
            rrji_22.break();
            HU[] hUArray = new HU[1];
            boolean bl2 = rrbb.rs();
            boolean bl3 = bl2 && rrdZ.q;
            lT.class();
            Random random = new Random();
            lo lo2 = qy_1.instanceof().synchronized();
            for (rrGi rrGi2 : rrGi.byte(rfH2, rfH3)) {
                Object object;
                Object object2;
                rrGq rrGq2;
                ryo_2 ryo_22;
                xc_0 xc_02 = rrji_22.byte(rrGi2);
                if (xc_02.catch()) continue;
                if (xc_02.implements(rrji_22, rrGi2)) {
                    yl_22.class(rrGi2);
                }
                if (xc_02.break().protected() && (ryo_22 = rrji_22.class((rfH)rrGi2, rox.CHECK)) != null) {
                    this.class(yz_22, hashSet, ryo_22);
                }
                rxe_2 object3 = xc_02.volatile();
                rrGq rrGq3 = rrGq2 = yz_1.new ? this.class(rrGi2) : null;
                if (!object3.byte()) {
                    object2 = this.throws.class(object3, hUArray);
                    for (int k = 0; k < ((HU[])object2).length; ++k) {
                        HU hU = object2[k];
                        if (yz_1.super && !rrxr_0.break(rrxr_0.Pw, object3, hU)) continue;
                        if (yz_1.this) {
                            rrxr_0.class(rrxr_0.rj, hU);
                        }
                        lD lD2 = hv_02.class(hU);
                        lD2.break(hU);
                        object = lD2.class(xc_02, rrGi2);
                        ((rrxf_0)object).class(hv_02);
                        rrji_22.class((rrxf_0)object);
                        if (yz_22.byte.add(hU)) {
                            this.throws.class(lD2);
                        }
                        if (!lo2.class(rrGi2, rrji_22, lD2, object3)) continue;
                        yz_22.protected = false;
                        yz_22.break.class(hU);
                    }
                }
                if (xc_02.private() != xn_0.INVISIBLE) {
                    Object object4 = object2 = this.throws.class(xc_02, hUArray);
                    int n2 = ((HU[])object4).length;
                    for (int k = 0; k < n2; ++k) {
                        Object object5 = object = object4[k];
                        if (yz_1.continue && !rrxr_0.break(rrxr_0.Pt, xc_02, object5)) continue;
                        if (yz_1.this) {
                            rrxr_0.class(rrxr_0.rj, object5);
                        }
                        object5 = this.throws.class(rrji_22, xc_02, (rfH)rrGi2, (HU)object5);
                        lD lD3 = hv_02.class((HU)object5);
                        lD3.break((HU)object5);
                        rrxf_0 rrxf_02 = lD3.class(xc_02, rrGi2);
                        rrxf_02.class(hv_02);
                        rrji_22.class(rrxf_02);
                        if (yz_22.byte.add((HU)object5)) {
                            this.throws.class(lD3);
                        }
                        ml_12.class();
                        ml_12.class((double)this.throws.super + (double)(rrGi2.b_() & 0xF), (double)this.throws.this + (double)(rrGi2.c_() & 0xF), (double)this.throws.else + (double)(rrGi2.d_() & 0xF));
                        if (bl3) {
                            lD3.byte(0.5f + (float)this.throws.super + (float)(rrGi2.b_() & 0xF), 0.5f + (float)this.throws.this + (float)(rrGi2.c_() & 0xF), 0.5f + (float)this.throws.else + (float)(rrGi2.d_() & 0xF));
                        }
                        if (lo2.class(xc_02, rrGi2, rrji_22, ml_12, lD3, true, random, rrGq2)) {
                            yz_22.protected = false;
                            yz_22.break.class((HU)object5);
                            if (rrxf_02.int()) {
                                this.throws.class(hv_02, yz_22);
                                rrxf_02.class(false);
                            }
                        }
                        ml_12.break();
                    }
                }
                if ((object2 = this.throws.public) == null) continue;
                rrnw_0 rrnw_02 = new rrnw_0(rrGi2, xc_02, xc_02.break(), ((roj_0)object2).private());
                ((rrqx_1)rrqx_1.staticFields09f1f28026cd378cb9df490a64ac8f2a[0]).finally().class(rrnw_02);
            }
            if (yz_22.break.break(HU.implements())) {
                lD lD4 = hv_02.class(HU.implements());
                lD4.protected((float)this.throws.super + f2 - (float)rfH2.b_(), (float)this.throws.this + f3 - (float)rfH2.c_(), (float)this.throws.else + f4 - (float)rfH2.d_());
                yz_22.catch = lD4.implements();
            }
            yz_22.byte.stream().map(hv_02::class).forEach(lD::finally);
            for (HU hU : yz_1.class) {
                yz_22.class(hU, null);
            }
            for (HU hU : yz_22.byte) {
                if (rrbb.rs()) {
                    rrdk.case(hv_02.class(hU));
                }
                lD lD5 = hv_02.class(hU);
                if (lD5.finally == null || lD5.finally.isEmpty()) continue;
                yz_22.class(hU, (BitSet)lD5.finally.clone());
            }
            rrji_22.byte();
            lT.break();
        }
        yz_22.case = yl_22.class();
        return hashSet;
    }

    @Override
    public CompletableFuture<ym_2> class(hv_0 hv_02) {
        if (this.break.get()) {
            return CompletableFuture.completedFuture(ym_2.CANCELLED);
        }
        if (!this.throws.class()) {
            this.protected = null;
            this.throws.class(false);
            this.break.set(true);
            return CompletableFuture.completedFuture(ym_2.CANCELLED);
        }
        if (this.break.get()) {
            return CompletableFuture.completedFuture(ym_2.CANCELLED);
        }
        rjU rjU2 = this.throws.throws.break();
        float f2 = (float)rjU2.break;
        float f3 = (float)rjU2.byte;
        float f4 = (float)rjU2.protected;
        yz_2 yz_22 = new yz_2();
        Set<ryo_2> set = this.class(f2, f3, f4, yz_22, hv_02);
        this.throws.class(set);
        if (this.break.get()) {
            return CompletableFuture.completedFuture(ym_2.CANCELLED);
        }
        ArrayList arrayList = Lists.newArrayList();
        yz_22.byte.forEach(hU -> arrayList.add(this.throws.throws.class(hv_02.class((HU)hU), this.throws.class((HU)hU))));
        return rqR.break(arrayList).handle((list, throwable) -> {
            if (throwable != null && !(throwable instanceof CancellationException) && !(throwable instanceof InterruptedException)) {
                qy_1.instanceof().break(KY.class(throwable, "Rendering chunk"));
            }
            if (this.break.get()) {
                return ym_2.CANCELLED;
            }
            this.throws.class.set(yz_22);
            return ym_2.SUCCESSFUL;
        });
    }
}

