/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.brigadier.ImmutableStringReader
 *  com.mojang.brigadier.Message
 *  com.mojang.brigadier.StringReader
 *  com.mojang.brigadier.exceptions.CommandSyntaxException
 *  com.mojang.brigadier.exceptions.SimpleCommandExceptionType
 */
package protected;

import com.mojang.brigadier.ImmutableStringReader;
import com.mojang.brigadier.Message;
import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.SimpleCommandExceptionType;
import java.util.function.Function;
import protected.rgn;
import protected.xu_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.XL
 */
public class xl_2 {
    public static final xl_2 class = new xl_2(null, null);
    public static final SimpleCommandExceptionType break = new SimpleCommandExceptionType((Message)new rgn("argument.range.ints"));
    private final Float byte;
    private final Float protected;

    public xl_2(Float f2, Float f3) {
        this.byte = f2;
        this.protected = f3;
    }

    private static Float class(Float f2, Function<Float, Float> function) {
        return f2 == null ? null : function.apply(f2);
    }

    public Float class() {
        return this.byte;
    }

    public static xl_2 class(StringReader stringReader, boolean bl2, Function<Float, Float> function) throws CommandSyntaxException {
        Float f2;
        if (!stringReader.canRead()) {
            throw xu_2.class.createWithContext((ImmutableStringReader)stringReader);
        }
        int n2 = stringReader.getCursor();
        Float f3 = xl_2.class(xl_2.class(stringReader, bl2), function);
        if (stringReader.canRead(2) && stringReader.peek() == '.' && stringReader.peek(1) == '.') {
            stringReader.skip();
            stringReader.skip();
            f2 = xl_2.class(xl_2.class(stringReader, bl2), function);
            if (f3 == null && f2 == null) {
                stringReader.setCursor(n2);
                throw xu_2.class.createWithContext((ImmutableStringReader)stringReader);
            }
        } else {
            if (!bl2 && stringReader.canRead() && stringReader.peek() == '.') {
                stringReader.setCursor(n2);
                throw break.createWithContext((ImmutableStringReader)stringReader);
            }
            f2 = f3;
        }
        if (f3 == null && f2 == null) {
            stringReader.setCursor(n2);
            throw xu_2.class.createWithContext((ImmutableStringReader)stringReader);
        }
        return new xl_2(f3, f2);
    }

    private static Float class(StringReader stringReader, boolean bl2) throws CommandSyntaxException {
        int n2 = stringReader.getCursor();
        while (stringReader.canRead() && xl_2.break(stringReader, bl2)) {
            stringReader.skip();
        }
        String string = stringReader.getString().substring(n2, stringReader.getCursor());
        if (string.isEmpty()) {
            return null;
        }
        try {
            return Float.valueOf(Float.parseFloat(string));
        }
        catch (NumberFormatException numberFormatException) {
            if (bl2) {
                throw CommandSyntaxException.BUILT_IN_EXCEPTIONS.readerInvalidDouble().createWithContext((ImmutableStringReader)stringReader, (Object)string);
            }
            throw CommandSyntaxException.BUILT_IN_EXCEPTIONS.readerInvalidInt().createWithContext((ImmutableStringReader)stringReader, (Object)string);
        }
    }

    public Float break() {
        return this.protected;
    }

    private static boolean break(StringReader stringReader, boolean bl2) {
        char c = stringReader.peek();
        if ((c < '0' || c > '9') && c != '-') {
            if (bl2 && c == '.') {
                return !stringReader.canRead(2) || stringReader.peek(1) != '.';
            }
            return false;
        }
        return true;
    }
}

