/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.rpH;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.rCI
 */
public final class rci_0
extends Enum<rci_0>
implements rpH {
    public static final /* enum */ rci_0 LEFT = new rci_0();
    public static final /* enum */ rci_0 RIGHT = new rci_0();
    private static final /* synthetic */ rci_0[] $VALUES;

    static {
        $VALUES = rci_0.break();
    }

    public String toString() {
        return this.class();
    }

    public static rci_0[] values() {
        return (rci_0[])$VALUES.clone();
    }

    public static rci_0 valueOf(String string) {
        return Enum.valueOf(rci_0.class, string);
    }

    @Override
    public String class() {
        return this == LEFT ? "left" : "right";
    }

    private static /* synthetic */ rci_0[] break() {
        return new rci_0[]{LEFT, RIGHT};
    }
}

