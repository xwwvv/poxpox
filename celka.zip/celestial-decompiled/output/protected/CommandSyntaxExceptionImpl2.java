/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Date;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.else;
import protected.rfH;
import protected.ru_1;
import protected.this;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class while
implements this {
    private static byte[] break;
    public Object[] class;
    private static boolean[] byte;
    private static long[] protected;
    private static String[] throws;
    private static short[] case;

    @Override
    public String byte() {
        return (String)this.class[case[8]];
    }

    public while(String string, else else_, ru_1 ru_12, long l2) {
        this.catch();
        String string2 = string;
        this.class[while.case[0]] = string2;
        else else_2 = else_;
        this.class[while.case[1]] = else_2;
        ru_1 ru_13 = ru_12;
        this.class[while.case[2]] = ru_13;
        Long l3 = l2;
        this.class[while.case[3]] = l3;
    }

    public while(String string, else else_, ru_1 ru_12) {
        this(string, else_, ru_12, System.currentTimeMillis());
    }

    static {
        while.ntfClinit();
    }

    public boolean equals(Object object) {
        if (object == null) {
            return byte[2];
        }
        if (!(object instanceof this)) {
            return byte[3];
        }
        this this_ = (this)object;
        return ((String)this.class[case[15]]).equals(this_.byte()) && (else)((Object)this.class[case[16]]) == this_.break() && ((ru_1)this.class[case[17]]).equals(this_.class()) ? byte[4] : byte[5];
    }

    public String toString() {
        Object[] objectArray = new Object[break[0]];
        objectArray[while.byte[0]] = (String)this.class[case[12]];
        objectArray[while.byte[1]] = ru_1.class((rfH)((ru_1)this.class[case[13]])).toString();
        objectArray[while.break[1]] = new Date((Long)this.class[case[14]]).toString();
        return String.format(throws[0], objectArray);
    }

    public int hashCode() {
        return ((String)this.class[case[4]]).hashCode() ^ ((else)((Object)this.class[case[5]])).hashCode() ^ ((ru_1)this.class[case[6]]).hashCode() ^ Long.hashCode((Long)this.class[case[7]]);
    }

    @Override
    public ru_1 class() {
        return (ru_1)this.class[case[11]];
    }

    public static String class(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{-53, 100, 34, 118, -11, 112, -10, -23}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0xEFCC783BA90A2893L;
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0x11E2BFB3;
    }

    @Override
    public else break() {
        return (else)((Object)this.class[case[9]]);
    }

    private static void throws() {
        boolean[] blArray = new boolean[6];
        blArray[1] = true;
        blArray[4] = true;
        byte = blArray;
    }

    private static /* synthetic */ void ntfClinit() {
        while.throws();
        while.private();
        while.case();
        while.finally();
        while.implements();
    }

    private static void finally() {
        short[] sArray = new short[18];
        sArray[1] = 1;
        sArray[2] = 3;
        sArray[3] = 2;
        sArray[5] = 1;
        sArray[6] = 3;
        sArray[7] = 2;
        sArray[9] = 1;
        sArray[10] = 2;
        sArray[11] = 3;
        sArray[13] = 3;
        sArray[14] = 2;
        sArray[16] = 1;
        sArray[17] = 3;
        case = sArray;
    }

    private void catch() {
        if (this.class == null) {
            Object[] objectArray = this.class = new Object[break[2]];
            objectArray[while.break[3]] = protected[0];
        }
    }

    private static void case() {
        protected = new long[1];
    }

    private static void implements() {
        break = new byte[]{3, 2, 4, 2};
    }

    @Override
    public long protected() {
        return (Long)this.class[case[10]];
    }

    private static void private() {
        throws = new String[]{new String("%s %s %s")};
    }
}

