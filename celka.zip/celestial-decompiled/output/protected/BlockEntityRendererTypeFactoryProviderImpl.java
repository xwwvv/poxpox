/*
 * Decompiled with CFR 0.152.
 */
package protected;

/*
 * Renamed from protected.yH
 * Illegal identifiers - consider using --renameillegalidents true
 */
class yh_2 {
    public int class = Integer.MIN_VALUE;
    public int break = Integer.MIN_VALUE;
    public int[] byte;

    yh_2() {
    }
}

