/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.util.AbstractList;
import protected.rcz_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.rcx
 */
public abstract class rcx_1<T extends rcz_1>
extends AbstractList<T>
implements rcz_1 {
    public abstract T byte(int var1);

    public abstract void byte(int var1, T var2);

    @Override
    public /* synthetic */ Object remove(int n2) {
        return this.byte(n2);
    }

    @Override
    public /* synthetic */ void add(int n2, Object object) {
        this.byte(n2, (rcz_1)object);
    }

    public abstract boolean class(int var1, rcz_1 var2);

    @Override
    public /* synthetic */ Object set(int n2, Object object) {
        return this.protected(n2, (rcz_1)object);
    }

    public abstract boolean break(int var1, rcz_1 var2);

    public abstract byte throws();

    public abstract T protected(int var1, T var2);
}

