/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonObject
 */
package protected;

import com.google.gson.JsonObject;
import protected.an;
import protected.hg_2;
import protected.hn_1;
import protected.ho_1;
import protected.hy_1;
import protected.hz_1;
import protected.rhn_2;
import protected.rqo_0;
import protected.rwl_1;
import protected.rye_1;
import protected.rzr_2;
import protected.xk_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.Xd
 */
public class xd_2
extends hg_2<xk_2> {
    final rqo_0 class;

    public xd_2(rqo_0 rqo_02) {
        this.class = rqo_02;
    }

    public void class(rhn_2 rhn_22, an an2, rye_1 rye_12) {
        rzr_2 rzr_22 = hy_1.break(rhn_22, an2);
        this.class(rhn_22, (T xk_22) -> xk_22.class(rhn_22, rzr_22, rye_12));
    }

    @Override
    public /* synthetic */ hz_1 class(JsonObject jsonObject, ho_1 ho_12, rwl_1 rwl_12) {
        return this.break(jsonObject, ho_12, rwl_12);
    }

    @Override
    public rqo_0 class() {
        return this.class;
    }

    public xk_2 break(JsonObject jsonObject, ho_1 ho_12, rwl_1 rwl_12) {
        return new xk_2(this.class, ho_12, ho_1.class(jsonObject, "entity", rwl_12), hn_1.class(jsonObject.get("killing_blow")));
    }
}

