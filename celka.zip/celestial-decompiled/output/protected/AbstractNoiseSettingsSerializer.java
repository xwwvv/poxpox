/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.datafixers.types.Type
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
package protected;

import com.mojang.datafixers.types.Type;
import java.util.Set;
import java.util.function.Supplier;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import protected.rHC;
import protected.rHH;
import protected.rHR;
import protected.rHU;
import protected.rHZ;
import protected.rHa;
import protected.rHb;
import protected.rHg;
import protected.rHj;
import protected.rHl;
import protected.rHn;
import protected.rHp;
import protected.rHq;
import protected.rHt;
import protected.rHx;
import protected.rRq;
import protected.rTC;
import protected.rfH;
import protected.rha_0;
import protected.rhc_0;
import protected.rhj_0;
import protected.rhl_0;
import protected.rhm_0;
import protected.rho_0;
import protected.rhq_0;
import protected.rht_0;
import protected.rhu_0;
import protected.rhw_0;
import protected.rhy_0;
import protected.rhz_0;
import protected.rqR;
import protected.rqo_0;
import protected.rvl_0;
import protected.rye_2;
import protected.ryg_2;
import protected.ryo_2;
import protected.ryq_2;
import protected.ryr_2;
import protected.rys_1;
import protected.rys_2;
import protected.ryz_2;
import protected.xd_0;
import protected.xu_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.ryW
 */
public class ryw_2<T extends ryo_2> {
    private static final Logger float = LogManager.getLogger();
    public static final ryw_2<rht_0> class = ryw_2.class("furnace", ryz_2.class(rht_0::new, xu_0.Ps));
    public static final ryw_2<rhu_0> break = ryw_2.class("chest", ryz_2.class(rhu_0::new, xu_0.re));
    public static final ryw_2<ryq_2> byte = ryw_2.class("trapped_chest", ryz_2.class(ryq_2::new, xu_0.sZ));
    public static final ryw_2<rHq> protected = ryw_2.class("ender_chest", ryz_2.class(rHq::new, xu_0.SW));
    public static final ryw_2<rHg> throws = ryw_2.class("jukebox", ryz_2.class(rHg::new, xu_0.Pj));
    public static final ryw_2<rHC> case = ryw_2.class("dispenser", ryz_2.class(rHC::new, xu_0.v));
    public static final ryw_2<rHl> catch = ryw_2.class("dropper", ryz_2.class(rHl::new, xu_0.st));
    public static final ryw_2<rys_2> private = ryw_2.class("sign", ryz_2.class(rys_2::new, xu_0.PE, xu_0.PG, xu_0.Pb, xu_0.PM, xu_0.PO, xu_0.Ph, xu_0.Pk, xu_0.PW, xu_0.Pz, xu_0.PQ, xu_0.PN, xu_0.Pc, xu_0.Jr, xu_0.JB, xu_0.JP, xu_0.JS));
    public static final ryw_2<rHU> implements = ryw_2.class("mob_spawner", ryz_2.class(rHU::new, xu_0.rD));
    public static final ryw_2<rHa> finally = ryw_2.class("piston", ryz_2.class(rHa::new, xu_0.rc));
    public static final ryw_2<rhq_0> extends = ryw_2.class("brewing_stand", ryz_2.class(rhq_0::new, xu_0.SG));
    public static final ryw_2<rHH> native = ryw_2.class("enchanting_table", ryz_2.class(rHH::new, xu_0.SE));
    public static final ryw_2<rHp> volatile = ryw_2.class("end_portal", ryz_2.class(rHp::new, xu_0.SM));
    public static final ryw_2<rho_0> final = ryw_2.class("beacon", ryz_2.class(rho_0::new, xu_0.Sv));
    public static final ryw_2<rys_1> package = ryw_2.class("skull", ryz_2.class(rys_1::new, xu_0.sM, xu_0.sO, xu_0.sW, xu_0.sz, xu_0.sQ, xu_0.sN, xu_0.sJ, xu_0.sx, xu_0.sh, xu_0.sX, xu_0.sd, xu_0.sk));
    public static final ryw_2<rHn> int = ryw_2.class("daylight_detector", ryz_2.class(rHn::new, xu_0.sA));
    public static final ryw_2<rHt> new = ryw_2.class("hopper", ryz_2.class(rHt::new, xu_0.sl));
    public static final ryw_2<rhl_0> continue = ryw_2.class("comparator", ryz_2.class(rhl_0::new, xu_0.sL));
    public static final ryw_2<rHb> super = ryw_2.class("banner", ryz_2.class(rHb::new, xu_0.GG, xu_0.Gb, xu_0.GM, xu_0.GO, xu_0.Gh, xu_0.GX, xu_0.GJ, xu_0.Gx, xu_0.Gd, xu_0.Gk, xu_0.GW, xu_0.Gz, xu_0.GQ, xu_0.GN, xu_0.Gc, xu_0.Gu, xu_0.Gm, xu_0.GZ, xu_0.Gv, xu_0.GF, xu_0.GL, xu_0.GA, xu_0.Gn, xu_0.GC, xu_0.Gl, xu_0.GH, xu_0.Gy, xu_0.Gp, xu_0.Gq, xu_0.GT, xu_0.Gt, xu_0.Gw));
    public static final ryw_2<ryg_2> this = ryw_2.class("structure_block", ryz_2.class(ryg_2::new, xu_0.Js));
    public static final ryw_2<rhy_0> else = ryw_2.class("end_gateway", ryz_2.class(rhy_0::new, xu_0.bw));
    public static final ryw_2<rHZ> synchronized = ryw_2.class("command_block", ryz_2.class(rHZ::new, xu_0.SZ, xu_0.bf, xu_0.bI));
    public static final ryw_2<ryr_2> return = ryw_2.class("shulker_box", ryz_2.class(ryr_2::new, xu_0.bD, xu_0.MX, xu_0.Mb, xu_0.MM, xu_0.ME, xu_0.MS, xu_0.MO, xu_0.bi, xu_0.Ms, xu_0.MP, xu_0.ba, xu_0.be, xu_0.MB, xu_0.MG, xu_0.Mh, xu_0.bU, xu_0.Mr));
    public static final ryw_2<rhj_0> public = ryw_2.class("bed", ryz_2.class(rhj_0::new, xu_0.R, xu_0.Y, xu_0.j, xu_0.V, xu_0.I, xu_0.t, xu_0.g, xu_0.y, xu_0.w, xu_0.q, xu_0.H, xu_0.l, xu_0.T, xu_0.f, xu_0.C, xu_0.p));
    public static final ryw_2<rha_0> goto = ryw_2.class("conduit", ryz_2.class(rha_0::new, xu_0.hB));
    public static final ryw_2<rhm_0> while = ryw_2.class("barrel", ryz_2.class(rhm_0::new, xu_0.ha));
    public static final ryw_2<rye_2> try = ryw_2.class("smoker", ryz_2.class(rye_2::new, xu_0.hi));
    public static final ryw_2<rhz_0> instanceof = ryw_2.class("blast_furnace", ryz_2.class(rhz_0::new, xu_0.Xr));
    public static final ryw_2<rHR> throw = ryw_2.class("lectern", ryz_2.class(rHR::new, xu_0.Xs));
    public static final ryw_2<rhw_0> interface = ryw_2.class("bell", ryz_2.class(rhw_0::new, xu_0.Xb));
    public static final ryw_2<rHj> char = ryw_2.class("jigsaw", ryz_2.class(rHj::new, xu_0.JE));
    public static final ryw_2<rhc_0> abstract = ryw_2.class("campfire", ryz_2.class(rhc_0::new, xu_0.Xh, xu_0.XX));
    public static final ryw_2<rHx> long = ryw_2.class("beehive", ryz_2.class(rHx::new, xu_0.JM, xu_0.JO));
    private final Supplier<? extends T> void;
    private final Set<xd_0> static;
    private final Type<?> import;

    public ryw_2(Supplier<? extends T> supplier, Set<xd_0> set, Type<?> type) {
        this.void = supplier;
        this.static = set;
        this.import = type;
    }

    public static rqo_0 class(ryw_2<?> ryw_22) {
        return rvl_0.r.break(ryw_22);
    }

    public T class(rRq rRq2, rfH rfH2) {
        ryo_2 ryo_22 = rRq2.class(rfH2);
        return (T)(ryo_22 != null && ryo_22.void() == this ? ryo_22 : null);
    }

    public boolean class(xd_0 xd_02) {
        return this.static.contains(xd_02);
    }

    public T class() {
        return (T)((ryo_2)this.void.get());
    }

    private static <T extends ryo_2> ryw_2<T> class(String string, ryz_2<T> ryz_22) {
        if (ryz_22.break.isEmpty()) {
            float.warn("Block entity type {} requires at least one valid block to be defined!", (Object)string);
        }
        Type<?> type = rqR.class(rTC.extends, string);
        return rvl_0.class(rvl_0.r, string, ryz_22.class(type));
    }
}

