/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.util.concurrent.CancellationException;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;
import protected.HU;
import protected.KY;
import protected.hv_0;
import protected.lD;
import protected.le;
import protected.qy_1;
import protected.rfj;
import protected.rjU;
import protected.ym_2;
import protected.yn_2;
import protected.yq_2;
import protected.yz_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.yu
 */
class yu_2
extends yn_2 {
    private final yz_2 throws;
    final /* synthetic */ yq_2 protected;

    public yu_2(yq_2 yq_22, double d, yz_2 yz_22) {
        this(yq_22, null, d, yz_22);
    }

    public yu_2(yq_2 yq_22, rfj rfj2, double d, yz_2 yz_22) {
        this.protected = yq_22;
        super(yq_22, rfj2, d);
        this.throws = yz_22;
    }

    @Override
    public void class() {
        this.break.set(true);
    }

    @Override
    public CompletableFuture<ym_2> class(hv_0 hv_02) {
        if (this.break.get()) {
            return CompletableFuture.completedFuture(ym_2.CANCELLED);
        }
        if (!this.protected.class()) {
            this.break.set(true);
            return CompletableFuture.completedFuture(ym_2.CANCELLED);
        }
        if (this.break.get()) {
            return CompletableFuture.completedFuture(ym_2.CANCELLED);
        }
        rjU rjU2 = this.protected.throws.break();
        float f2 = (float)rjU2.break;
        float f3 = (float)rjU2.byte;
        float f4 = (float)rjU2.protected;
        le le2 = this.throws.catch;
        if (le2 != null && this.throws.break.break(HU.implements())) {
            lD lD2 = hv_02.class(HU.implements());
            lD2.break(HU.implements());
            this.protected.class(lD2);
            lD2.class(le2);
            lD2.protected((float)this.protected.super + f2 - (float)this.protected.native.b_(), (float)this.protected.this + f3 - (float)this.protected.native.c_(), (float)this.protected.else + f4 - (float)this.protected.native.d_());
            this.throws.catch = lD2.implements();
            lD2.finally();
            if (this.break.get()) {
                return CompletableFuture.completedFuture(ym_2.CANCELLED);
            }
            CompletionStage completionStage = this.protected.throws.class(hv_02.class(HU.implements()), this.protected.class(HU.implements())).thenApply(void_ -> ym_2.CANCELLED);
            return ((CompletableFuture)completionStage).handle((ym_22, throwable) -> {
                if (throwable != null && !(throwable instanceof CancellationException) && !(throwable instanceof InterruptedException)) {
                    qy_1.instanceof().break(KY.class(throwable, "Rendering chunk"));
                }
                return this.break.get() ? ym_2.CANCELLED : ym_2.SUCCESSFUL;
            });
        }
        return CompletableFuture.completedFuture(ym_2.CANCELLED);
    }
}

