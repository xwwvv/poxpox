/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableList
 */
package protected;

import com.google.common.collect.ImmutableList;
import protected.an;
import protected.cg_2;
import protected.ib_0;
import protected.iq_1;
import protected.rjU;
import protected.tx_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class tl<T extends ib_0>
extends tx_2<T> {
    private final iq_1 class;
    private final iq_1 break = new iq_1(this, 22, 0);

    public tl() {
        this.break.class(-10.0f, 0.0f, 0.0f, 10.0f, 20.0f, 2.0f, 1.0f);
        this.class = new iq_1(this, 22, 0);
        this.class.implements = true;
        this.class.class(0.0f, 0.0f, 0.0f, 10.0f, 20.0f, 2.0f, 1.0f);
    }

    @Override
    public void class(T t2, float f2, float f3, float f4, float f5, float f6) {
        float f7 = 0.2617994f;
        float f8 = -0.2617994f;
        float f9 = 0.0f;
        float f10 = 0.0f;
        if (((ib_0)t2).Sy()) {
            float f11 = 1.0f;
            rjU rjU2 = ((an)t2).rv();
            if (rjU2.byte < 0.0) {
                rjU rjU3 = rjU2.protected();
                f11 = 1.0f - (float)Math.pow(-rjU3.byte, 1.5);
            }
            f7 = f11 * 0.34906584f + (1.0f - f11) * f7;
            f8 = f11 * -1.5707964f + (1.0f - f11) * f8;
        } else if (((an)t2).x()) {
            f7 = 0.69813174f;
            f8 = -0.7853982f;
            f9 = 3.0f;
            f10 = 0.08726646f;
        }
        this.break.byte = 5.0f;
        this.break.protected = f9;
        if (t2 instanceof cg_2) {
            cg_2 cg_22 = (cg_2)t2;
            Float f12 = Float.valueOf((float)((double)((Float)cg_22.class[2]).floatValue() + (double)(f7 - ((Float)cg_22.class[2]).floatValue()) * 0.1));
            cg_22.class[2] = f12;
            Float f13 = Float.valueOf((float)((double)((Float)cg_22.class[3]).floatValue() + (double)(f10 - ((Float)cg_22.class[3]).floatValue()) * 0.1));
            cg_22.class[3] = f13;
            Float f14 = Float.valueOf((float)((double)((Float)cg_22.class[4]).floatValue() + (double)(f8 - ((Float)cg_22.class[4]).floatValue()) * 0.1));
            cg_22.class[4] = f14;
            this.break.case = ((Float)cg_22.class[2]).floatValue();
            this.break.catch = ((Float)cg_22.class[3]).floatValue();
            this.break.private = ((Float)cg_22.class[4]).floatValue();
        } else {
            this.break.case = f7;
            this.break.private = f8;
            this.break.catch = f10;
        }
        this.class.byte = -this.break.byte;
        this.class.catch = -this.break.catch;
        this.class.protected = this.break.protected;
        this.class.case = this.break.case;
        this.class.private = -this.break.private;
    }

    @Override
    protected Iterable<iq_1> class() {
        return ImmutableList.of();
    }

    @Override
    protected Iterable<iq_1> break() {
        return ImmutableList.of((Object)this.break, (Object)this.class);
    }
}

