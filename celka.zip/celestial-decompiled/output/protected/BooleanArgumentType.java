/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.float;
import protected.import;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.Sa
 */
public class sa_1
implements float<Boolean> {
    private static short[] break;
    private static byte[] byte;
    private static boolean[] protected;
    private static String[] throws;
    public static Object[] class;

    private static void byte() {
        boolean[] blArray = new boolean[8];
        blArray[0] = true;
        blArray[4] = true;
        blArray[5] = true;
        blArray[7] = true;
        protected = blArray;
    }

    static {
        sa_1.ntfClinit();
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0xDB242BB7;
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0x4A7FC0D40A09B4A4L;
    }

    @Override
    public Class<Boolean> class() {
        return Boolean.class;
    }

    public static String class(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{-72, -98, 118, 9, 60, 42, -46, 37}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    @Override
    public /* synthetic */ Object class(import import_) throws Exception {
        return this.break(import_);
    }

    private static void break() {
        throws = new String[]{new String("invalid boolean"), new String("1"), new String("true"), new String("yes"), new String("t"), new String("y"), new String("on"), new String("enable"), new String("0"), new String("false"), new String("no"), new String("f"), new String("n"), new String("off"), new String("disable")};
    }

    public Boolean break(import import_) throws RuntimeException {
        String string = import_.break();
        if (((List)sa_1.class[break[0]]).contains(string.toLowerCase(Locale.US))) {
            return protected[0];
        }
        if (((List)sa_1.class[break[1]]).contains(string.toLowerCase(Locale.US))) {
            return protected[1];
        }
        throw new IllegalArgumentException(throws[0]);
    }

    private static void throws() {
        break = new short[]{1, 2};
    }

    private static /* synthetic */ void ntfClinit() {
        sa_1.byte();
        sa_1.break();
        sa_1.throws();
        sa_1.protected();
        sa_1.case();
    }

    private static void case() {
        Object[] objectArray = new Object[3];
        objectArray[0] = new sa_1();
        String[] stringArray = new String[]{throws[1], throws[2], throws[3], throws[4], throws[5], throws[6], throws[7]};
        objectArray[1] = Arrays.asList((Object[])stringArray);
        String[] stringArray2 = new String[]{throws[8], throws[9], throws[10], throws[11], throws[12], throws[13], throws[14]};
        objectArray[2] = Arrays.asList((Object[])stringArray2);
        sa_1.class = objectArray;
    }

    private static void protected() {
        byte = new byte[]{7, 2, 3, 4, 5, 6, 7, 2, 3, 4, 5, 6, 2, 3};
    }
}

