/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ForwardingList
 */
package protected;

import com.google.common.collect.ForwardingList;
import java.util.Iterator;
import java.util.List;
import protected.rcd_2;
import protected.rcy_2;
import protected.rdn_1;
import protected.rhz_2;
import protected.rqs;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.VQ
 */
public class vq_0
extends ForwardingList<rdn_1> {
    private final rqs<rdn_1> class = rqs.class(rhz_2.protected(), rdn_1.break);

    public boolean isEmpty() {
        Iterator iterator = this.delegate().iterator();
        while (iterator.hasNext()) {
            rdn_1 rdn_12 = (rdn_1)iterator.next();
            if (rdn_12.class()) continue;
            return false;
        }
        return true;
    }

    public void class(rcy_2 rcy_22) {
        Object object = this.delegate();
        for (int k = 0; k < object.size(); ++k) {
            object.set(k, rdn_1.class(rcy_22.class(k)));
        }
    }

    public rcy_2 class() {
        rcy_2 rcy_22 = new rcy_2();
        Iterator iterator = this.delegate().iterator();
        while (iterator.hasNext()) {
            rdn_1 rdn_12 = (rdn_1)iterator.next();
            rcy_22.add(rdn_12.break(new rcd_2()));
        }
        return rcy_22;
    }

    protected List<rdn_1> delegate() {
        return this.class;
    }
}

