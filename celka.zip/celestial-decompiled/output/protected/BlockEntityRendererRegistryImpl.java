/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.ho_2;
import protected.rYB;
import protected.rqm_0;
import protected.rrrZ;
import protected.ryg_0;
import protected.xm_1;
import protected.xn_2;
import protected.xq_2;
import protected.xs_2;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.Xc
 */
public class xc_2 {
    private xm_1 class = xm_1.throws;
    private xm_1 break = xm_1.throws;
    private xm_1 byte = xm_1.throws;
    private rqm_0<ryg_0> protected;
    private rrrZ<?> throws;
    private rqm_0<rYB> case;
    private Boolean catch;
    private xq_2 private = xq_2.class;
    private ho_2 implements = ho_2.class;
    private xs_2 finally = xs_2.class;

    public xc_2 class(Boolean bl2) {
        this.catch = bl2;
        return this;
    }

    public xc_2 class(ho_2 ho_22) {
        this.implements = ho_22;
        return this;
    }

    public xc_2 class(rqm_0<ryg_0> rqm_02) {
        this.protected = rqm_02;
        return this;
    }

    public static xc_2 class() {
        return new xc_2();
    }

    public xn_2 break() {
        return new xn_2(this.class, this.break, this.byte, this.protected, this.throws, this.case, this.catch, this.private, this.implements, this.finally);
    }
}

