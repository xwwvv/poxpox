/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.io.DataInput;
import java.io.IOException;
import protected.rcg_1;
import protected.rcn_2;
import protected.rcv_2;
import protected.rcz_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.rcF
 */
class rcf_2
implements rcv_2<rcn_2> {
    final /* synthetic */ int class;

    /*
     * Ignored method signature, as it can't be verified against descriptor
     */
    rcf_2(int n2) {
        this.class = n2;
    }

    @Override
    public String class() {
        return "INVALID[" + this.class + "]";
    }

    public rcn_2 class(DataInput dataInput, int n2, rcg_1 rcg_12) throws IOException {
        throw new IllegalArgumentException("Invalid tag id: " + this.class);
    }

    @Override
    public String break() {
        return "UNKNOWN_" + this.class;
    }

    @Override
    public /* synthetic */ rcz_1 break(DataInput dataInput, int n2, rcg_1 rcg_12) throws IOException {
        return this.class(dataInput, n2, rcg_12);
    }
}

