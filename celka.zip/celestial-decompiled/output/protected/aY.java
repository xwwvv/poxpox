/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.aa;
import protected.ib_0;
import protected.rYB;
import protected.rdn_1;
import protected.rdy_2;
import protected.rfU;
import protected.rhf_1;
import protected.rhj_1;
import protected.rjU;
import protected.rjY;
import protected.rje;
import protected.rpm;
import protected.rqn;
import protected.rxm;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public interface aY
extends aa {
    default public void class(ib_0 ib_02, ib_0 ib_03, rhf_1 rhf_12, float f2, float f3) {
        double d = ib_03.rx() - ib_02.rx();
        double d2 = ib_03.BO() - ib_02.BO();
        double d3 = rfU.class(d * d + d2 * d2);
        double d4 = ib_03.byte(0.3333333333333333) - rhf_12.re() + d3 * (double)0.2f;
        rje rje2 = this.class(ib_02, new rjU(d, d4, d2), f2);
        rhf_12.byte(rje2.class(), rje2.break(), rje2.byte(), f3, 14 - ((rYB)ib_02.throws[7]).abstract().class() * 4);
        ib_02.class(rqn.PH, 1.0f, 1.0f / (ib_02.Sa().nextFloat() * 0.4f + 0.8f));
    }

    default public void class(ib_0 ib_02, float f2) {
        rpm rpm2 = rhj_1.class(ib_02, rdy_2.kU);
        rdn_1 rdn_12 = ib_02.protected(rpm2);
        if (ib_02.class(rdy_2.kU)) {
            rxm.class((rYB)ib_02.throws[7], ib_02, rpm2, rdn_12, f2, 14 - ((rYB)ib_02.throws[7]).abstract().class() * 4);
        }
        this.class();
    }

    default public rje class(ib_0 ib_02, rjU rjU2, float f2) {
        rjU rjU3 = rjU2.protected();
        rjU rjU4 = rjU3.byte(new rjU(0.0, 1.0, 0.0));
        if (rjU4.catch() <= 1.0E-7) {
            rjU4 = rjU3.byte(ib_02.continue(1.0f));
        }
        rjY rjY2 = new rjY(new rje(rjU4), 90.0f, true);
        rje rje2 = new rje(rjU3);
        rje2.class(rjY2);
        rjY rjY3 = new rjY(rje2, f2, true);
        rje rje3 = new rje(rjU3);
        rje3.class(rjY3);
        return rje3;
    }

    public void class();

    public void class(ib_0 var1, rdn_1 var2, rhf_1 var3, float var4);

    public void break(boolean var1);

    public ib_0 I_();
}

