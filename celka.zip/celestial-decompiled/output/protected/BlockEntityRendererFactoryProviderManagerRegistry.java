/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Maps
 */
package protected;

import com.google.common.collect.Maps;
import java.util.Map;
import protected.HU;
import protected.kz_1;
import protected.lp;
import protected.qy_1;
import protected.rdb_1;
import protected.rdn_1;
import protected.rqR;
import protected.rxe_2;
import protected.rxg_2;
import protected.rxj_0;
import protected.rxs_1;
import protected.xc_0;
import protected.xd_0;
import protected.xu_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.yS
 */
public class ys_2 {
    private static final Map<xd_0, HU> class = rqR.class(Maps.newHashMap(), hashMap -> {
        HU hU = HU.synchronized();
        hashMap.put(xu_0.SQ, hU);
        HU hU2 = HU.catch();
        hashMap.put(xu_0.implements, hU2);
        hashMap.put(xu_0.Bf, hU2);
        hashMap.put(xu_0.BV, hU2);
        hashMap.put(xu_0.Sz, hU2);
        hashMap.put(xu_0.sl, hU2);
        hashMap.put(xu_0.Bj, hU2);
        hashMap.put(xu_0.W, hU2);
        hashMap.put(xu_0.x, hU2);
        hashMap.put(xu_0.d, hU2);
        hashMap.put(xu_0.z, hU2);
        hashMap.put(xu_0.k, hU2);
        hashMap.put(xu_0.Q, hU2);
        HU hU3 = HU.private();
        hashMap.put(xu_0.this, hU3);
        hashMap.put(xu_0.else, hU3);
        hashMap.put(xu_0.synchronized, hU3);
        hashMap.put(xu_0.return, hU3);
        hashMap.put(xu_0.public, hU3);
        hashMap.put(xu_0.goto, hU3);
        hashMap.put(xu_0.u, hU3);
        hashMap.put(xu_0.C, hU3);
        hashMap.put(xu_0.l, hU3);
        hashMap.put(xu_0.H, hU3);
        hashMap.put(xu_0.y, hU3);
        hashMap.put(xu_0.p, hU3);
        hashMap.put(xu_0.q, hU3);
        hashMap.put(xu_0.T, hU3);
        hashMap.put(xu_0.t, hU3);
        hashMap.put(xu_0.w, hU3);
        hashMap.put(xu_0.I, hU3);
        hashMap.put(xu_0.f, hU3);
        hashMap.put(xu_0.j, hU3);
        hashMap.put(xu_0.V, hU3);
        hashMap.put(xu_0.g, hU3);
        hashMap.put(xu_0.R, hU3);
        hashMap.put(xu_0.Y, hU3);
        hashMap.put(xu_0.o, hU3);
        hashMap.put(xu_0.K, hU3);
        hashMap.put(xu_0.U, hU3);
        hashMap.put(xu_0.e, hU3);
        hashMap.put(xu_0.a, hU3);
        hashMap.put(xu_0.i, hU3);
        hashMap.put(xu_0.rr, hU3);
        hashMap.put(xu_0.rP, hU3);
        hashMap.put(xu_0.ru, hU3);
        hashMap.put(xu_0.rm, hU3);
        hashMap.put(xu_0.rZ, hU3);
        hashMap.put(xu_0.rv, hU3);
        hashMap.put(xu_0.rF, hU3);
        hashMap.put(xu_0.rL, hU3);
        hashMap.put(xu_0.rA, hU3);
        hashMap.put(xu_0.rn, hU3);
        hashMap.put(xu_0.rC, hU3);
        hashMap.put(xu_0.rl, hU3);
        hashMap.put(xu_0.rH, hU3);
        hashMap.put(xu_0.ry, hU3);
        hashMap.put(xu_0.rp, hU3);
        hashMap.put(xu_0.rq, hU3);
        hashMap.put(xu_0.rT, hU3);
        hashMap.put(xu_0.rR, hU3);
        hashMap.put(xu_0.rY, hU3);
        hashMap.put(xu_0.PU, hU3);
        hashMap.put(xu_0.Pe, hU3);
        hashMap.put(xu_0.ro, hU3);
        hashMap.put(xu_0.rK, hU3);
        hashMap.put(xu_0.rD, hU3);
        hashMap.put(xu_0.ra, hU3);
        hashMap.put(xu_0.PB, hU3);
        hashMap.put(xu_0.PX, hU3);
        hashMap.put(xu_0.PJ, hU3);
        hashMap.put(xu_0.Px, hU3);
        hashMap.put(xu_0.PZ, hU3);
        hashMap.put(xu_0.PH, hU3);
        hashMap.put(xu_0.Py, hU3);
        hashMap.put(xu_0.Pw, hU3);
        hashMap.put(xu_0.Pf, hU3);
        hashMap.put(xu_0.BS, hU3);
        hashMap.put(xu_0.Bc, hU3);
        hashMap.put(xu_0.Bu, hU3);
        hashMap.put(xu_0.Bm, hU3);
        hashMap.put(xu_0.BZ, hU3);
        hashMap.put(xu_0.Bv, hU3);
        hashMap.put(xu_0.BF, hU3);
        hashMap.put(xu_0.Xg, hU3);
        hashMap.put(xu_0.XR, hU3);
        hashMap.put(xu_0.BR, hU3);
        hashMap.put(xu_0.BY, hU3);
        hashMap.put(xu_0.Bo, hU3);
        hashMap.put(xu_0.BK, hU3);
        hashMap.put(xu_0.BD, hU3);
        hashMap.put(xu_0.Sr, hU3);
        hashMap.put(xu_0.Ss, hU3);
        hashMap.put(xu_0.SG, hU3);
        hashMap.put(xu_0.Sx, hU3);
        hashMap.put(xu_0.Sv, hU3);
        hashMap.put(xu_0.SA, hU3);
        hashMap.put(xu_0.Sn, hU3);
        hashMap.put(xu_0.SC, hU3);
        hashMap.put(xu_0.Sl, hU3);
        hashMap.put(xu_0.SH, hU3);
        hashMap.put(xu_0.Sy, hU3);
        hashMap.put(xu_0.Sp, hU3);
        hashMap.put(xu_0.Sq, hU3);
        hashMap.put(xu_0.ST, hU3);
        hashMap.put(xu_0.St, hU3);
        hashMap.put(xu_0.Sw, hU3);
        hashMap.put(xu_0.SI, hU3);
        hashMap.put(xu_0.Sf, hU3);
        hashMap.put(xu_0.Sj, hU3);
        hashMap.put(xu_0.SV, hU3);
        hashMap.put(xu_0.Sg, hU3);
        hashMap.put(xu_0.SR, hU3);
        hashMap.put(xu_0.SY, hU3);
        hashMap.put(xu_0.So, hU3);
        hashMap.put(xu_0.SK, hU3);
        hashMap.put(xu_0.SD, hU3);
        hashMap.put(xu_0.SU, hU3);
        hashMap.put(xu_0.Se, hU3);
        hashMap.put(xu_0.Sa, hU3);
        hashMap.put(xu_0.Si, hU3);
        hashMap.put(xu_0.sr, hU3);
        hashMap.put(xu_0.sP, hU3);
        hashMap.put(xu_0.sL, hU3);
        hashMap.put(xu_0.sT, hU3);
        hashMap.put(xu_0.Eu, hU3);
        hashMap.put(xu_0.Gr, hU3);
        hashMap.put(xu_0.GP, hU3);
        hashMap.put(xu_0.GB, hU3);
        hashMap.put(xu_0.GS, hU3);
        hashMap.put(xu_0.Gs, hU3);
        hashMap.put(xu_0.GE, hU3);
        hashMap.put(xu_0.bZ, hU3);
        hashMap.put(xu_0.bv, hU3);
        hashMap.put(xu_0.bF, hU3);
        hashMap.put(xu_0.bL, hU3);
        hashMap.put(xu_0.bA, hU3);
        hashMap.put(xu_0.bn, hU3);
        hashMap.put(xu_0.bC, hU3);
        hashMap.put(xu_0.bl, hU3);
        hashMap.put(xu_0.bT, hU3);
        hashMap.put(xu_0.OM, hU3);
        hashMap.put(xu_0.OO, hU3);
        hashMap.put(xu_0.OX, hU3);
        hashMap.put(xu_0.Om, hU3);
        hashMap.put(xu_0.OZ, hU3);
        hashMap.put(xu_0.Ov, hU3);
        hashMap.put(xu_0.OF, hU3);
        hashMap.put(xu_0.OL, hU3);
        hashMap.put(xu_0.OA, hU3);
        hashMap.put(xu_0.On, hU3);
        hashMap.put(xu_0.OC, hU3);
        hashMap.put(xu_0.Ol, hU3);
        hashMap.put(xu_0.OH, hU3);
        hashMap.put(xu_0.Oy, hU3);
        hashMap.put(xu_0.Op, hU3);
        hashMap.put(xu_0.Oq, hU3);
        hashMap.put(xu_0.OT, hU3);
        hashMap.put(xu_0.Ot, hU3);
        hashMap.put(xu_0.Ow, hU3);
        hashMap.put(xu_0.OI, hU3);
        hashMap.put(xu_0.Of, hU3);
        hashMap.put(xu_0.Oj, hU3);
        hashMap.put(xu_0.OV, hU3);
        hashMap.put(xu_0.Og, hU3);
        hashMap.put(xu_0.OR, hU3);
        hashMap.put(xu_0.OY, hU3);
        hashMap.put(xu_0.Oo, hU3);
        hashMap.put(xu_0.OK, hU3);
        hashMap.put(xu_0.OD, hU3);
        hashMap.put(xu_0.OU, hU3);
        hashMap.put(xu_0.Oe, hU3);
        hashMap.put(xu_0.Oa, hU3);
        hashMap.put(xu_0.Oi, hU3);
        hashMap.put(xu_0.hr, hU3);
        hashMap.put(xu_0.hB, hU3);
        hashMap.put(xu_0.hS, hU3);
        hashMap.put(xu_0.hs, hU3);
        hashMap.put(xu_0.hE, hU3);
        hashMap.put(xu_0.hU, hU3);
        hashMap.put(xu_0.XG, hU3);
        hashMap.put(xu_0.XM, hU3);
        hashMap.put(xu_0.XO, hU3);
        hashMap.put(xu_0.Xh, hU3);
        hashMap.put(xu_0.XX, hU3);
        hashMap.put(xu_0.XJ, hU3);
        hashMap.put(xu_0.XC, hU3);
        hashMap.put(xu_0.Xl, hU3);
        hashMap.put(xu_0.XH, hU3);
        hashMap.put(xu_0.Xy, hU3);
        hashMap.put(xu_0.Xu, hU3);
        hashMap.put(xu_0.XA, hU3);
        hashMap.put(xu_0.XQ, hU3);
        hashMap.put(xu_0.Xp, hU3);
        hashMap.put(xu_0.Xc, hU3);
        hashMap.put(xu_0.JW, hU3);
        hashMap.put(xu_0.Jz, hU3);
        hashMap.put(xu_0.JQ, hU3);
        hashMap.put(xu_0.JN, hU3);
        hashMap.put(xu_0.Xa, hU3);
        hashMap.put(xu_0.Xi, hU3);
        HU hU4 = HU.implements();
        hashMap.put(xu_0.PT, hU4);
        hashMap.put(xu_0.Pi, hU4);
        hashMap.put(xu_0.Bs, hU4);
        hashMap.put(xu_0.BE, hU4);
        hashMap.put(xu_0.BG, hU4);
        hashMap.put(xu_0.Bb, hU4);
        hashMap.put(xu_0.BM, hU4);
        hashMap.put(xu_0.BO, hU4);
        hashMap.put(xu_0.Bh, hU4);
        hashMap.put(xu_0.BX, hU4);
        hashMap.put(xu_0.BJ, hU4);
        hashMap.put(xu_0.Bx, hU4);
        hashMap.put(xu_0.Bd, hU4);
        hashMap.put(xu_0.Bk, hU4);
        hashMap.put(xu_0.BW, hU4);
        hashMap.put(xu_0.Bz, hU4);
        hashMap.put(xu_0.BQ, hU4);
        hashMap.put(xu_0.BN, hU4);
        hashMap.put(xu_0.EP, hU4);
        hashMap.put(xu_0.EB, hU4);
        hashMap.put(xu_0.ES, hU4);
        hashMap.put(xu_0.Es, hU4);
        hashMap.put(xu_0.EE, hU4);
        hashMap.put(xu_0.EG, hU4);
        hashMap.put(xu_0.Eb, hU4);
        hashMap.put(xu_0.EM, hU4);
        hashMap.put(xu_0.EO, hU4);
        hashMap.put(xu_0.Eh, hU4);
        hashMap.put(xu_0.EX, hU4);
        hashMap.put(xu_0.EJ, hU4);
        hashMap.put(xu_0.Ex, hU4);
        hashMap.put(xu_0.Ed, hU4);
        hashMap.put(xu_0.Ek, hU4);
        hashMap.put(xu_0.EW, hU4);
        hashMap.put(xu_0.EN, hU4);
        hashMap.put(xu_0.Jh, hU4);
        hashMap.put(xu_0.bj, hU4);
        hashMap.put(xu_0.hM, hU4);
    });
    private static final Map<rxs_1, HU> break = rqR.class(Maps.newHashMap(), hashMap -> {
        HU hU = HU.implements();
        hashMap.put(rxg_2.break, hU);
        hashMap.put(rxg_2.byte, hU);
    });
    private static boolean byte;

    public static HU class(rxe_2 rxe_22) {
        HU hU = break.get(rxe_22.class());
        return hU != null ? hU : HU.case();
    }

    public static HU class(xc_0 xc_02) {
        xd_0 xd_02 = xc_02.break();
        if (xd_02 instanceof kz_1) {
            return byte ? HU.catch() : HU.case();
        }
        HU hU = ys_2.class.get(xd_02);
        return hU != null ? hU : HU.case();
    }

    public static void class(boolean bl2) {
        byte = bl2;
    }

    public static HU class(xc_0 xc_02, boolean bl2) {
        HU hU = ys_2.class(xc_02);
        if (hU == HU.implements()) {
            if (!qy_1.d()) {
                return lp.finally();
            }
            return bl2 ? lp.finally() : lp.implements();
        }
        return lp.private();
    }

    public static HU class(rdn_1 rdn_12, boolean bl2) {
        rdb_1 rdb_12 = rdn_12.break();
        if (rdb_12 instanceof rxj_0) {
            xd_0 xd_02 = ((rxj_0)rdb_12).catch();
            return ys_2.class(xd_02.continue(), bl2);
        }
        return bl2 ? lp.finally() : lp.implements();
    }

    public static HU break(xc_0 xc_02) {
        xd_0 xd_02 = xc_02.break();
        if (xd_02 instanceof kz_1) {
            return byte ? HU.catch() : HU.case();
        }
        HU hU = ys_2.class.get(xd_02);
        if (hU != null) {
            return hU == HU.implements() ? HU.finally() : hU;
        }
        return HU.case();
    }
}

