/*
 * Decompiled with CFR 0.152.
 */
package protected;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public interface aD {
    public void class(int var1);

    public void break(int var1);

    public boolean throws();

    public void case();
}

