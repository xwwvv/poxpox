/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.rCR;
import protected.rpa;
import protected.rqd_0;

/*
 * Renamed from protected.WX
 * Illegal identifiers - consider using --renameillegalidents true
 */
class wx_2 {
    static final /* synthetic */ int[] class;
    static final /* synthetic */ int[] break;
    static final /* synthetic */ int[] byte;

    static {
        byte = new int[rpa.values().length];
        try {
            wx_2.byte[rpa.LEFT_RIGHT.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            wx_2.byte[rpa.FRONT_BACK.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        break = new int[rqd_0.values().length];
        try {
            wx_2.break[rqd_0.CLOCKWISE_180.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            wx_2.break[rqd_0.COUNTERCLOCKWISE_90.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            wx_2.break[rqd_0.CLOCKWISE_90.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        wx_2.class = new int[rCR.values().length];
        try {
            wx_2.class[rCR.ASCENDING_EAST.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            wx_2.class[rCR.ASCENDING_WEST.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            wx_2.class[rCR.ASCENDING_NORTH.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            wx_2.class[rCR.ASCENDING_SOUTH.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            wx_2.class[rCR.SOUTH_EAST.ordinal()] = 5;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            wx_2.class[rCR.SOUTH_WEST.ordinal()] = 6;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            wx_2.class[rCR.NORTH_WEST.ordinal()] = 7;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            wx_2.class[rCR.NORTH_EAST.ordinal()] = 8;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            wx_2.class[rCR.NORTH_SOUTH.ordinal()] = 9;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            wx_2.class[rCR.EAST_WEST.ordinal()] = 10;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}

