/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.CD;
import protected.ch_0;
import protected.gm;

public class Cm
extends CD {
    protected Cm(gm gm2, double d, double d2, double d3, double d4, double d5, double d6, ch_0 ch_02) {
        super(gm2, d, d2, d3, d4, d5, d6, 2.5f, ch_02);
    }
}

