/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.rCZ;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class rCv<T extends Comparable<T>> {
    private final rCZ<T> class;
    private final T break;

    rCv(rCZ<T> rCZ2, T t2) {
        if (!rCZ2.class().contains(t2)) {
            throw new IllegalArgumentException("Value " + t2 + " does not belong to property " + rCZ2);
        }
        this.class = rCZ2;
        this.break = t2;
    }

    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof rCv)) {
            return false;
        }
        rCv rCv2 = (rCv)object;
        return this.class == rCv2.class && this.break.equals(rCv2.break);
    }

    public String toString() {
        return this.class.throws() + "=" + this.class.class(this.break);
    }

    public int hashCode() {
        int n2 = this.class.hashCode();
        return 31 * n2 + this.break.hashCode();
    }

    public rCZ<T> class() {
        return this.class;
    }

    public T break() {
        return this.break;
    }
}

