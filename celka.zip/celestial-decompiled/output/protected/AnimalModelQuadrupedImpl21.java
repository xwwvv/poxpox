/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableList
 */
package protected;

import com.google.common.collect.ImmutableList;
import protected.iq_1;
import protected.ml_1;
import protected.ok_2;
import protected.rfU;
import protected.rmi_1;
import protected.tp_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.wW
 */
public class ww_0<T extends rmi_1>
extends tp_0<T> {
    private final iq_1 class = new iq_1(this, 26, 24);
    private final iq_1 break;
    private final iq_1 byte;
    private final iq_1 protected;
    private final iq_1 throws;
    private final iq_1 case;
    private final iq_1 catch;
    private final iq_1 private;
    private final iq_1 implements;
    private final iq_1 finally;
    private final iq_1 extends;
    private final iq_1 native;
    private float volatile;

    public ww_0() {
        this.class.class(-1.0f, 5.5f, -3.7f, 2.0f, 1.0f, 7.0f);
        this.class.class(3.0f, 17.5f, 3.7f);
        this.class.implements = true;
        this.class(this.class, 0.0f, 0.0f, 0.0f);
        this.break = new iq_1(this, 8, 24);
        this.break.class(-1.0f, 5.5f, -3.7f, 2.0f, 1.0f, 7.0f);
        this.break.class(-3.0f, 17.5f, 3.7f);
        this.break.implements = true;
        this.class(this.break, 0.0f, 0.0f, 0.0f);
        this.byte = new iq_1(this, 30, 15);
        this.byte.class(-1.0f, 0.0f, 0.0f, 2.0f, 4.0f, 5.0f);
        this.byte.class(3.0f, 17.5f, 3.7f);
        this.byte.implements = true;
        this.class(this.byte, -0.34906584f, 0.0f, 0.0f);
        this.protected = new iq_1(this, 16, 15);
        this.protected.class(-1.0f, 0.0f, 0.0f, 2.0f, 4.0f, 5.0f);
        this.protected.class(-3.0f, 17.5f, 3.7f);
        this.protected.implements = true;
        this.class(this.protected, -0.34906584f, 0.0f, 0.0f);
        this.throws = new iq_1(this, 0, 0);
        this.throws.class(-3.0f, -2.0f, -10.0f, 6.0f, 5.0f, 10.0f);
        this.throws.class(0.0f, 19.0f, 8.0f);
        this.throws.implements = true;
        this.class(this.throws, -0.34906584f, 0.0f, 0.0f);
        this.case = new iq_1(this, 8, 15);
        this.case.class(-1.0f, 0.0f, -1.0f, 2.0f, 7.0f, 2.0f);
        this.case.class(3.0f, 17.0f, -1.0f);
        this.case.implements = true;
        this.class(this.case, -0.17453292f, 0.0f, 0.0f);
        this.catch = new iq_1(this, 0, 15);
        this.catch.class(-1.0f, 0.0f, -1.0f, 2.0f, 7.0f, 2.0f);
        this.catch.class(-3.0f, 17.0f, -1.0f);
        this.catch.implements = true;
        this.class(this.catch, -0.17453292f, 0.0f, 0.0f);
        this.private = new iq_1(this, 32, 0);
        this.private.class(-2.5f, -4.0f, -5.0f, 5.0f, 4.0f, 5.0f);
        this.private.class(0.0f, 16.0f, -1.0f);
        this.private.implements = true;
        this.class(this.private, 0.0f, 0.0f, 0.0f);
        this.implements = new iq_1(this, 52, 0);
        this.implements.class(-2.5f, -9.0f, -1.0f, 2.0f, 5.0f, 1.0f);
        this.implements.class(0.0f, 16.0f, -1.0f);
        this.implements.implements = true;
        this.class(this.implements, 0.0f, -0.2617994f, 0.0f);
        this.finally = new iq_1(this, 58, 0);
        this.finally.class(0.5f, -9.0f, -1.0f, 2.0f, 5.0f, 1.0f);
        this.finally.class(0.0f, 16.0f, -1.0f);
        this.finally.implements = true;
        this.class(this.finally, 0.0f, 0.2617994f, 0.0f);
        this.extends = new iq_1(this, 52, 6);
        this.extends.class(-1.5f, -1.5f, 0.0f, 3.0f, 3.0f, 2.0f);
        this.extends.class(0.0f, 20.0f, 7.0f);
        this.extends.implements = true;
        this.class(this.extends, -0.3490659f, 0.0f, 0.0f);
        this.native = new iq_1(this, 32, 9);
        this.native.class(-0.5f, -2.5f, -5.5f, 1.0f, 1.0f, 1.0f);
        this.native.class(0.0f, 16.0f, -1.0f);
        this.native.implements = true;
        this.class(this.native, 0.0f, 0.0f, 0.0f);
    }

    @Override
    private void class(iq_1 iq_12, float f2, float f3, float f4) {
        iq_12.case = f2;
        iq_12.catch = f3;
        iq_12.private = f4;
    }

    @Override
    public void class(ml_1 ml_12, ok_2 ok_22, int n2, int n3, float f2, float f3, float f4, float f5) {
        if (this.int) {
            float f6 = 1.5f;
            ml_12.class();
            ml_12.class(0.56666666f, 0.56666666f, 0.56666666f);
            ml_12.class(0.0, 1.375, 0.125);
            ImmutableList.of((Object)this.private, (Object)this.finally, (Object)this.implements, (Object)this.native).forEach(iq_12 -> iq_12.class(ml_12, ok_22, n2, n3, f2, f3, f4, f5));
            ml_12.break();
            ml_12.class();
            ml_12.class(0.4f, 0.4f, 0.4f);
            ml_12.class(0.0, 2.25, 0.0);
            ImmutableList.of((Object)this.class, (Object)this.break, (Object)this.byte, (Object)this.protected, (Object)this.throws, (Object)this.case, (Object)this.catch, (Object)this.extends).forEach(iq_12 -> iq_12.class(ml_12, ok_22, n2, n3, f2, f3, f4, f5));
            ml_12.break();
        } else {
            ml_12.class();
            ml_12.class(0.6f, 0.6f, 0.6f);
            ml_12.class(0.0, 1.0, 0.0);
            ImmutableList.of((Object)this.class, (Object)this.break, (Object)this.byte, (Object)this.protected, (Object)this.throws, (Object)this.case, (Object)this.catch, (Object)this.private, (Object)this.implements, (Object)this.finally, (Object)this.extends, (Object)this.native, (Object[])new iq_1[0]).forEach(iq_12 -> iq_12.class(ml_12, ok_22, n2, n3, f2, f3, f4, f5));
            ml_12.break();
        }
    }

    @Override
    public void class(T t2, float f2, float f3, float f4, float f5, float f6) {
        float f7 = f4 - (float)((Integer)((rmi_1)t2).throws[41]).intValue();
        this.native.case = f6 * ((float)Math.PI / 180);
        this.private.case = f6 * ((float)Math.PI / 180);
        this.implements.case = f6 * ((float)Math.PI / 180);
        this.finally.case = f6 * ((float)Math.PI / 180);
        this.native.catch = f5 * ((float)Math.PI / 180);
        this.private.catch = f5 * ((float)Math.PI / 180);
        this.implements.catch = this.native.catch - 0.2617994f;
        this.finally.catch = this.native.catch + 0.2617994f;
        this.volatile = rfU.class(((rmi_1)t2).throw(f7) * (float)Math.PI);
        this.byte.case = (this.volatile * 50.0f - 21.0f) * ((float)Math.PI / 180);
        this.protected.case = (this.volatile * 50.0f - 21.0f) * ((float)Math.PI / 180);
        this.class.case = this.volatile * 50.0f * ((float)Math.PI / 180);
        this.break.case = this.volatile * 50.0f * ((float)Math.PI / 180);
        this.case.case = (this.volatile * -40.0f - 11.0f) * ((float)Math.PI / 180);
        this.catch.case = (this.volatile * -40.0f - 11.0f) * ((float)Math.PI / 180);
    }

    @Override
    public void class(T t2, float f2, float f3, float f4) {
        super.class(t2, f2, f3, f4);
        this.volatile = rfU.class(((rmi_1)t2).throw(f4) * (float)Math.PI);
    }
}

