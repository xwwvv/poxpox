/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.Sh
 */
public class sh_2 {
    public static Object[] class;
    private static boolean[] break;
    private static byte[] byte;

    private static void byte() {
        byte = new byte[]{2};
    }

    static {
        sh_2.ntfClinit();
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0x21CC0F705765220DL;
    }

    private static void class() {
        boolean[] blArray = new boolean[5];
        blArray[2] = true;
        blArray[4] = true;
        break = blArray;
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0x726D6FB4;
    }

    public static String class(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{-24, -75, -69, 100, -56, -109, -100, 61}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    private static void break() {
        Object[] objectArray = new Object[1];
        int[] nArray = new int[6];
        nArray[0] = 1;
        nArray[1] = 2;
        objectArray[0] = nArray;
        sh_2.class = objectArray;
    }

    private static /* synthetic */ void ntfClinit() {
        sh_2.class();
        sh_2.byte();
        sh_2.break();
    }
}

