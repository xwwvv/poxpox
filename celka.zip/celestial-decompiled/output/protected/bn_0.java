/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.bN
 */
public class bn_0 {
    private static byte[] break;
    public static Object[] class;
    private static boolean[] byte;

    private static void byte() {
        Object[] objectArray = new Object[]{new int[]{1, 2}};
        bn_0.class = objectArray;
    }

    static {
        bn_0.ntfClinit();
    }

    private static void class() {
        break = new byte[]{2};
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0xAA9669FA;
    }

    public static String class(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{-31, 111, 115, -112, -88, -21, -70, 88}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0xD03B3D4A91827BA9L;
    }

    private static void break() {
        boolean[] blArray = new boolean[7];
        blArray[3] = true;
        blArray[5] = true;
        blArray[6] = true;
        byte = blArray;
    }

    private static /* synthetic */ void ntfClinit() {
        bn_0.break();
        bn_0.class();
        bn_0.byte();
    }
}

