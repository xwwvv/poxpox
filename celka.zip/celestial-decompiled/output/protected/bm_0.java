/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.ArrayList;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import protected.U;
import protected.bb_0;
import protected.class;
import protected.rVi;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.bM
 */
public class bm_0 {
    private static byte[] class;
    private static short[] byte;
    public Object[] break;

    public void byte(bb_0 bb_02) {
        ((class)this.break[byte[9]]).s().break(bb_02);
    }

    public void byte() {
        ((List)this.break[byte[2]]).stream().filter(bb_0::protected).forEach(bb_0::class);
        this.catch();
    }

    public bm_0(class clazz) {
        ArrayList arrayList;
        this.finally();
        class clazz2 = clazz;
        this.break[bm_0.byte[0]] = clazz2;
        this.break[bm_0.byte[1]] = arrayList = new ArrayList();
    }

    static {
        bm_0.ntfClinit();
    }

    public void class(bb_0 bb_02) {
        ((List)this.break[byte[3]]).add(bb_02);
    }

    public void class(bb_0 bb_02, rVi rVi2) {
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0xA46E33A2;
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0x5AC273A7367A1FCBL;
    }

    public void class() {
        U u = ((class)this.break[byte[6]]).s();
        for (bb_0 bb_02 : (List)this.break[byte[7]]) {
            u.break(bb_02);
        }
    }

    public static String break(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{-54, 98, -89, 121, -2, -60, -75, 96}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    public void break(bb_0 bb_02) {
        ((class)this.break[byte[8]]).s().class(bb_02);
    }

    public List<bb_0> break() {
        return (List)this.break[byte[11]];
    }

    public class throws() {
        return (class)this.break[byte[10]];
    }

    private static /* synthetic */ void ntfClinit() {
        bm_0.implements();
        bm_0.private();
    }

    private void finally() {
        if (this.break == null) {
            Object[] objectArray = this.break = new Object[bm_0.class[0]];
        }
    }

    public void catch() {
    }

    public void case() {
        U u = ((class)this.break[byte[4]]).s();
        for (bb_0 bb_02 : (List)this.break[byte[5]]) {
            u.class(bb_02);
        }
    }

    private static void implements() {
        short[] sArray = new short[12];
        sArray[1] = 1;
        sArray[2] = 1;
        sArray[3] = 1;
        sArray[5] = 1;
        sArray[7] = 1;
        sArray[11] = 1;
        byte = sArray;
    }

    public void protected() {
    }

    private static void private() {
        bm_0.class = new byte[]{2};
    }
}

