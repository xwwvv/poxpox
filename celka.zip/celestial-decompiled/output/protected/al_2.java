/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.authlib.GameProfile
 *  com.mojang.authlib.exceptions.AuthenticationException
 *  com.mojang.authlib.exceptions.AuthenticationUnavailableException
 *  com.mojang.authlib.exceptions.InsufficientPrivilegesException
 *  com.mojang.authlib.exceptions.InvalidCredentialsException
 *  com.mojang.authlib.minecraft.MinecraftSessionService
 *  io.netty.util.concurrent.Future
 *  io.netty.util.concurrent.GenericFutureListener
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
package protected;

import com.mojang.authlib.GameProfile;
import com.mojang.authlib.exceptions.AuthenticationException;
import com.mojang.authlib.exceptions.AuthenticationUnavailableException;
import com.mojang.authlib.exceptions.InsufficientPrivilegesException;
import com.mojang.authlib.exceptions.InvalidCredentialsException;
import com.mojang.authlib.minecraft.MinecraftSessionService;
import io.netty.util.concurrent.Future;
import io.netty.util.concurrent.GenericFutureListener;
import java.math.BigInteger;
import java.security.PublicKey;
import java.util.function.Consumer;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import protected.ah_1;
import protected.aq_1;
import protected.cn_2;
import protected.qy_1;
import protected.rgP;
import protected.rgn;
import protected.rma_0;
import protected.rmc_0;
import protected.rmf_0;
import protected.rml_0;
import protected.rmn;
import protected.rmn_0;
import protected.rmv_0;
import protected.rpu_0;
import protected.rud_1;
import protected.ruv_1;
import protected.ryk_1;
import protected.ryo_1;
import protected.vm_1;
import protected.zg_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.Al
 */
public class al_2
implements ah_1 {
    private static final Logger class = LogManager.getLogger();
    private final qy_1 break;
    private final vm_1 byte;
    private final Consumer<rgP> protected;
    private final rud_1 throws;
    private GameProfile case;

    public al_2(rud_1 rud_12, qy_1 qy_12, vm_1 vm_12, Consumer<rgP> consumer) {
        this.throws = rud_12;
        this.break = qy_12;
        this.byte = vm_12;
        this.protected = consumer;
    }

    @Override
    public void class(rmf_0 rmf_02) {
        this.throws.class(rmf_02.break());
    }

    @Override
    public void class(rml_0 rml_02) {
        if (!this.throws.protected()) {
            this.throws.class(rml_02.break());
        }
    }

    @Override
    public void class(rmv_0 rmv_02) {
        this.protected.accept(new rgn("connect.negotiating"));
        this.throws.class(new rmn_0(rmv_02.break(), null));
    }

    @Override
    public rud_1 class() {
        return this.throws;
    }

    private rgP class(String string) {
        try {
            this.break().joinServer(this.break.while().throws(), this.break.while().protected(), string);
            return null;
        }
        catch (AuthenticationUnavailableException authenticationUnavailableException) {
            return new rgn("disconnect.loginFailedInfo", new rgn("disconnect.loginFailedInfo.serversUnavailable"));
        }
        catch (InvalidCredentialsException invalidCredentialsException) {
            return new rgn("disconnect.loginFailedInfo", new rgn("disconnect.loginFailedInfo.invalidSession"));
        }
        catch (InsufficientPrivilegesException insufficientPrivilegesException) {
            return new rgn("disconnect.loginFailedInfo", new rgn("disconnect.loginFailedInfo.insufficientPrivileges"));
        }
        catch (AuthenticationException authenticationException) {
            return new rgn("disconnect.loginFailedInfo", authenticationException.getMessage());
        }
    }

    @Override
    public void class(rmn rmn2) {
        this.protected.accept(new rgn("connect.joining"));
        this.case = rmn2.break();
        this.throws.class(ruv_1.PLAY);
        this.throws.class(new aq_1(this.break, this.byte, this.throws, this.case));
    }

    @Override
    public void class(rgP rgP2, rgP rgP3) {
        this.break.break(new zg_0(this.byte, cn_2.implements, rgP3));
    }

    @Override
    public void class(rma_0 rma_02) {
        rmc_0 rmc_02;
        Cipher cipher;
        Cipher cipher2;
        String string;
        try {
            SecretKey secretKey = ryk_1.class();
            PublicKey publicKey = rma_02.byte();
            string = new BigInteger(ryk_1.class(rma_02.break(), publicKey, secretKey)).toString(16);
            cipher2 = ryk_1.class(2, secretKey);
            cipher = ryk_1.class(1, secretKey);
            rmc_02 = new rmc_0(secretKey, publicKey, rma_02.protected());
        }
        catch (ryo_1 ryo_12) {
            throw new IllegalStateException("Protocol error", ryo_12);
        }
        this.protected.accept(new rgn("connect.authorizing"));
        rpu_0.class.submit(() -> {
            rgP rgP2 = this.class(string);
            if (rgP2 != null) {
                if (this.break.S() == null || !this.break.S().protected()) {
                    this.throws.class(rgP2);
                    return;
                }
                al_2.class.warn(rgP2.getString());
            }
            this.protected.accept(new rgn("connect.encrypting"));
            this.throws.class(rmc_02, (GenericFutureListener<? extends Future<? super Void>>)((GenericFutureListener)future -> this.throws.class(cipher2, cipher)));
        });
    }

    private MinecraftSessionService break() {
        return this.break.r();
    }
}

