/*
 * Decompiled with CFR 0.152.
 */
package protected;

import protected.rfl_2;

/*
 * Renamed from protected.ck
 * Illegal identifiers - consider using --renameillegalidents true
 */
class ck_1 {
    static final /* synthetic */ int[] class;

    static {
        ck_1.class = new int[rfl_2.values().length];
        try {
            ck_1.class[rfl_2.UPDATE_NAME.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            ck_1.class[rfl_2.UPDATE_PCT.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            ck_1.class[rfl_2.UPDATE_STYLE.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            ck_1.class[rfl_2.UPDATE_PROPERTIES.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}

