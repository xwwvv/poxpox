/*
 * Decompiled with CFR 0.152.
 */
package protected;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class bH {
    private static boolean[] break;
    private static byte[] byte;
    public static Object[] class;

    private static void byte() {
        Object[] objectArray = new Object[]{new int[]{1, 2, 3}};
        bH.class = objectArray;
    }

    static {
        bH.ntfClinit();
    }

    private static long class(long l2) {
        return Long.rotateLeft(l2, 32) ^ 0x4A3FF3C36BD48380L;
    }

    private static void class() {
        byte = new byte[]{2, 3};
    }

    public static String class(String string) throws Exception {
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{14, -22, 67, 23, 77, -15, 9, -86}, "DES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
        cipher.init(2, (Key)secretKeySpec, ivParameterSpec);
        return new String(cipher.doFinal(string.getBytes(StandardCharsets.ISO_8859_1)), StandardCharsets.UTF_8);
    }

    private static int class(int n2) {
        return Integer.rotateLeft(n2, 16) ^ 0x7B4B2508;
    }

    private static void break() {
        boolean[] blArray = new boolean[6];
        blArray[2] = true;
        blArray[5] = true;
        break = blArray;
    }

    private static /* synthetic */ void ntfClinit() {
        bH.break();
        bH.class();
        bH.byte();
    }
}

