/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.ImmutableList
 */
package protected;

import com.google.common.collect.ImmutableList;
import java.util.List;
import java.util.function.Consumer;
import protected.ai_0;
import protected.ha_2;
import protected.hc_1;
import protected.hi_2;
import protected.hk_1;
import protected.hl_1;
import protected.ho_1;
import protected.hq_2;
import protected.hs_2;
import protected.jb_2;
import protected.jo_2;
import protected.jr_2;
import protected.ju_2;
import protected.jx_1;
import protected.jz_1;
import protected.oe_1;
import protected.or_1;
import protected.ot_1;
import protected.ot_2;
import protected.rYl;
import protected.rdy_2;
import protected.rgP;
import protected.rgn;
import protected.rle_0;
import protected.rqm_0;
import protected.rqo_0;
import protected.rrer_0;
import protected.rvl_0;
import protected.ryg_0;
import protected.xf_1;
import protected.xf_2;
import protected.xk_1;
import protected.xk_2;
import protected.xm_1;
import protected.xn_2;
import protected.xu_0;
import protected.xx_1;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.UQ
 */
public class uq_0
implements Consumer<Consumer<ot_1>> {
    private static final List<rqm_0<ryg_0>> class = ImmutableList.of(rYl.throw, rYl.private, rYl.catch, rYl.byte, rYl.super, rYl.float, rYl.char, rYl.short, rYl.throws, rYl.while, rYl.volatile, rYl.this, (Object[])new rqm_0[]{rYl.final, rYl.default, rYl.static, rYl.break, rYl.native, rYl.long, rYl.try, rYl.return, rYl.public, rYl.int, rYl.protected, rYl.continue, rYl.synchronized, rYl.new, rYl.import, rYl.abstract, rYl.const, rYl.interface, rYl.case, rYl.instanceof, rYl.package, rYl.void, rYl.double, rYl.switch, rYl.r, rYl.B, rYl.S, rYl.s, rYl.A, rYl.n});
    private static final ai_0<?>[] break = new ai_0[]{ai_0.case, ai_0.implements, ai_0.volatile, ai_0.new, ai_0.continue, ai_0.this, ai_0.else, ai_0.synchronized, ai_0.return, ai_0.interface, ai_0.abstract, ai_0.long, ai_0.void, ai_0.double, ai_0.J, ai_0.d, ai_0.k, ai_0.W, ai_0.u, ai_0.v, ai_0.L, ai_0.A, ai_0.C, ai_0.q, ai_0.t, ai_0.K, ai_0.U, ai_0.a, ai_0.rr, ai_0.i, ai_0.rS, ai_0.rG, ai_0.rs, ai_0.rb};

    protected static ot_2 class(ot_2 ot_22, List<rqm_0<ryg_0>> list) {
        for (rqm_0<ryg_0> rqm_02 : list) {
            ot_22.class(rqm_02.class().toString(), xk_1.class(xn_2.class(rqm_02)));
        }
        return ot_22;
    }

    public void class(Consumer<ot_1> consumer) {
        ot_1 ot_12 = ot_2.class().class(rdy_2.dM, (rgP)new rgn("advancements.adventure.root.title"), (rgP)new rgn("advancements.adventure.root.description"), new rqo_0("textures/gui/advancements/backgrounds/adventure.png"), oe_1.TASK, false, false, false).class(hs_2.break).class("killed_something", xk_2.break()).class("killed_by_something", xk_2.protected()).class(consumer, "adventure/root");
        ot_1 ot_13 = ot_2.class().class(ot_12).class(xu_0.R, (rgP)new rgn("advancements.adventure.sleep_in_bed.title"), (rgP)new rgn("advancements.adventure.sleep_in_bed.description"), (rqo_0)null, oe_1.TASK, true, true, false).class("slept_in_bed", xk_1.break()).class(consumer, "adventure/sleep_in_bed");
        uq_0.class(ot_2.class(), uq_0.class).class(ot_13).class(rdy_2.hN, (rgP)new rgn("advancements.adventure.adventuring_time.title"), (rgP)new rgn("advancements.adventure.adventuring_time.description"), (rqo_0)null, oe_1.CHALLENGE, true, true, false).class(or_1.class(500)).class(consumer, "adventure/adventuring_time");
        ot_1 ot_14 = ot_2.class().class(ot_12).class(rdy_2.dP, (rgP)new rgn("advancements.adventure.trade.title"), (rgP)new rgn("advancements.adventure.trade.description"), (rqo_0)null, oe_1.TASK, true, true, false).class("traded", jz_1.break()).class(consumer, "adventure/trade");
        ot_1 ot_15 = this.class(ot_2.class()).class(ot_12).class(rdy_2.Oy, (rgP)new rgn("advancements.adventure.kill_a_mob.title"), (rgP)new rgn("advancements.adventure.kill_a_mob.description"), (rqo_0)null, oe_1.TASK, true, true, false).class(hs_2.break).class(consumer, "adventure/kill_a_mob");
        this.class(ot_2.class()).class(ot_15).class(rdy_2.Ow, (rgP)new rgn("advancements.adventure.kill_all_mobs.title"), (rgP)new rgn("advancements.adventure.kill_all_mobs.description"), (rqo_0)null, oe_1.CHALLENGE, true, true, false).class(or_1.class(100)).class(consumer, "adventure/kill_all_mobs");
        ot_1 ot_16 = ot_2.class().class(ot_15).class(rdy_2.OM, (rgP)new rgn("advancements.adventure.shoot_arrow.title"), (rgP)new rgn("advancements.adventure.shoot_arrow.description"), (rqo_0)null, oe_1.TASK, true, true, false).class("shot_arrow", xf_1.class(ha_2.class().class(hc_1.class().class(true).class(hk_1.class().class(rle_0.throws))))).class(consumer, "adventure/shoot_arrow");
        ot_1 ot_17 = ot_2.class().class(ot_15).class(rdy_2.kY, (rgP)new rgn("advancements.adventure.throw_trident.title"), (rgP)new rgn("advancements.adventure.throw_trident.description"), (rqo_0)null, oe_1.TASK, true, true, false).class("shot_trident", xf_1.class(ha_2.class().class(hc_1.class().class(true).class(hk_1.class().class(ai_0.g))))).class(consumer, "adventure/throw_trident");
        ot_2.class().class(ot_17).class(rdy_2.kY, (rgP)new rgn("advancements.adventure.very_very_frightening.title"), (rgP)new rgn("advancements.adventure.very_very_frightening.description"), (rqo_0)null, oe_1.TASK, true, true, false).class("struck_villager", hq_2.class(hk_1.class().class(ai_0.D).break())).class(consumer, "adventure/very_very_frightening");
        ot_2.class().class(ot_14).class(xu_0.Br, (rgP)new rgn("advancements.adventure.summon_iron_golem.title"), (rgP)new rgn("advancements.adventure.summon_iron_golem.description"), (rqo_0)null, oe_1.GOAL, true, true, false).class("summoned_golem", jo_2.class(hk_1.class().class(ai_0.import))).class(consumer, "adventure/summon_iron_golem");
        ot_2.class().class(ot_16).class(rdy_2.OO, (rgP)new rgn("advancements.adventure.sniper_duel.title"), (rgP)new rgn("advancements.adventure.sniper_duel.description"), (rqo_0)null, oe_1.CHALLENGE, true, true, false).class(or_1.class(50)).class("killed_skeleton", xk_2.class(hk_1.class().class(ai_0.A).class(hl_1.class(xm_1.class(50.0f))), hc_1.class().class(true))).class(consumer, "adventure/sniper_duel");
        ot_2.class().class(ot_15).class(rdy_2.kL, (rgP)new rgn("advancements.adventure.totem_of_undying.title"), (rgP)new rgn("advancements.adventure.totem_of_undying.description"), (rqo_0)null, oe_1.GOAL, true, true, false).class("used_totem", ju_2.class(rdy_2.kL)).class(consumer, "adventure/totem_of_undying");
        ot_1 ot_18 = ot_2.class().class(ot_12).class(rdy_2.kU, (rgP)new rgn("advancements.adventure.ol_betsy.title"), (rgP)new rgn("advancements.adventure.ol_betsy.description"), (rqo_0)null, oe_1.TASK, true, true, false).class("shot_crossbow", jr_2.class(rdy_2.kU)).class(consumer, "adventure/ol_betsy");
        ot_2.class().class(ot_18).class(rdy_2.kU, (rgP)new rgn("advancements.adventure.whos_the_pillager_now.title"), (rgP)new rgn("advancements.adventure.whos_the_pillager_now.description"), (rqo_0)null, oe_1.TASK, true, true, false).class("kill_pillager", xx_1.class(hk_1.class().class(ai_0.W))).class(consumer, "adventure/whos_the_pillager_now");
        ot_2.class().class(ot_18).class(rdy_2.kU, (rgP)new rgn("advancements.adventure.two_birds_one_arrow.title"), (rgP)new rgn("advancements.adventure.two_birds_one_arrow.description"), (rqo_0)null, oe_1.CHALLENGE, true, true, false).class(or_1.class(65)).class("two_birds", xx_1.class(hk_1.class().class(ai_0.J), hk_1.class().class(ai_0.J))).class(consumer, "adventure/two_birds_one_arrow");
        ot_2.class().class(ot_18).class(rdy_2.kU, (rgP)new rgn("advancements.adventure.arbalistic.title"), (rgP)new rgn("advancements.adventure.arbalistic.description"), (rqo_0)null, oe_1.CHALLENGE, true, true, true).class(or_1.class(85)).class("arbalistic", xx_1.class(xf_2.class(5))).class(consumer, "adventure/arbalistic");
        ot_1 ot_19 = ot_2.class().class(ot_12).class(rrer_0.new(), (rgP)new rgn("advancements.adventure.voluntary_exile.title"), (rgP)new rgn("advancements.adventure.voluntary_exile.description"), (rqo_0)null, oe_1.TASK, true, true, true).class("voluntary_exile", xk_2.class(hk_1.class().class(rle_0.byte).class(hi_2.break))).class(consumer, "adventure/voluntary_exile");
        ot_2.class().class(ot_19).class(rrer_0.new(), (rgP)new rgn("advancements.adventure.hero_of_the_village.title"), (rgP)new rgn("advancements.adventure.hero_of_the_village.description"), (rqo_0)null, oe_1.CHALLENGE, true, true, true).class(or_1.class(100)).class("hero_of_the_village", xk_1.protected()).class(consumer, "adventure/hero_of_the_village");
        ot_2.class().class(ot_12).class(xu_0.Jh.case(), (rgP)new rgn("advancements.adventure.honey_block_slide.title"), (rgP)new rgn("advancements.adventure.honey_block_slide.description"), (rqo_0)null, oe_1.TASK, true, true, false).class("honey_block_slide", jb_2.class(xu_0.Jh)).class(consumer, "adventure/honey_block_slide");
        ot_2.class().class(ot_16).class(xu_0.Jb.case(), (rgP)new rgn("advancements.adventure.bullseye.title"), (rgP)new rgn("advancements.adventure.bullseye.description"), (rqo_0)null, oe_1.CHALLENGE, true, true, false).class(or_1.class(50)).class("bullseye", jx_1.class(xf_2.class(15), ho_1.class(hk_1.class().class(hl_1.class(xm_1.class(30.0f))).break()))).class(consumer, "adventure/bullseye");
    }

    private ot_2 class(ot_2 ot_22) {
        for (ai_0<?> ai_02 : break) {
            ot_22.class(rvl_0.transient.break(ai_02).toString(), xk_2.class(hk_1.class().class(ai_02)));
        }
        return ot_22;
    }

    @Override
    public /* synthetic */ void accept(Object object) {
        this.class((Consumer)object);
    }
}

