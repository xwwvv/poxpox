/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Maps
 */
package protected;

import com.google.common.collect.Maps;
import java.util.Map;
import protected.jl_2;
import protected.jq_1;
import protected.rCL;
import protected.rCZ;
import protected.rCm;
import protected.rRR;
import protected.rRg;
import protected.rRq;
import protected.rct_0;
import protected.rfH;
import protected.rfU;
import protected.rjC;
import protected.rjm;
import protected.rpa;
import protected.rpr_0;
import protected.rqd_0;
import protected.rxl_0;
import protected.rxx;
import protected.xc_0;
import protected.xd_0;
import protected.xu_0;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 * Renamed from protected.xS
 */
public class xs_0
extends jl_2 {
    public static final rCm volatile = rct_0.T;
    private static final Map<rxl_0, xd_0> final = Maps.newHashMap();
    private static final rjC package = xd_0.class(4.0, 0.0, 4.0, 12.0, 16.0, 12.0);

    public xs_0(rxl_0 rxl_02, jq_1 jq_12) {
        super(rxl_02, jq_12);
        this.extends((xc_0)((xc_0)this.abstract.break()).class(volatile, 0));
        final.put(rxl_02, this);
    }

    @Override
    public xc_0 class(xc_0 xc_02, rpa rpa2) {
        return (xc_0)xc_02.class(volatile, rpa2.class(xc_02.byte(volatile), 16));
    }

    @Override
    protected void class(rCL<xd_0, xc_0> rCL2) {
        rCL2.class(new rCZ[]{volatile});
    }

    public static xd_0 class(rxl_0 rxl_02) {
        return final.getOrDefault(rxl_02, xu_0.GG);
    }

    @Override
    public xc_0 class(xc_0 xc_02, rqd_0 rqd_02) {
        return (xc_0)xc_02.class(volatile, rqd_02.class(xc_02.byte(volatile), 16));
    }

    @Override
    public rjC class(xc_0 xc_02, rRq rRq2, rfH rfH2, rjm rjm2) {
        return package;
    }

    @Override
    public xc_0 class(rxx rxx2) {
        return (xc_0)this.continue().class(volatile, rfU.byte((double)((180.0f + rxx2.private()) * 16.0f / 360.0f) + 0.5) & 0xF);
    }

    @Override
    public xc_0 class(xc_0 xc_02, rpr_0 rpr_02, xc_0 xc_03, rRg rRg2, rfH rfH2, rfH rfH3) {
        return rpr_02 == rpr_0.DOWN && !xc_02.class(rRg2, rfH2) ? xu_0.class.continue() : super.class(xc_02, rpr_02, xc_03, rRg2, rfH2, rfH3);
    }

    @Override
    public boolean class(xc_0 xc_02, rRR rRR2, rfH rfH2) {
        return rRR2.byte(rfH2.break()).byte().break();
    }
}

